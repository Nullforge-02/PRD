'use client'

import * as React from 'react'
import { motion, useReducedMotion } from 'framer-motion'
import { cn } from '@/lib/utils'

export function PageTransition({
  children,
  className,
  viewKey,
}: {
  children: React.ReactNode
  className?: string
  viewKey: string
}) {
  const reduced = useReducedMotion()
  return (
    <motion.div
      key={viewKey}
      initial={
        reduced ? false : { opacity: 0, y: 12, filter: 'blur(4px)' }
      }
      animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
      exit={reduced ? undefined : { opacity: 0, y: -8, filter: 'blur(4px)' }}
      transition={{
        duration: 0.38,
        ease: [0.16, 1, 0.3, 1],
        // Slight stagger on nested elements for a premium cascading feel
        staggerChildren: 0.04,
      }}
      className={cn('flex min-h-0 flex-1 flex-col', className)}
    >
      <motion.div
        initial={reduced ? false : { opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.06, duration: 0.3 }}
        className="flex min-h-0 flex-1 flex-col"
      >
        {children}
      </motion.div>
    </motion.div>
  )
}
