'use client'

import * as React from 'react'
import { cn } from '@/lib/utils'

// ============================================================
// Loading skeletons — premium placeholder UI for all views.
// Uses .alpha-shimmer for the animated gradient sweep.
// ============================================================

export function Skeleton({
  className,
  style,
}: {
  className?: string
  style?: React.CSSProperties
}) {
  return (
    <div
      style={style}
      className={cn(
        'alpha-shimmer rounded-md bg-muted/40',
        className,
      )}
    />
  )
}

// Chat conversation list skeleton
export function ChatListSkeleton() {
  return (
    <div className="flex flex-col gap-1 p-2">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="flex items-center gap-2 rounded-lg p-2">
          <Skeleton className="size-7 rounded-full" />
          <div className="flex-1 space-y-1.5">
            <Skeleton className="h-2.5 w-3/4" />
            <Skeleton className="h-2 w-1/2" />
          </div>
        </div>
      ))}
    </div>
  )
}

// Chat message thread skeleton
export function ChatThreadSkeleton() {
  return (
    <div className="flex flex-col gap-4 p-4 sm:p-6">
      {Array.from({ length: 4 }).map((_, i) => (
        <div
          key={i}
          className={cn(
            'flex gap-3',
            i % 2 === 0 ? 'flex-row' : 'flex-row-reverse',
          )}
        >
          <Skeleton className="size-8 rounded-full shrink-0" />
          <div className="max-w-[70%] space-y-2">
            <Skeleton className="h-3 w-full" />
            <Skeleton className="h-3 w-5/6" />
            <Skeleton className="h-3 w-2/3" />
          </div>
        </div>
      ))}
    </div>
  )
}

// Notes list skeleton
export function NotesListSkeleton() {
  return (
    <div className="flex flex-col gap-1 p-2">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="rounded-lg p-2 space-y-1.5">
          <Skeleton className="h-3 w-4/5" />
          <Skeleton className="h-2 w-3/5" />
        </div>
      ))}
    </div>
  )
}

// Memory cards skeleton
export function MemoryCardsSkeleton() {
  return (
    <div className="grid gap-2">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="rounded-lg border border-border/60 p-3 space-y-2">
          <Skeleton className="h-3 w-full" />
          <Skeleton className="h-2 w-2/3" />
          <div className="flex gap-2">
            <Skeleton className="h-5 w-16 rounded-full" />
            <Skeleton className="h-5 w-12 rounded-full" />
          </div>
        </div>
      ))}
    </div>
  )
}

// Files grid skeleton
export function FilesGridSkeleton() {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="rounded-lg border border-border/60 p-2 space-y-2">
          <Skeleton className="aspect-square w-full rounded-md" />
          <Skeleton className="h-2 w-3/4" />
          <Skeleton className="h-2 w-1/2" />
        </div>
      ))}
    </div>
  )
}

// Files list (table rows) skeleton
export function FilesListSkeleton() {
  return (
    <div className="flex flex-col gap-2">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="flex items-center gap-3 rounded-lg border border-border/60 p-3">
          <Skeleton className="size-8 rounded-md" />
          <div className="flex-1 space-y-1.5">
            <Skeleton className="h-3 w-1/2" />
            <Skeleton className="h-2 w-1/4" />
          </div>
          <Skeleton className="h-5 w-16 rounded-full" />
        </div>
      ))}
    </div>
  )
}

// Media gallery skeleton
export function MediaGallerySkeleton() {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="aspect-square overflow-hidden rounded-lg border border-border/60">
          <Skeleton className="size-full" />
        </div>
      ))}
    </div>
  )
}

// Generic card skeleton
export function CardSkeleton({ lines = 3 }: { lines?: number }) {
  return (
    <div className="rounded-xl border border-border/60 p-4 space-y-2">
      {Array.from({ length: lines }).map((_, i) => (
        <Skeleton key={i} className="h-3 w-full" style={{ maxWidth: `${80 - i * 15}%` }} />
      ))}
    </div>
  )
}

// Compact list skeleton (recent cards on Home, etc.)
export function RecentListSkeleton({ rows = 3 }: { rows?: number }) {
  return (
    <div className="flex flex-col gap-2">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex items-center gap-2 rounded-lg p-2">
          <Skeleton className="size-7 rounded-full" />
          <div className="flex-1 space-y-1.5">
            <Skeleton className="h-2.5 w-3/4" />
            <Skeleton className="h-2 w-1/3" />
          </div>
        </div>
      ))}
    </div>
  )
}
