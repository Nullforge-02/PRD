'use client'

import * as React from 'react'
import { cn } from '@/lib/utils'

interface EmptyStateProps {
  icon?: React.ElementType
  title: string
  description?: string
  action?: React.ReactNode
  className?: string
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
  className,
}: EmptyStateProps) {
  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center gap-3 rounded-lg border border-dashed border-border/60 bg-transparent p-10 text-center',
        className,
      )}
    >
      {Icon && (
        <div
          className="flex size-10 items-center justify-center rounded-full text-muted-foreground ring-1 ring-border/70"
          aria-hidden
        >
          <Icon className="size-[18px]" />
        </div>
      )}
      <div>
        <p className="text-sm font-medium text-foreground/90">{title}</p>
        {description && (
          <p className="mt-1 max-w-sm text-xs text-muted-foreground">
            {description}
          </p>
        )}
      </div>
      {action && <div className="mt-1">{action}</div>}
    </div>
  )
}
