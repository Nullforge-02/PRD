'use client'

import * as React from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import { Bell, CalendarClock, Check, Plus } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { api, ApiError, type CalendarEvent, type Reminder } from '@/lib/api'

// ============================================================
// Today panel — real reminders + calendar events for today.
// Fully self-contained (used by the Home view).
// ============================================================

const DAY_MS = 24 * 60 * 60 * 1000

function startOfToday(): Date {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  return d
}

function dueLabel(dueAt: number | null): string | null {
  if (dueAt === null) return null
  const now = new Date()
  const today = startOfToday()
  const due = new Date(dueAt)
  const time = due.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  if (due < today) return 'Overdue'
  if (dueAt < today.getTime() + DAY_MS) return `Today ${time}`
  if (dueAt < today.getTime() + 2 * DAY_MS) return `Tomorrow ${time}`
  return due.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
}

function dayLabel(ts: number): string {
  const today = startOfToday()
  const d = new Date(ts)
  if (ts < today.getTime() + DAY_MS) return 'Today'
  if (ts < today.getTime() + 2 * DAY_MS) return 'Tomorrow'
  return d.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })
}

export function TodayPanel({ className }: { className?: string }) {
  const queryClient = useQueryClient()
  const [quickTitle, setQuickTitle] = React.useState('')
  const [adding, setAdding] = React.useState(false)

  const today = startOfToday()
  const weekEnd = new Date(today.getTime() + 7 * DAY_MS)

  const remindersQuery = useQuery({
    queryKey: ['reminders'],
    queryFn: () => api.get<{ reminders: Reminder[] }>('/api/v1/reminders?done=0'),
  })
  const eventsQuery = useQuery({
    queryKey: ['calendar'],
    queryFn: () =>
      api.get<{ events: CalendarEvent[] }>(
        `/api/v1/calendar?from=${today.getTime()}&to=${weekEnd.getTime()}`,
      ),
  })

  const reminders = React.useMemo(() => {
    const list = remindersQuery.data?.reminders ?? []
    return [...list]
      .sort((a, b) => (a.dueAt ?? Number.MAX_SAFE_INTEGER) - (b.dueAt ?? Number.MAX_SAFE_INTEGER))
      .slice(0, 6)
  }, [remindersQuery.data])

  const events = React.useMemo(() => {
    const list = eventsQuery.data?.events ?? []
    return [...list].sort((a, b) => a.startAt - b.startAt).slice(0, 5)
  }, [eventsQuery.data])

  async function toggleDone(reminder: Reminder) {
    // Optimistic flip, then persist.
    await queryClient.cancelQueries({ queryKey: ['reminders'] })
    const prev = queryClient.getQueryData<{ reminders: Reminder[] }>(['reminders'])
    if (prev) {
      queryClient.setQueryData(['reminders'], {
        reminders: prev.reminders.map((r) =>
          r.id === reminder.id ? { ...r, done: !r.done } : r,
        ),
      })
    }
    try {
      await api.patch(`/api/v1/reminders/${reminder.id}`, { done: !reminder.done })
    } catch {
      if (prev) queryClient.setQueryData(['reminders'], prev)
      toast.error('Could not update reminder')
    } finally {
      void queryClient.invalidateQueries({ queryKey: ['reminders'] })
    }
  }

  async function quickAdd(e: React.FormEvent) {
    e.preventDefault()
    const title = quickTitle.trim()
    if (!title) return
    setAdding(true)
    try {
      await api.post('/api/v1/reminders', { title })
      setQuickTitle('')
      await queryClient.invalidateQueries({ queryKey: ['reminders'] })
      toast.success('Reminder added')
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : 'Could not add reminder')
    } finally {
      setAdding(false)
    }
  }

  const loading = remindersQuery.isLoading || eventsQuery.isLoading

  return (
    <motion.section
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className={className}
      aria-label="Today"
    >
      <Card className="alpha-panel alpha-panel-hover border-0">
        <div className="flex items-center justify-between gap-2 border-b border-border/60 px-4 py-3 sm:px-5">
          <div className="flex items-center gap-2">
            <CalendarClock className="size-4 text-accent" aria-hidden />
            <h2 className="text-sm font-semibold">Today</h2>
          </div>
          <p className="text-xs text-muted-foreground">
            {today.toLocaleDateString([], {
              weekday: 'long',
              month: 'long',
              day: 'numeric',
            })}
          </p>
        </div>
        <CardContent className="grid gap-5 p-4 sm:grid-cols-2 sm:p-5">
          {/* Reminders column */}
          <div className="min-w-0">
            <div className="mb-2 flex items-center gap-1.5">
              <Bell className="size-3.5 text-accent" aria-hidden />
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Reminders
              </p>
            </div>
            {loading ? (
              <div className="space-y-2" aria-hidden>
                <div className="h-8 animate-pulse rounded-lg bg-muted/50" />
                <div className="h-8 animate-pulse rounded-lg bg-muted/50" />
              </div>
            ) : reminders.length === 0 ? (
              <p className="rounded-lg border border-dashed border-border/60 px-3 py-4 text-center text-xs text-muted-foreground">
                No reminders
              </p>
            ) : (
              <ul className="max-h-56 space-y-1 overflow-y-auto alpha-scroll pr-0.5">
                {reminders.map((r) => {
                  const label = dueLabel(r.dueAt)
                  const overdue = label === 'Overdue'
                  return (
                    <li
                      key={r.id}
                      className="group flex items-start gap-2 rounded-lg p-1.5 transition-colors hover:bg-accent/5"
                    >
                      <button
                        type="button"
                        onClick={() => void toggleDone(r)}
                        className={cn(
                          'mt-0.5 flex size-4 shrink-0 items-center justify-center rounded-full border transition-colors',
                          r.done
                            ? 'border-accent bg-accent text-accent-foreground'
                            : 'border-muted-foreground/40 hover:border-accent',
                        )}
                        aria-label={r.done ? 'Mark reminder incomplete' : 'Mark reminder complete'}
                      >
                        {r.done && <Check className="size-3" aria-hidden />}
                      </button>
                      <div className="min-w-0 flex-1">
                        <p
                          className={cn(
                            'truncate text-xs font-medium',
                            r.done && 'text-muted-foreground line-through',
                          )}
                        >
                          {r.title}
                        </p>
                        {label && (
                          <p
                            className={cn(
                              'text-[10px]',
                              overdue ? 'text-destructive' : 'text-muted-foreground',
                            )}
                          >
                            {label}
                          </p>
                        )}
                      </div>
                    </li>
                  )
                })}
              </ul>
            )}
            {/* Quick add */}
            <form onSubmit={quickAdd} className="mt-2 flex gap-1.5">
              <label className="sr-only" htmlFor="today-quick-add">
                Quick add reminder
              </label>
              <Input
                id="today-quick-add"
                value={quickTitle}
                onChange={(e) => setQuickTitle(e.target.value)}
                placeholder="Add a reminder…"
                className="h-8 text-xs"
                maxLength={300}
              />
              <Button
                type="submit"
                size="sm"
                variant="secondary"
                className="h-8 shrink-0 gap-1 px-2.5 text-xs"
                disabled={adding || !quickTitle.trim()}
                aria-label="Add reminder"
              >
                <Plus className="size-3.5" aria-hidden />
                Add
              </Button>
            </form>
          </div>

          {/* Events column */}
          <div className="min-w-0">
            <div className="mb-2 flex items-center gap-1.5">
              <CalendarClock className="size-3.5 text-accent" aria-hidden />
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Upcoming events
              </p>
            </div>
            {loading ? (
              <div className="space-y-2" aria-hidden>
                <div className="h-8 animate-pulse rounded-lg bg-muted/50" />
                <div className="h-8 animate-pulse rounded-lg bg-muted/50" />
              </div>
            ) : events.length === 0 ? (
              <p className="rounded-lg border border-dashed border-border/60 px-3 py-4 text-center text-xs text-muted-foreground">
                No events today
              </p>
            ) : (
              <ul className="max-h-64 space-y-1 overflow-y-auto alpha-scroll pr-0.5">
                {events.map((e) => (
                  <li
                    key={e.id}
                    className="flex items-center gap-2 rounded-lg p-1.5 transition-colors hover:bg-accent/5"
                  >
                    <div className="flex w-12 shrink-0 flex-col items-center rounded-md border border-border/60 bg-muted/30 py-1">
                      <span className="text-[9px] uppercase tracking-wide text-muted-foreground">
                        {dayLabel(e.startAt)}
                      </span>
                      <span className="font-mono text-[11px] font-semibold leading-tight">
                        {new Date(e.startAt).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-xs font-medium">{e.title}</p>
                      {e.location && (
                        <p className="truncate text-[10px] text-muted-foreground">{e.location}</p>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.section>
  )
}
