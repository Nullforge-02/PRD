'use client'

import * as React from 'react'
import ReactMarkdown from 'react-markdown'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism'
import { cn } from '@/lib/utils'

export function Markdown({ children, className }: { children: string; className?: string }) {
  return (
    <div className={cn('alpha-markdown', className)}>
      <ReactMarkdown
        components={{
          code(props) {
            const { children, className, node, ...rest } = props as React.ComponentProps<'code'> & {
              node?: unknown
            }
            const match = /language-(\w+)/.exec(className || '')
            const inline = !match && !String(children).includes('\n')
            void node
            if (!inline && match) {
              return (
                <SyntaxHighlighter
                  style={oneDark}
                  language={match[1]}
                  PreTag="div"
                  customStyle={{
                    margin: 0,
                    background: 'transparent',
                    fontSize: '0.85em',
                  }}
                  codeTagProps={{
                    style: { fontFamily: 'var(--font-mono)' },
                  }}
                >
                  {String(children).replace(/\n$/, '')}
                </SyntaxHighlighter>
              )
            }
            return (
              <code className={className} {...rest}>
                {children}
              </code>
            )
          },
          a(props) {
            const { href, children, ...rest } = props as React.ComponentProps<'a'>
            return (
              <a href={href} target="_blank" rel="noreferrer" {...rest}>
                {children}
              </a>
            )
          },
        }}
      >
        {children}
      </ReactMarkdown>
    </div>
  )
}
