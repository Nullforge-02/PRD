'use client'

import * as React from 'react'
import { Keyboard } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { useAlpha, SHORTCUTS } from '@/lib/store'
import { cn } from '@/lib/utils'

// Keyboard shortcuts overlay — opened via ⌘/ (or Ctrl+/).
// Shows all available shortcuts grouped by category.
export function ShortcutsOverlay() {
  const open = useAlpha((s) => s.shortcutsOpen)
  const setOpen = useAlpha((s) => s.setShortcutsOpen)

  const groups = React.useMemo(() => {
    const map: Record<string, typeof SHORTCUTS> = {}
    for (const s of SHORTCUTS) {
      if (!map[s.group]) map[s.group] = []
      map[s.group].push(s)
    }
    return map
  }, [])

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="alpha-slide-up max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base">
            <Keyboard className="size-4 text-accent" />
            Keyboard Shortcuts
          </DialogTitle>
          <DialogDescription className="text-xs">
            Press <kbd className="rounded border border-border/60 bg-muted/40 px-1 font-mono text-[10px]">⌘K</kbd> for the command palette,
            <kbd className="ml-1 rounded border border-border/60 bg-muted/40 px-1 font-mono text-[10px]">⌘/</kbd> to reopen this overlay.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 sm:grid-cols-2">
          {Object.entries(groups).map(([group, items]) => (
            <div key={group} className="space-y-1.5">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                {group}
              </p>
              {items.map((s) => (
                <div
                  key={s.keys}
                  className="flex items-center justify-between gap-2 rounded-md px-2 py-1.5 transition-colors hover:bg-accent/8"
                >
                  <span className="text-xs text-foreground">{s.description}</span>
                  <kbd
                    className={cn(
                      'shrink-0 rounded border border-border/60 bg-muted/40 px-1.5 py-0.5 font-mono text-[10px] font-medium',
                    )}
                  >
                    {s.keys}
                  </kbd>
                </div>
              ))}
            </div>
          ))}
        </div>
        <div className="flex items-center justify-between border-t border-border/60 pt-3">
          <Badge variant="outline" className="gap-1.5 bg-card/40 text-[10px]">
            <span className="alpha-status-dot alpha-status-pulse bg-accent" />
            {SHORTCUTS.length} shortcuts
          </Badge>
          <p className="text-[10px] text-muted-foreground">
            "g" sequences: press g, then the next key within 800ms
          </p>
        </div>
      </DialogContent>
    </Dialog>
  )
}
