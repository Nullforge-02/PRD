'use client'

import * as React from 'react'
import { Sidebar, SidebarProvider } from '@/components/shell/Sidebar'
import { Header } from '@/components/shell/Header'
import { Footer } from '@/components/shell/Footer'
import { CommandPalette } from '@/components/shell/CommandPalette'
import { ShortcutsOverlay } from '@/components/shell/ShortcutsOverlay'
import { useAlpha } from '@/lib/store'
import { useGlobalShortcuts } from '@/lib/use-global-shortcuts'
import { PageTransition } from '@/components/common/PageTransition'
import { toast } from 'sonner'

import { HomeView } from '@/components/views/HomeView'
import { ChatView } from '@/components/views/ChatView'
import { FilesView } from '@/components/views/FilesView'
import { NotesView } from '@/components/views/NotesView'
import { PlannerView } from '@/components/views/PlannerView'
import { GmailView } from '@/components/views/GmailView'
import { MediaView } from '@/components/views/MediaView'
import { MemoryView } from '@/components/views/MemoryView'
import { GitHubView } from '@/components/views/GitHubView'
import { ToolsView } from '@/components/views/ToolsView'
import { SystemView } from '@/components/views/SystemView'
import { SecurityView } from '@/components/views/SecurityView'
import { SettingsView } from '@/components/views/SettingsView'

const OAUTH_MESSAGES: Record<string, string> = {
  connected: 'Account connected — you can now use the integration.',
  disconnected: 'Account disconnected.',
  reauth: 'The connection needs to be reauthorized — click Reconnect.',
}

/**
 * OAuth callbacks redirect back to "/" with ?view=…&oauth=… — handle those
 * params ONCE on mount (then clean the URL) so the user lands on the right
 * view with a clear result toast.
 */
function useOAuthRedirectParams() {
  const setView = useAlpha((s) => s.setView)
  React.useEffect(() => {
    try {
      const url = new URL(window.location.href)
      const view = url.searchParams.get('view')
      const oauth = url.searchParams.get('oauth')
      if (!view && !oauth) return
      if (view === 'gmail' || view === 'github' || view === 'settings') {
        setView(view)
      }
      if (oauth) {
        if (oauth === 'connected') toast.success(OAUTH_MESSAGES.connected)
        else if (oauth === 'disconnected') toast.info(OAUTH_MESSAGES.disconnected)
        else if (oauth === 'reauth') toast.error(OAUTH_MESSAGES.reauth)
        else if (oauth.startsWith('error')) toast.error('OAuth connection failed', {
          description: oauth === 'error:denied'
            ? 'Authorization was denied.'
            : oauth === 'error:state'
              ? 'Security check failed (invalid state). Please retry the connection.'
              : oauth === 'error:session'
                ? 'Your session expired — sign in again and retry.'
                : 'The OAuth flow did not complete.',
        })
      }
      url.searchParams.delete('view')
      url.searchParams.delete('oauth')
      window.history.replaceState({}, '', url.pathname + (url.searchParams.size ? `?${url.searchParams}` : ''))
    } catch {
      // URL manipulation is best-effort — never block the shell.
    }
  }, [setView])
}

export function AlphaShell() {
  const activeView = useAlpha((s) => s.activeView)

  // Wire global keyboard shortcuts (⌘/, ⌘L, g h / g c / …)
  useGlobalShortcuts()
  // OAuth redirect result (?view=…&oauth=… — handled once, then cleaned)
  useOAuthRedirectParams()

  function renderView() {
    switch (activeView) {
      case 'home':
        return <HomeView />
      case 'chat':
        return <ChatView />
      case 'files':
        return <FilesView />
      case 'notes':
        return <NotesView />
      case 'planner':
        return <PlannerView />
      case 'gmail':
        return <GmailView />
      case 'media':
        return <MediaView />
      case 'memory':
        return <MemoryView />
      case 'github':
        return <GitHubView />
      case 'tools':
        return <ToolsView />
      case 'system':
        return <SystemView />
      case 'security':
        return <SecurityView />
      case 'settings':
        return <SettingsView />
      default:
        return <HomeView />
    }
  }

  return (
    <SidebarProvider>
      {/* Viewport-fixed OS shell: the page itself never scrolls — long views
          scroll inside <main>, so the header and footer stay pinned. */}
      <div className="flex h-dvh w-full flex-col overflow-hidden bg-background text-foreground">
        <div className="flex min-h-0 flex-1 overflow-hidden">
          <Sidebar />
          <div className="flex min-w-0 flex-1 flex-col">
            <Header />
            <main className="alpha-enter flex min-h-0 flex-1 flex-col gap-6 overflow-y-auto p-4 sm:p-6">
              <PageTransition viewKey={activeView}>{renderView()}</PageTransition>
            </main>
            <Footer />
          </div>
        </div>
        <CommandPalette />
        <ShortcutsOverlay />
      </div>
    </SidebarProvider>
  )
}
