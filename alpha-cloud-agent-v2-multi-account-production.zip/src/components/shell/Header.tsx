'use client'

import * as React from 'react'
import { useQuery } from '@tanstack/react-query'
import { Settings as SettingsIcon, Keyboard } from 'lucide-react'
import { useAlpha, type ViewKey } from '@/lib/store'
import { api, type SystemHealth } from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { MobileSidebarTrigger } from '@/components/shell/Sidebar'
import { cn } from '@/lib/utils'
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip'

const VIEW_META: Record<ViewKey, { title: string; subtitle: string }> = {
  home: {
    title: 'Home',
    subtitle: 'Welcome back — what should Alpha do for you today?',
  },
  chat: {
    title: 'Chat',
    subtitle: 'Streamed conversations with the Alpha AI assistant.',
  },
  files: {
    title: 'Files',
    subtitle: 'Uploads stored in cloud object storage.',
  },
  notes: {
    title: 'Notes',
    subtitle: 'Markdown notes that Alpha can read and create.',
  },
  planner: {
    title: 'Planner',
    subtitle: 'Reminders and calendar events — Alpha can set them from chat.',
  },
  gmail: {
    title: 'Gmail',
    subtitle: 'Inbox search across a connected Gmail account.',
  },
  media: {
    title: 'Media',
    subtitle: 'AI image generation + persistent gallery.',
  },
  memory: {
    title: 'Memory',
    subtitle: 'Persistent facts Alpha keeps about you — fully controlled.',
  },
  github: {
    title: 'GitHub Archive',
    subtitle: 'Private repo used as cold archive.',
  },
  tools: {
    title: 'Tools',
    subtitle: 'Tool registry, permissions, and a live executor.',
  },
  system: {
    title: 'System Health',
    subtitle: 'Real health checks + background jobs at a glance.',
  },
  security: {
    title: 'Security',
    subtitle: 'Lock, active sessions, and audit log.',
  },
  settings: {
    title: 'Settings',
    subtitle: 'Account, connections, AI providers, and preferences.',
  },
}

// Real system health pill: DB + R2 status from /api/v1/system/health.
function StatusPill() {
  const { data: health, isError } = useQuery({
    queryKey: ['system-health'],
    queryFn: () => api.get<SystemHealth>('/api/v1/system/health'),
    refetchInterval: 30_000,
    staleTime: 15_000,
    retry: 0,
  })

  let label = 'checking'
  let color = 'bg-muted-foreground'
  let title = 'Checking system health…'

  if (isError || (health && !health.db.ok && !health.storage.ok)) {
    label = 'sys down'
    color = 'bg-destructive'
    title = 'System unreachable'
  } else if (health) {
    const ok = health.db.ok && health.storage.ok
    label = ok ? 'sys ok' : 'degraded'
    color = ok ? 'bg-emerald-500' : 'bg-amber-500'
    title = ok
      ? `DB ${health.db.latencyMs}ms · R2 ${health.storage.latencyMs}ms`
      : health.db.ok
        ? `R2 issue: ${health.storage.error ?? 'degraded'}`
        : `DB issue: ${health.db.error ?? 'degraded'}`
  }

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Badge
          variant="outline"
          className="gap-1.5 rounded-md border-border/60 bg-card/40 px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.08em] text-muted-foreground"
        >
          <span className={cn('alpha-status-dot alpha-status-pulse', color)} />
          {label}
        </Badge>
      </TooltipTrigger>
      <TooltipContent>{title}</TooltipContent>
    </Tooltip>
  )
}

export function Header() {
  const activeView = useAlpha((s) => s.activeView)
  const setView = useAlpha((s) => s.setView)
  const setShortcutsOpen = useAlpha((s) => s.setShortcutsOpen)
  const user = useAlpha((s) => s.user)
  const meta = VIEW_META[activeView]

  return (
    <header className="alpha-header-ambient sticky top-0 z-30 border-b border-border bg-background/70 backdrop-blur-xl">
      <div className="flex items-center gap-3 px-4 py-3 sm:px-6">
        <MobileSidebarTrigger />

        <div className="min-w-0 flex-1">
          <h1 className="truncate text-base font-semibold tracking-tight sm:text-lg">
            {meta.title}
          </h1>
          <p className="hidden truncate text-xs text-muted-foreground sm:block">
            {meta.subtitle}
          </p>
        </div>

        <div className="hidden items-center gap-2 sm:flex">
          <StatusPill />
        </div>

        <div className="flex items-center gap-1">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                aria-label="Keyboard shortcuts"
                className="size-8 rounded-md"
                onClick={() => setShortcutsOpen(true)}
              >
                <Keyboard className="size-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Keyboard shortcuts (⌘/)</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                aria-label="Settings"
                className="size-8 rounded-md"
                onClick={() => setView('settings')}
              >
                <SettingsIcon className="size-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Settings</TooltipContent>
          </Tooltip>
          <button
            onClick={() => setView('settings')}
            className="alpha-lift alpha-focus-ring ml-1 rounded-full"
            aria-label="Open settings"
          >
            <Avatar className="size-8 ring-1 ring-border/70">
              <AvatarFallback className="bg-accent/10 text-xs font-semibold text-foreground">
                {user ? user.name.slice(0, 1).toUpperCase() : '·'}
              </AvatarFallback>
            </Avatar>
          </button>
        </div>
      </div>
    </header>
  )
}
