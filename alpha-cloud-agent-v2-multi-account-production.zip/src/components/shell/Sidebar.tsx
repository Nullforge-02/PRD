'use client'

import * as React from 'react'
import { useQueryClient } from '@tanstack/react-query'
import {
  Home,
  MessageSquare,
  FolderOpen,
  StickyNote,
  CalendarDays,
  Mail,
  ImageIcon,
  BrainCircuit,
  Github,
  Wrench,
  Activity,
  ShieldCheck,
  Settings,
  Menu,
  Lock,
  LogOut,
  Sun,
  Moon,
  Laptop,
  ChevronLeft,
  ChevronRight,
  Loader2,
} from 'lucide-react'
import { useTheme } from 'next-themes'
import { toast } from 'sonner'
import { api } from '@/lib/api'
import { useAlpha, type ViewKey } from '@/lib/store'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { NullForgeMark, NullForgeMonogram } from '@/components/brand/NullForgeMark'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'

interface NavItem {
  key: ViewKey
  label: string
  icon: React.ElementType
  description: string
}

const NAV: NavItem[] = [
  { key: 'home', label: 'Home', icon: Home, description: 'Greeting + quick actions' },
  { key: 'chat', label: 'Chat', icon: MessageSquare, description: 'Streamed AI assistant' },
  { key: 'files', label: 'Files', icon: FolderOpen, description: 'Uploads in cloud storage' },
  { key: 'notes', label: 'Notes', icon: StickyNote, description: 'Markdown notes' },
  { key: 'planner', label: 'Planner', icon: CalendarDays, description: 'Reminders + calendar' },
  { key: 'gmail', label: 'Gmail', icon: Mail, description: 'Inbox (needs connection)' },
  { key: 'media', label: 'Media', icon: ImageIcon, description: 'Image generation gallery' },
  { key: 'memory', label: 'Memory', icon: BrainCircuit, description: 'Persistent memory' },
  { key: 'github', label: 'GitHub', icon: Github, description: 'Archive (needs connection)' },
  { key: 'tools', label: 'Tools', icon: Wrench, description: 'Tool registry + executor' },
  { key: 'system', label: 'System', icon: Activity, description: 'Provider health' },
  { key: 'security', label: 'Security', icon: ShieldCheck, description: 'Lock, sessions, audit' },
  { key: 'settings', label: 'Settings', icon: Settings, description: 'All preferences' },
]

function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = React.useState(false)
  React.useEffect(() => setMounted(true), [])

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          aria-label="Toggle theme"
          className="size-9 rounded-md"
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
        >
          {!mounted ? <Laptop className="size-4" /> : theme === 'dark' ? (
            <Sun className="size-4" />
          ) : (
            <Moon className="size-4" />
          )}
        </Button>
      </TooltipTrigger>
      <TooltipContent side="right">Toggle theme</TooltipContent>
    </Tooltip>
  )
}

// Lock the CURRENT session server-side. AuthGate polls auth status and swaps
// the shell for the UnlockScreen as soon as the lock is reflected.
function LockButton() {
  const queryClient = useQueryClient()
  const [busy, setBusy] = React.useState(false)

  async function lock() {
    setBusy(true)
    try {
      await api.post('/api/v1/auth/lock')
      await queryClient.invalidateQueries({ queryKey: ['auth-status'] })
      toast.warning('Alpha locked — enter your password to unlock.')
    } catch {
      toast.error('Could not lock Alpha right now.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          aria-label="Lock Alpha"
          className="size-9 rounded-md text-destructive hover:text-destructive"
          disabled={busy}
          onClick={lock}
        >
          {busy ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Lock className="size-4" />
          )}
        </Button>
      </TooltipTrigger>
      <TooltipContent side="right">Lock Alpha</TooltipContent>
    </Tooltip>
  )
}

// Sign out: revokes the server-side session and clears the cookie. AuthGate
// reacts to the invalidated status query by showing the LoginScreen.
function LogOutButton() {
  const queryClient = useQueryClient()
  const [busy, setBusy] = React.useState(false)

  async function signOut() {
    setBusy(true)
    try {
      await api.post('/api/v1/auth/logout')
      await queryClient.invalidateQueries({ queryKey: ['auth-status'] })
      queryClient.clear()
      toast.success('Signed out')
    } catch {
      toast.error('Sign out failed')
    } finally {
      setBusy(false)
    }
  }

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          aria-label="Sign out"
          className="size-9 rounded-md text-muted-foreground hover:text-foreground"
          disabled={busy}
          onClick={signOut}
        >
          {busy ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <LogOut className="size-4" />
          )}
        </Button>
      </TooltipTrigger>
      <TooltipContent side="right">Sign out</TooltipContent>
    </Tooltip>
  )
}

function NavLinks({ onNavigate }: { onNavigate?: () => void }) {
  const activeView = useAlpha((s) => s.activeView)
  const setView = useAlpha((s) => s.setView)

  return (
    <nav className="flex flex-col gap-0.5 px-3" aria-label="Primary">
      {NAV.map((item) => {
        const Icon = item.icon
        const active = activeView === item.key
        return (
          <button
            key={item.key}
            onClick={() => {
              setView(item.key)
              onNavigate?.()
            }}
            aria-current={active ? 'page' : undefined}
            data-active={active ? 'true' : 'false'}
            title={item.description}
            className={cn(
              'alpha-nav-rail group flex min-h-11 items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition-all',
              active
                ? 'bg-sidebar-accent/70 text-sidebar-accent-foreground'
                : 'text-sidebar-foreground/70 hover:bg-sidebar-accent/40 hover:text-sidebar-foreground',
            )}
          >
            <Icon
              className={cn(
                'size-[18px] transition-colors',
                active
                  ? 'text-accent'
                  : 'text-sidebar-foreground/60 group-hover:text-sidebar-foreground',
              )}
            />
            <span className="flex-1 text-left">{item.label}</span>
            {active && (
              <span className="alpha-status-dot alpha-status-pulse bg-accent text-accent" />
            )}
          </button>
        )
      })}
    </nav>
  )
}

// Collapsed nav — icons only, centered, with tooltips
function CollapsedNavLinks() {
  const activeView = useAlpha((s) => s.activeView)
  const setView = useAlpha((s) => s.setView)

  return (
    <nav className="flex flex-col items-center gap-1 px-1 py-2" aria-label="Primary">
      {NAV.map((item) => {
        const Icon = item.icon
        const active = activeView === item.key
        return (
          <Tooltip key={item.key}>
            <TooltipTrigger asChild>
              <button
                onClick={() => setView(item.key)}
                aria-current={active ? 'page' : undefined}
                aria-label={item.label}
                className={cn(
                  'flex size-11 items-center justify-center rounded-md transition-all',
                  active
                    ? 'bg-sidebar-accent text-accent'
                    : 'text-sidebar-foreground/60 hover:bg-sidebar-accent/40 hover:text-sidebar-foreground',
                )}
              >
                <Icon className="size-[18px]" />
              </button>
            </TooltipTrigger>
            <TooltipContent side="right">{item.label}</TooltipContent>
          </Tooltip>
        )
      })}
    </nav>
  )
}

// Real signed-in user from the global store (set by AuthGate from the
// server-side auth status). No hardcoded identity.
function UserCard() {
  const user = useAlpha((s) => s.user)

  return (
    <div className="alpha-panel m-3 rounded-lg p-3">
      <div className="flex items-center gap-3">
        <Avatar className="size-9 rounded-md ring-1 ring-border/70">
          <AvatarFallback className="bg-accent/10 font-mono font-semibold text-foreground">
            {user ? user.name.slice(0, 1).toUpperCase() : '·'}
          </AvatarFallback>
        </Avatar>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold">{user?.name ?? 'Signed in'}</p>
          <p className="truncate text-xs text-muted-foreground">
            {user?.email ?? ''}
          </p>
        </div>
        <div className="flex items-center gap-1">
          <ThemeToggle />
          <LogOutButton />
          <LockButton />
        </div>
      </div>
    </div>
  )
}

function BrandHeader() {
  return (
    <div className="flex items-center gap-3 px-5 py-5">
      <NullForgeMark
        variant="static"
        size="sm"
        subline="ALPHA · CLOUD DIGITAL AGENT"
        align="left"
        className="py-0.5"
      />
    </div>
  )
}

export function Sidebar() {
  const sidebarOpen = useAlpha((s) => s.sidebarOpen)
  const setSidebar = useAlpha((s) => s.setSidebar)

  const sidebarCollapsed = useAlpha((s) => s.sidebarCollapsed)
  const toggleSidebarCollapsed = useAlpha((s) => s.toggleSidebarCollapsed)

  return (
    <>
      {/* Desktop sidebar */}
      <aside
        className={cn(
          'alpha-sidebar-inner alpha-sidebar-collapse hidden md:flex md:flex-col md:shrink-0 border-r border-sidebar-border bg-sidebar/80 backdrop-blur-xl overflow-hidden',
          sidebarCollapsed ? 'md:w-16' : 'md:w-64',
        )}
      >
        {sidebarCollapsed ? (
          <>
            {/* Collapsed brand — compact NF monogram */}
            <div className="flex items-center justify-center px-2 py-5">
              <NullForgeMonogram />
            </div>
            {/* Collapsed nav — icons only */}
            <ScrollArea className="flex-1 px-0">
              <CollapsedNavLinks />
            </ScrollArea>
            {/* Collapse toggle */}
            <div className="border-t border-sidebar-border p-2">
              <Button
                variant="ghost"
                size="icon"
                className="h-9 w-full"
                onClick={toggleSidebarCollapsed}
                aria-label="Expand sidebar"
              >
                <ChevronRight className="size-4" />
              </Button>
            </div>
          </>
        ) : (
          <>
            <BrandHeader />
            <ScrollArea className="flex-1 px-0">
              <NavLinks />
            </ScrollArea>
            <UserCard />
            {/* Collapse toggle */}
            <div className="border-t border-sidebar-border px-3 py-1.5">
              <Button
                variant="ghost"
                size="sm"
                className="h-8 w-full gap-1 text-[10px] text-muted-foreground"
                onClick={toggleSidebarCollapsed}
                aria-label="Collapse sidebar"
              >
                <ChevronLeft className="size-3" />
                Collapse
              </Button>
            </div>
          </>
        )}
      </aside>

      {/* Mobile sheet */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebar}>
        <SheetContent
          side="left"
          className="flex w-72 max-w-[80vw] flex-col bg-sidebar border-sidebar-border p-0"
        >
          <SheetHeader className="text-left">
            <SheetTitle className="flex items-center gap-3">
              <NullForgeMark
                variant="static"
                size="sm"
                subline="ALPHA · CLOUD DIGITAL AGENT"
                align="left"
                className="py-0.5"
              />
            </SheetTitle>
          </SheetHeader>
          <div className="alpha-scroll flex-1 overflow-y-auto pb-2">
            <NavLinks onNavigate={() => setSidebar(false)} />
          </div>
          <UserCard />
        </SheetContent>
      </Sheet>
    </>
  )
}

// Mobile menu trigger — used in the Header
export function MobileSidebarTrigger() {
  const setSidebar = useAlpha((s) => s.setSidebar)
  return (
    <Button
      variant="ghost"
      size="icon"
      className="md:hidden"
      onClick={() => setSidebar(true)}
      aria-label="Open menu"
    >
      <Menu className="size-5" />
    </Button>
  )
}

// Wrap everything in a provider at the shell level
export function SidebarProvider({
  children,
}: {
  children: React.ReactNode
}) {
  return <TooltipProvider delayDuration={200}>{children}</TooltipProvider>
}
