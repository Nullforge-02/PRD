'use client'

import * as React from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { useTheme } from 'next-themes'
import {
  CommandDialog,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandSeparator,
  CommandShortcut,
} from '@/components/ui/command'
import {
  Home,
  MessageSquare,
  Folder,
  StickyNote,
  CalendarCheck,
  Mail,
  Image as ImageIcon,
  Brain,
  Github,
  Wrench,
  Activity,
  ShieldCheck,
  Settings as SettingsIcon,
  Search,
  Sparkles,
  Lock,
  LogOut,
  SunMoon,
  Plus,
} from 'lucide-react'
import { toast } from 'sonner'
import { api } from '@/lib/api'
import type { Conversation, Note, Memory, FileRecord } from '@/lib/api'
import { useAlpha, type ViewKey } from '@/lib/store'

interface SearchResults {
  query: string
  conversations: Conversation[]
  notes: Note[]
  memories: Memory[]
  files: FileRecord[]
  total: number
}

const NAV_ITEMS: { v: ViewKey; label: string; icon: React.ElementType; hint: string; shortcut: string }[] = [
  { v: 'home', label: 'Home', icon: Home, hint: 'Dashboard & quick chat', shortcut: 'g h' },
  { v: 'chat', label: 'Chat', icon: MessageSquare, hint: 'Streamed AI conversations', shortcut: 'g c' },
  { v: 'files', label: 'Files', icon: Folder, hint: 'Cloud storage manager', shortcut: 'g f' },
  { v: 'notes', label: 'Notes', icon: StickyNote, hint: 'Markdown notepad', shortcut: 'g n' },
  { v: 'planner', label: 'Planner', icon: CalendarCheck, hint: 'Reminders + calendar', shortcut: 'g p' },
  { v: 'gmail', label: 'Gmail', icon: Mail, hint: 'Inbox (needs connection)', shortcut: 'g m' },
  { v: 'media', label: 'Media', icon: ImageIcon, hint: 'Image generation + analyze', shortcut: 'g i' },
  { v: 'memory', label: 'Memory', icon: Brain, hint: 'Persistent memory store', shortcut: 'g b' },
  { v: 'github', label: 'GitHub Archive', icon: Github, hint: 'Private archive browser', shortcut: 'g g' },
  { v: 'tools', label: 'Tools', icon: Wrench, hint: 'Tool registry + try', shortcut: 'g t' },
  { v: 'system', label: 'System Health', icon: Activity, hint: 'Real provider health', shortcut: 'g s' },
  { v: 'security', label: 'Security', icon: ShieldCheck, hint: 'Lock + sessions + audit', shortcut: 'g x' },
  { v: 'settings', label: 'Settings', icon: SettingsIcon, hint: 'Preferences', shortcut: 'g ,' },
]

export function CommandPalette() {
  const queryClient = useQueryClient()
  const { theme, setTheme } = useTheme()
  const setView = useAlpha((s) => s.setView)
  const setConversation = useAlpha((s) => s.setConversation)
  const [paletteOpen, setPaletteOpen] = React.useState(false)
  const [query, setQuery] = React.useState('')

  // ⌘K / Ctrl+K to open; Escape closes (cmdk handles Esc)
  React.useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && (e.key === 'k' || e.key === 'K')) {
        e.preventDefault()
        setPaletteOpen((v) => !v)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  // Reset on close
  React.useEffect(() => {
    if (!paletteOpen) {
      setQuery('')
    }
  }, [paletteOpen])

  // Unified search — REAL server-side search across conversations, notes,
  // memories, and files. Debounced 300ms.
  const q = query.trim()
  const [results, setResults] = React.useState<SearchResults | null>(null)
  const [searching, setSearching] = React.useState(false)
  React.useEffect(() => {
    if (!paletteOpen) return
    if (q.length < 2) {
      setResults(null)
      setSearching(false)
      return
    }
    let cancelled = false
    setSearching(true)
    const t = setTimeout(async () => {
      try {
        const data = await api.get<SearchResults>(
          `/api/v1/search?q=${encodeURIComponent(q)}`,
        )
        if (!cancelled) setResults(data)
      } catch {
        if (!cancelled) setResults(null)
      } finally {
        if (!cancelled) setSearching(false)
      }
    }, 300)
    return () => {
      cancelled = true
      clearTimeout(t)
    }
  }, [q, paletteOpen])

  function go(v: ViewKey) {
    setView(v)
    setPaletteOpen(false)
  }

  function toggleTheme() {
    setTheme(theme === 'dark' ? 'light' : 'dark')
    setPaletteOpen(false)
  }

  function startNewConversation() {
    setConversation(null)
    go('chat')
  }

  async function lockAlpha() {
    setPaletteOpen(false)
    try {
      await api.post('/api/v1/auth/lock')
      await queryClient.invalidateQueries({ queryKey: ['auth-status'] })
      toast.warning('Alpha locked — enter your password to unlock.')
    } catch {
      toast.error('Could not lock Alpha right now.')
    }
  }

  async function signOut() {
    setPaletteOpen(false)
    try {
      await api.post('/api/v1/auth/logout')
      await queryClient.invalidateQueries({ queryKey: ['auth-status'] })
      queryClient.clear()
      toast.success('Signed out')
    } catch {
      toast.error('Sign out failed')
    }
  }

  // Manually filter commands when a query is typed (cmdk filtering is off so
  // server-matched search results always render verbatim).
  const lowerQuery = q.toLowerCase()
  const matchedNav = NAV_ITEMS.filter(
    (n) =>
      !q ||
      n.label.toLowerCase().includes(lowerQuery) ||
      n.hint.toLowerCase().includes(lowerQuery),
  )

  const actions: {
    id: string
    label: string
    keywords: string
    icon: React.ElementType
    run: () => void
  }[] = [
    {
      id: 'act-new-chat',
      label: 'New conversation',
      keywords: 'new conversation chat start message',
      icon: Plus,
      run: startNewConversation,
    },
    {
      id: 'act-generate',
      label: 'Generate an image',
      keywords: 'generate image media picture draw',
      icon: Sparkles,
      run: () => go('media'),
    },
    {
      id: 'act-theme',
      label: 'Toggle theme',
      keywords: 'theme dark light toggle appearance',
      icon: SunMoon,
      run: toggleTheme,
    },
    {
      id: 'act-lock',
      label: 'Lock Alpha',
      keywords: 'lock secure security pause',
      icon: Lock,
      run: () => void lockAlpha(),
    },
    {
      id: 'act-signout',
      label: 'Sign out',
      keywords: 'sign out logout exit account',
      icon: LogOut,
      run: () => void signOut(),
    },
  ]
  const matchedActions = actions.filter(
    (a) => !q || a.keywords.includes(lowerQuery) || a.label.toLowerCase().includes(lowerQuery),
  )

  const hasResults =
    !!results &&
    (results.conversations.length > 0 ||
      results.notes.length > 0 ||
      results.memories.length > 0 ||
      results.files.length > 0)

  return (
    <CommandDialog
      open={paletteOpen}
      onOpenChange={setPaletteOpen}
      title="Alpha Command Palette"
      description="Search everything, navigate, run actions. ⌘K to toggle."
      className="alpha-command"
      shouldFilter={false}
    >
      <CommandInput
        placeholder="Type a command or search across chats, notes, memory, files…"
        value={query}
        onValueChange={setQuery}
      />
      <CommandList className="alpha-scroll">
        <CommandEmpty>
          {searching
            ? 'Searching across your data…'
            : q
              ? 'No matching commands or results.'
              : 'Type to search or pick a command.'}
        </CommandEmpty>

        {/* Real search results */}
        {q.length >= 2 && hasResults && (
          <>
            {results!.conversations.length > 0 && (
              <CommandGroup heading="Conversations">
                {results!.conversations.map((c) => (
                  <CommandItem
                    key={`c-${c.id}`}
                    onSelect={() => {
                      setConversation(c.id)
                      go('chat')
                    }}
                  >
                    <MessageSquare className="size-4 text-accent" />
                    <div className="min-w-0">
                      <p className="truncate text-sm">{c.title}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {new Date(c.updatedAt).toLocaleString()}
                      </p>
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
            )}
            {results!.notes.length > 0 && (
              <CommandGroup heading="Notes">
                {results!.notes.map((n) => (
                  <CommandItem
                    key={`n-${n.id}`}
                    onSelect={() => {
                      try {
                        sessionStorage.setItem('alpha:open-note', n.id)
                      } catch {}
                      go('notes')
                    }}
                  >
                    <StickyNote className="size-4 text-accent" />
                    <div className="min-w-0">
                      <p className="truncate text-sm">{n.title}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {n.content ? n.content.slice(0, 90) : 'Empty note'}
                      </p>
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
            )}
            {results!.memories.length > 0 && (
              <CommandGroup heading="Memory">
                {results!.memories.map((m) => (
                  <CommandItem key={`m-${m.id}`} onSelect={() => go('memory')}>
                    <Brain className="size-4 text-accent" />
                    <div className="min-w-0">
                      <p className="truncate text-sm">{m.content}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {m.category}
                      </p>
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
            )}
            {results!.files.length > 0 && (
              <CommandGroup heading="Files">
                {results!.files.map((f) => (
                  <CommandItem key={`f-${f.id}`} onSelect={() => go('files')}>
                    <Folder className="size-4 text-accent" />
                    <div className="min-w-0">
                      <p className="truncate text-sm">{f.filename}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {f.source} · {f.mimeType}
                      </p>
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
            )}
            <CommandSeparator />
          </>
        )}

        {/* Search-in-progress hint */}
        {q.length >= 2 && searching && !hasResults && (
          <p className="px-4 py-2 text-xs text-muted-foreground">
            Searching your conversations, notes, memory, and files…
          </p>
        )}

        {/* Commands */}
        {matchedNav.length > 0 && (
          <CommandGroup heading="Navigation">
            {matchedNav.map((n) => (
              <CommandItem key={`nav-${n.v}`} onSelect={() => go(n.v)}>
                <n.icon className="size-4" />
                <span>Go to {n.label}</span>
                <CommandShortcut>{n.shortcut}</CommandShortcut>
              </CommandItem>
            ))}
          </CommandGroup>
        )}
        {matchedActions.length > 0 && (
          <CommandGroup heading="Actions">
            {matchedActions.map((a) => (
              <CommandItem key={a.id} onSelect={a.run}>
                <a.icon className="size-4" />
                <span>{a.label}</span>
                {a.id === 'act-lock' && <CommandShortcut>⌘L</CommandShortcut>}
              </CommandItem>
            ))}
          </CommandGroup>
        )}
      </CommandList>
      <div className="border-t border-border/60 px-3 py-2 text-[11px] text-muted-foreground">
        <span className="inline-flex items-center gap-1">
          <Search className="size-3" />
          Unified search across your conversations, notes, memory, and files.
        </span>
      </div>
    </CommandDialog>
  )
}
