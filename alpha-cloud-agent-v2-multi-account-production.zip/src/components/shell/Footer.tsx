'use client'

import * as React from 'react'
import { useQuery } from '@tanstack/react-query'
import { Database, Cloud, Sparkles } from 'lucide-react'
import { cn } from '@/lib/utils'
import { api, type SystemHealth } from '@/lib/api'
import { NullForgeMark } from '@/components/brand/NullForgeMark'

// Quiet pinned footer: NULLFORGE brand line + REAL status readouts from the
// system health endpoint (DB, R2 storage, AI provider). Honest — if the AI
// provider isn't configured, it says so.
export function Footer() {
  const { data: health } = useQuery({
    queryKey: ['system-health'],
    queryFn: () => api.get<SystemHealth>('/api/v1/system/health'),
    refetchInterval: 30_000,
    staleTime: 15_000,
    retry: 0,
  })

  const dbOk = health?.db.ok
  const r2Ok = health?.storage.ok
  const aiConfigured = health?.ai.configured

  return (
    <footer className="mt-auto border-t border-border bg-background/70 backdrop-blur-xl">
      <div className="flex flex-col items-center gap-2 px-4 py-2.5 text-xs text-muted-foreground sm:flex-row sm:justify-between sm:px-6">
        <div className="flex items-center gap-3">
          <NullForgeMark
            variant="static"
            size="sm"
            showSubline={false}
            className="gap-0"
          />
          <span aria-hidden className="text-muted-foreground/40">·</span>
          <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            Alpha · Personal Cloud Agent
          </span>
        </div>
        <div className="flex items-center gap-3">
          <Pill
            title={health ? `Database · ${health.db.latencyMs}ms` : 'Database status'}
          >
            <Database className="size-3" />
            <span>{health ? (dbOk ? 'DB ok' : 'DB down') : 'DB…'}</span>
            <span
              className={cn(
                'alpha-status-dot',
                !health ? 'bg-muted-foreground' : dbOk ? 'bg-emerald-500' : 'bg-destructive',
              )}
            />
          </Pill>
          <Pill
            title={health ? `R2 storage · ${health.storage.latencyMs}ms` : 'Storage status'}
          >
            <Cloud className="size-3" />
            <span>{health ? (r2Ok ? 'R2 ok' : 'R2 down') : 'R2…'}</span>
            <span
              className={cn(
                'alpha-status-dot',
                !health ? 'bg-muted-foreground' : r2Ok ? 'bg-emerald-500' : 'bg-destructive',
              )}
            />
          </Pill>
          <Pill
            title={
              health
                ? aiConfigured
                  ? `AI provider: ${health.ai.provider}`
                  : 'AI provider not configured'
                : 'AI provider status'
            }
          >
            <Sparkles className="size-3" />
            <span>{health ? (aiConfigured ? 'AI ready' : 'AI not configured') : 'AI…'}</span>
            <span
              className={cn(
                'alpha-status-dot',
                !health
                  ? 'bg-muted-foreground'
                  : aiConfigured
                    ? 'bg-emerald-500'
                    : 'bg-amber-500',
              )}
            />
          </Pill>
        </div>
      </div>
    </footer>
  )
}

function Pill({
  children,
  className,
  title,
}: {
  children: React.ReactNode
  className?: string
  title?: string
}) {
  return (
    <span
      title={title}
      className={cn(
        'inline-flex items-center gap-1.5 rounded-md border border-border/60 bg-card/40 px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.08em] text-muted-foreground',
        className,
      )}
    >
      {children}
    </span>
  )
}
