'use client'

import * as React from 'react'
import { Loader2, LockKeyhole } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { toast } from 'sonner'
import { api, ApiError } from '@/lib/api'
import { AuthCard, useRefreshAuthStatus } from '@/components/auth/AuthGate'

// Sign-in screen — real password verification against the owner account.
export function LoginScreen() {
  const refreshStatus = useRefreshAuthStatus()
  const [email, setEmail] = React.useState('')
  const [password, setPassword] = React.useState('')
  const [busy, setBusy] = React.useState(false)
  const [error, setError] = React.useState<string | null>(null)
  const [rateLimited, setRateLimited] = React.useState(false)

  const valid = email.trim().length > 0 && password.length > 0

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!valid || busy) return
    setBusy(true)
    setError(null)
    setRateLimited(false)
    try {
      await api.post('/api/v1/auth/login', {
        email: email.trim().toLowerCase(),
        password,
      })
      toast.success('Welcome back')
      refreshStatus()
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err.message)
        setRateLimited(err.status === 429)
      } else {
        setError('Sign-in failed. Please try again.')
      }
    } finally {
      setBusy(false)
    }
  }

  return (
    <AuthCard
      title="Sign in to Alpha"
      description="Enter your owner account credentials to open your personal AI operating system."
      footer={
        <p className="inline-flex items-center gap-1.5">
          <LockKeyhole className="size-3" />
          Sessions are server-side, revocable, and rate-limited
        </p>
      }
    >
      <form onSubmit={submit} className="flex flex-col gap-4" noValidate>
        {error && (
          <div
            role="alert"
            className={
              rateLimited
                ? 'rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2.5 text-xs text-amber-600 dark:text-amber-400'
                : 'rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2.5 text-xs text-destructive'
            }
          >
            {rateLimited ? 'Too many attempts — ' : ''}
            {error}
          </div>
        )}
        <div className="flex flex-col gap-2">
          <Label htmlFor="login-email">Email</Label>
          <Input
            id="login-email"
            type="email"
            autoComplete="email"
            inputMode="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            required
            maxLength={200}
            disabled={busy}
            className="h-10 rounded-lg"
          />
        </div>
        <div className="flex flex-col gap-2">
          <Label htmlFor="login-password">Password</Label>
          <Input
            id="login-password"
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Your password"
            required
            disabled={busy}
            className="h-10 rounded-lg"
          />
        </div>
        <Button type="submit" className="mt-1 gap-2" disabled={!valid || busy}>
          {busy ? <Loader2 className="size-4 animate-spin" /> : null}
          {busy ? 'Signing in…' : 'Sign in'}
        </Button>
      </form>
    </AuthCard>
  )
}
