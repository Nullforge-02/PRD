'use client'

import * as React from 'react'
import { Loader2, ShieldCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { toast } from 'sonner'
import { api, ApiError } from '@/lib/api'
import { AuthCard, useRefreshAuthStatus } from '@/components/auth/AuthGate'

// First-run screen: create the owner account. Only reachable while the
// server reports setupNeeded (no users exist yet) — one account, ever.
export function SetupScreen() {
  const refreshStatus = useRefreshAuthStatus()
  const [name, setName] = React.useState('')
  const [email, setEmail] = React.useState('')
  const [password, setPassword] = React.useState('')
  const [confirm, setConfirm] = React.useState('')
  const [busy, setBusy] = React.useState(false)
  const [error, setError] = React.useState<string | null>(null)

  const valid =
    name.trim().length > 0 &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()) &&
    password.length >= 8 &&
    confirm === password

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!valid || busy) return
    setBusy(true)
    setError(null)
    try {
      await api.post('/api/v1/auth/setup', {
        name: name.trim(),
        email: email.trim().toLowerCase(),
        password,
      })
      toast.success('Welcome to Alpha', {
        description: 'Your account is ready — this is now your personal AI operating system.',
      })
      refreshStatus()
    } catch (err) {
      setError(
        err instanceof ApiError
          ? err.message
          : 'Setup failed. Please try again.',
      )
    } finally {
      setBusy(false)
    }
  }

  return (
    <AuthCard
      title="Welcome to Alpha — set up your account"
      description="This becomes your personal AI operating system. Create the owner account to get started."
      footer={
        <p className="inline-flex items-center gap-1.5">
          <ShieldCheck className="size-3" />
          One owner account · password protected · sessions are revocable
        </p>
      }
    >
      <form onSubmit={submit} className="flex flex-col gap-4" noValidate>
        {error && (
          <div
            role="alert"
            className="rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2.5 text-xs text-destructive"
          >
            {error}
          </div>
        )}
        <div className="flex flex-col gap-2">
          <Label htmlFor="setup-name">Name</Label>
          <Input
            id="setup-name"
            autoComplete="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Your name"
            required
            maxLength={80}
            disabled={busy}
            className="h-10 rounded-lg"
          />
        </div>
        <div className="flex flex-col gap-2">
          <Label htmlFor="setup-email">Email</Label>
          <Input
            id="setup-email"
            type="email"
            autoComplete="email"
            inputMode="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            required
            maxLength={200}
            disabled={busy}
            className="h-10 rounded-lg"
          />
        </div>
        <div className="flex flex-col gap-2">
          <Label htmlFor="setup-password">Password</Label>
          <Input
            id="setup-password"
            type="password"
            autoComplete="new-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="At least 8 characters"
            required
            minLength={8}
            disabled={busy}
            className="h-10 rounded-lg"
            aria-describedby="setup-password-hint"
          />
          <p id="setup-password-hint" className="text-[11px] text-muted-foreground">
            Minimum 8 characters. Stored with salted PBKDF2 — never in plain text.
          </p>
        </div>
        <div className="flex flex-col gap-2">
          <Label htmlFor="setup-confirm">Confirm password</Label>
          <Input
            id="setup-confirm"
            type="password"
            autoComplete="new-password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            placeholder="Repeat your password"
            required
            disabled={busy}
            className="h-10 rounded-lg"
            aria-invalid={confirm.length > 0 && confirm !== password}
          />
          {confirm.length > 0 && confirm !== password && (
            <p className="text-[11px] text-destructive">Passwords don't match yet.</p>
          )}
        </div>
        <Button type="submit" className="mt-1 gap-2" disabled={!valid || busy}>
          {busy ? <Loader2 className="size-4 animate-spin" /> : null}
          {busy ? 'Creating account…' : 'Create owner account'}
        </Button>
      </form>
    </AuthCard>
  )
}
