'use client'

import * as React from 'react'
import { Loader2, LockKeyhole, ShieldAlert } from 'lucide-react'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { toast } from 'sonner'
import { api, ApiError } from '@/lib/api'
import { AuthCard, useRefreshAuthStatus } from '@/components/auth/AuthGate'
import type { CurrentUser } from '@/lib/store'

// Unlock screen — the session is soft-locked server-side; the account
// password unlocks it. Shows the REAL signed-in user from auth status.
export function UnlockScreen({ user }: { user: CurrentUser | null }) {
  const refreshStatus = useRefreshAuthStatus()
  const [password, setPassword] = React.useState('')
  const [busy, setBusy] = React.useState(false)
  const [error, setError] = React.useState<string | null>(null)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!password || busy) return
    setBusy(true)
    setError(null)
    try {
      await api.post('/api/v1/auth/unlock', { password })
      toast.success('Alpha unlocked')
      refreshStatus()
    } catch (err) {
      setError(
        err instanceof ApiError ? err.message : 'Unlock failed. Please try again.',
      )
    } finally {
      setBusy(false)
    }
  }

  return (
    <AuthCard
      title="Alpha is locked"
      description="This session was locked for security. Enter your password to pick up where you left off."
      footer={
        <p className="inline-flex items-center gap-1.5">
          <LockKeyhole className="size-3" />
          Your data stays protected while locked
        </p>
      }
    >
      <div
        role="status"
        className="mb-4 flex items-center gap-3 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2.5"
      >
        <ShieldAlert className="size-4 shrink-0 text-amber-500" />
        <p className="text-xs text-amber-600 dark:text-amber-400">
          All tools and API access are disabled until you unlock.
        </p>
      </div>

      {user && (
        <div className="mb-4 flex items-center gap-3 rounded-lg border border-border/60 bg-card/40 px-3 py-2.5">
          <Avatar className="size-9 ring-1 ring-accent/40">
            <AvatarFallback className="bg-accent/15 text-sm font-semibold">
              {user.name.slice(0, 1).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <p className="truncate text-sm font-medium">{user.name}</p>
            <p className="truncate text-xs text-muted-foreground">{user.email}</p>
          </div>
        </div>
      )}

      <form onSubmit={submit} className="flex flex-col gap-4" noValidate>
        {error && (
          <div
            role="alert"
            className="rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2.5 text-xs text-destructive"
          >
            {error}
          </div>
        )}
        <div className="flex flex-col gap-2">
          <Label htmlFor="unlock-password">Password</Label>
          <Input
            id="unlock-password"
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Your password"
            required
            autoFocus
            disabled={busy}
            className="h-10 rounded-lg"
          />
        </div>
        <Button type="submit" className="mt-1 gap-2" disabled={!password || busy}>
          {busy ? <Loader2 className="size-4 animate-spin" /> : null}
          {busy ? 'Unlocking…' : 'Unlock Alpha'}
        </Button>
      </form>
    </AuthCard>
  )
}
