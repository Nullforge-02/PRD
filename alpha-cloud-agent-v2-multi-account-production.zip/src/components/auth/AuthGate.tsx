'use client'

import * as React from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { NullForgeMark } from '@/components/brand/NullForgeMark'
import { api, type AuthStatus } from '@/lib/api'
import { useAlpha } from '@/lib/store'
import { SetupScreen } from '@/components/auth/SetupScreen'
import { LoginScreen } from '@/components/auth/LoginScreen'
import { UnlockScreen } from '@/components/auth/UnlockScreen'
import { AlphaShell } from '@/components/shell/AlphaShell'

// Shared chrome for every auth screen (setup / login / unlock):
// premium gradient background, floating orbs, brand mark, centered card.
export function AuthCard({
  title,
  description,
  children,
  footer,
}: {
  title: string
  description: string
  children: React.ReactNode
  footer?: React.ReactNode
}) {
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background p-4 sm:p-6">
      {/* Ambient floating orbs */}
      <div className="alpha-orb alpha-orb-1" aria-hidden />
      <div className="alpha-orb alpha-orb-2" aria-hidden />
      <div className="alpha-orb alpha-orb-3" aria-hidden />

      <motion.div
        initial={{ opacity: 0, y: 18, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="relative flex w-full max-w-md flex-col"
      >
        {/* Real page heading for screen readers (the visual brand is the
            animated wordmark). */}
        <h1 className="sr-only">NullForge Alpha — {title}</h1>
        <div className="mb-6 flex flex-col items-center gap-4">
          <NullForgeMark variant="animated" size="md" />
        </div>

        <Card className="alpha-panel border-0">
          <CardHeader>
            <CardTitle className="text-base">{title}</CardTitle>
            <CardDescription>{description}</CardDescription>
          </CardHeader>
          <CardContent>{children}</CardContent>
        </Card>

        {footer && <div className="mt-4 text-center text-xs text-muted-foreground">{footer}</div>}
      </motion.div>
    </div>
  )
}

function Splash() {
  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center gap-4 overflow-hidden bg-background">
      <div className="alpha-orb alpha-orb-1" aria-hidden />
      <div className="alpha-orb alpha-orb-2" aria-hidden />
      {/* Wordmark reveal runs once; only the thin amber seam breathes
          afterwards (disabled under prefers-reduced-motion). */}
      <NullForgeMark variant="animated" size="md" accentPulse />
    </div>
  )
}

// The single entry point of the app: decides which surface to show based on
// the REAL auth status from the server. No local auth state, no fake user.
export function AuthGate() {
  const queryClient = useQueryClient()
  const setUser = useAlpha((s) => s.setUser)

  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ['auth-status'],
    queryFn: () => api.get<AuthStatus>('/api/v1/auth/status'),
    refetchInterval: 60_000,
    refetchOnWindowFocus: true,
    staleTime: 5_000,
    retry: 1,
  })

  // Keep the global user slice in sync with the real server-side session.
  React.useEffect(() => {
    setUser(data?.authenticated ? data.user : null)
  }, [data, setUser])

  if (isLoading && !data) {
    return <Splash />
  }

  if (isError && !data) {
    return (
      <AuthCard
        title="Can't reach Alpha"
        description="The server did not respond. Check your connection and try again."
      >
        <button
          onClick={() => void refetch()}
          className="alpha-focus-ring w-full rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
        >
          Retry
        </button>
      </AuthCard>
    )
  }

  if (!data) return <Splash />

  if (data.setupNeeded) {
    return <SetupScreen />
  }
  if (!data.authenticated) {
    return <LoginScreen />
  }
  if (data.locked) {
    return <UnlockScreen user={data.user} />
  }
  return <AlphaShell />
}

// Helper shared by the auth screens: invalidate the status query after a
// successful auth action so AuthGate re-renders the right surface instantly.
export function useRefreshAuthStatus() {
  const queryClient = useQueryClient()
  return React.useCallback(() => {
    void queryClient.invalidateQueries({ queryKey: ['auth-status'] })
  }, [queryClient])
}
