'use client'

import * as React from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import { useTheme } from 'next-themes'
import {
  Activity,
  AlertTriangle,
  Bell,
  BrainCircuit,
  Cpu,
  Github,
  KeyRound,
  Loader2,
  Lock,
  LogOut,
  Mail,
  Mic2,
  Monitor,
  Moon,
  Palette,
  Plug,
  RefreshCw,
  Save,
  ServerCog,
  ShieldAlert,
  Sun,
  Unplug,
  User,
} from 'lucide-react'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { Separator } from '@/components/ui/separator'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { useAlpha } from '@/lib/store'
import { api, ApiError, type IntegrationInfo, type SessionInfo, type Settings } from '@/lib/api'
import { AiProvidersPanel } from '@/components/views/settings/AiProvidersPanel'

// ============================================================
// Settings — real persisted preferences (PATCH /api/v1/settings).
// Accent is locked to Alpha amber in this release.
// ============================================================

const SETTING_KEYS = [
  'chat_model',
  'voice',
  'voice_speed',
  'memory_enabled',
  'memory_auto_learn',
  'notifications',
  'density',
  'accent',
] as const

const SECTIONS = [
  { key: 'account', label: 'Account', icon: User },
  { key: 'ai', label: 'AI', icon: Cpu },
  { key: 'providers', label: 'AI Providers', icon: ServerCog },
  { key: 'voice', label: 'Voice', icon: Mic2 },
  { key: 'memory', label: 'Memory', icon: BrainCircuit },
  { key: 'notifications', label: 'Notifications', icon: Bell },
  { key: 'appearance', label: 'Appearance', icon: Palette },
  { key: 'integrations', label: 'Integrations', icon: Plug },
  { key: 'danger', label: 'Danger zone', icon: ShieldAlert },
] as const

type SectionKey = (typeof SECTIONS)[number]['key']

function unique(values: Array<string>): string[] {
  return Array.from(new Set(values))
}

// ============================================================
// Integrations — one settings card per real OAuth connection.
// Same honest states as the Gmail / GitHub views (configured /
// connected / needs_reauthorization), with small state-aware
// controls. Nothing here is ever simulated.
// ============================================================
function IntegrationSettingsCard({ integration }: { integration: IntegrationInfo }) {
  const queryClient = useQueryClient()
  const [disconnectOpen, setDisconnectOpen] = React.useState(false)
  const [disconnecting, setDisconnecting] = React.useState(false)

  const isGmail = integration.id === 'gmail'
  const Icon = isGmail ? Mail : Github
  const connectHref = isGmail
    ? '/api/v1/integrations/google/connect'
    : '/api/v1/integrations/github/connect'
  const disconnectHref = isGmail
    ? '/api/v1/integrations/google'
    : '/api/v1/integrations/github'
  const label = isGmail ? 'Gmail' : 'GitHub'

  const notConfigured = !integration.configured
  const needsReauth = integration.status === 'needs_reauthorization'
  const connected = integration.connected && !needsReauth
  const accountCount = integration.accounts.length
  const multiAccount = accountCount > 1

  async function disconnect() {
    setDisconnecting(true)
    try {
      await api.delete<{ ok: boolean }>(disconnectHref)
      toast.success(`${label} disconnected`)
      await queryClient.invalidateQueries({ queryKey: ['integrations'] })
    } catch (e) {
      toast.error(e instanceof ApiError ? e.message : `Could not disconnect ${label}`)
    } finally {
      setDisconnecting(false)
      setDisconnectOpen(false)
    }
  }

  const statusBadge = connected ? (
    <Badge className="gap-1.5 border-emerald-500/30 bg-emerald-500/10 text-[10px] text-emerald-600 dark:text-emerald-400">
      <span className="alpha-status-dot bg-emerald-500 text-emerald-500" aria-hidden />
      Connected
    </Badge>
  ) : needsReauth ? (
    <Badge className="gap-1.5 border-accent/40 bg-accent/10 text-[10px] text-accent">
      <AlertTriangle className="size-2.5" aria-hidden />
      Needs reauthorization
    </Badge>
  ) : notConfigured ? (
    <Badge variant="outline" className="text-[10px] text-muted-foreground">
      Not configured
    </Badge>
  ) : (
    <Badge variant="outline" className="text-[10px] text-muted-foreground">
      Not connected
    </Badge>
  )

  return (
    <Card className="alpha-panel border-0">
      <CardHeader className="border-b border-border/60 py-3">
        <CardTitle className="flex flex-wrap items-center gap-2 text-sm">
          <span className="flex size-7 shrink-0 items-center justify-center rounded-lg bg-accent/10 text-accent">
            <Icon className="size-4" aria-hidden />
          </span>
          {integration.name}
          {statusBadge}
        </CardTitle>
        <CardDescription className="text-xs">
          {connected
            ? accountCount > 1
              ? `${accountCount} ${label} accounts connected — the default is used unless you pick another.`
              : `Real OAuth connection active${integration.accountName ? ` — ${integration.accountName}` : ''}.`
            : needsReauth
              ? 'The OAuth grant expired or was revoked — reconnect to restore access.'
              : notConfigured
                ? 'OAuth client credentials are missing on the server.'
                : `Connect ${label} with a real OAuth grant — never simulated.`}
        </CardDescription>
      </CardHeader>
      <CardContent className="p-4 sm:p-6">
        {connected && multiAccount ? (
          <div className="flex flex-col gap-4">
            <ul className="space-y-1.5">
              {integration.accounts.map((acct) => (
                <li
                  key={acct.id}
                  className="flex min-w-0 items-center justify-between gap-3 rounded-lg border border-border/60 bg-muted/20 px-3 py-2"
                >
                  <span className="flex min-w-0 items-center gap-2">
                    <span
                      className={`alpha-status-dot ${acct.status === 'connected' ? 'bg-emerald-500 text-emerald-500' : 'bg-amber-500 text-amber-500'}`}
                      aria-hidden
                    />
                    <span className="truncate font-mono text-[11px] text-foreground/90">
                      {acct.accountName ?? acct.id}
                    </span>
                  </span>
                  {acct.isDefault ? (
                    <Badge variant="outline" className="shrink-0 border-accent/40 text-[10px] text-accent">
                      Default
                    </Badge>
                  ) : null}
                </li>
              ))}
            </ul>
            <p className="text-xs text-muted-foreground">
              Manage accounts (use / roles / per-account disconnect) in the {label} view.
            </p>
            <div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setDisconnectOpen(true)}
                disabled={disconnecting}
                className="gap-2"
              >
                {disconnecting ? (
                  <Loader2 className="size-3.5 animate-spin" aria-hidden />
                ) : (
                  <Unplug className="size-3.5" aria-hidden />
                )}
                Disconnect all ({accountCount})
              </Button>
            </div>
          </div>
        ) : connected ? (
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex min-w-0 items-center gap-3">
              <Avatar className="size-9 border border-border/60">
                {integration.avatarUrl ? (
                  <AvatarImage
                    src={integration.avatarUrl}
                    alt={integration.accountName ?? `${label} account avatar`}
                  />
                ) : null}
                <AvatarFallback className="bg-accent/15 text-accent">
                  <Icon className="size-4" aria-hidden />
                </AvatarFallback>
              </Avatar>
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">
                  {integration.accountName ?? `Connected ${label} account`}
                </p>
                <p className="text-xs text-muted-foreground">
                  Tokens are revoked if you disconnect.
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setDisconnectOpen(true)}
              disabled={disconnecting}
              className="gap-2"
            >
              {disconnecting ? (
                <Loader2 className="size-3.5 animate-spin" aria-hidden />
              ) : (
                <Unplug className="size-3.5" aria-hidden />
              )}
              Disconnect
            </Button>
          </div>
        ) : needsReauth ? (
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="max-w-sm text-xs leading-relaxed text-muted-foreground">
              Alpha lost access — reconnect to restore it. The old tokens are
              replaced by a fresh grant.
            </p>
            <Button asChild size="sm" className="gap-2">
              <a href={connectHref}>
                <RefreshCw className="size-3.5" aria-hidden /> Reconnect
              </a>
            </Button>
          </div>
        ) : notConfigured ? (
          <div className="flex flex-col gap-3">
            <div className="flex items-start gap-2.5 rounded-lg border border-border/60 bg-muted/30 p-3">
              <Plug className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden />
              <p className="min-w-0 break-words text-xs leading-relaxed text-muted-foreground">
                {integration.setup}
              </p>
            </div>
            <Tooltip>
              <TooltipTrigger asChild>
                <span tabIndex={0} className="inline-flex w-fit">
                  <Button disabled size="sm" className="gap-2" aria-disabled="true">
                    <Icon className="size-3.5" aria-hidden /> Connect {label}
                  </Button>
                </span>
              </TooltipTrigger>
              <TooltipContent>
                Set {isGmail ? 'GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET' : 'GITHUB_CLIENT_ID and GITHUB_CLIENT_SECRET'}{' '}
                as Worker secrets to enable this
              </TooltipContent>
            </Tooltip>
          </div>
        ) : (
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="max-w-sm text-xs leading-relaxed text-muted-foreground">
              {isGmail
                ? 'Connect requires a real Google OAuth grant — Alpha never simulates a mailbox.'
                : 'Connecting requires a real GitHub OAuth grant — Alpha never simulates a repository.'}
            </p>
            <Button asChild size="sm" className="gap-2">
              <a href={connectHref}>
                <Icon className="size-3.5" aria-hidden /> Connect {label}
              </a>
            </Button>
          </div>
        )}
      </CardContent>

      <AlertDialog open={disconnectOpen} onOpenChange={setDisconnectOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {multiAccount ? `Disconnect all ${accountCount} ${label} accounts?` : `Disconnect ${label}?`}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {multiAccount
                ? `Every connected ${label} account loses access — tokens are revoked and deleted. Individual accounts can be disconnected separately in the ${label} view.`
                : isGmail
                  ? 'Alpha loses access to your mailbox. Tokens are revoked and deleted.'
                  : `Alpha loses access to your GitHub account. Tokens are revoked and deleted.`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={disconnecting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={disconnecting}
              onClick={(e) => {
                e.preventDefault()
                void disconnect()
              }}
              className="gap-2 bg-destructive text-white hover:bg-destructive/90"
            >
              {disconnecting ? (
                <Loader2 className="size-4 animate-spin" aria-hidden />
              ) : (
                <Unplug className="size-4" aria-hidden />
              )}
              Disconnect
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  )
}

export function SettingsView() {
  const queryClient = useQueryClient()
  const setView = useAlpha((s) => s.setView)
  const [section, setSection] = React.useState<SectionKey>('account')
  const [form, setForm] = React.useState<Settings | null>(null)
  const [original, setOriginal] = React.useState<Settings | null>(null)
  const [saving, setSaving] = React.useState(false)
  const [signOutConfirm, setSignOutConfirm] = React.useState(false)
  const [signingOut, setSigningOut] = React.useState(false)

  const settingsQuery = useQuery({
    queryKey: ['settings'],
    queryFn: () => api.get<{ settings: Settings }>('/api/v1/settings'),
  })
  const meQuery = useQuery({
    queryKey: ['me'],
    queryFn: () => api.get<{ user: { id: string; email: string; name: string } }>(
      '/api/v1/auth/me',
    ),
  })
  const integrationsQuery = useQuery({
    queryKey: ['integrations'],
    queryFn: () => api.get<{ integrations: IntegrationInfo[] }>('/api/v1/integrations'),
  })
  const sessionsQuery = useQuery({
    queryKey: ['sessions'],
    queryFn: () => api.get<{ sessions: SessionInfo[] }>('/api/v1/sessions'),
  })
  const otherSessions = (sessionsQuery.data?.sessions ?? []).filter((s) => !s.current)

  // Hydrate the form once from the server.
  React.useEffect(() => {
    if (settingsQuery.data?.settings && original === null) {
      setForm(settingsQuery.data.settings)
      setOriginal(settingsQuery.data.settings)
    }
  }, [settingsQuery.data, original])

  // Apply density preference as a data attribute.
  React.useEffect(() => {
    if (form?.density) {
      document.documentElement.setAttribute('data-density', form.density)
    }
  }, [form?.density])

  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = React.useState(false)
  React.useEffect(() => setMounted(true), [])

  if (!form || !original) {
    return (
      <div className="flex flex-col gap-6" aria-busy="true" aria-label="Loading settings">
        <Card className="alpha-panel border-0" aria-hidden>
          <CardContent className="space-y-3 p-6">
            <div className="h-8 w-40 animate-pulse rounded-lg bg-muted/50" />
            <div className="h-24 animate-pulse rounded-xl bg-muted/50" />
            <div className="h-24 animate-pulse rounded-xl bg-muted/50" />
          </CardContent>
        </Card>
      </div>
    )
  }

  const changedKeys = SETTING_KEYS.filter((k) => form[k] !== original[k])
  const dirty = changedKeys.length > 0

  function update<K extends keyof Settings>(key: K, value: Settings[K]) {
    setForm((f) => (f ? { ...f, [key]: value } : f))
  }

  function discard() {
    setForm(original)
  }

  async function save() {
    if (!form || !dirty || saving) return
    const patch: Record<string, string> = {}
    for (const key of changedKeys) patch[key] = form[key]
    setSaving(true)
    try {
      const res = await api.patch<{ settings: Settings }>('/api/v1/settings', patch)
      setForm(res.settings)
      setOriginal(res.settings)
      toast.success('Settings saved')
    } catch (e) {
      toast.error(e instanceof ApiError ? e.message : 'Could not save settings')
    } finally {
      setSaving(false)
    }
  }

  async function signOutOthers() {
    setSigningOut(true)
    try {
      const targets = (sessionsQuery.data?.sessions ?? []).filter((s) => !s.current)
      await Promise.all(targets.map((s) => api.delete(`/api/v1/sessions/${s.id}`)))
      await queryClient.invalidateQueries({ queryKey: ['sessions'] })
      await queryClient.invalidateQueries({ queryKey: ['audit'] })
      toast.success(
        targets.length === 1
          ? 'Signed out 1 other session'
          : `Signed out ${targets.length} other sessions`,
      )
    } catch (e) {
      toast.error(e instanceof ApiError ? e.message : 'Failed to sign out sessions')
    } finally {
      setSigningOut(false)
      setSignOutConfirm(false)
    }
  }

  const user = meQuery.data?.user
  const gmail = integrationsQuery.data?.integrations.find((i) => i.id === 'gmail')
  const github = integrationsQuery.data?.integrations.find((i) => i.id === 'github')
  const chatModels = unique([form.chat_model, 'glm-4.6', 'glm-4.5v'])
  const voices = unique([form.voice, 'tongtong'])
  const speed = Number(form.voice_speed) || 1

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
    >
      <Tabs value={section} onValueChange={(v) => setSection(v as SectionKey)} className="gap-4">
        <div className="flex flex-col gap-4 lg:flex-row">
          {/* Section nav */}
          <Card className="alpha-panel border-0 lg:sticky lg:top-2 lg:w-56 lg:self-start">
            <CardContent className="p-2">
              {/* justify-start: the shadcn default (justify-center) lets an
                  overflowing strip bleed past the LEFT scroll edge at mobile
                  widths, making the first tabs unreachable. */}
              <TabsList className="h-auto w-full justify-start gap-0.5 overflow-x-auto bg-transparent p-0 lg:flex-col">
                {SECTIONS.map((s) => {
                  const Icon = s.icon
                  return (
                    <TabsTrigger
                      key={s.key}
                      value={s.key}
                      className="w-full shrink-0 justify-start gap-2 px-3 py-2 text-xs lg:w-full"
                    >
                      <Icon className="size-3.5" aria-hidden />
                      {s.label}
                    </TabsTrigger>
                  )
                })}
              </TabsList>
            </CardContent>
          </Card>

          {/* Panels */}
          <div className="min-w-0 flex-1">
            {/* Account */}
            <TabsContent value="account" className="mt-0">
              <Card className="alpha-panel border-0">
                <CardHeader className="border-b border-border/60 py-3">
                  <CardTitle className="text-sm">Account</CardTitle>
                  <CardDescription className="text-xs">
                    Single-user personal instance — this is your owner account.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-4 sm:p-6">
                  {meQuery.isLoading || !user ? (
                    <div className="space-y-3" aria-hidden>
                      <div className="h-10 w-40 animate-pulse rounded-lg bg-muted/50" />
                      <div className="h-10 animate-pulse rounded-lg bg-muted/50" />
                    </div>
                  ) : (
                    <div className="flex items-center gap-4">
                      <Avatar className="size-12 border border-border/60">
                        <AvatarFallback className="bg-accent/15 font-semibold text-accent">
                          {(user.name || user.email).slice(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold">{user.name}</p>
                        <p className="truncate text-xs text-muted-foreground">{user.email}</p>
                      </div>
                    </div>
                  )}
                  <div>
                    <Label htmlFor="settings-email" className="text-xs text-muted-foreground">
                      Email (read-only)
                    </Label>
                    <Input
                      id="settings-email"
                      value={user?.email ?? ''}
                      readOnly
                      disabled
                      className="mt-1"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Password, sessions, and the audit log are managed in the
                    Security view.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>

            {/* AI */}
            <TabsContent value="ai" className="mt-0">
              <Card className="alpha-panel border-0">
                <CardHeader className="border-b border-border/60 py-3">
                  <CardTitle className="text-sm">AI</CardTitle>
                  <CardDescription className="text-xs">
                    The model Alpha uses for conversations and reasoning.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-4 sm:p-6">
                  <div className="max-w-xs">
                    <Label htmlFor="chat-model" className="text-xs text-muted-foreground">
                      Chat model
                    </Label>
                    <Select value={form.chat_model} onValueChange={(v) => update('chat_model', v)}>
                      <SelectTrigger id="chat-model" className="mt-1 w-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {chatModels.map((m) => (
                          <SelectItem key={m} value={m}>
                            {m}
                            {m === 'glm-4.6' ? ' (default)' : ''}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <p className="text-xs leading-relaxed text-muted-foreground">
                    Live provider configuration and latency are shown in the
                    System view.
                  </p>
                  <div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setView('system')}
                      className="gap-2"
                    >
                      <Activity className="size-3.5" aria-hidden /> Open System view
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* AI Providers — dashboard-managed provider credentials */}
            <TabsContent value="providers" className="mt-0">
              <AiProvidersPanel />
            </TabsContent>

            {/* Voice */}
            <TabsContent value="voice" className="mt-0">
              <Card className="alpha-panel border-0">
                <CardHeader className="border-b border-border/60 py-3">
                  <CardTitle className="text-sm">Voice</CardTitle>
                  <CardDescription className="text-xs">
                    Voice used when Alpha speaks (text-to-speech).
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-5 p-4 sm:p-6">
                  <div className="max-w-xs">
                    <Label htmlFor="voice-select" className="text-xs text-muted-foreground">
                      Voice
                    </Label>
                    <Select value={form.voice} onValueChange={(v) => update('voice', v)}>
                      <SelectTrigger id="voice-select" className="mt-1 w-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {voices.map((v) => (
                          <SelectItem key={v} value={v}>
                            {v}
                            {v === 'tongtong' ? ' (default)' : ''}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <div className="mb-2 flex items-center justify-between">
                      <Label htmlFor="voice-speed" className="text-xs text-muted-foreground">
                        Speed
                      </Label>
                      <span className="font-mono text-xs text-muted-foreground">
                        {speed.toFixed(2)}×
                      </span>
                    </div>
                    <Slider
                      id="voice-speed"
                      value={[speed]}
                      min={0.5}
                      max={2}
                      step={0.05}
                      onValueChange={([v]) => update('voice_speed', v.toFixed(2))}
                      className="max-w-sm"
                      aria-label="Voice speed"
                    />
                    <p className="mt-1.5 text-[11px] text-muted-foreground">
                      0.5× slow — 2× fast. Applies to spoken replies.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Memory */}
            <TabsContent value="memory" className="mt-0">
              <Card className="alpha-panel border-0">
                <CardHeader className="border-b border-border/60 py-3">
                  <CardTitle className="text-sm">Memory</CardTitle>
                  <CardDescription className="text-xs">
                    Control what Alpha remembers across conversations.
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-4 sm:p-6">
                  <div className="space-y-4">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <p className="text-sm font-medium">Memory enabled</p>
                        <p className="mt-0.5 text-xs text-muted-foreground">
                          Alpha can consult your saved memories when answering.
                        </p>
                      </div>
                      <Switch
                        checked={form.memory_enabled === 'true'}
                        onCheckedChange={(v) => update('memory_enabled', String(v))}
                        aria-label="Memory enabled"
                      />
                    </div>
                    <Separator />
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <p className="text-sm font-medium">Auto-learn</p>
                        <p className="mt-0.5 text-xs text-muted-foreground">
                          Future capability — Alpha will distill new memories
                          from your conversations automatically. Stored as a
                          preference flag for now.
                        </p>
                      </div>
                      <Switch
                        checked={form.memory_auto_learn === 'true'}
                        onCheckedChange={(v) => update('memory_auto_learn', String(v))}
                        aria-label="Memory auto-learn"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Notifications */}
            <TabsContent value="notifications" className="mt-0">
              <Card className="alpha-panel border-0">
                <CardHeader className="border-b border-border/60 py-3">
                  <CardTitle className="text-sm">Notifications</CardTitle>
                </CardHeader>
                <CardContent className="p-4 sm:p-6">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-sm font-medium">In-app notifications</p>
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        Show toasts for reminders, finished jobs, and security
                        events.
                      </p>
                    </div>
                    <Switch
                      checked={form.notifications === 'true'}
                      onCheckedChange={(v) => update('notifications', String(v))}
                      aria-label="Notifications"
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Appearance */}
            <TabsContent value="appearance" className="mt-0">
              <Card className="alpha-panel border-0">
                <CardHeader className="border-b border-border/60 py-3">
                  <CardTitle className="text-sm">Appearance</CardTitle>
                </CardHeader>
                <CardContent className="space-y-5 p-4 sm:p-6">
                  <div>
                    <p className="text-sm font-medium">Theme</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      Alpha is dark-first; light mode is fully supported.
                    </p>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {(
                        [
                          { value: 'light', label: 'Light', icon: Sun },
                          { value: 'dark', label: 'Dark', icon: Moon },
                          { value: 'system', label: 'System', icon: Monitor },
                        ] as const
                      ).map((t) => {
                        const Icon = t.icon
                        const active = mounted && theme === t.value
                        return (
                          <button
                            key={t.value}
                            type="button"
                            onClick={() => setTheme(t.value)}
                            aria-pressed={active}
                            className={cn(
                              'flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-medium transition-all',
                              active
                                ? 'border-accent bg-accent/15 text-foreground'
                                : 'border-border/70 bg-card/40 text-muted-foreground hover:border-accent/40 hover:text-foreground',
                            )}
                          >
                            <Icon className="size-3.5" aria-hidden />
                            {t.label}
                          </button>
                        )
                      })}
                    </div>
                  </div>
                  <Separator />
                  <div>
                    <p className="text-sm font-medium">Density</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      Comfortable adds breathing room; compact tightens lists
                      and cards.
                    </p>
                    <ToggleGroup
                      type="single"
                      value={form.density}
                      onValueChange={(v) => {
                        if (v) update('density', v)
                      }}
                      className="mt-2 gap-1.5"
                    >
                      <ToggleGroupItem
                        value="comfortable"
                        className="border border-border/70 px-3 py-1.5 text-xs data-[state=on]:border-accent data-[state=on]:bg-accent/15"
                      >
                        Comfortable
                      </ToggleGroupItem>
                      <ToggleGroupItem
                        value="compact"
                        className="border border-border/70 px-3 py-1.5 text-xs data-[state=on]:border-accent data-[state=on]:bg-accent/15"
                      >
                        Compact
                      </ToggleGroupItem>
                    </ToggleGroup>
                  </div>
                  <Separator />
                  <div>
                    <p className="text-sm font-medium">Accent</p>
                    <div className="mt-2 flex items-center gap-2">
                      <span className="inline-flex items-center gap-1.5 rounded-md border border-accent/40 bg-accent/10 px-3 py-1 text-xs font-medium text-accent">
                        <span className="size-2.5 rounded-full bg-accent" aria-hidden />
                        Alpha amber
                      </span>
                      <Badge variant="outline" className="gap-1 text-[10px] text-muted-foreground">
                        <Lock className="size-2.5" aria-hidden /> locked
                      </Badge>
                    </div>
                    <p className="mt-1.5 text-[11px] text-muted-foreground">
                      The accent color is fixed to Alpha amber in this release.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Integrations */}
            <TabsContent value="integrations" className="mt-0">
              <div className="space-y-4">
                {integrationsQuery.isLoading || !gmail || !github ? (
                  <>
                    <Card className="alpha-panel border-0" aria-hidden>
                      <CardContent className="space-y-3 p-4 sm:p-6">
                        <div className="h-6 w-40 animate-pulse rounded-lg bg-muted/50" />
                        <div className="h-10 animate-pulse rounded-lg bg-muted/50" />
                      </CardContent>
                    </Card>
                    <Card className="alpha-panel border-0" aria-hidden>
                      <CardContent className="space-y-3 p-4 sm:p-6">
                        <div className="h-6 w-40 animate-pulse rounded-lg bg-muted/50" />
                        <div className="h-10 animate-pulse rounded-lg bg-muted/50" />
                      </CardContent>
                    </Card>
                  </>
                ) : (
                  <>
                    <IntegrationSettingsCard integration={gmail} />
                    <IntegrationSettingsCard integration={github} />
                  </>
                )}
                <p className="px-1 text-xs leading-relaxed text-muted-foreground">
                  Real OAuth connections only — Alpha never simulates an
                  integration. Connection state and controls also live in the
                  Gmail and GitHub views.
                </p>
              </div>
            </TabsContent>

            {/* Danger zone */}
            <TabsContent value="danger" className="mt-0">
              <Card className="border-destructive/40 bg-destructive/5 backdrop-blur-sm">
                <CardHeader className="border-b border-destructive/30 py-3">
                  <CardTitle className="flex items-center gap-2 text-sm text-destructive">
                    <ShieldAlert className="size-4" aria-hidden /> Danger zone
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 p-4 sm:p-6">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="text-sm font-medium">Sign out all other sessions</p>
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        {otherSessions.length === 0
                          ? 'No other active sessions right now.'
                          : `${otherSessions.length} other active session${otherSessions.length === 1 ? '' : 's'} will be signed out.`}
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      disabled={otherSessions.length === 0 || signingOut}
                      onClick={() => setSignOutConfirm(true)}
                      className="gap-2 border-destructive/40 text-destructive hover:bg-destructive/10"
                    >
                      <LogOut className="size-4" aria-hidden /> Sign out others
                    </Button>
                  </div>
                  <Separator className="bg-destructive/20" />
                  <p className="text-xs leading-relaxed text-muted-foreground">
                    Bulk data deletion (conversations, notes, memories) is
                    intentionally not offered here. Alpha does not expose
                    destructive actions that are not fully implemented.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Save bar */}
            {dirty && (
              <div className="sticky bottom-4 z-10 mt-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-accent/30 bg-card/95 p-3 shadow-lg backdrop-blur">
                <p className="text-xs text-muted-foreground">
                  {changedKeys.length} unsaved change{changedKeys.length === 1 ? '' : 's'}
                </p>
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm" onClick={discard} disabled={saving}>
                    Discard
                  </Button>
                  <Button size="sm" onClick={() => void save()} disabled={saving} className="gap-2">
                    {saving ? (
                      <Loader2 className="size-3.5 animate-spin" aria-hidden />
                    ) : (
                      <Save className="size-3.5" aria-hidden />
                    )}
                    Save changes
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </Tabs>

      {/* Sign out others confirm */}
      <AlertDialog open={signOutConfirm} onOpenChange={setSignOutConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Sign out all other sessions?</AlertDialogTitle>
            <AlertDialogDescription>
              {otherSessions.length} session{otherSessions.length === 1 ? '' : 's'} on
              other devices will be revoked immediately. This device stays
              signed in.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={signingOut}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={signingOut}
              className="gap-2 bg-destructive text-white hover:bg-destructive/90"
              onClick={(e) => {
                e.preventDefault()
                void signOutOthers()
              }}
            >
              {signingOut ? (
                <Loader2 className="size-4 animate-spin" aria-hidden />
              ) : (
                <KeyRound className="size-4" aria-hidden />
              )}
              Sign out {otherSessions.length} session{otherSessions.length === 1 ? '' : 's'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  )
}
