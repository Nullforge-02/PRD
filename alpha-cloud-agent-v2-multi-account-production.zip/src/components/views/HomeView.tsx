'use client'

import * as React from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  ArrowRight,
  MessageSquare,
  StickyNote,
  ImageIcon,
  Mic,
  Send,
  Command,
  Keyboard,
} from 'lucide-react'
import { api, type Conversation, type Note, type FileRecord } from '@/lib/api'
import { useAlpha } from '@/lib/store'
import { NullForgeMark } from '@/components/brand/NullForgeMark'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { toast } from 'sonner'
import { RecentListSkeleton, Skeleton } from '@/components/common/Skeletons'
import { TodayPanel } from '@/components/common/TodayPanel'

const SUGGESTIONS = [
  'Search the web for the latest news on…',
  'Create a note about…',
  'What can you do?',
  'Generate an image of…',
]

function greeting() {
  const h = new Date().getHours()
  if (h < 5) return 'Good night'
  if (h < 12) return 'Good morning'
  if (h < 17) return 'Good afternoon'
  if (h < 21) return 'Good evening'
  return 'Good night'
}

function timeOfDay() {
  const h = new Date().getHours()
  if (h < 5) return 'Late night vibes'
  if (h < 12) return 'A fresh start'
  if (h < 17) return 'Mid-day momentum'
  if (h < 21) return 'Evening focus'
  return 'Quiet hours'
}

export function HomeView() {
  const setView = useAlpha((s) => s.setView)
  const setConversation = useAlpha((s) => s.setConversation)
  const user = useAlpha((s) => s.user)
  const [message, setMessage] = React.useState('')

  const { data: conversationsData, isLoading: loadingConversations } = useQuery({
    queryKey: ['conversations'],
    queryFn: () =>
      api.get<{ conversations: Conversation[] }>('/api/v1/conversations'),
  })
  const conversations = conversationsData?.conversations ?? []

  const { data: notesData, isLoading: loadingNotes } = useQuery({
    queryKey: ['notes', ''],
    queryFn: () => api.get<{ notes: Note[] }>('/api/v1/notes'),
  })
  const notes = notesData?.notes ?? []

  const { data: mediaData, isLoading: loadingMedia } = useQuery({
    queryKey: ['media'],
    queryFn: () =>
      api.get<{ media: FileRecord[] }>('/api/v1/media'),
  })
  const media = mediaData?.media ?? []

  // Hand off to ChatView, which performs the real streaming send via
  // POST /api/v1/chat and renders the live answer.
  function sendMessage() {
    const m = message.trim()
    if (!m) return
    setConversation(null)
    try {
      sessionStorage.setItem('alpha:pending-prompt', m)
    } catch {
      // ignore storage failures — user can paste manually
    }
    setView('chat')
    setMessage('')
  }

  function pickConversation(id: string) {
    setConversation(id)
    setView('chat')
  }

  function openNote(id: string) {
    try {
      sessionStorage.setItem('alpha:open-note', id)
    } catch {}
    setView('notes')
  }

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col gap-6">
      {/* Hero — brand first, then the greeting hierarchy */}
      <div className="relative flex flex-col items-center gap-3 overflow-hidden pt-4 text-center">
        {/* Ambient floating orbs */}
        <div className="alpha-orb alpha-orb-1" aria-hidden />
        <div className="alpha-orb alpha-orb-2" aria-hidden />
        <div className="alpha-orb alpha-orb-3" aria-hidden />
        <NullForgeMark variant="static" size="md" className="relative" />
        <div className="alpha-hairline relative w-full max-w-xs" aria-hidden />
        <p className="relative text-xs uppercase tracking-[0.2em] text-muted-foreground">
          {timeOfDay()} ·{' '}
          {new Date().toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}
        </p>
        <h1 className="alpha-hero-greeting relative text-3xl font-semibold tracking-tight sm:text-4xl">
          {greeting()}, <span className="alpha-text-gradient">{user?.name ?? 'there'}</span>.
        </h1>
        <p className="relative text-base text-muted-foreground">
          What do you want Alpha to do?
        </p>
      </div>

      {/* Chat composer */}
      <Card className="alpha-panel border-0">
        <CardContent className="relative p-4 sm:p-6">
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault()
                sendMessage()
              }
            }}
            placeholder="Ask Alpha anything — it can chat, search the web, create notes, remember facts, and generate images. Press Enter to send."
            aria-label="Message Alpha"
            className="min-h-[110px] resize-none border-0 bg-transparent p-0 text-base shadow-none focus-visible:ring-0"
          />
          <div className="mt-3 flex items-center justify-between">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                toast.info('Voice input is in Chat — switching you there.')
                setView('chat')
              }}
              className="text-muted-foreground"
            >
              <Mic className="size-4" />
              Voice
            </Button>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">
                {message.length} chars
              </span>
              <Button
                onClick={sendMessage}
                disabled={!message.trim()}
                size="default"
                className="alpha-ripple gap-2"
              >
                <Send className="size-4" />
                Send
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Suggestion chips — prefill the composer */}
      <div className="flex flex-wrap justify-center gap-2">
        {SUGGESTIONS.map((s) => (
          <button
            key={s}
            onClick={() => setMessage(s)}
            className="rounded-md border border-border/60 px-3 py-1.5 font-mono text-[11px] text-muted-foreground transition-colors hover:border-accent/40 hover:text-foreground"
          >
            {s}
          </button>
        ))}
      </div>

      {/* Command palette + shortcuts hint */}
      <div className="flex flex-wrap justify-center gap-2">
        <button
          onClick={openCommandPalette}
          className="alpha-lift inline-flex items-center gap-2 rounded-md border border-border/60 px-3 py-1.5 text-[11px] text-muted-foreground transition-colors hover:border-accent/40 hover:text-foreground"
        >
          <Command className="size-3" />
          <span>
            <kbd className="alpha-kbd">⌘K</kbd> Search & commands
          </span>
        </button>
        <button
          onClick={openShortcuts}
          className="alpha-lift inline-flex items-center gap-2 rounded-md border border-border/60 px-3 py-1.5 text-[11px] text-muted-foreground transition-colors hover:border-accent/40 hover:text-foreground"
        >
          <Keyboard className="size-3" />
          <span>
            <kbd className="alpha-kbd">⌘/</kbd> Shortcuts
          </span>
        </button>
      </div>

      {/* Today — real reminders & calendar events */}
      <TodayPanel />

      {/* Recent grids */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {/* Recent conversations */}
        <Card className="alpha-panel alpha-panel-hover border-0">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-sm">
                <MessageSquare className="size-4 text-accent" />
                Recent Chats
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs"
                onClick={() => setView('chat')}
              >
                All <ArrowRight className="size-3" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="max-h-64 space-y-2 overflow-y-auto p-0 px-2 pb-3 pt-0 alpha-scroll">
            {loadingConversations ? (
              <RecentListSkeleton />
            ) : conversations.length === 0 ? (
              <p className="px-2 py-6 text-center text-xs text-muted-foreground">
                No conversations yet — send your first message above.
              </p>
            ) : (
              conversations.slice(0, 3).map((c) => (
                <button
                  key={c.id}
                  onClick={() => pickConversation(c.id)}
                  className="flex w-full items-start gap-2 rounded-lg p-2 text-left transition-colors hover:bg-accent/10"
                >
                  <Avatar className="size-7">
                    <AvatarFallback className="bg-accent/15 text-[10px]">
                      {c.title.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-medium">{c.title}</p>
                    <p className="text-[10px] text-muted-foreground">
                      {new Date(c.updatedAt).toLocaleDateString()}
                    </p>
                  </div>
                </button>
              ))
            )}
          </CardContent>
        </Card>

        {/* Recent notes */}
        <Card className="alpha-panel alpha-panel-hover border-0">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-sm">
                <StickyNote className="size-4 text-accent" />
                Recent Notes
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs"
                onClick={() => setView('notes')}
              >
                All <ArrowRight className="size-3" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="max-h-64 space-y-2 overflow-y-auto p-0 px-2 pb-3 pt-0 alpha-scroll">
            {loadingNotes ? (
              <RecentListSkeleton />
            ) : notes.length === 0 ? (
              <p className="px-2 py-6 text-center text-xs text-muted-foreground">
                No notes yet — ask Alpha to create one, or add your own in Notes.
              </p>
            ) : (
              notes.slice(0, 3).map((n) => (
                <button
                  key={n.id}
                  onClick={() => openNote(n.id)}
                  className="flex w-full flex-col gap-1 rounded-lg p-2 text-left transition-colors hover:bg-accent/10"
                >
                  <div className="flex items-center gap-2">
                    <span
                      className={
                        n.pinned
                          ? 'size-1.5 rounded-full bg-accent'
                          : 'size-1.5 rounded-full bg-muted-foreground/40'
                      }
                    />
                    <p className="truncate text-xs font-medium">{n.title}</p>
                  </div>
                  <p className="truncate text-[10px] text-muted-foreground">
                    {n.content || 'Empty note'}
                  </p>
                </button>
              ))
            )}
          </CardContent>
        </Card>

        {/* Recent generated media */}
        <Card className="alpha-panel alpha-panel-hover border-0">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-sm">
                <ImageIcon className="size-4 text-accent" />
                Recent Images
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs"
                onClick={() => setView('media')}
              >
                All <ArrowRight className="size-3" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-0 px-2 pb-3 pt-0">
            {loadingMedia ? (
              <div className="grid grid-cols-3 gap-2">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="aspect-square rounded-md" />
                ))}
              </div>
            ) : media.length === 0 ? (
              <p className="px-2 py-6 text-center text-xs text-muted-foreground">
                No generated images yet.
              </p>
            ) : (
              <div className="grid grid-cols-3 gap-2">
                {media.slice(0, 3).map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setView('media')}
                    className="aspect-square overflow-hidden rounded-md border border-border/60 bg-muted"
                    aria-label={`Open generated image ${f.filename}`}
                  >
                    {/* Streams the real bytes from cloud storage (auth cookie
                        rides along). */}
                    <img
                      src={`/api/v1/files/${f.id}`}
                      alt={f.filename}
                      className="size-full object-cover transition-transform hover:scale-105"
                    />
                  </button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Bottom card */}
      <Card className="alpha-panel border-0">
        <CardHeader>
          <CardTitle className="text-sm">Tip</CardTitle>
          <CardDescription className="text-xs">
            Alpha can chat, search the web, create and search notes, remember
            facts, generate images, and set reminders — all from the Chat
            panel. Tool calls and their permission levels are listed under
            Tools, and everything it remembers about you lives in Memory.
          </CardDescription>
        </CardHeader>
      </Card>
    </div>
  )
}

// Trigger the global ⌘K palette via a synthetic event (CommandPalette listens).
function openCommandPalette() {
  const ev = new KeyboardEvent('keydown', {
    key: 'k',
    metaKey: true,
    ctrlKey: !navigator.platform.toLowerCase().includes('mac'),
    bubbles: true,
  })
  window.dispatchEvent(ev)
}

function openShortcuts() {
  const ev = new KeyboardEvent('keydown', {
    key: '/',
    metaKey: true,
    ctrlKey: !navigator.platform.toLowerCase().includes('mac'),
    bubbles: true,
  })
  window.dispatchEvent(ev)
}
