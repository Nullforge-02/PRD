'use client'

import * as React from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import {
  CheckCircle2,
  Clock,
  Download,
  ImageIcon,
  Loader2,
  Trash2,
  Wand2,
  XCircle,
} from 'lucide-react'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { EmptyState } from '@/components/common/EmptyState'
import { MediaGallerySkeleton } from '@/components/common/Skeletons'
import { api, ApiError, type FileRecord } from '@/lib/api'

// ============================================================
// Media — REAL AI image generation (Z.ai → R2) + gallery + jobs.
// No mock images, no simulated progress — generation takes as
// long as the real provider takes.
// ============================================================

interface MediaJob {
  id: string
  kind: string
  status: string
  payload: string | null
  error: string | null
  createdAt: string
  finishedAt: string | null
}

interface MediaResponse {
  media: FileRecord[]
  jobs: MediaJob[]
  sizes: string[]
}

const SIZE_LABELS: Record<string, string> = {
  '1024x1024': 'Square',
  '768x1344': 'Tall',
  '864x1152': 'Portrait',
  '1344x768': 'Landscape',
  '1152x864': 'Wide',
  '1440x720': 'Wide XL',
  '720x1440': 'Tall XL',
}

function aspectFor(size: string): number {
  const [w, h] = size.split('x').map(Number)
  if (!w || !h) return 1
  return w / h
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  const units = ['KB', 'MB', 'GB']
  let value = bytes / 1024
  let i = 0
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024
    i++
  }
  return `${value < 10 ? value.toFixed(1) : Math.round(value)} ${units[i]}`
}

function timeAgo(iso: string): string {
  const s = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000))
  if (s < 5) return 'just now'
  if (s < 60) return `${s}s ago`
  if (s < 3600) return `${Math.floor(s / 60)}m ago`
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`
  return `${Math.floor(s / 86400)}d ago`
}

function JobStatusIcon({ status }: { status: string }) {
  if (status === 'done') return <CheckCircle2 className="size-3.5 text-emerald-500" aria-hidden />
  if (status === 'failed') return <XCircle className="size-3.5 text-destructive" aria-hidden />
  if (status === 'queued') return <Clock className="size-3.5 text-muted-foreground" aria-hidden />
  return <Loader2 className="size-3.5 animate-spin text-accent" aria-hidden />
}

function jobPrompt(job: MediaJob): string | null {
  if (!job.payload) return null
  try {
    const parsed = JSON.parse(job.payload) as { prompt?: string }
    return parsed.prompt ?? null
  } catch {
    return null
  }
}

export function MediaView() {
  const queryClient = useQueryClient()
  const [prompt, setPrompt] = React.useState('')
  const [size, setSize] = React.useState('1024x1024')
  const [generating, setGenerating] = React.useState(false)
  const [configError, setConfigError] = React.useState<string | null>(null)
  const [preview, setPreview] = React.useState<FileRecord | null>(null)
  const [deleteTarget, setDeleteTarget] = React.useState<FileRecord | null>(null)
  const [deleting, setDeleting] = React.useState(false)

  const { data, isLoading } = useQuery({
    queryKey: ['media'],
    queryFn: () => api.get<MediaResponse>('/api/v1/media'),
  })
  const media = data?.media ?? []
  const jobs = data?.jobs ?? []
  const sizes = data?.sizes ?? ['1024x1024']

  async function generate() {
    const trimmed = prompt.trim()
    if (!trimmed || generating) return
    setGenerating(true)
    setConfigError(null)
    try {
      const res = await api.post<{ file: FileRecord }>('/api/v1/media/generate', {
        prompt: trimmed,
        size,
      })
      setPrompt('')
      setPreview(res.file)
      await queryClient.invalidateQueries({ queryKey: ['media'] })
      toast.success('Image generated — saved to your gallery')
    } catch (e) {
      if (e instanceof ApiError && (e.status === 503 || e.status === 501)) {
        setConfigError(e.message)
      }
      toast.error(e instanceof ApiError ? e.message : 'Generation failed')
    } finally {
      setGenerating(false)
    }
  }

  async function deleteMedia(file: FileRecord) {
    setDeleting(true)
    try {
      await api.delete(`/api/v1/files/${file.id}`)
      setPreview((p) => (p?.id === file.id ? null : p))
      await queryClient.invalidateQueries({ queryKey: ['media'] })
      await queryClient.invalidateQueries({ queryKey: ['files'] })
      toast.success('Image deleted')
    } catch (e) {
      toast.error(e instanceof ApiError ? e.message : 'Delete failed')
    } finally {
      setDeleting(false)
      setDeleteTarget(null)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="flex flex-col gap-6"
    >
      {/* Generate */}
      <Card className="alpha-panel border-0">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm">
            <Wand2 className="size-4 text-accent" aria-hidden /> Generate image
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <label className="sr-only" htmlFor="media-prompt">
            Image prompt
          </label>
          <Textarea
            id="media-prompt"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="A warm amber Alpha mark on a near-black background — premium, minimal."
            className="min-h-[80px] resize-none"
            disabled={generating}
            maxLength={2000}
          />
          <div className="flex flex-wrap gap-2" role="group" aria-label="Image size">
            {sizes.map((s) => {
              const selected = size === s
              return (
                <button
                  key={s}
                  type="button"
                  onClick={() => setSize(s)}
                  disabled={generating}
                  aria-pressed={selected}
                  className={cn(
                    'flex items-center gap-2 rounded-lg border px-3 py-1.5 text-xs font-medium transition-all',
                    selected
                      ? 'border-accent bg-accent/15 text-foreground'
                      : 'border-border/70 bg-card/40 text-muted-foreground hover:border-accent/40 hover:text-foreground',
                  )}
                >
                  <span
                    aria-hidden
                    className={cn(
                      'w-4 rounded-[3px] border',
                      selected ? 'border-accent bg-accent/30' : 'border-muted-foreground/40',
                    )}
                    style={{ aspectRatio: String(aspectFor(s)) }}
                  />
                  {SIZE_LABELS[s] ?? 'Custom'} · <span className="font-mono">{s}</span>
                </button>
              )
            })}
          </div>
          {configError && (
            <div
              role="alert"
              className="rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-xs text-destructive"
            >
              <p className="font-semibold">Image generation is not available</p>
              <p className="mt-1 leading-relaxed">{configError}</p>
            </div>
          )}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-xs text-muted-foreground">
              Real Z.ai image generation — images are saved to your R2 storage and
              appear in Files.
            </p>
            <Button onClick={() => void generate()} disabled={generating || !prompt.trim()} className="gap-2">
              {generating ? (
                <Loader2 className="size-4 animate-spin" aria-hidden />
              ) : (
                <Wand2 className="size-4" aria-hidden />
              )}
              {generating ? 'Generating…' : 'Generate'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Gallery */}
      <Card className="alpha-panel border-0">
        <CardHeader className="border-b border-border/60 py-3">
          <CardTitle className="flex items-center gap-2 text-sm">
            <ImageIcon className="size-4 text-accent" aria-hidden /> Gallery
            <span className="text-xs font-normal text-muted-foreground">
              {media.length} image{media.length === 1 ? '' : 's'}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          {isLoading ? (
            <MediaGallerySkeleton />
          ) : media.length === 0 ? (
            <EmptyState
              icon={ImageIcon}
              title="No media yet"
              description="Generate your first image above — it will be saved here and listed in Files."
            />
          ) : (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {media.map((f) => (
                <div
                  key={f.id}
                  className="group relative aspect-square overflow-hidden rounded-lg border border-border/60 bg-muted"
                >
                  <button
                    type="button"
                    onClick={() => setPreview(f)}
                    className="size-full cursor-zoom-in"
                    aria-label={`Open ${f.filename}`}
                  >
                    <img
                      src={`/api/v1/files/${f.id}`}
                      alt={f.filename}
                      loading="lazy"
                      className="size-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  </button>
                  <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                  <div className="absolute right-1.5 top-1.5 flex gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                    <Button
                      asChild
                      size="icon"
                      variant="secondary"
                      className="size-7 rounded-md bg-black/60 text-white hover:bg-black/80 hover:text-white"
                    >
                      <a
                        href={`/api/v1/files/${f.id}?download=1`}
                        download={f.filename}
                        aria-label={`Download ${f.filename}`}
                      >
                        <Download className="size-3.5" aria-hidden />
                      </a>
                    </Button>
                    <Button
                      size="icon"
                      variant="secondary"
                      className="size-7 rounded-md bg-black/60 text-white hover:bg-destructive hover:text-white"
                      onClick={() => setDeleteTarget(f)}
                      aria-label={`Delete ${f.filename}`}
                    >
                      <Trash2 className="size-3.5" aria-hidden />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent jobs */}
      <Card className="alpha-panel border-0">
        <CardHeader className="border-b border-border/60 py-3">
          <CardTitle className="text-sm">Recent jobs</CardTitle>
        </CardHeader>
        <CardContent className="p-3">
          {isLoading ? (
            <div className="space-y-2 p-1" aria-hidden>
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="h-8 animate-pulse rounded-lg bg-muted/50" />
              ))}
            </div>
          ) : jobs.length === 0 ? (
            <p className="px-2 py-6 text-center text-xs text-muted-foreground">
              No jobs yet — generated images and their outcomes will appear here.
            </p>
          ) : (
            <ul className="flex flex-col gap-1">
              {jobs.map((j) => {
                const promptText = jobPrompt(j)
                return (
                  <li
                    key={j.id}
                    className="flex items-center gap-3 rounded-lg p-2 text-xs transition-colors hover:bg-accent/5"
                  >
                    <span className="rounded border border-border/60 bg-muted/30 px-1.5 py-0.5 font-mono text-[10px]">
                      {j.kind}
                    </span>
                    <JobStatusIcon status={j.status} />
                    <span className="min-w-0 flex-1 truncate text-muted-foreground">
                      {promptText ?? (j.error ? j.error : '—')}
                    </span>
                    <span className="shrink-0 capitalize text-muted-foreground">{j.status}</span>
                    <span className="shrink-0 text-[10px] text-muted-foreground">
                      {timeAgo(j.createdAt)}
                    </span>
                  </li>
                )
              })}
            </ul>
          )}
        </CardContent>
      </Card>

      {/* Preview dialog */}
      <Dialog open={!!preview} onOpenChange={(o) => !o && setPreview(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="text-sm">{preview?.filename ?? 'Image'}</DialogTitle>
          </DialogHeader>
          {preview && (
            <div className="flex flex-col gap-4">
              <img
                src={`/api/v1/files/${preview.id}`}
                alt={preview.filename}
                className="max-h-[65vh] w-full rounded-lg border border-border/60 object-contain"
              />
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
                <div className="flex flex-wrap items-center gap-2">
                  <span>{formatBytes(preview.size)}</span>
                  <span aria-hidden>·</span>
                  <span className="font-mono">{preview.mimeType}</span>
                  <span aria-hidden>·</span>
                  <span>{new Date(preview.createdAt).toLocaleString()}</span>
                </div>
                <div className="flex gap-2">
                  <Button asChild size="sm" variant="outline" className="gap-1.5">
                    <a href={`/api/v1/files/${preview.id}?download=1`} download={preview.filename}>
                      <Download className="size-3.5" aria-hidden /> Download
                    </a>
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="gap-1.5 text-destructive hover:bg-destructive/10"
                    onClick={() => {
                      setDeleteTarget(preview)
                      setPreview(null)
                    }}
                  >
                    <Trash2 className="size-3.5" aria-hidden /> Delete
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this image?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTarget
                ? `${deleteTarget.filename} (${formatBytes(deleteTarget.size)}) will be permanently removed from your storage.`
                : ''}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={deleting}
              className="gap-1.5 bg-destructive text-white hover:bg-destructive/90"
              onClick={(e) => {
                e.preventDefault()
                if (deleteTarget) void deleteMedia(deleteTarget)
              }}
            >
              {deleting ? (
                <Loader2 className="size-4 animate-spin" aria-hidden />
              ) : (
                <Trash2 className="size-4" aria-hidden />
              )}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  )
}
