'use client'

import * as React from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import { Loader2, Play, Wrench } from 'lucide-react'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { api, ApiError, type ToolInfo } from '@/lib/api'

// ============================================================
// Tools — real registry + real executor.
// Medium/high permission tools require an explicit confirmation
// (the API answers 409 requiresConfirmation until confirmed).
// ============================================================

type Permission = ToolInfo['permission']

const PERMISSION_ORDER: Record<Permission, number> = { low: 0, medium: 1, high: 2 }

const PERMISSION_COLORS: Record<Permission, string> = {
  low: 'text-emerald-600 dark:text-emerald-400 border-emerald-500/30',
  medium: 'text-amber-600 dark:text-amber-400 border-amber-500/30',
  high: 'text-destructive border-destructive/30',
}

const PERMISSION_LABELS: Record<Permission, string> = {
  low: 'Low — runs automatically',
  medium: 'Medium — requires confirmation',
  high: 'High — requires confirmation',
}

/** Example args for the editor — UI help text only; results are always real. */
const TOOL_EXAMPLES: Record<string, Record<string, unknown>> = {
  create_note: { title: 'Ideas', content: 'A short note created via the tool executor.' },
  search_notes: { query: 'ideas' },
  read_note: { id: 'note-id-from-search-notes' },
  save_memory: { content: 'Prefers concise answers', category: 'preferences' },
  search_memory: { query: 'preferences' },
  search_files: { query: 'generated' },
  web_search: { query: 'Next.js 16 release notes', num: 5 },
  generate_image: {
    prompt: 'A minimal amber crescent mark on a near-black background',
    size: '1024x1024',
  },
  create_reminder: { title: 'Review the audit log', priority: 'normal' },
  list_reminders: { done: false },
}

type ExecResult = { ok: true; data: unknown } | { ok: false; message: string }

export function ToolsView() {
  const queryClient = useQueryClient()
  const [toolName, setToolName] = React.useState('')
  const [argsText, setArgsText] = React.useState('')
  const [running, setRunning] = React.useState(false)
  const [configError, setConfigError] = React.useState<string | null>(null)
  const [result, setResult] = React.useState<ExecResult | null>(null)
  const [pending, setPending] = React.useState<{ name: string; args: Record<string, unknown> } | null>(null)

  const { data, isLoading } = useQuery({
    queryKey: ['tools'],
    queryFn: () => api.get<{ tools: ToolInfo[] }>('/api/v1/tools'),
  })
  const tools = React.useMemo(
    () => [...(data?.tools ?? [])].sort((a, b) => PERMISSION_ORDER[a.permission] - PERMISSION_ORDER[b.permission]),
    [data],
  )
  const byPermission = React.useMemo(() => {
    const groups: Record<Permission, ToolInfo[]> = { low: [], medium: [], high: [] }
    for (const t of tools) groups[t.permission].push(t)
    return groups
  }, [tools])

  const activeTool = tools.find((t) => t.name === toolName)

  function selectTool(name: string) {
    setToolName(name)
    setArgsText(JSON.stringify(TOOL_EXAMPLES[name] ?? {}, null, 2))
    setResult(null)
  }

  // Default to the first (lowest-permission) tool once the registry loads.
  React.useEffect(() => {
    if (!toolName && tools.length > 0) {
      const first = tools[0]
      setToolName(first.name)
      setArgsText(JSON.stringify(TOOL_EXAMPLES[first.name] ?? {}, null, 2))
    }
  }, [toolName, tools])

  async function execute(name: string, args: Record<string, unknown>, confirmed: boolean) {
    setRunning(true)
    setResult(null)
    setConfigError(null)
    try {
      const res = await api.post<{ result: unknown }>('/api/v1/tools/execute', {
        name,
        args,
        confirmed,
      })
      setResult({ ok: true, data: res.result })
      toast.success(`${name} executed`)
      // Some tools change data shown in other views.
      void queryClient.invalidateQueries({ queryKey: ['notes'] })
      void queryClient.invalidateQueries({ queryKey: ['memory'] })
      void queryClient.invalidateQueries({ queryKey: ['reminders'] })
      void queryClient.invalidateQueries({ queryKey: ['files'] })
      void queryClient.invalidateQueries({ queryKey: ['media'] })
    } catch (e) {
      if (e instanceof ApiError) {
        const body = e.body as { requiresConfirmation?: boolean } | undefined
        if (e.status === 409 && body?.requiresConfirmation) {
          setPending({ name, args })
          return
        }
        if (e.status === 503) setConfigError(e.message)
        setResult({ ok: false, message: e.message })
        toast.error(e.message)
      } else {
        setResult({ ok: false, message: 'Execution failed' })
        toast.error('Execution failed')
      }
    } finally {
      setRunning(false)
    }
  }

  function tryExecute() {
    if (!activeTool || running) return
    let args: Record<string, unknown>
    try {
      const parsed: unknown = argsText.trim() ? JSON.parse(argsText) : {}
      if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
        throw new Error('not an object')
      }
      args = parsed as Record<string, unknown>
    } catch {
      toast.error('Args must be a valid JSON object')
      return
    }
    void execute(activeTool.name, args, false)
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="flex flex-col gap-6"
    >
      {/* Permission legend */}
      <Card className="alpha-panel border-0">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              <Wrench className="size-4 text-accent" aria-hidden />
              <p className="text-sm font-semibold">Permission levels</p>
            </div>
            <div className="flex flex-wrap gap-2 text-xs">
              {(['low', 'medium', 'high'] as Permission[]).map((p) => (
                <Badge key={p} variant="outline" className={PERMISSION_COLORS[p]}>
                  {PERMISSION_LABELS[p]}
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {configError && (
        <div
          role="alert"
          className="rounded-xl border border-destructive/40 bg-destructive/10 p-4 text-xs text-destructive"
        >
          <p className="font-semibold">Tool execution is unavailable</p>
          <p className="mt-1 leading-relaxed">{configError}</p>
        </div>
      )}

      {/* Registry grouped by tier */}
      {isLoading ? (
        <Card className="alpha-panel border-0" aria-hidden>
          <CardContent className="space-y-2 p-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-12 animate-pulse rounded-lg bg-muted/50" />
            ))}
          </CardContent>
        </Card>
      ) : (
        (['low', 'medium', 'high'] as Permission[]).map((perm) => (
          <Card key={perm} className="alpha-panel border-0">
            <CardHeader className="border-b border-border/60 py-3">
              <CardTitle className="flex items-center gap-2 text-sm capitalize">
                {perm} permission
                <Badge variant="outline" className={cn('text-[10px]', PERMISSION_COLORS[perm])}>
                  {byPermission[perm].length}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-3">
              {byPermission[perm].length === 0 ? (
                <p className="px-2 py-4 text-center text-xs text-muted-foreground">
                  No tools in this permission tier.
                </p>
              ) : (
                <div className="flex flex-col gap-1">
                  {byPermission[perm].map((t) => (
                    <div
                      key={t.name}
                      className="flex items-start gap-3 rounded-lg p-2 transition-colors hover:bg-accent/5"
                    >
                      <Badge variant="outline" className="mt-0.5 shrink-0 font-mono text-[10px]">
                        {t.name}
                      </Badge>
                      <p className="flex-1 text-xs leading-relaxed">{t.description}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        ))
      )}

      {/* Try a tool */}
      <Card className="alpha-panel border-0">
        <CardHeader className="border-b border-border/60 py-3">
          <CardTitle className="flex items-center gap-2 text-sm">
            <Play className="size-4 text-accent" aria-hidden /> Try a tool
          </CardTitle>
          <CardDescription className="text-xs">
            Pick a tool, edit the args JSON, execute. Medium and high permission
            tools ask for confirmation first.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3 p-4">
          <div className="flex flex-col gap-3 sm:flex-row">
            <div className="min-w-0 flex-1">
              <Label htmlFor="tool-select" className="text-xs text-muted-foreground">
                Tool
              </Label>
              <Select value={toolName} onValueChange={selectTool}>
                <SelectTrigger id="tool-select" className="mt-1 w-full">
                  <SelectValue placeholder={tools.length === 0 ? 'No tools available' : 'Select a tool'} />
                </SelectTrigger>
                <SelectContent>
                  {tools.map((t) => (
                    <SelectItem key={t.name} value={t.name}>
                      {t.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="shrink-0">
              <Label className="text-xs text-muted-foreground">Permission</Label>
              <div className="mt-1 flex h-9 items-center">
                {activeTool ? (
                  <Badge variant="outline" className={cn('capitalize', PERMISSION_COLORS[activeTool.permission])}>
                    {activeTool.permission}
                  </Badge>
                ) : (
                  <span className="text-xs text-muted-foreground">—</span>
                )}
              </div>
            </div>
          </div>
          <div>
            <Label htmlFor="tool-args" className="text-xs text-muted-foreground">
              Args (JSON)
            </Label>
            <Textarea
              id="tool-args"
              value={argsText}
              onChange={(e) => setArgsText(e.target.value)}
              className="mt-1 min-h-[120px] font-mono text-xs"
              spellCheck={false}
              disabled={running || !activeTool}
            />
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="min-w-0 flex-1 text-xs text-muted-foreground">
              {activeTool?.description ?? 'Tool descriptions appear here.'}
            </p>
            <Button
              onClick={tryExecute}
              disabled={running || !activeTool || !toolName}
              className="gap-2"
            >
              {running ? (
                <Loader2 className="size-4 animate-spin" aria-hidden />
              ) : (
                <Play className="size-4" aria-hidden />
              )}
              Execute
            </Button>
          </div>
          {result && (
            <div
              className={cn(
                'rounded-lg border p-3',
                result.ok ? 'border-border/60 bg-muted/30' : 'border-destructive/40 bg-destructive/10',
              )}
            >
              <p className="mb-2 text-xs font-medium text-muted-foreground">
                {result.ok ? 'Result' : 'Error'}
              </p>
              <pre className="max-h-64 overflow-auto alpha-scroll text-xs leading-relaxed">
                {result.ok ? JSON.stringify(result.data, null, 2) : result.message}
              </pre>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Confirmation dialog (409 requiresConfirmation) */}
      <Dialog open={!!pending} onOpenChange={(o) => !o && setPending(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirm tool execution</DialogTitle>
            <DialogDescription>
              This tool can create or change your data. Review the arguments
              before it runs.
            </DialogDescription>
          </DialogHeader>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="font-mono text-[10px]">
              {pending?.name}
            </Badge>
            {pending && (
              <Badge
                variant="outline"
                className={cn(
                  'capitalize',
                  PERMISSION_COLORS[tools.find((t) => t.name === pending.name)?.permission ?? 'medium'],
                )}
              >
                {tools.find((t) => t.name === pending.name)?.permission ?? 'medium'}
              </Badge>
            )}
          </div>
          <pre className="max-h-40 overflow-auto alpha-scroll rounded-lg border border-border/60 bg-muted/30 p-2 text-xs">
            {JSON.stringify(pending?.args ?? {}, null, 2)}
          </pre>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setPending(null)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (pending) {
                  const { name, args } = pending
                  setPending(null)
                  void execute(name, args, true)
                }
              }}
              className="gap-2"
            >
              <Play className="size-4" aria-hidden /> Confirm &amp; execute
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  )
}
