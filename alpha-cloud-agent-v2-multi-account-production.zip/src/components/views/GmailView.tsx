'use client'

import * as React from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import {
  AlertTriangle,
  Check,
  Inbox,
  Info,
  Loader2,
  Mail,
  PenLine,
  RefreshCw,
  Search,
  Send,
  Unplug,
} from 'lucide-react'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import {
  api,
  ApiError,
  type ConnectedAccountInfo,
  type GmailMessageDetail,
  type GmailMessageSummary,
  type IntegrationInfo,
} from '@/lib/api'
import { EmptyState } from '@/components/common/EmptyState'
import { Skeleton } from '@/components/common/Skeletons'

// ============================================================
// Gmail — real Google OAuth, MULTI-ACCOUNT (never simulated).
// Every connected Google account is listed and manageable:
// set the default ("Use"), reconnect expired grants per
// account, disconnect single accounts (others untouched).
// Search / detail / send always name the account they use —
// never silently the wrong one. Mail is fetched only when the
// user asks; send always requires an explicit confirmation
// naming the sending account (consequential action).
// ============================================================

const CONNECT_HREF = '/api/v1/integrations/google/connect'

/** Relative date for list rows ("3h ago"), locale-short for older. */
function formatMailDate(value: string | null): string {
  if (!value) return ''
  const t = Date.parse(value)
  if (Number.isNaN(t)) return ''
  const diff = Date.now() - t
  if (diff < 60_000) return 'just now'
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}h ago`
  if (diff < 7 * 86_400_000) return `${Math.floor(diff / 86_400_000)}d ago`
  return new Date(t).toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  })
}

/** Only server-provided sanitized messages reach the UI. */
function sanitizedError(e: unknown, fallback: string): string {
  if (e instanceof ApiError) return e.message
  return fallback
}

export function GmailView() {
  const queryClient = useQueryClient()

  // ---------- Integration status ----------
  const integrationsQuery = useQuery({
    queryKey: ['integrations'],
    queryFn: () => api.get<{ integrations: IntegrationInfo[] }>('/api/v1/integrations'),
  })
  const gmail = integrationsQuery.data?.integrations.find((i) => i.id === 'gmail')

  // ---------- Multi-account state ----------
  const accounts = React.useMemo(() => gmail?.accounts ?? [], [gmail])

  // Runtime 401 marks (lost access mid-session) — PER ACCOUNT now.
  const [reauthAccountIds, setReauthAccountIds] = React.useState<ReadonlySet<string>>(
    () => new Set<string>(),
  )
  const reauthToastedRef = React.useRef(false)
  const handleReauth = React.useCallback(
    (accountId?: string) => {
      if (accountId) {
        setReauthAccountIds((prev) => {
          if (prev.has(accountId)) return prev
          const next = new Set(prev)
          next.add(accountId)
          return next
        })
      }
      if (!reauthToastedRef.current) {
        reauthToastedRef.current = true
        toast.error('Gmail needs reauthorization', {
          description:
            'Alpha lost access to that Google account — reconnect it to continue.',
        })
      }
      void queryClient.invalidateQueries({ queryKey: ['integrations'] })
    },
    [queryClient],
  )

  const usableAccounts = React.useMemo(
    () =>
      accounts.filter(
        (a) => a.status === 'connected' && !reauthAccountIds.has(a.id),
      ),
    [accounts, reauthAccountIds],
  )

  const notConfigured = !!gmail && !gmail.configured
  const hasAccounts = accounts.length > 0
  // View-level banner ONLY when every connected account needs reauth
  // (no usable account left). Single expired grants are per-row.
  const allReauth = hasAccounts && usableAccounts.length === 0
  const connected = usableAccounts.length > 0

  // The account THIS view uses for search/detail/send. Independent of
  // the provider default — switching here never changes the default.
  const [selectedAccountId, setSelectedAccountId] = React.useState<string | null>(null)

  // Never reference a dead id (e.g. after disconnecting the selection).
  React.useEffect(() => {
    if (selectedAccountId !== null && !accounts.some((a) => a.id === selectedAccountId)) {
      setSelectedAccountId(null)
    }
  }, [accounts, selectedAccountId])

  const activeAccount = React.useMemo(() => {
    if (usableAccounts.length === 0) return null
    if (selectedAccountId !== null) {
      const explicit = usableAccounts.find((a) => a.id === selectedAccountId)
      if (explicit) return explicit
    }
    const def = usableAccounts.find((a) => a.id === gmail?.defaultAccountId)
    if (def) return def
    return usableAccounts[0]
  }, [usableAccounts, selectedAccountId, gmail?.defaultAccountId])

  // ---------- Account mutations ----------
  const setDefaultMutation = useMutation({
    mutationFn: (account: ConnectedAccountInfo) =>
      api.post<{ account: { id: string; accountName: string | null } }>(
        `/api/v1/integrations/accounts/${encodeURIComponent(account.id)}/default`,
      ),
    onSuccess: async (_data, account) => {
      toast.success('Default Google account set', {
        description: account.accountName ?? 'The selected account is now the default.',
      })
      await queryClient.invalidateQueries({ queryKey: ['integrations'] })
    },
    onError: (e) => toast.error(sanitizedError(e, 'Could not set the default account')),
  })

  const [disconnectTarget, setDisconnectTarget] =
    React.useState<ConnectedAccountInfo | null>(null)
  const disconnectMutation = useMutation({
    mutationFn: (account: ConnectedAccountInfo) =>
      api.delete<{ ok: boolean; promotedDefaultId: string | null }>(
        `/api/v1/integrations/accounts/${encodeURIComponent(account.id)}`,
      ),
    onSuccess: async (_data, account) => {
      toast.success(`Disconnected ${account.accountName ?? 'Google account'}`)
      setDisconnectTarget(null)
      await queryClient.invalidateQueries({ queryKey: ['integrations'] })
    },
    onError: (e) => toast.error(sanitizedError(e, 'Could not disconnect that account')),
  })

  // ---------- Mail search (fetch only when the user asks) ----------
  const [searchText, setSearchText] = React.useState('')
  const [executedQuery, setExecutedQuery] = React.useState<string | null>(null)

  // Which account a request ACTUALLY used — 401s must mark THAT one.
  const queriedAccountIdRef = React.useRef<string | null>(null)

  const mailQuery = useQuery({
    queryKey: ['gmail', 'messages', executedQuery, activeAccount?.id ?? null],
    queryFn: async () => {
      const id = activeAccount?.id
      if (!id) throw new ApiError(0, 'No Google account selected')
      queriedAccountIdRef.current = id
      return api.get<{
        messages: GmailMessageSummary[]
        account: { id: string; accountName: string | null }
      }>(
        `/api/v1/gmail/messages?${
          executedQuery ? `q=${encodeURIComponent(executedQuery)}&` : ''
        }max=15&accountId=${encodeURIComponent(id)}`,
      )
    },
    // Switching accounts re-runs the current search for that account.
    enabled: executedQuery !== null && activeAccount !== null,
    retry: false,
  })
  const messages = mailQuery.data?.messages ?? []

  const mailError = mailQuery.error
  React.useEffect(() => {
    if (mailError instanceof ApiError && mailError.status === 401) {
      handleReauth(queriedAccountIdRef.current ?? undefined)
    }
  }, [mailError, handleReauth])

  function runSearch(q: string) {
    setExecutedQuery(q)
  }

  // ---------- Message detail ----------
  const [openMessageId, setOpenMessageId] = React.useState<string | null>(null)
  const detailQuery = useQuery({
    queryKey: ['gmail', 'message', openMessageId, activeAccount?.id ?? null],
    queryFn: async () => {
      const id = openMessageId
      const accountId = activeAccount?.id
      if (!id) throw new ApiError(0, 'No message selected')
      if (!accountId) throw new ApiError(0, 'No Google account selected')
      return api.get<{ message: GmailMessageDetail }>(
        `/api/v1/gmail/messages/${encodeURIComponent(id)}?accountId=${encodeURIComponent(
          accountId,
        )}`,
      )
    },
    enabled: openMessageId !== null && activeAccount !== null,
    retry: false,
  })

  // ---------- Compose + consequential send ----------
  const [composeOpen, setComposeOpen] = React.useState(false)
  const [to, setTo] = React.useState('')
  const [subject, setSubject] = React.useState('')
  const [body, setBody] = React.useState('')
  const [sendConfirmOpen, setSendConfirmOpen] = React.useState(false)

  const sendMutation = useMutation({
    mutationFn: () => {
      const accountId = activeAccount?.id
      if (!accountId) throw new ApiError(0, 'No Google account selected')
      return api.post<{
        ok: boolean
        account: { id: string; accountName: string | null }
      }>('/api/v1/gmail/send', {
        to: to.trim(),
        subject,
        body,
        confirmed: true,
        accountId,
      })
    },
    onSuccess: (data) => {
      toast.success('Email sent', {
        description: data.account?.accountName
          ? `Sent via ${data.account.accountName}`
          : undefined,
      })
      setSendConfirmOpen(false)
      setComposeOpen(false)
      setTo('')
      setSubject('')
      setBody('')
    },
    onError: (e) => toast.error(sanitizedError(e, 'Could not send email')),
  })

  const canSend = to.trim().length > 0 && !sendMutation.isPending

  function closeCompose(open: boolean) {
    setComposeOpen(open)
    if (!open) {
      setTo('')
      setSubject('')
      setBody('')
    }
  }

  const statusLoading =
    integrationsQuery.isLoading || (!gmail && !integrationsQuery.error)

  const countVisible =
    executedQuery !== null && !mailQuery.isFetching && !mailQuery.error

  // ============================================================
  // Render
  // ============================================================
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="flex flex-col gap-6"
    >
      {/* ---------- Google accounts card ---------- */}
      <Card className="alpha-panel border-0">
        <CardHeader className="border-b border-border/60 py-3">
          <CardTitle className="flex items-center gap-2 text-sm">
            <Mail className="size-4 text-accent" aria-hidden /> Gmail
          </CardTitle>
          <CardDescription className="text-xs">
            Search and send mail through real Google OAuth connections — multiple
            Google accounts supported.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-4 sm:p-6">
          {statusLoading ? (
            <div className="space-y-3" aria-busy="true" aria-hidden>
              <div className="flex items-center gap-4">
                <Skeleton className="size-11 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-3.5 w-40" />
                  <Skeleton className="h-2.5 w-64" />
                </div>
              </div>
              <Skeleton className="h-9 w-full rounded-lg" />
            </div>
          ) : !gmail ? (
            <div
              role="alert"
              className="flex items-start gap-2.5 rounded-lg border border-destructive/30 bg-destructive/5 p-3"
            >
              <AlertTriangle
                className="mt-0.5 size-4 shrink-0 text-destructive"
                aria-hidden
              />
              <div className="flex min-w-0 flex-1 items-center justify-between gap-3">
                <p className="text-xs leading-relaxed text-destructive">
                  {sanitizedError(
                    integrationsQuery.error,
                    'Could not load the Gmail connection status.',
                  )}
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  className="shrink-0 gap-2"
                  onClick={() => void integrationsQuery.refetch()}
                >
                  <RefreshCw className="size-3.5" aria-hidden /> Retry
                </Button>
              </div>
            </div>
          ) : notConfigured ? (
            <div className="flex flex-col items-center gap-4 text-center">
              <div className="flex size-14 items-center justify-center rounded-lg bg-accent/10 text-accent">
                <Mail className="size-7" aria-hidden />
              </div>
              <div>
                <p className="text-base font-semibold">
                  Gmail OAuth is not configured
                </p>
                <p className="mx-auto mt-1 max-w-md text-xs leading-relaxed text-muted-foreground">
                  The server is missing Google OAuth client credentials, so the
                  connect flow cannot start yet. This is an operator action —
                  nothing is wrong with your account.
                </p>
              </div>
              <div className="flex w-full max-w-xl items-start gap-2.5 rounded-lg border border-border/60 bg-muted/30 p-3 text-left">
                <Info className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden />
                <div className="min-w-0">
                  <p className="text-xs font-medium">Setup</p>
                  <p className="mt-0.5 break-words text-xs leading-relaxed text-muted-foreground">
                    {gmail.setup}
                  </p>
                </div>
              </div>
              <Tooltip>
                <TooltipTrigger asChild>
                  <span tabIndex={0} className="inline-flex">
                    <Button disabled className="gap-2" aria-disabled="true">
                      <Mail className="size-4" aria-hidden /> Connect Gmail
                    </Button>
                  </span>
                </TooltipTrigger>
                <TooltipContent>
                  Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET as Worker
                  secrets to enable this
                </TooltipContent>
              </Tooltip>
              <p className="text-[11px] text-muted-foreground">
                The connect button unlocks automatically once credentials are
                configured — no need to reinstall anything.
              </p>
            </div>
          ) : allReauth ? (
            <div className="flex flex-col items-center gap-4 text-center">
              <div className="flex size-14 items-center justify-center rounded-lg bg-accent/10 text-accent">
                <AlertTriangle className="size-7" aria-hidden />
              </div>
              <div>
                <p className="text-base font-semibold">Reauthorization needed</p>
                <p className="mx-auto mt-1 max-w-md text-xs leading-relaxed text-muted-foreground">
                  Alpha lost access to every connected Google account — the
                  grants expired or were revoked. Reconnect to restore search
                  and send.
                </p>
              </div>
              <Button asChild className="gap-2">
                <a href={CONNECT_HREF}>
                  <RefreshCw className="size-4" aria-hidden /> Reconnect
                </a>
              </Button>
            </div>
          ) : hasAccounts ? (
            <div className="flex flex-col gap-3">
              <p className="font-mono text-[11px] uppercase tracking-[0.08em] text-muted-foreground">
                Google accounts · {accounts.length} connected
              </p>
              <ul className="flex flex-col gap-2">
                {accounts.map((account) => {
                  const accountLabel = account.accountName ?? 'Google account'
                  const usePending =
                    setDefaultMutation.isPending &&
                    setDefaultMutation.variables?.id === account.id
                  const disconnectPending =
                    disconnectMutation.isPending &&
                    disconnectMutation.variables?.id === account.id
                  const needsReauth =
                    account.status === 'needs_reauthorization' ||
                    reauthAccountIds.has(account.id)
                  return (
                    <li
                      key={account.id}
                      className="flex flex-wrap items-center gap-x-3 gap-y-2.5 rounded-lg border border-border/60 p-3"
                    >
                      <Avatar className="size-9 shrink-0 border border-border/60">
                        {account.avatarUrl ? (
                          <AvatarImage
                            src={account.avatarUrl}
                            alt={`${accountLabel} avatar`}
                          />
                        ) : null}
                        <AvatarFallback className="bg-accent/15 text-accent">
                          <Mail className="size-4" aria-hidden />
                        </AvatarFallback>
                      </Avatar>
                      <div className="min-w-0 flex-1 basis-44">
                        <p className="truncate font-mono text-xs text-foreground">
                          {account.accountName ?? 'Google account'}
                        </p>
                        <p className="mt-0.5 flex min-w-0 items-center gap-1.5 text-[11px] text-muted-foreground">
                          <span
                            className={cn(
                              'alpha-status-dot shrink-0',
                              needsReauth
                                ? 'bg-amber-500 text-amber-500'
                                : 'bg-emerald-500 text-emerald-500',
                            )}
                            aria-hidden
                          />
                          <span className="truncate">
                            {needsReauth
                              ? 'needs reauthorization'
                              : 'connected'}
                            {account.lastUsedAt
                              ? ` · last used ${formatMailDate(account.lastUsedAt)}`
                              : ' · not used yet'}
                          </span>
                        </p>
                      </div>
                      <div className="flex shrink-0 flex-wrap items-center gap-2">
                        {needsReauth && (
                          <Button asChild variant="outline" size="sm" className="gap-1.5">
                            <a
                              href={CONNECT_HREF}
                              aria-label={`Reconnect ${accountLabel}`}
                            >
                              <RefreshCw className="size-3.5" aria-hidden />
                              Reconnect
                            </a>
                          </Button>
                        )}
                        {account.isDefault ? (
                          <Badge
                            variant="outline"
                            className="gap-1 border-accent/40 bg-accent/10 text-accent"
                          >
                            <Check className="size-3" aria-hidden /> Default
                          </Badge>
                        ) : (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="outline"
                                size="sm"
                                className="gap-1.5"
                                onClick={() => setDefaultMutation.mutate(account)}
                                disabled={usePending}
                                aria-label={`Use ${accountLabel} by default`}
                              >
                                {usePending ? (
                                  <Loader2
                                    className="size-3.5 animate-spin"
                                    aria-hidden
                                  />
                                ) : (
                                  <Check className="size-3.5" aria-hidden />
                                )}
                                Use
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              Use this Google account by default (chat &quot;check
                              my email&quot; uses it)
                            </TooltipContent>
                          </Tooltip>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          className="gap-1.5 text-destructive hover:bg-destructive/10 hover:text-destructive"
                          onClick={() => setDisconnectTarget(account)}
                          disabled={disconnectPending}
                          aria-label={`Disconnect ${accountLabel}`}
                        >
                          {disconnectPending ? (
                            <Loader2 className="size-3.5 animate-spin" aria-hidden />
                          ) : (
                            <Unplug className="size-3.5" aria-hidden />
                          )}
                          Disconnect
                        </Button>
                      </div>
                    </li>
                  )
                })}
              </ul>
              <Button asChild variant="outline" className="w-full gap-2 sm:w-auto">
                <a href={CONNECT_HREF}>
                  <Mail className="size-4" aria-hidden /> Connect another Google
                  account
                </a>
              </Button>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-4 text-center">
              <div className="flex size-14 items-center justify-center rounded-lg bg-accent/10 text-accent">
                <Mail className="size-7" aria-hidden />
              </div>
              <div>
                <p className="text-base font-semibold">Gmail is not connected</p>
                <p className="mx-auto mt-1 max-w-md text-xs leading-relaxed text-muted-foreground">
                  Connect requires a real Google OAuth grant — Alpha never
                  simulates a mailbox. Multiple Google accounts are supported.
                </p>
              </div>
              <Button asChild className="gap-2">
                <a href={CONNECT_HREF}>
                  <Mail className="size-4" aria-hidden /> Connect Gmail
                </a>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ---------- Mail card (only with a usable account) ---------- */}
      {connected && (
        <Card className="alpha-panel border-0">
          <CardHeader className="gap-3 border-b border-border/60 py-3">
            <div className="flex flex-wrap items-center gap-3">
              <div className="relative min-w-[180px] flex-1">
                <Search
                  className="absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground"
                  aria-hidden
                />
                <Input
                  value={searchText}
                  onChange={(e) => setSearchText(e.target.value)}
                  placeholder="Search mail…"
                  className="h-9 pl-8 text-sm"
                  aria-label="Search mail"
                />
              </div>
              <Button
                onClick={() => runSearch(searchText.trim())}
                disabled={mailQuery.isFetching}
                className="gap-2"
              >
                {mailQuery.isFetching ? (
                  <Loader2 className="size-4 animate-spin" aria-hidden />
                ) : (
                  <Search className="size-4" aria-hidden />
                )}
                Search
              </Button>
            </div>
            {(countVisible || usableAccounts.length >= 2) && (
              <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-2">
                {countVisible && (
                  <p className="min-w-0 flex-1 text-[11px] text-muted-foreground">
                    {executedQuery
                      ? `${messages.length} result${messages.length === 1 ? '' : 's'} for “${executedQuery}”`
                      : `${messages.length} recent message${messages.length === 1 ? '' : 's'}`}
                  </p>
                )}
                {usableAccounts.length >= 2 && (
                  <div className="flex min-w-0 items-center gap-2">
                    <span className="shrink-0 font-mono text-[10px] uppercase tracking-[0.08em] text-muted-foreground">
                      Using
                    </span>
                    <Select
                      value={activeAccount?.id ?? ''}
                      onValueChange={setSelectedAccountId}
                    >
                      <SelectTrigger
                        size="sm"
                        className="h-8 max-w-[220px] rounded-md border-border/60 bg-background font-mono text-xs"
                        aria-label="Google account used for search and send"
                      >
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {usableAccounts.map((a) => (
                          <SelectItem
                            key={a.id}
                            value={a.id}
                            className="font-mono text-xs"
                          >
                            {a.accountName ?? 'Google account'}
                            {a.isDefault ? ' · default' : ''}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            )}
          </CardHeader>
          <CardContent className="p-2 sm:p-4">
            {executedQuery === null ? (
              <div className="py-6">
                <EmptyState
                  icon={Inbox}
                  title="Nothing fetched yet"
                  description="Search your mailbox to fetch messages — nothing is fetched until you ask."
                  action={
                    <Button
                      variant="outline"
                      className="gap-2"
                      onClick={() => runSearch('')}
                      disabled={mailQuery.isFetching}
                    >
                      {mailQuery.isFetching ? (
                        <Loader2 className="size-4 animate-spin" aria-hidden />
                      ) : (
                        <Inbox className="size-4" aria-hidden />
                      )}
                      Load recent
                    </Button>
                  }
                />
              </div>
            ) : mailQuery.isLoading || mailQuery.isFetching ? (
              <div className="space-y-2" aria-busy="true" aria-label="Loading messages">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div
                    key={i}
                    className="space-y-1.5 rounded-lg border border-border/60 p-3"
                    aria-hidden
                  >
                    <Skeleton className="h-2.5 w-1/3" />
                    <Skeleton className="h-3.5 w-2/3" />
                    <Skeleton className="h-2.5 w-full" />
                  </div>
                ))}
              </div>
            ) : mailQuery.error ? (
              <div
                role="alert"
                className="flex items-start gap-2.5 rounded-lg border border-destructive/30 bg-destructive/5 p-3"
              >
                <AlertTriangle
                  className="mt-0.5 size-4 shrink-0 text-destructive"
                  aria-hidden
                />
                <p className="text-xs leading-relaxed text-destructive">
                  {mailQuery.error instanceof ApiError &&
                  mailQuery.error.status === 401
                    ? 'Gmail needs reauthorization — Alpha lost access to that Google account. Use Reconnect above to restore it.'
                    : sanitizedError(mailQuery.error, 'Could not load messages.')}
                </p>
              </div>
            ) : messages.length === 0 ? (
              <div className="py-6">
                <EmptyState
                  icon={Inbox}
                  title="No messages matched."
                  description="Try a different search — this mailbox returned no results."
                />
              </div>
            ) : (
              <div className="alpha-scroll max-h-[28rem] space-y-1 overflow-y-auto">
                {messages.map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setOpenMessageId(m.id)}
                    className="group flex w-full flex-col gap-1 rounded-lg border border-transparent p-3 text-left transition-colors hover:border-border/60 hover:bg-accent/5"
                  >
                    <div className="flex items-center gap-2">
                      <span className="flex size-1.5 shrink-0 items-center justify-center">
                        {m.unread ? (
                          <span
                            className="size-1.5 rounded-full bg-accent shadow-[0_0_6px] shadow-accent/60"
                            role="img"
                            aria-label="Unread"
                          />
                        ) : null}
                      </span>
                      <span
                        className={cn(
                          'min-w-0 flex-1 truncate text-xs',
                          m.unread
                            ? 'font-semibold text-foreground'
                            : 'text-muted-foreground',
                        )}
                      >
                        {m.from}
                      </span>
                      <span className="shrink-0 text-[10px] text-muted-foreground">
                        {formatMailDate(m.date)}
                      </span>
                    </div>
                    <p
                      className={cn(
                        'truncate text-sm',
                        m.unread ? 'font-semibold' : 'font-medium',
                      )}
                    >
                      {m.subject || '(no subject)'}
                    </p>
                    <p className="line-clamp-2 text-xs leading-relaxed text-muted-foreground">
                      {m.snippet}
                    </p>
                  </button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* ---------- Compose card (only with a usable account) ---------- */}
      {connected && (
        <Card className="alpha-panel border-0">
          <CardHeader className="border-b border-border/60 py-3">
            <CardTitle className="text-sm">Compose</CardTitle>
            <CardDescription className="text-xs">
              Send a real email — every send asks for a confirmation naming the
              exact sending account first.
            </CardDescription>
          </CardHeader>
          <CardContent className="p-4 sm:p-6">
            <Button onClick={() => setComposeOpen(true)} className="gap-2">
              <PenLine className="size-4" aria-hidden /> Compose
            </Button>
          </CardContent>
        </Card>
      )}

      {/* ---------- Message detail dialog ---------- */}
      <Dialog
        open={openMessageId !== null}
        onOpenChange={(o) => !o && setOpenMessageId(null)}
      >
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-left text-base">
              {detailQuery.data?.message.subject || '(no subject)'}
            </DialogTitle>
            <DialogDescription className="text-left">
              Full message from your connected Gmail account.
            </DialogDescription>
          </DialogHeader>
          {detailQuery.isLoading ? (
            <div className="space-y-2" aria-busy="true" aria-label="Loading message">
              <Skeleton className="h-3 w-2/3" />
              <Skeleton className="h-3 w-1/2" />
              <Skeleton className="h-40 w-full rounded-lg" />
            </div>
          ) : detailQuery.error ? (
            <div
              role="alert"
              className="flex items-start gap-2.5 rounded-lg border border-destructive/30 bg-destructive/5 p-3"
            >
              <AlertTriangle
                className="mt-0.5 size-4 shrink-0 text-destructive"
                aria-hidden
              />
              <p className="text-xs leading-relaxed text-destructive">
                {sanitizedError(detailQuery.error, 'Could not load this message.')}
              </p>
            </div>
          ) : detailQuery.data ? (
            <div className="flex flex-col gap-4">
              <dl className="grid grid-cols-[4.5rem_1fr] gap-x-3 gap-y-1.5 text-xs">
                <dt className="text-muted-foreground">From</dt>
                <dd className="min-w-0 break-words">{detailQuery.data.message.from}</dd>
                <dt className="text-muted-foreground">To</dt>
                <dd className="min-w-0 break-words">{detailQuery.data.message.to}</dd>
                {detailQuery.data.message.date && (
                  <>
                    <dt className="text-muted-foreground">Date</dt>
                    <dd>
                      {new Date(detailQuery.data.message.date).toLocaleString()}
                    </dd>
                  </>
                )}
                {detailQuery.data.message.unread && (
                  <>
                    <dt className="text-muted-foreground">Status</dt>
                    <dd className="flex items-center gap-1.5">
                      <span className="size-1.5 rounded-full bg-accent" aria-hidden />
                      Unread
                    </dd>
                  </>
                )}
              </dl>
              <div className="alpha-scroll max-h-[60vh] overflow-y-auto whitespace-pre-wrap break-words rounded-lg border border-border/60 bg-muted/20 p-4 text-sm leading-relaxed">
                {detailQuery.data.message.body || '(empty body)'}
              </div>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>

      {/* ---------- Compose dialog ---------- */}
      <Dialog open={composeOpen} onOpenChange={closeCompose}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Compose email</DialogTitle>
            <DialogDescription>
              Sent from{' '}
              <span className="font-mono text-xs text-foreground">
                {activeAccount?.accountName ?? 'your selected Google account'}
              </span>{' '}
              — a confirmation step follows before anything is delivered.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-4">
            <div>
              <Label htmlFor="gmail-to" className="text-xs text-muted-foreground">
                To
              </Label>
              <Input
                id="gmail-to"
                type="email"
                value={to}
                onChange={(e) => setTo(e.target.value)}
                placeholder="recipient@example.com"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="gmail-subject" className="text-xs text-muted-foreground">
                Subject
              </Label>
              <Input
                id="gmail-subject"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Subject"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="gmail-body" className="text-xs text-muted-foreground">
                Body
              </Label>
              <Textarea
                id="gmail-body"
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="Write your message…"
                className="mt-1 min-h-[160px] resize-none"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => closeCompose(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => setSendConfirmOpen(true)}
              disabled={!canSend}
              className="gap-2"
            >
              <Send className="size-4" aria-hidden /> Send
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ---------- Send confirmation (consequential — names the sender) ---------- */}
      <AlertDialog open={sendConfirmOpen} onOpenChange={setSendConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Send this email to {to.trim()}?</AlertDialogTitle>
            <AlertDialogDescription>
              This sends a real email — it cannot be unsent once delivered.
              Please confirm the sending account below.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex items-center gap-3 rounded-lg border border-accent/40 bg-accent/5 p-3">
            <Avatar className="size-8 shrink-0 border border-border/60">
              {activeAccount?.avatarUrl ? (
                <AvatarImage
                  src={activeAccount.avatarUrl}
                  alt={`${activeAccount.accountName ?? 'Google account'} avatar`}
                />
              ) : null}
              <AvatarFallback className="bg-accent/15 text-accent">
                <Mail className="size-4" aria-hidden />
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <p className="font-mono text-[10px] uppercase tracking-[0.08em] text-muted-foreground">
                Send from
              </p>
              <p className="truncate font-mono text-xs text-foreground">
                {activeAccount?.accountName ?? 'your selected Google account'}
              </p>
            </div>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={sendMutation.isPending}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={sendMutation.isPending}
              onClick={(e) => {
                e.preventDefault()
                sendMutation.mutate()
              }}
              className="gap-2"
            >
              {sendMutation.isPending ? (
                <Loader2 className="size-4 animate-spin" aria-hidden />
              ) : (
                <Send className="size-4" aria-hidden />
              )}
              Send
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ---------- Disconnect confirmation (names the EXACT account) ---------- */}
      <AlertDialog
        open={disconnectTarget !== null}
        onOpenChange={(o) => !o && setDisconnectTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Disconnect{' '}
              {disconnectTarget?.accountName ?? 'this Google account'}?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Alpha loses access to{' '}
              <span className="font-mono">
                {disconnectTarget?.accountName ?? 'this account'}
              </span>{' '}
              — its tokens are revoked and deleted.
              {disconnectTarget &&
              accounts.some((a) => a.id !== disconnectTarget.id)
                ? ' Your other connected Google accounts are untouched.'
                : ''}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={disconnectMutation.isPending}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              disabled={disconnectMutation.isPending}
              onClick={(e) => {
                e.preventDefault()
                if (disconnectTarget) disconnectMutation.mutate(disconnectTarget)
              }}
              className="gap-2 bg-destructive text-white hover:bg-destructive/90"
            >
              {disconnectMutation.isPending ? (
                <Loader2 className="size-4 animate-spin" aria-hidden />
              ) : (
                <Unplug className="size-4" aria-hidden />
              )}
              Disconnect
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  )
}
