'use client'

import * as React from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Plus,
  Search,
  Trash2,
  Pin,
  Pencil,
  BrainCircuit,
  Loader2,
} from 'lucide-react'
import { api } from '@/lib/api'
import type { Memory } from '@/lib/api'
import {
  Card,
  CardContent,
  CardHeader,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { EmptyState } from '@/components/common/EmptyState'
import { MemoryCardsSkeleton } from '@/components/common/Skeletons'

interface MemoryForm {
  content: string
  category: string
  confidence: number
  pinned: boolean
}

/** Friendly label for a memory's origin — unknown values render verbatim. */
function sourceLabel(source: string): string {
  if (source === 'manual') return 'manual'
  if (source === 'ai') return 'learned'
  return source
}

export function MemoryView() {
  const queryClient = useQueryClient()
  const [category, setCategory] = React.useState('all')
  const [search, setSearch] = React.useState('')
  const [addOpen, setAddOpen] = React.useState(false)
  const [editId, setEditId] = React.useState<string | null>(null)
  const [deleteId, setDeleteId] = React.useState<string | null>(null)
  const [saving, setSaving] = React.useState(false)
  const [form, setForm] = React.useState<MemoryForm>({
    content: '',
    category: 'other',
    confidence: 1,
    pinned: false,
  })

  // Real memories + the REAL category list from the server.
  const { data, isLoading } = useQuery({
    queryKey: ['memory', category, search],
    queryFn: () => {
      const params = new URLSearchParams()
      if (category !== 'all') params.set('category', category)
      if (search) params.set('q', search)
      const qs = params.toString()
      return api.get<{ memories: Memory[]; categories: string[] }>(
        qs ? `/api/v1/memory?${qs}` : '/api/v1/memory',
      )
    },
  })
  const memories = data?.memories ?? []
  const categories = data?.categories ?? []

  function openAdd() {
    setEditId(null)
    setForm({
      content: '',
      category: categories[0] ?? 'other',
      confidence: 1,
      pinned: false,
    })
    setAddOpen(true)
  }

  function openEdit(m: Memory) {
    setEditId(m.id)
    setForm({
      content: m.content,
      category: m.category,
      confidence: m.confidence,
      pinned: m.pinned,
    })
    setAddOpen(true)
  }

  async function save() {
    if (!form.content.trim() || saving) {
      if (!form.content.trim()) toast.error('Content required')
      return
    }
    setSaving(true)
    try {
      if (editId) {
        await api.patch(`/api/v1/memory/${editId}`, {
          content: form.content.trim(),
          category: form.category,
          confidence: form.confidence,
          pinned: form.pinned,
        })
        toast.success('Memory updated')
      } else {
        await api.post('/api/v1/memory', {
          content: form.content.trim(),
          category: form.category,
          confidence: form.confidence,
          pinned: form.pinned,
        })
        toast.success('Memory added')
      }
      await queryClient.invalidateQueries({ queryKey: ['memory'] })
      setAddOpen(false)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to save')
    } finally {
      setSaving(false)
    }
  }

  async function togglePin(m: Memory) {
    try {
      await api.patch(`/api/v1/memory/${m.id}`, { pinned: !m.pinned })
      await queryClient.invalidateQueries({ queryKey: ['memory'] })
    } catch {
      toast.error('Failed to toggle pin')
    }
  }

  async function confirmDelete() {
    if (!deleteId) return
    try {
      await api.delete(`/api/v1/memory/${deleteId}`)
      await queryClient.invalidateQueries({ queryKey: ['memory'] })
      toast.success('Memory deleted')
    } catch {
      toast.error('Failed to delete')
    } finally {
      setDeleteId(null)
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <Card className="alpha-panel border-0">
        <CardContent className="flex items-start gap-3 p-4">
          <BrainCircuit className="size-5 shrink-0 text-accent" />
          <div>
            <p className="text-sm font-medium">Alpha stores important persistent info here.</p>
            <p className="text-xs text-muted-foreground">
              You control what&apos;s kept. Alpha reads this memory when chatting with
              you, and can add new memories from conversations.
            </p>
          </div>
        </CardContent>
      </Card>

      <Card className="alpha-panel border-0">
        <CardHeader className="border-b border-border/60 py-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <Tabs value={category} onValueChange={setCategory}>
              <TabsList className="h-auto flex-wrap">
                <TabsTrigger value="all" className="text-xs">
                  All
                </TabsTrigger>
                {categories.map((c) => (
                  <TabsTrigger key={c} value={c} className="text-xs capitalize">
                    {c}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Filter…"
                  className="h-9 w-32 pl-8 text-xs sm:w-48"
                  aria-label="Filter memories"
                />
              </div>
              <Button onClick={openAdd} className="gap-2">
                <Plus className="size-4" /> Add memory
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <Card className="alpha-panel border-0">
        <CardContent className="p-4 sm:p-6">
          {isLoading ? (
            <MemoryCardsSkeleton />
          ) : memories.length === 0 ? (
            <EmptyState
              icon={BrainCircuit}
              title="No memories stored"
              description="Alpha will remember facts you save here — preferences, people, projects, decisions. It can also learn from your chats."
              action={
                <Button onClick={openAdd} className="gap-2">
                  <Plus className="size-4" /> Add memory
                </Button>
              }
            />
          ) : (
            <div className="grid gap-2">
              {memories.map((m) => (
                <div
                  key={m.id}
                  className="alpha-memory-card flex flex-col gap-2 rounded-md border border-border/60 bg-card/40 p-3"
                >
                  <div className="flex items-start gap-3">
                    <button
                      onClick={() => void togglePin(m)}
                      aria-label={m.pinned ? 'Unpin memory' : 'Pin memory'}
                      aria-pressed={m.pinned}
                      className="mt-0.5 rounded p-0.5 transition-colors hover:bg-accent/10"
                    >
                      <Pin
                        className={cn(
                          'size-3.5 shrink-0 transition-colors',
                          m.pinned ? 'text-accent' : 'text-muted-foreground/50',
                        )}
                        fill={m.pinned ? 'currentColor' : 'none'}
                      />
                    </button>
                    <p className="flex-1 text-sm">{m.content}</p>
                    <div className="flex items-center gap-1">
                      <Button
                        size="icon"
                        variant="ghost"
                        className="size-7"
                        onClick={() => openEdit(m)}
                        aria-label="Edit memory"
                      >
                        <Pencil className="size-3.5" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="size-7 text-destructive"
                        onClick={() => setDeleteId(m.id)}
                        aria-label="Delete memory"
                      >
                        <Trash2 className="size-3.5" />
                      </Button>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 pl-6">
                    <Badge
                      variant="outline"
                      className="rounded-md text-[10px] capitalize"
                    >
                      {m.category}
                    </Badge>
                    <Badge
                      variant="outline"
                      className="rounded-md px-1.5 font-mono text-[9px] uppercase tracking-[0.06em] text-muted-foreground"
                    >
                      {sourceLabel(m.source)}
                    </Badge>
                    <div className="ml-2 flex items-center gap-1">
                      <span className="text-[10px] text-muted-foreground">confidence</span>
                      <div className="h-1 w-16 overflow-hidden rounded-full bg-muted">
                        <div
                          className="alpha-confidence-bar h-full bg-accent"
                          style={{ width: `${Math.round(m.confidence * 100)}%` }}
                        />
                      </div>
                      <span className="text-[10px] text-muted-foreground">
                        {Math.round(m.confidence * 100)}%
                      </span>
                    </div>
                    <span className="ml-auto font-mono text-[9px] uppercase tracking-[0.04em] text-muted-foreground">
                      {new Date(m.updatedAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add/edit dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editId ? 'Edit memory' : 'Add memory'}</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4">
            <div className="flex flex-col gap-2">
              <Label htmlFor="memory-content">Content</Label>
              <Textarea
                id="memory-content"
                value={form.content}
                onChange={(e) => setForm((f) => ({ ...f, content: e.target.value }))}
                placeholder="e.g. I prefer dark-first UI and concise answers."
                className="min-h-[80px]"
                maxLength={2000}
              />
            </div>
            <div className="flex flex-col gap-2">
              <Label>Category</Label>
              <div className="mt-1 flex flex-wrap gap-1">
                {categories.map((c) => (
                  <button
                    key={c}
                    onClick={() => setForm((f) => ({ ...f, category: c }))}
                    className={cn(
                      'rounded-md border px-2.5 py-1 text-xs capitalize transition-colors',
                      form.category === c
                        ? 'border-accent bg-accent/15 text-accent'
                        : 'border-border/70 hover:bg-accent/10',
                    )}
                    aria-pressed={form.category === c}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <Label>Confidence: {Math.round(form.confidence * 100)}%</Label>
              <Slider
                value={[form.confidence]}
                min={0.1}
                max={1}
                step={0.05}
                onValueChange={(v) => setForm((f) => ({ ...f, confidence: v[0] }))}
                aria-label="Memory confidence"
              />
            </div>
            <div className="flex items-center justify-between gap-2">
              <Label htmlFor="memory-pinned" className="text-xs">
                Pin this memory (always surfaces first)
              </Label>
              <Switch
                id="memory-pinned"
                checked={form.pinned}
                onCheckedChange={(pinned) => setForm((f) => ({ ...f, pinned }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setAddOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => void save()} disabled={saving} className="gap-2">
              {saving ? <Loader2 className="size-4 animate-spin" /> : null}
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this memory?</AlertDialogTitle>
            <AlertDialogDescription>
              Alpha will no longer recall this fact in conversations. This
              cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => void confirmDelete()}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
