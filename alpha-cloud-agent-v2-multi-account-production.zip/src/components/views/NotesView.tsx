'use client'

import * as React from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Plus,
  Search,
  Trash2,
  Download,
  Pencil,
  Eye,
  PencilLine,
  Pin,
  Loader2,
} from 'lucide-react'
import { api } from '@/lib/api'
import type { Note } from '@/lib/api'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { Markdown } from '@/components/common/Markdown'
import { EmptyState } from '@/components/common/EmptyState'
import { NotesListSkeleton } from '@/components/common/Skeletons'

export function NotesView() {
  const queryClient = useQueryClient()
  const [search, setSearch] = React.useState('')
  const [selectedId, setSelectedId] = React.useState<string | null>(null)
  const [draftOpen, setDraftOpen] = React.useState(false) // blank editor for a NEW note
  const [title, setTitle] = React.useState('')
  const [content, setContent] = React.useState('')
  const [pinned, setPinned] = React.useState(false)
  const [mode, setMode] = React.useState<'edit' | 'preview'>('edit')
  const [saving, setSaving] = React.useState(false)
  const [deleteId, setDeleteId] = React.useState<string | null>(null)

  // Real search — server-side LIKE over title + content.
  const { data: notesData, isLoading } = useQuery({
    queryKey: ['notes', search],
    queryFn: () =>
      api.get<{ notes: Note[] }>(
        search ? `/api/v1/notes?q=${encodeURIComponent(search)}` : '/api/v1/notes',
      ),
  })
  const notes = notesData?.notes ?? []

  // Pick pending note id from Home / command palette.
  React.useEffect(() => {
    const pendingId = sessionStorage.getItem('alpha:open-note')
    if (pendingId) {
      sessionStorage.removeItem('alpha:open-note')
      setSelectedId(pendingId)
      setDraftOpen(false)
    }
  }, [])

  // Load the selected note into the editor.
  React.useEffect(() => {
    const n = notes.find((x) => x.id === selectedId)
    if (n) {
      setTitle(n.title)
      setContent(n.content)
      setPinned(n.pinned)
    }
  }, [selectedId, notes])

  function openNote(n: Note) {
    setSelectedId(n.id)
    setDraftOpen(false)
    setMode('edit')
  }

  function openDraft() {
    setSelectedId(null)
    setDraftOpen(true)
    setTitle('')
    setContent('')
    setPinned(false)
    setMode('edit')
  }

  async function save() {
    if (saving) return
    if (!title.trim()) {
      toast.error('Title required')
      return
    }
    setSaving(true)
    try {
      if (selectedId) {
        await api.patch(`/api/v1/notes/${selectedId}`, { title, content, pinned })
      } else {
        const data = await api.post<{ note: Note }>('/api/v1/notes', {
          title,
          content,
          pinned,
        })
        setSelectedId(data.note.id)
        setDraftOpen(false)
      }
      await queryClient.invalidateQueries({ queryKey: ['notes'] })
      toast.success('Note saved')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to save')
    } finally {
      setSaving(false)
    }
  }

  function downloadTxt() {
    const blob = new Blob([`# ${title}\n\n${content}`], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${title.replace(/[^a-zA-Z0-9._-]+/g, '_') || 'note'}.txt`
    a.click()
    URL.revokeObjectURL(url)
  }

  async function confirmDelete() {
    if (!deleteId) return
    try {
      await api.delete(`/api/v1/notes/${deleteId}`)
      if (selectedId === deleteId) {
        setSelectedId(null)
        setDraftOpen(false)
        setTitle('')
        setContent('')
      }
      await queryClient.invalidateQueries({ queryKey: ['notes'] })
      toast.success('Note deleted')
    } catch {
      toast.error('Failed to delete note')
    } finally {
      setDeleteId(null)
    }
  }

  const wordCount = content.trim() ? content.trim().split(/\s+/).length : 0
  const selectedNote = notes.find((n) => n.id === selectedId)
  const editorVisible = draftOpen || !!selectedId

  return (
    <div className="flex h-full min-h-[calc(100vh-180px)] flex-col gap-4 md:flex-row">
      {/* List */}
      <Card className="flex w-full flex-col alpha-panel border-0 md:w-80">
        <CardHeader className="border-b border-border/60 pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm">Notes</CardTitle>
            <Button size="sm" onClick={openDraft} className="h-7 gap-1">
              <Plus className="size-3.5" /> New
            </Button>
          </div>
          <div className="relative mt-2">
            <Search className="absolute left-2 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search notes…"
              className="h-8 pl-7 text-xs"
              aria-label="Search notes"
            />
          </div>
        </CardHeader>
        <CardContent className="min-h-0 flex-1 overflow-hidden p-0">
          <div className="alpha-scroll max-h-72 overflow-y-auto p-2 md:max-h-[calc(100vh-280px)]">
            {isLoading ? (
              <NotesListSkeleton />
            ) : notes.length === 0 ? (
              <p className="px-2 py-6 text-center text-xs text-muted-foreground">
                {search ? 'No notes match your search.' : 'No notes yet.'}
              </p>
            ) : (
              notes.map((n) => (
                <button
                  key={n.id}
                  onClick={() => openNote(n)}
                  className={cn(
                    'alpha-note-card group flex w-full flex-col gap-1 rounded-lg p-2 text-left',
                    selectedId === n.id ? 'alpha-conv-active' : 'hover:bg-accent/10',
                  )}
                >
                  <div className="flex items-center gap-2">
                    {n.pinned && <Pin className="size-3 shrink-0 text-accent" fill="currentColor" />}
                    <span className="flex-1 truncate text-xs font-medium">{n.title}</span>
                  </div>
                  <p className="truncate text-[10px] text-muted-foreground">
                    {n.content || 'Empty note'}
                  </p>
                  <p className="text-[10px] text-muted-foreground">
                    {new Date(n.updatedAt).toLocaleString()}
                  </p>
                </button>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Editor */}
      <Card className="flex min-w-0 flex-1 flex-col alpha-panel border-0">
        <CardHeader className="border-b border-border/60 py-3">
          <div className="flex items-center justify-between gap-2">
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Note title"
              aria-label="Note title"
              className="border-0 bg-transparent px-0 text-base font-semibold shadow-none focus-visible:ring-0"
              disabled={!editorVisible}
            />
            <div className="flex items-center gap-1">
              <Button
                size="sm"
                variant={mode === 'edit' ? 'default' : 'ghost'}
                onClick={() => setMode('edit')}
                className="h-7"
                aria-pressed={mode === 'edit'}
              >
                <Pencil className="size-3.5" /> Edit
              </Button>
              <Button
                size="sm"
                variant={mode === 'preview' ? 'default' : 'ghost'}
                onClick={() => setMode('preview')}
                className="h-7"
                aria-pressed={mode === 'preview'}
              >
                <Eye className="size-3.5" /> Preview
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="min-h-0 flex-1 overflow-hidden p-0">
          {!editorVisible ? (
            <div className="flex h-full items-center justify-center">
              <EmptyState
                icon={PencilLine}
                title="Pick a note or create a new one"
                description="Your notes are markdown-capable. Alpha can also create notes for you from Chat — just ask."
                action={
                  <Button onClick={openDraft} className="gap-2">
                    <Plus className="size-4" /> New note
                  </Button>
                }
              />
            </div>
          ) : (
            <div className="alpha-scroll max-h-[calc(100vh-380px)] overflow-y-auto p-4 sm:p-6 md:max-h-[calc(100vh-280px)]">
              {mode === 'edit' ? (
                <Textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Write in Markdown. Use # for headings, - for bullets, ``` for code…"
                  aria-label="Note content"
                  className="min-h-[300px] resize-none border-0 bg-transparent p-0 font-mono text-sm shadow-none focus-visible:ring-0"
                />
              ) : (
                <div className="max-w-3xl">
                  {content ? (
                    <Markdown>{content}</Markdown>
                  ) : (
                    <p className="text-sm text-muted-foreground">Nothing to preview.</p>
                  )}
                </div>
              )}
            </div>
          )}
        </CardContent>

        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border/60 p-3">
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <span>{wordCount} words</span>
            {selectedNote && (
              <span className="hidden sm:inline">
                Last updated {new Date(selectedNote.updatedAt).toLocaleString()}
              </span>
            )}
            {!selectedId && draftOpen && <span className="text-accent">New note</span>}
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              className="gap-2"
              onClick={() => setPinned((p) => !p)}
              aria-pressed={pinned}
              disabled={!editorVisible}
            >
              <Pin className={cn('size-3.5', pinned && 'text-accent')} fill={pinned ? 'currentColor' : 'none'} />
              {pinned ? 'Pinned' : 'Pin'}
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="gap-2"
              onClick={downloadTxt}
              disabled={!editorVisible || (!content.trim() && !title.trim())}
            >
              <Download className="size-3.5" /> .txt
            </Button>
            <Button
              size="sm"
              onClick={() => void save()}
              disabled={saving || !editorVisible}
              className="gap-2"
            >
              {saving ? <Loader2 className="size-3.5 animate-spin" /> : null}
              {saving ? 'Saving…' : selectedId ? 'Save' : 'Create'}
            </Button>
            {selectedId && (
              <Button
                size="sm"
                variant="ghost"
                className="text-destructive"
                onClick={() => setDeleteId(selectedId)}
                aria-label="Delete note"
              >
                <Trash2 className="size-3.5" />
              </Button>
            )}
          </div>
        </div>
      </Card>

      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this note?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently removes the note from the database. This cannot
              be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => void confirmDelete()}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
