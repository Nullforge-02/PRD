'use client'

import * as React from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import {
  AlertTriangle,
  Check,
  CircleDot,
  ExternalLink,
  FolderGit2,
  GitFork,
  Github,
  Info,
  Loader2,
  RefreshCw,
  ShieldCheck,
  Star,
  Unplug,
} from 'lucide-react'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import {
  api,
  ApiError,
  type ConnectedAccountInfo,
  type GitHubIssue,
  type GitHubRepo,
  type GithubAccountRole,
  type IntegrationInfo,
} from '@/lib/api'
import { EmptyState } from '@/components/common/EmptyState'
import { Skeleton } from '@/components/common/Skeletons'

// ============================================================
// GitHub — real GitHub OAuth, MULTI-ACCOUNT (never simulated).
// Every connected GitHub account is listed and manageable:
// set the default ("Use"), assign a ROLE (storage / scripts /
// general — what this account is used for), reconnect expired
// grants per account, disconnect single accounts. Repos and
// issues are browsed per selected account, read-only.
// ============================================================

const CONNECT_HREF = '/api/v1/integrations/github/connect'

/** GitHub account roles — what each connected account is used for. */
const ROLE_OPTIONS: GithubAccountRole[] = ['storage', 'scripts', 'general']

const ROLE_DESCRIPTIONS: Record<GithubAccountRole, string> = {
  storage: 'Repo & file storage operations',
  scripts: 'Automation & scripts',
  general: 'Everything else',
}

/** Relative date for list rows ("3h ago"), locale-short for older. */
function formatRepoDate(value: string | null): string {
  if (!value) return ''
  const t = Date.parse(value)
  if (Number.isNaN(t)) return ''
  const diff = Date.now() - t
  if (diff < 60_000) return 'just now'
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}h ago`
  if (diff < 30 * 86_400_000) return `${Math.floor(diff / 86_400_000)}d ago`
  return new Date(t).toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  })
}

/** Only server-provided sanitized messages reach the UI. */
function sanitizedError(e: unknown, fallback: string): string {
  if (e instanceof ApiError) return e.message
  return fallback
}

export function GitHubView() {
  const queryClient = useQueryClient()

  // ---------- Integration status ----------
  const integrationsQuery = useQuery({
    queryKey: ['integrations'],
    queryFn: () => api.get<{ integrations: IntegrationInfo[] }>('/api/v1/integrations'),
  })
  const github = integrationsQuery.data?.integrations.find((i) => i.id === 'github')

  // ---------- Multi-account state ----------
  const accounts = React.useMemo(() => github?.accounts ?? [], [github])

  // Runtime 401 marks (lost access mid-session) — PER ACCOUNT now.
  const [reauthAccountIds, setReauthAccountIds] = React.useState<ReadonlySet<string>>(
    () => new Set<string>(),
  )
  const reauthToastedRef = React.useRef(false)
  const handleReauth = React.useCallback(
    (accountId?: string) => {
      if (accountId) {
        setReauthAccountIds((prev) => {
          if (prev.has(accountId)) return prev
          const next = new Set(prev)
          next.add(accountId)
          return next
        })
      }
      if (!reauthToastedRef.current) {
        reauthToastedRef.current = true
        toast.error('GitHub needs reauthorization', {
          description:
            'Alpha lost access to that GitHub account — reconnect it to continue.',
        })
      }
      void queryClient.invalidateQueries({ queryKey: ['integrations'] })
    },
    [queryClient],
  )

  const usableAccounts = React.useMemo(
    () =>
      accounts.filter(
        (a) => a.status === 'connected' && !reauthAccountIds.has(a.id),
      ),
    [accounts, reauthAccountIds],
  )

  const notConfigured = !!github && !github.configured
  const hasAccounts = accounts.length > 0
  // View-level banner ONLY when every connected account needs reauth
  // (no usable account left). Single expired grants are per-row.
  const allReauth = hasAccounts && usableAccounts.length === 0
  const connected = usableAccounts.length > 0

  // The account THIS view uses for repos/issues. Independent of the
  // provider default — switching here never changes the default.
  const [selectedAccountId, setSelectedAccountId] = React.useState<string | null>(null)

  // Never reference a dead id (e.g. after disconnecting the selection).
  React.useEffect(() => {
    if (selectedAccountId !== null && !accounts.some((a) => a.id === selectedAccountId)) {
      setSelectedAccountId(null)
    }
  }, [accounts, selectedAccountId])

  const activeAccount = React.useMemo(() => {
    if (usableAccounts.length === 0) return null
    if (selectedAccountId !== null) {
      const explicit = usableAccounts.find((a) => a.id === selectedAccountId)
      if (explicit) return explicit
    }
    const def = usableAccounts.find((a) => a.id === github?.defaultAccountId)
    if (def) return def
    return usableAccounts[0]
  }, [usableAccounts, selectedAccountId, github?.defaultAccountId])

  // ---------- Account mutations ----------
  const setDefaultMutation = useMutation({
    mutationFn: (account: ConnectedAccountInfo) =>
      api.post<{ account: { id: string; accountName: string | null } }>(
        `/api/v1/integrations/accounts/${encodeURIComponent(account.id)}/default`,
      ),
    onSuccess: async (_data, account) => {
      toast.success('Default GitHub account set', {
        description: account.accountName ?? 'The selected account is now the default.',
      })
      await queryClient.invalidateQueries({ queryKey: ['integrations'] })
    },
    onError: (e) => toast.error(sanitizedError(e, 'Could not set the default account')),
  })

  const setRoleMutation = useMutation({
    mutationFn: (input: { account: ConnectedAccountInfo; role: GithubAccountRole }) =>
      api.patch<{ account: { id: string; role: GithubAccountRole } }>(
        `/api/v1/integrations/accounts/${encodeURIComponent(input.account.id)}`,
        { role: input.role },
      ),
    onSuccess: async (_data, input) => {
      toast.success(`Role set to ${input.role}`, {
        description: `${input.account.accountName ?? 'GitHub account'} · ${ROLE_DESCRIPTIONS[input.role]}`,
      })
      await queryClient.invalidateQueries({ queryKey: ['integrations'] })
    },
    onError: (e) => toast.error(sanitizedError(e, 'Could not set that role')),
  })

  const [disconnectTarget, setDisconnectTarget] =
    React.useState<ConnectedAccountInfo | null>(null)
  const disconnectMutation = useMutation({
    mutationFn: (account: ConnectedAccountInfo) =>
      api.delete<{ ok: boolean; promotedDefaultId: string | null }>(
        `/api/v1/integrations/accounts/${encodeURIComponent(account.id)}`,
      ),
    onSuccess: async (_data, account) => {
      toast.success(`Disconnected ${account.accountName ?? 'GitHub account'}`)
      setDisconnectTarget(null)
      await queryClient.invalidateQueries({ queryKey: ['integrations'] })
    },
    onError: (e) => toast.error(sanitizedError(e, 'Could not disconnect that account')),
  })

  // ---------- Repositories (fetch only when the user asks) ----------
  const [reposRequested, setReposRequested] = React.useState(false)

  // Which account a request ACTUALLY used — 401s must mark THAT one.
  const queriedAccountIdRef = React.useRef<string | null>(null)

  const reposQuery = useQuery({
    queryKey: ['github', 'repos', activeAccount?.id ?? null],
    queryFn: async () => {
      const id = activeAccount?.id
      if (!id) throw new ApiError(0, 'No GitHub account selected')
      queriedAccountIdRef.current = id
      return api.get<{
        repos: GitHubRepo[]
        account: { id: string; accountName: string | null; role: GithubAccountRole | null }
      }>(`/api/v1/github/repos?accountId=${encodeURIComponent(id)}`)
    },
    enabled: reposRequested && activeAccount !== null,
    retry: false,
  })
  const repos = reposQuery.data?.repos ?? []

  const reposError = reposQuery.error
  React.useEffect(() => {
    if (reposError instanceof ApiError && reposError.status === 401) {
      handleReauth(queriedAccountIdRef.current ?? undefined)
    }
  }, [reposError, handleReauth])

  function loadRepos() {
    setReposRequested(true)
    if (reposRequested) void reposQuery.refetch()
  }

  // ---------- Issues (per repo, read-only — same account) ----------
  const [issuesRepo, setIssuesRepo] = React.useState<GitHubRepo | null>(null)
  const issuesQuery = useQuery({
    queryKey: [
      'github',
      'issues',
      issuesRepo?.owner,
      issuesRepo?.name,
      activeAccount?.id ?? null,
    ],
    queryFn: async () => {
      if (!issuesRepo) throw new ApiError(0, 'No repository selected')
      const accountId = activeAccount?.id
      if (!accountId) throw new ApiError(0, 'No GitHub account selected')
      queriedAccountIdRef.current = accountId
      return api.get<{ issues: GitHubIssue[] }>(
        `/api/v1/github/repos/${encodeURIComponent(issuesRepo.owner)}/${encodeURIComponent(
          issuesRepo.name,
        )}/issues?accountId=${encodeURIComponent(accountId)}`,
      )
    },
    enabled: issuesRepo !== null && activeAccount !== null,
    retry: false,
  })
  const issues = issuesQuery.data?.issues ?? []

  const issuesError = issuesQuery.error
  React.useEffect(() => {
    if (issuesError instanceof ApiError && issuesError.status === 401) {
      handleReauth(queriedAccountIdRef.current ?? undefined)
    }
  }, [issuesError, handleReauth])

  const statusLoading =
    integrationsQuery.isLoading || (!github && !integrationsQuery.error)

  // ============================================================
  // Render
  // ============================================================
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="flex flex-col gap-6"
    >
      {/* ---------- GitHub accounts card ---------- */}
      <Card className="alpha-panel border-0">
        <CardHeader className="border-b border-border/60 py-3">
          <CardTitle className="flex items-center gap-2 text-sm">
            <Github className="size-4 text-accent" aria-hidden /> GitHub
          </CardTitle>
          <CardDescription className="text-xs">
            Browse repositories and issues through real GitHub OAuth connections —
            multiple accounts with roles supported.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-4 sm:p-6">
          {statusLoading ? (
            <div className="space-y-3" aria-busy="true" aria-hidden>
              <div className="flex items-center gap-4">
                <Skeleton className="size-11 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-3.5 w-40" />
                  <Skeleton className="h-2.5 w-64" />
                </div>
              </div>
              <Skeleton className="h-9 w-full rounded-lg" />
            </div>
          ) : !github ? (
            <div
              role="alert"
              className="flex items-start gap-2.5 rounded-lg border border-destructive/30 bg-destructive/5 p-3"
            >
              <AlertTriangle
                className="mt-0.5 size-4 shrink-0 text-destructive"
                aria-hidden
              />
              <div className="flex min-w-0 flex-1 items-center justify-between gap-3">
                <p className="text-xs leading-relaxed text-destructive">
                  {sanitizedError(
                    integrationsQuery.error,
                    'Could not load the GitHub connection status.',
                  )}
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  className="shrink-0 gap-2"
                  onClick={() => void integrationsQuery.refetch()}
                >
                  <RefreshCw className="size-3.5" aria-hidden /> Retry
                </Button>
              </div>
            </div>
          ) : notConfigured ? (
            <div className="flex flex-col items-center gap-4 text-center">
              <div className="flex size-14 items-center justify-center rounded-lg bg-accent/10 text-accent">
                <Github className="size-7" aria-hidden />
              </div>
              <div>
                <p className="text-base font-semibold">
                  GitHub OAuth is not configured
                </p>
                <p className="mx-auto mt-1 max-w-md text-xs leading-relaxed text-muted-foreground">
                  The server is missing GitHub OAuth client credentials, so the
                  connect flow cannot start yet. This is an operator action —
                  nothing is wrong with your account.
                </p>
              </div>
              <div className="flex w-full max-w-xl items-start gap-2.5 rounded-lg border border-border/60 bg-muted/30 p-3 text-left">
                <Info className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden />
                <div className="min-w-0">
                  <p className="text-xs font-medium">Setup</p>
                  <p className="mt-0.5 break-words text-xs leading-relaxed text-muted-foreground">
                    {github.setup}
                  </p>
                </div>
              </div>
              <Tooltip>
                <TooltipTrigger asChild>
                  <span tabIndex={0} className="inline-flex">
                    <Button disabled className="gap-2" aria-disabled="true">
                      <Github className="size-4" aria-hidden /> Connect GitHub
                    </Button>
                  </span>
                </TooltipTrigger>
                <TooltipContent>
                  Set GITHUB_CLIENT_ID and GITHUB_CLIENT_SECRET as Worker
                  secrets to enable this
                </TooltipContent>
              </Tooltip>
              <p className="text-[11px] text-muted-foreground">
                The connect button unlocks automatically once credentials are
                configured — no need to reinstall anything.
              </p>
            </div>
          ) : allReauth ? (
            <div className="flex flex-col items-center gap-4 text-center">
              <div className="flex size-14 items-center justify-center rounded-lg bg-accent/10 text-accent">
                <AlertTriangle className="size-7" aria-hidden />
              </div>
              <div>
                <p className="text-base font-semibold">Reauthorization needed</p>
                <p className="mx-auto mt-1 max-w-md text-xs leading-relaxed text-muted-foreground">
                  Alpha lost access to every connected GitHub account — the
                  grants expired or were revoked. Reconnect to restore browsing.
                </p>
              </div>
              <Button asChild className="gap-2">
                <a href={CONNECT_HREF}>
                  <RefreshCw className="size-4" aria-hidden /> Reconnect
                </a>
              </Button>
            </div>
          ) : hasAccounts ? (
            <div className="flex flex-col gap-3">
              <p className="font-mono text-[11px] uppercase tracking-[0.08em] text-muted-foreground">
                GitHub accounts · {accounts.length} connected
              </p>
              <ul className="flex flex-col gap-2">
                {accounts.map((account) => {
                  const accountLabel = account.accountName ?? 'GitHub account'
                  const usePending =
                    setDefaultMutation.isPending &&
                    setDefaultMutation.variables?.id === account.id
                  const disconnectPending =
                    disconnectMutation.isPending &&
                    disconnectMutation.variables?.id === account.id
                  const rolePending =
                    setRoleMutation.isPending &&
                    setRoleMutation.variables?.account.id === account.id
                      ? setRoleMutation.variables.role
                      : null
                  const effectiveRole: GithubAccountRole =
                    rolePending ?? account.role ?? 'general'
                  const needsReauth =
                    account.status === 'needs_reauthorization' ||
                    reauthAccountIds.has(account.id)
                  return (
                    <li
                      key={account.id}
                      className="flex flex-wrap items-center gap-x-3 gap-y-2.5 rounded-lg border border-border/60 p-3"
                    >
                      <Avatar className="size-9 shrink-0 border border-border/60">
                        {account.avatarUrl ? (
                          <AvatarImage
                            src={account.avatarUrl}
                            alt={`${accountLabel} avatar`}
                          />
                        ) : null}
                        <AvatarFallback className="bg-accent/15 text-accent">
                          <Github className="size-4" aria-hidden />
                        </AvatarFallback>
                      </Avatar>
                      <div className="min-w-0 flex-1 basis-44">
                        <p className="flex min-w-0 items-center gap-2">
                          <span className="truncate font-mono text-xs text-foreground">
                            {account.accountName ?? 'GitHub account'}
                          </span>
                          <Badge
                            variant="outline"
                            className="shrink-0 border-border/60 bg-muted/30 text-[10px] text-muted-foreground"
                          >
                            {effectiveRole}
                          </Badge>
                        </p>
                        <p className="mt-0.5 flex min-w-0 items-center gap-1.5 text-[11px] text-muted-foreground">
                          <span
                            className={cn(
                              'alpha-status-dot shrink-0',
                              needsReauth
                                ? 'bg-amber-500 text-amber-500'
                                : 'bg-emerald-500 text-emerald-500',
                            )}
                            aria-hidden
                          />
                          <span className="truncate">
                            {needsReauth
                              ? 'needs reauthorization'
                              : 'connected'}
                            {account.lastUsedAt
                              ? ` · last used ${formatRepoDate(account.lastUsedAt)}`
                              : ' · not used yet'}
                          </span>
                        </p>
                        <div className="mt-1.5 flex min-w-0 flex-wrap items-center gap-x-2 gap-y-1">
                          <span className="shrink-0 font-mono text-[10px] uppercase tracking-[0.08em] text-muted-foreground">
                            Role
                          </span>
                          <Select
                            value={effectiveRole}
                            onValueChange={(value) =>
                              setRoleMutation.mutate({
                                account,
                                role: value as GithubAccountRole,
                              })
                            }
                            disabled={rolePending !== null}
                          >
                            <SelectTrigger
                              size="sm"
                              className="h-7 rounded-md border-border/60 bg-background px-2 font-mono text-[11px]"
                              aria-label={`Role for ${accountLabel}`}
                            >
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {ROLE_OPTIONS.map((role) => (
                                <SelectItem
                                  key={role}
                                  value={role}
                                  className="font-mono text-xs"
                                >
                                  {role}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <span className="min-w-0 truncate text-[11px] text-muted-foreground">
                            {ROLE_DESCRIPTIONS[effectiveRole]}
                          </span>
                        </div>
                      </div>
                      <div className="flex shrink-0 flex-wrap items-center gap-2">
                        {needsReauth && (
                          <Button asChild variant="outline" size="sm" className="gap-1.5">
                            <a
                              href={CONNECT_HREF}
                              aria-label={`Reconnect ${accountLabel}`}
                            >
                              <RefreshCw className="size-3.5" aria-hidden />
                              Reconnect
                            </a>
                          </Button>
                        )}
                        {account.isDefault ? (
                          <Badge
                            variant="outline"
                            className="gap-1 border-accent/40 bg-accent/10 text-accent"
                          >
                            <Check className="size-3" aria-hidden /> Default
                          </Badge>
                        ) : (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="outline"
                                size="sm"
                                className="gap-1.5"
                                onClick={() => setDefaultMutation.mutate(account)}
                                disabled={usePending}
                                aria-label={`Use ${accountLabel} by default`}
                              >
                                {usePending ? (
                                  <Loader2
                                    className="size-3.5 animate-spin"
                                    aria-hidden
                                  />
                                ) : (
                                  <Check className="size-3.5" aria-hidden />
                                )}
                                Use
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              Use this GitHub account by default
                            </TooltipContent>
                          </Tooltip>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          className="gap-1.5 text-destructive hover:bg-destructive/10 hover:text-destructive"
                          onClick={() => setDisconnectTarget(account)}
                          disabled={disconnectPending}
                          aria-label={`Disconnect ${accountLabel}`}
                        >
                          {disconnectPending ? (
                            <Loader2 className="size-3.5 animate-spin" aria-hidden />
                          ) : (
                            <Unplug className="size-3.5" aria-hidden />
                          )}
                          Disconnect
                        </Button>
                      </div>
                    </li>
                  )
                })}
              </ul>
              <div className="flex flex-col gap-2">
                <Button asChild variant="outline" className="w-full gap-2 sm:w-auto">
                  <a href={CONNECT_HREF}>
                    <Github className="size-4" aria-hidden /> Connect another GitHub
                    account
                  </a>
                </Button>
                <p className="text-[11px] leading-relaxed text-muted-foreground">
                  GitHub always shows its authorize screen — connecting a second
                  account is just clicking this again.
                </p>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-4 text-center">
              <div className="flex size-14 items-center justify-center rounded-lg bg-accent/10 text-accent">
                <Github className="size-7" aria-hidden />
              </div>
              <div>
                <p className="text-base font-semibold">GitHub is not connected</p>
                <p className="mx-auto mt-1 max-w-md text-xs leading-relaxed text-muted-foreground">
                  Alpha will never simulate a repository. Connecting requires a
                  real GitHub OAuth grant — multiple accounts are supported.
                </p>
              </div>
              <Button asChild className="gap-2">
                <a href={CONNECT_HREF}>
                  <Github className="size-4" aria-hidden /> Connect GitHub
                </a>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ---------- Repositories card (only with a usable account) ---------- */}
      {connected && (
        <Card className="alpha-panel border-0">
          <CardHeader className="gap-3 border-b border-border/60 py-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="min-w-0">
                <CardTitle className="text-sm">Repositories</CardTitle>
                <CardDescription className="text-xs">
                  Real repositories from the selected GitHub account.
                </CardDescription>
              </div>
              {reposRequested && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => void reposQuery.refetch()}
                  disabled={reposQuery.isFetching}
                  className="gap-2"
                  aria-label="Refresh repositories"
                >
                  <RefreshCw
                    className={cn(
                      'size-3.5',
                      reposQuery.isFetching && 'animate-spin',
                    )}
                    aria-hidden
                  />
                  Refresh
                </Button>
              )}
            </div>
            {usableAccounts.length >= 2 && (
              <div className="flex min-w-0 items-center gap-2">
                <span className="shrink-0 font-mono text-[10px] uppercase tracking-[0.08em] text-muted-foreground">
                  Using
                </span>
                <Select
                  value={activeAccount?.id ?? ''}
                  onValueChange={setSelectedAccountId}
                >
                  <SelectTrigger
                    size="sm"
                    className="h-8 max-w-[220px] rounded-md border-border/60 bg-background font-mono text-xs"
                    aria-label="GitHub account used for repositories and issues"
                  >
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {usableAccounts.map((a) => (
                      <SelectItem
                        key={a.id}
                        value={a.id}
                        className="font-mono text-xs"
                      >
                        {a.accountName ?? 'GitHub account'}
                        {a.isDefault ? ' · default' : ''}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </CardHeader>
          <CardContent className="p-2 sm:p-4">
            {!reposRequested ? (
              <div className="py-6">
                <EmptyState
                  icon={FolderGit2}
                  title="Repositories not loaded yet"
                  description="Nothing is fetched until you ask — load your repositories on demand."
                  action={
                    <Button onClick={loadRepos} className="gap-2">
                      <FolderGit2 className="size-4" aria-hidden /> Load
                      repositories
                    </Button>
                  }
                />
              </div>
            ) : reposQuery.isLoading || reposQuery.isFetching ? (
              <div className="space-y-2" aria-busy="true" aria-label="Loading repositories">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div
                    key={i}
                    className="space-y-2 rounded-lg border border-border/60 p-3"
                    aria-hidden
                  >
                    <Skeleton className="h-3.5 w-1/3" />
                    <Skeleton className="h-2.5 w-1/2" />
                    <Skeleton className="h-2.5 w-2/3" />
                  </div>
                ))}
              </div>
            ) : reposQuery.error ? (
              <div
                role="alert"
                className="flex items-start gap-2.5 rounded-lg border border-destructive/30 bg-destructive/5 p-3"
              >
                <AlertTriangle
                  className="mt-0.5 size-4 shrink-0 text-destructive"
                  aria-hidden
                />
                <p className="text-xs leading-relaxed text-destructive">
                  {reposQuery.error instanceof ApiError &&
                  reposQuery.error.status === 401
                    ? 'GitHub needs reauthorization — Alpha lost access to that account. Use Reconnect above to restore it.'
                    : sanitizedError(reposQuery.error, 'Could not load repositories.')}
                </p>
              </div>
            ) : repos.length === 0 ? (
              <div className="py-6">
                <EmptyState
                  icon={FolderGit2}
                  title="No repositories found."
                  description="This account has no visible repositories for the granted access."
                />
              </div>
            ) : (
              <div className="alpha-scroll max-h-[32rem] space-y-2 overflow-y-auto">
                {repos.map((repo) => (
                  <button
                    key={repo.id}
                    type="button"
                    onClick={() => setIssuesRepo(repo)}
                    className="group flex w-full flex-col gap-1.5 rounded-lg border border-border/60 p-3 text-left transition-colors hover:border-accent/40 hover:bg-accent/5"
                    aria-label={`View issues for ${repo.fullName}`}
                  >
                    <div className="flex items-baseline justify-between gap-2">
                      <div className="flex min-w-0 items-center gap-2">
                        <span className="truncate text-sm font-medium">
                          {repo.name}
                        </span>
                        <Badge
                          variant="outline"
                          className="shrink-0 text-[10px] text-muted-foreground"
                        >
                          {repo.private ? 'Private' : 'Public'}
                        </Badge>
                      </div>
                      {repo.updatedAt && (
                        <span className="shrink-0 text-[10px] text-muted-foreground">
                          Updated {formatRepoDate(repo.updatedAt)}
                        </span>
                      )}
                    </div>
                    <p className="truncate text-[11px] text-muted-foreground">
                      {repo.fullName}
                    </p>
                    {repo.description && (
                      <p className="truncate text-xs leading-relaxed text-muted-foreground">
                        {repo.description}
                      </p>
                    )}
                    <div className="mt-0.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-muted-foreground">
                      {repo.language && (
                        <span className="flex items-center gap-1.5">
                          <span
                            className="size-2 rounded-full bg-accent/70"
                            aria-hidden
                          />
                          {repo.language}
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        <Star className="size-3" aria-hidden />
                        <span aria-label={`${repo.stars} stars`}>{repo.stars}</span>
                      </span>
                      <span className="flex items-center gap-1">
                        <GitFork className="size-3" aria-hidden />
                        <span aria-label={`${repo.forks} forks`}>{repo.forks}</span>
                      </span>
                      <span className="flex items-center gap-1">
                        <CircleDot className="size-3" aria-hidden />
                        <span aria-label={`${repo.issues} issues`}>{repo.issues}</span>
                      </span>
                      <span className="ml-auto hidden items-center gap-1 text-accent opacity-0 transition-opacity group-hover:opacity-100 sm:flex">
                        View issues
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            )}
            <p className="mt-3 flex items-start gap-2 rounded-lg border border-border/60 bg-muted/20 p-2.5 text-[11px] leading-relaxed text-muted-foreground">
              <ShieldCheck className="mt-0.5 size-3.5 shrink-0 text-accent" aria-hidden />
              Read-only access — Alpha will never create, merge or delete
              anything on GitHub without explicit confirmation flows.
            </p>
          </CardContent>
        </Card>
      )}

      {/* ---------- Issues dialog (read-only) ---------- */}
      <Dialog
        open={issuesRepo !== null}
        onOpenChange={(o) => !o && setIssuesRepo(null)}
      >
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="truncate text-base">
              {issuesRepo ? `${issuesRepo.fullName} — issues` : 'Issues'}
            </DialogTitle>
            <DialogDescription>
              Real issues from GitHub — read-only, nothing can be changed from
              here.
            </DialogDescription>
          </DialogHeader>
          {issuesQuery.isLoading || issuesQuery.isFetching ? (
            <div className="space-y-2" aria-busy="true" aria-label="Loading issues">
              {Array.from({ length: 4 }).map((_, i) => (
                <div
                  key={i}
                  className="space-y-1.5 rounded-lg border border-border/60 p-3"
                  aria-hidden
                >
                  <Skeleton className="h-3 w-3/4" />
                  <Skeleton className="h-2.5 w-1/3" />
                </div>
              ))}
            </div>
          ) : issuesQuery.error ? (
            <div
              role="alert"
              className="flex items-start gap-2.5 rounded-lg border border-destructive/30 bg-destructive/5 p-3"
            >
              <AlertTriangle
                className="mt-0.5 size-4 shrink-0 text-destructive"
                aria-hidden
              />
              <p className="text-xs leading-relaxed text-destructive">
                {sanitizedError(issuesQuery.error, 'Could not load issues.')}
              </p>
            </div>
          ) : issues.length === 0 ? (
            <EmptyState
              icon={CircleDot}
              title="No issues found."
              description="This repository returned no issues for the granted access."
            />
          ) : (
            <div className="alpha-scroll max-h-[60vh] space-y-1 overflow-y-auto">
              {issues.map((issue) => (
                <div
                  key={issue.id}
                  className="flex items-start gap-3 rounded-lg p-2.5 transition-colors hover:bg-accent/5"
                >
                  <span className="mt-0.5 shrink-0 font-mono text-xs text-muted-foreground">
                    #{issue.number}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{issue.title}</p>
                    <p className="mt-0.5 text-[11px] text-muted-foreground">
                      by {issue.user}
                      {(issue.updatedAt || issue.createdAt) &&
                        ` · ${formatRepoDate(issue.updatedAt ?? issue.createdAt)}`}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-1.5">
                    {issue.isPullRequest && (
                      <Badge className="border-accent/40 bg-accent/10 text-[10px] text-accent">
                        PR
                      </Badge>
                    )}
                    <Badge
                      variant="outline"
                      className={cn(
                        'text-[10px]',
                        issue.state === 'open'
                          ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                          : 'text-muted-foreground',
                      )}
                    >
                      {issue.state}
                    </Badge>
                    <a
                      href={issue.url}
                      target="_blank"
                      rel="noreferrer"
                      className="flex size-6 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent/10 hover:text-accent"
                      aria-label={`Open issue #${issue.number} on GitHub (new tab)`}
                    >
                      <ExternalLink className="size-3.5" aria-hidden />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ---------- Disconnect confirmation (names the EXACT account) ---------- */}
      <AlertDialog
        open={disconnectTarget !== null}
        onOpenChange={(o) => !o && setDisconnectTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Disconnect{' '}
              {disconnectTarget?.accountName ?? 'this GitHub account'}?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Alpha loses access to{' '}
              <span className="font-mono">
                {disconnectTarget?.accountName ?? 'this account'}
              </span>{' '}
              — its tokens are revoked and deleted.
              {disconnectTarget &&
              accounts.some((a) => a.id !== disconnectTarget.id)
                ? ' Your other connected GitHub accounts are untouched.'
                : ''}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={disconnectMutation.isPending}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              disabled={disconnectMutation.isPending}
              onClick={(e) => {
                e.preventDefault()
                if (disconnectTarget) disconnectMutation.mutate(disconnectTarget)
              }}
              className="gap-2 bg-destructive text-white hover:bg-destructive/90"
            >
              {disconnectMutation.isPending ? (
                <Loader2 className="size-4 animate-spin" aria-hidden />
              ) : (
                <Unplug className="size-4" aria-hidden />
              )}
              Disconnect
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  )
}
