'use client'

// ALPHA — Settings → AI Providers → "Add API" / edit dialog
//
// One dialog, three modes (all against the Task 10-a API contract):
//   add          → POST  /api/v1/providers/custom        "Test & Add" — the
//                  server makes a REAL request with the supplied key before
//                  saving anything; a 502/409/400 keeps the dialog open with
//                  the sanitized error inline. Success is NEVER faked.
//   edit-custom  → PATCH /api/v1/providers/custom/[id]   omitting apiKey
//                  preserves the stored encrypted key; no forced retest.
//   edit-builtin → POST  /api/v1/providers/[id]          dashboard override
//                  for a built-in provider (apiKey optional = preserve),
//                  respecting supportsBaseUrl / supportsVisionModel.
//
// Security properties (mirrors AiProvidersPanel):
//   - the key input is type=password; the plaintext exists only in form state
//     for the duration of the dialog, is sent once over the same-origin API,
//     and is never logged or rendered back
//   - the dialog unmounts on close, clearing the field — only masked keys are
//     ever displayed
//   - [ Fetch Models ] is a SOFT convenience (POST /api/v1/providers/custom/
//     models with {baseUrl, apiKey} — or {providerId} when editing a saved
//     provider with an empty key field): failure shows a sanitized hint and
//     NEVER blocks manual model entry.

import * as React from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import {
  Check,
  EyeOff,
  KeyRound,
  List,
  Loader2,
  Plug,
  Save,
  Search,
  X,
  XCircle,
} from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import {
  ApiError,
  api,
  type CustomProviderInfo,
  type CustomProviderSaveResult,
  type ModelsDiscoveryResult,
  type ProviderInfo,
  type ProviderSaveResult,
} from '@/lib/api'

// ---------- Capability metadata (mirrors src/server/ai/capabilities.ts) ----------

/** Canonical user capability keys (never imported from the server bundle). */
export const USER_CAPABILITY_ORDER = [
  'TEXT',
  'VISION',
  'IMAGE_GENERATION',
  'VIDEO',
  'REASONING',
  'FAST',
] as const

/** Human labels for UI chips — identical to the server's CAPABILITY_LABELS. */
export const USER_CAPABILITY_LABELS: Record<string, string> = {
  TEXT: 'Text',
  VISION: 'Vision',
  IMAGE_GENERATION: 'Image Generation',
  VIDEO: 'Video',
  REASONING: 'Reasoning',
  FAST: 'Fast',
}

/**
 * Built-in providers report internal routing flags; map them to the same user
 * labels the custom rows use. streaming / toolCalling are engine-level
 * features of every chat-capable provider → omitted.
 */
export const BUILTIN_CAPABILITY_LABELS: Record<string, string> = {
  chat: 'Text',
  vision: 'Vision',
  imageGeneration: 'Image Generation',
  webSearch: 'Search',
  tts: 'Speech',
  asr: 'Transcription',
  reasoning: 'Reasoning',
  video: 'Video',
  fast: 'Fast',
}

// ---------- Types ----------

export type AddProviderTarget =
  | { kind: 'add' }
  | { kind: 'edit-custom'; provider: CustomProviderInfo }
  | { kind: 'edit-builtin'; provider: ProviderInfo }

interface AddProviderDialogProps {
  target: AddProviderTarget
  open: boolean
  onOpenChange: (open: boolean) => void
}

interface FormState {
  name: string
  apiKey: string
  baseUrl: string
  model: string
  visionModel: string
  imageModel: string
  videoModel: string
  capabilities: string[]
  priority: string
  enabled: boolean
}

/** 1–99 integer or null (the server contract). */
function parsePriority(value: string): number | null {
  const n = Number.parseInt(value, 10)
  return Number.isFinite(n) && n >= 1 && n <= 99 ? n : null
}

function initialState(target: AddProviderTarget): FormState {
  if (target.kind === 'edit-custom') {
    const p = target.provider
    return {
      name: p.name,
      apiKey: '',
      baseUrl: p.baseUrl,
      model: p.model,
      visionModel: p.visionModel ?? '',
      imageModel: p.imageModel ?? '',
      videoModel: p.videoModel ?? '',
      capabilities: USER_CAPABILITY_ORDER.filter((c) => p.capabilities.includes(c)),
      priority: String(p.priority),
      enabled: p.enabled,
    }
  }
  if (target.kind === 'edit-builtin') {
    const p = target.provider
    return {
      name: p.name,
      apiKey: '',
      baseUrl: p.baseUrl ?? '',
      model: p.model ?? '',
      visionModel: p.supportsVisionModel ? (p.visionModel ?? '') : '',
      imageModel: '',
      videoModel: '',
      capabilities: [],
      priority: '',
      enabled: p.enabled ?? true,
    }
  }
  return {
    name: '',
    apiKey: '',
    baseUrl: '',
    model: '',
    visionModel: '',
    imageModel: '',
    videoModel: '',
    capabilities: ['TEXT'],
    priority: '1',
    enabled: true,
  }
}

// ---------- Dialog ----------

export function AddProviderDialog({ target, open, onOpenChange }: AddProviderDialogProps) {
  // Remount the form per target (and per open cycle) so no field — and never
  // an API key — survives between sessions.
  const formKey =
    target.kind === 'add'
      ? 'add'
      : target.kind === 'edit-custom'
        ? `edit-custom-${target.provider.id}`
        : `edit-builtin-${target.provider.id}`

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="flex max-h-[85vh] flex-col gap-4 overflow-hidden sm:max-w-lg">
        <ProviderForm key={formKey} target={target} onDone={() => onOpenChange(false)} />
      </DialogContent>
    </Dialog>
  )
}

function ProviderForm({ target, onDone }: { target: AddProviderTarget; onDone: () => void }) {
  const queryClient = useQueryClient()
  const kind = target.kind

  const [form, setForm] = React.useState<FormState>(() => initialState(target))
  const [submitError, setSubmitError] = React.useState<string | null>(null)
  const [modelsList, setModelsList] = React.useState<string[] | null>(null)
  const [modelFilter, setModelFilter] = React.useState('')
  const [modelsError, setModelsError] = React.useState<string | null>(null)

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) =>
    setForm((f) => ({ ...f, [key]: value }))

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ['providers'] })
    void queryClient.invalidateQueries({ queryKey: ['system-health'] })
  }

  // ---- Model discovery (soft, optional — never blocks manual entry) ----
  const canFetchModels =
    kind !== 'edit-builtin' &&
    (kind === 'edit-custom' && !form.apiKey.trim()
      ? true // saved provider → discover with the STORED key via {providerId}
      : form.baseUrl.trim().length > 0 && form.apiKey.trim().length > 0)

  const modelsMutation = useMutation({
    mutationFn: (): Promise<ModelsDiscoveryResult> => {
      if (target.kind === 'edit-custom' && !form.apiKey.trim()) {
        return api.post<ModelsDiscoveryResult>('/api/v1/providers/custom/models', {
          providerId: target.provider.id,
        })
      }
      return api.post<ModelsDiscoveryResult>('/api/v1/providers/custom/models', {
        baseUrl: form.baseUrl.trim(),
        apiKey: form.apiKey.trim(),
      })
    },
    onSuccess: (res) => {
      setModelFilter('')
      if (res.models.length > 0) {
        setModelsList(res.models)
        setModelsError(null)
      } else {
        setModelsList(null)
        setModelsError(
          res.error ?? 'This provider does not expose a model list — enter the model id manually',
        )
      }
    },
    onError: (e) => {
      setModelsList(null)
      setModelsError(
        `Fetching models failed: ${e instanceof ApiError ? e.message : 'unexpected error'}`,
      )
    },
  })

  // ---- Save (add / edit-custom / edit-builtin) ----
  const saveMutation = useMutation({
    mutationFn: async () => {
      if (target.kind === 'add') {
        const res = await api.post<CustomProviderSaveResult>('/api/v1/providers/custom', {
          name: form.name.trim(),
          apiKey: form.apiKey.trim(),
          baseUrl: form.baseUrl.trim(),
          model: form.model.trim(),
          visionModel: form.visionModel.trim() || null,
          imageModel: form.imageModel.trim() || null,
          videoModel: form.videoModel.trim() || null,
          capabilities: form.capabilities,
          priority: parsePriority(form.priority) ?? 1,
          enabled: form.enabled,
        })
        const latency = res.provider.latencyMs
        toast.success(
          `${res.provider.name} added — connection verified${latency != null ? ` (${latency} ms)` : ''}`,
        )
        return
      }
      if (target.kind === 'edit-custom') {
        const res = await api.patch<CustomProviderSaveResult>(
          `/api/v1/providers/custom/${target.provider.id}`,
          {
            name: form.name.trim(),
            // Omitted → the stored encrypted key is preserved.
            ...(form.apiKey.trim() ? { apiKey: form.apiKey.trim() } : {}),
            baseUrl: form.baseUrl.trim(),
            model: form.model.trim(),
            visionModel: form.visionModel.trim() || null,
            imageModel: form.imageModel.trim() || null,
            videoModel: form.videoModel.trim() || null,
            capabilities: form.capabilities,
            priority: parsePriority(form.priority) ?? 1,
            enabled: form.enabled,
          },
        )
        toast.success(`${res.provider.name} updated`, {
          description: 'Use Test after saving to verify the connection.',
        })
        return
      }
      const res = await api.post<ProviderSaveResult>(`/api/v1/providers/${target.provider.id}`, {
        ...(form.apiKey.trim() ? { apiKey: form.apiKey.trim() } : {}),
        enabled: form.enabled,
        model: form.model.trim() || null,
        visionModel: target.provider.supportsVisionModel ? form.visionModel.trim() || null : null,
        baseUrl: target.provider.supportsBaseUrl ? form.baseUrl.trim() || null : null,
      })
      toast.success(`${res.provider.name} credential saved`, {
        description: 'The key is encrypted at rest and never shown again.',
      })
    },
    onSuccess: () => {
      onDone()
      invalidate()
    },
    onError: (e) => {
      // Sanitized by the server — shown inline; the modal stays open.
      setSubmitError(e instanceof ApiError ? e.message : 'Could not save the provider — unexpected error')
    },
  })

  function toggleCapability(cap: string) {
    setForm((f) => ({
      ...f,
      capabilities: f.capabilities.includes(cap)
        ? f.capabilities.filter((c) => c !== cap)
        : [...f.capabilities, cap],
    }))
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSubmitError(null)

    if (kind === 'edit-builtin') {
      // A brand-new built-in credential requires a key; an update preserves.
      if (target.provider.source !== 'dashboard' && form.apiKey.trim().length < 4) {
        setSubmitError('An API key (4+ characters) is required to add this provider credential')
        return
      }
      saveMutation.mutate()
      return
    }

    if (!form.name.trim()) {
      setSubmitError('Provider name is required')
      return
    }
    if (kind === 'add' && form.apiKey.trim().length < 4) {
      setSubmitError('API key is required (4+ characters)')
      return
    }
    if (kind === 'edit-custom' && form.apiKey.trim() && form.apiKey.trim().length < 4) {
      setSubmitError('The new API key is too short (4+ characters)')
      return
    }
    if (!form.baseUrl.trim()) {
      setSubmitError('Base URL is required — http:// is allowed for local servers')
      return
    }
    if (!form.model.trim()) {
      setSubmitError('Model is required — use Fetch Models or type the model id')
      return
    }
    if (form.capabilities.length === 0) {
      setSubmitError('Select at least one capability')
      return
    }
    if (parsePriority(form.priority) === null) {
      setSubmitError('Priority must be a number between 1 and 99')
      return
    }
    saveMutation.mutate()
  }

  const filteredModels = (modelsList ?? []).filter((m) =>
    m.toLowerCase().includes(modelFilter.trim().toLowerCase()),
  )

  const maskedKey =
    target.kind === 'edit-custom'
      ? target.provider.maskedKey
      : target.kind === 'edit-builtin' && target.provider.source === 'dashboard'
        ? target.provider.maskedKey
        : null

  const isAdd = kind === 'add'
  const isPending = saveMutation.isPending

  return (
    <form onSubmit={handleSubmit} className="flex min-h-0 flex-1 flex-col gap-4">
      <DialogHeader className="shrink-0 pr-6">
        <DialogTitle className="text-base">
          {isAdd ? 'Add API' : `Edit ${target.provider.name}`}
        </DialogTitle>
        <DialogDescription className="text-xs">
          {isAdd ? (
            <>
              Connect any OpenAI-compatible provider — OpenRouter, Gemini, My Local AI, Ollama,
              vLLM… Alpha makes a <span className="text-foreground">real request</span> with your
              key before saving; the key is encrypted (AES-GCM) and never shown again.
            </>
          ) : kind === 'edit-custom' ? (
            <>
              Changes are saved without retesting — use{' '}
              <span className="text-foreground">Test</span> after saving to verify the
              connection. Leave the key empty to keep the current one.
            </>
          ) : target.provider.source === 'environment' ? (
            <>
              This provider currently uses an{' '}
              <span className="text-foreground">environment credential</span> — a dashboard key
              takes precedence once saved. Leave the key empty to keep a stored key.
            </>
          ) : target.provider.source === 'dashboard' ? (
            <>
              Dashboard settings take precedence over environment variables. Leave the key empty
              to keep the stored (encrypted) key.
            </>
          ) : (
            <>
              No credential is configured yet — paste an API key to enable this provider for
              routing.
            </>
          )}
        </DialogDescription>
      </DialogHeader>

      <div className="alpha-scroll -mr-1 min-h-0 flex-1 space-y-4 overflow-y-auto pr-3">
        {/* Provider name (custom providers only) */}
        {kind !== 'edit-builtin' && (
          <div>
            <Label htmlFor="apd-name" className="text-xs text-muted-foreground">
              Provider name <span className="text-red-500">*</span>
            </Label>
            <Input
              id="apd-name"
              className="mt-1"
              placeholder="e.g. OpenRouter, Gemini, My Local AI"
              autoComplete="off"
              maxLength={60}
              value={form.name}
              onChange={(e) => set('name', e.target.value)}
            />
          </div>
        )}

        {/* API key */}
        <div>
          <Label htmlFor="apd-key" className="text-xs text-muted-foreground">
            API key {!isAdd && <span className="text-muted-foreground/60">(optional in edit mode)</span>}
          </Label>
          <div className="mt-1 flex items-center gap-2">
            <KeyRound className="size-4 shrink-0 text-muted-foreground" aria-hidden />
            <Input
              id="apd-key"
              type="password"
              autoComplete="off"
              spellCheck={false}
              maxLength={512}
              className="font-mono"
              placeholder={isAdd ? "Paste the provider's API key" : 'Leave empty to keep the current key'}
              value={form.apiKey}
              onChange={(e) => set('apiKey', e.target.value)}
            />
          </div>
          {maskedKey ? (
            <p className="mt-1.5 flex flex-wrap items-center gap-1.5 font-mono text-xs text-muted-foreground">
              <EyeOff className="size-3 shrink-0" aria-hidden />
              {maskedKey}
              <span className="font-sans">— masked; the full key is never shown again</span>
            </p>
          ) : null}
        </div>

        {/* Base URL — required for custom providers, optional for built-ins that support it */}
        {(kind !== 'edit-builtin' || target.provider.supportsBaseUrl) && (
          <div>
            <Label htmlFor="apd-baseurl" className="text-xs text-muted-foreground">
              Base URL{' '}
              {kind !== 'edit-builtin' ? (
                <span className="text-red-500">*</span>
              ) : (
                <span className="text-muted-foreground/60">(optional)</span>
              )}
            </Label>
            <Input
              id="apd-baseurl"
              className="mt-1 font-mono"
              placeholder={
                kind === 'edit-builtin'
                  ? target.provider.defaultBaseUrl || 'https://…'
                  : 'https://openrouter.ai/api/v1'
              }
              autoComplete="off"
              spellCheck={false}
              maxLength={300}
              value={form.baseUrl}
              onChange={(e) => set('baseUrl', e.target.value)}
            />
            {kind !== 'edit-builtin' && (
              <p className="mt-1.5 text-xs text-muted-foreground">
                The OpenAI-compatible API root — <span className="font-mono">http://</span> is
                allowed for local servers (Ollama, LM Studio, vLLM).
              </p>
            )}
          </div>
        )}

        {/* Model (+ Fetch Models for custom providers) */}
        <div>
          <Label htmlFor="apd-model" className="text-xs text-muted-foreground">
            {kind === 'edit-builtin' ? 'Chat model' : 'Model'}{' '}
            {kind !== 'edit-builtin' && <span className="text-red-500">*</span>}
          </Label>
          <div className="mt-1 flex items-center gap-2">
            <Input
              id="apd-model"
              className="font-mono"
              placeholder={
                kind === 'edit-builtin'
                  ? target.provider.defaultModel || 'provider default'
                  : 'e.g. gpt-4o-mini, llama-3.3-70b-versatile'
              }
              autoComplete="off"
              spellCheck={false}
              maxLength={200}
              value={form.model}
              onChange={(e) => set('model', e.target.value)}
            />
            {kind !== 'edit-builtin' && (
              <Button
                type="button"
                size="sm"
                variant="secondary"
                className="h-9 shrink-0"
                disabled={!canFetchModels || modelsMutation.isPending || isPending}
                title={canFetchModels ? 'Fetch the model list from the provider' : 'Enter the base URL and API key first (or edit a saved provider)'}
                onClick={() => modelsMutation.mutate()}
              >
                {modelsMutation.isPending ? (
                  <Loader2 className="size-3.5 animate-spin" aria-hidden />
                ) : (
                  <List className="size-3.5" aria-hidden />
                )}
                Fetch Models
              </Button>
            )}
          </div>
          {modelsError && (
            <p className="mt-1.5 text-xs text-amber-600 dark:text-amber-400" role="status">
              {modelsError}
            </p>
          )}
          {modelsList && (
            <div
              className="mt-2 overflow-hidden rounded-md border border-border/60 bg-background/80 shadow-sm"
              role="listbox"
              aria-label="Discovered models"
            >
              <div className="flex items-center gap-2 border-b border-border/60 px-2.5 py-1">
                <Search className="size-3.5 shrink-0 text-muted-foreground" aria-hidden />
                <Input
                  id="apd-model-filter"
                  className="h-6 rounded-none border-0 px-0 text-xs shadow-none focus-visible:border-transparent focus-visible:ring-0"
                  placeholder={`Filter ${modelsList.length} models…`}
                  value={modelFilter}
                  onChange={(e) => setModelFilter(e.target.value)}
                  aria-label="Filter models"
                />
                <button
                  type="button"
                  onClick={() => setModelsList(null)}
                  aria-label="Close model list"
                  className="shrink-0 rounded p-1 text-muted-foreground transition-colors hover:bg-accent/10 hover:text-foreground"
                >
                  <X className="size-3.5" aria-hidden />
                </button>
              </div>
              <div className="alpha-scroll max-h-48 overflow-y-auto p-1">
                {filteredModels.length === 0 ? (
                  <p className="px-2 py-3 text-center text-xs text-muted-foreground">
                    No models match &ldquo;{modelFilter}&rdquo;
                  </p>
                ) : (
                  filteredModels.map((m) => (
                    <button
                      key={m}
                      type="button"
                      role="option"
                      aria-selected={m === form.model}
                      onClick={() => {
                        set('model', m)
                        setModelsList(null)
                      }}
                      className="flex w-full items-center justify-between gap-2 rounded px-2 py-1.5 text-left font-mono text-xs transition-colors hover:bg-accent/10"
                    >
                      <span className="truncate">{m}</span>
                      {m === form.model && <Check className="size-3.5 shrink-0 text-accent" aria-hidden />}
                    </button>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Vision model (custom always; built-in when supported) */}
        {(kind !== 'edit-builtin' || target.provider.supportsVisionModel) && (
          <div>
            <Label htmlFor="apd-vision" className="text-xs text-muted-foreground">
              Vision model <span className="text-muted-foreground/60">(optional)</span>
            </Label>
            <Input
              id="apd-vision"
              className="mt-1 font-mono"
              placeholder={
                kind === 'edit-builtin'
                  ? target.provider.defaultVisionModel || 'provider default'
                  : 'e.g. qwen2.5-vl-72b-instruct'
              }
              autoComplete="off"
              spellCheck={false}
              maxLength={200}
              value={form.visionModel}
              onChange={(e) => set('visionModel', e.target.value)}
            />
          </div>
        )}

        {/* Image / video models (custom providers only) */}
        {kind !== 'edit-builtin' && (
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="apd-image" className="text-xs text-muted-foreground">
                Image model <span className="text-muted-foreground/60">(optional)</span>
              </Label>
              <Input
                id="apd-image"
                className="mt-1 font-mono"
                placeholder="e.g. flux.1-schnell"
                autoComplete="off"
                spellCheck={false}
                maxLength={200}
                value={form.imageModel}
                onChange={(e) => set('imageModel', e.target.value)}
              />
              <p className="mt-1.5 text-xs text-muted-foreground">
                for IMAGE_GENERATION capability
              </p>
            </div>
            <div>
              <Label htmlFor="apd-video" className="text-xs text-muted-foreground">
                Video model <span className="text-muted-foreground/60">(optional)</span>
              </Label>
              <Input
                id="apd-video"
                className="mt-1 font-mono"
                placeholder="e.g. wan2.2-t2v"
                autoComplete="off"
                spellCheck={false}
                maxLength={200}
                value={form.videoModel}
                onChange={(e) => set('videoModel', e.target.value)}
              />
              <p className="mt-1.5 text-xs text-muted-foreground">for VIDEO capability</p>
            </div>
          </div>
        )}

        {/* Capabilities (custom providers only — manual selection is authoritative) */}
        {kind !== 'edit-builtin' && (
          <div>
            <span className="text-xs text-muted-foreground" id="apd-capabilities-label">
              Capabilities <span className="text-red-500">*</span>
            </span>
            <div
              className="mt-1.5 flex w-full flex-wrap gap-1.5"
              role="group"
              aria-labelledby="apd-capabilities-label"
            >
              {USER_CAPABILITY_ORDER.map((cap) => {
                const active = form.capabilities.includes(cap)
                return (
                  <button
                    key={cap}
                    type="button"
                    aria-pressed={active}
                    onClick={() => toggleCapability(cap)}
                    className={cn(
                      'inline-flex h-8 items-center gap-1 rounded-md border px-2.5 font-mono text-[11px] font-medium tracking-[0.02em] transition-colors',
                      active
                        ? 'border-accent/60 bg-accent/15 text-accent'
                        : 'border-border/60 bg-transparent text-muted-foreground hover:border-accent/30 hover:text-foreground',
                    )}
                  >
                    {active && <Check className="size-3" aria-hidden />}
                    {USER_CAPABILITY_LABELS[cap]}
                  </button>
                )
              })}
            </div>
            <p className="mt-1.5 text-xs text-muted-foreground">
              Select exactly what this provider supports — routing will never send a request your
              provider can&rsquo;t handle.
            </p>
          </div>
        )}

        {/* Priority (custom only) + enabled switch */}
        {kind !== 'edit-builtin' ? (
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="apd-priority" className="text-xs text-muted-foreground">
                Priority
              </Label>
              <Input
                id="apd-priority"
                type="number"
                min={1}
                max={99}
                className="mt-1 w-28 font-mono"
                value={form.priority}
                onChange={(e) => set('priority', e.target.value)}
              />
              <p className="mt-1.5 text-xs text-muted-foreground">1–99 — lower = tried earlier</p>
            </div>
            <div className="flex items-center gap-2 sm:pt-7">
              <Switch
                id="apd-enabled"
                checked={form.enabled}
                onCheckedChange={(v) => set('enabled', v)}
                aria-label="Enable this provider for routing"
              />
              <Label htmlFor="apd-enabled" className="text-xs text-muted-foreground">
                {form.enabled ? 'Enabled for routing' : 'Disabled — not routed'}
              </Label>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Switch
              id="apd-enabled"
              checked={form.enabled}
              onCheckedChange={(v) => set('enabled', v)}
              aria-label={`Enable ${target.provider.name} for routing`}
            />
            <Label htmlFor="apd-enabled" className="text-xs text-muted-foreground">
              {form.enabled ? 'Enabled for routing' : 'Disabled — not routed'}
            </Label>
          </div>
        )}
      </div>

      <div className="shrink-0 space-y-2">
        {submitError && (
          <p className="flex items-start gap-1.5 text-xs text-red-500" role="alert">
            <XCircle className="mt-0.5 size-3.5 shrink-0" aria-hidden />
            {submitError}
          </p>
        )}
        <DialogFooter>
          <Button type="button" variant="ghost" onClick={onDone} disabled={isPending}>
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={isPending}
            className="bg-accent text-accent-foreground hover:bg-accent/90"
          >
            {isPending ? (
              <Loader2 className="size-3.5 animate-spin" aria-hidden />
            ) : isAdd ? (
              <Plug className="size-3.5" aria-hidden />
            ) : (
              <Save className="size-3.5" aria-hidden />
            )}
            {isPending
              ? isAdd
                ? 'Testing connection…'
                : 'Saving…'
              : isAdd
                ? 'Test & Add'
                : 'Save'}
          </Button>
        </DialogFooter>
      </div>
    </form>
  )
}
