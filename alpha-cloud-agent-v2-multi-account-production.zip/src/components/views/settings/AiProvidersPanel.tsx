'use client'

// ALPHA — Settings → AI Providers panel
//
// Dynamic, unlimited provider management (Task 10-d): a merged list of the
// user's CUSTOM OpenAI-compatible providers (full CRUD, capability-aware)
// and the BUILT-IN registry providers (dashboard key overrides), driven by
// GET /api/v1/providers → { providers, custom, primary }.
//
// Security properties (unchanged from the previous panel):
//   - API keys are typed into a password input, sent once over the same-origin
//     API, encrypted server-side (AES-GCM) and NEVER returned to the browser.
//   - A saved key is displayed ONLY in masked form (••••••••••••abcd).
//   - "Test" issues a REAL provider request and reports real latency or a
//     sanitized error — nothing is simulated, success is never faked.

import * as React from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import {
  Activity,
  CheckCircle2,
  EyeOff,
  Loader2,
  Pencil,
  Plug,
  Plus,
  Power,
  ServerCog,
  ShieldCheck,
  Trash2,
  XCircle,
} from 'lucide-react'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import {
  ApiError,
  api,
  type CustomProviderInfo,
  type PrimaryChatProvider,
  type ProviderInfo,
  type ProviderTestResult,
  type ProvidersResponse,
} from '@/lib/api'
import {
  AddProviderDialog,
  BUILTIN_CAPABILITY_LABELS,
  USER_CAPABILITY_LABELS,
  USER_CAPABILITY_ORDER,
  type AddProviderTarget,
} from './AddProviderDialog'

function timeAgo(iso: string): string {
  const seconds = Math.max(0, Math.floor((Date.now() - Date.parse(iso)) / 1000))
  if (seconds < 60) return 'just now'
  const minutes = Math.floor(seconds / 60)
  if (minutes < 60) return `${minutes}m ago`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours}h ago`
  return `${Math.floor(hours / 24)}d ago`
}

const STATUS_DOT: Record<string, string> = {
  healthy: 'bg-emerald-500 text-emerald-500',
  degraded: 'bg-amber-500 text-amber-500',
  offline: 'bg-red-500/80 text-red-500/80',
  unknown: 'bg-muted-foreground/40 text-muted-foreground/40',
}

function StatusDot({ status }: { status: string }) {
  return (
    <span
      role="status"
      aria-label={`status: ${status}`}
      className={cn('alpha-status-dot shrink-0', STATUS_DOT[status] ?? STATUS_DOT.unknown)}
    />
  )
}

/** Inline result of a real Test request (green check / red X + message). */
function TestResultView({ result }: { result: { ok: boolean; message: string } | null }) {
  if (!result) return null
  return (
    <span
      className={cn(
        'ml-auto flex items-center gap-1.5 text-xs',
        result.ok ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500',
      )}
      role="status"
    >
      {result.ok ? (
        <CheckCircle2 className="size-3.5 shrink-0" aria-hidden />
      ) : (
        <XCircle className="size-3.5 shrink-0" aria-hidden />
      )}
      {result.message}
    </span>
  )
}

/** Custom capability keys → ordered human labels. */
function customCapabilityLabels(capabilities: string[]): string[] {
  return USER_CAPABILITY_ORDER.filter((c) => capabilities.includes(c)).map(
    (c) => USER_CAPABILITY_LABELS[c],
  )
}

/** Built-in routing flags → human labels (streaming/toolCalling omitted). */
function builtinCapabilityLabels(capabilities: string[]): string[] {
  const labels: string[] = []
  for (const flag of capabilities) {
    const label = BUILTIN_CAPABILITY_LABELS[flag]
    if (label && !labels.includes(label)) labels.push(label)
  }
  return labels
}

interface TestOutcome {
  ok: boolean
  message: string
}

/** Shared real Test-connection runner (custom + built-in endpoints). */
function useProviderTest(path: string, name: string) {
  const queryClient = useQueryClient()
  const [testing, setTesting] = React.useState(false)
  const [testResult, setTestResult] = React.useState<TestOutcome | null>(null)

  const runTest = React.useCallback(async () => {
    setTesting(true)
    setTestResult(null)
    try {
      const res = await api.post<ProviderTestResult>(path)
      if (res.success) {
        setTestResult({ ok: true, message: `Connected — ${res.latencyMs ?? '—'} ms` })
        toast.success(`${name} connection OK`, {
          description: `Real request · ${res.latencyMs ?? '—'} ms`,
        })
      } else {
        setTestResult({ ok: false, message: res.error ?? 'Test failed' })
        toast.error(`${name} connection failed`, { description: res.error })
      }
    } catch (e) {
      const message = e instanceof ApiError ? e.message : 'Test failed'
      setTestResult({ ok: false, message })
      toast.error(`${name} connection failed`, { description: message })
    } finally {
      setTesting(false)
      void queryClient.invalidateQueries({ queryKey: ['providers'] })
      void queryClient.invalidateQueries({ queryKey: ['system-health'] })
    }
  }, [path, name, queryClient])

  return { testing, testResult, runTest }
}

// ---------- Custom (user-added) provider row ----------

function CustomProviderRow({
  p,
  index,
  primary,
  onEdit,
}: {
  p: CustomProviderInfo
  index: number
  primary: PrimaryChatProvider | null
  onEdit: () => void
}) {
  const queryClient = useQueryClient()
  const [removeOpen, setRemoveOpen] = React.useState(false)
  const { testing, testResult, runTest } = useProviderTest(
    `/api/v1/providers/custom/${p.id}/test`,
    p.name,
  )

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ['providers'] })
    void queryClient.invalidateQueries({ queryKey: ['system-health'] })
  }

  // Disable/Enable — the Switch PATCHes {enabled}; optimistic with rollback,
  // verified via invalidate.
  const toggleMutation = useMutation({
    mutationFn: (next: boolean) =>
      api.patch<{ provider: CustomProviderInfo }>(`/api/v1/providers/custom/${p.id}`, {
        enabled: next,
      }),
    onMutate: async (next) => {
      await queryClient.cancelQueries({ queryKey: ['providers'] })
      const prev = queryClient.getQueryData<ProvidersResponse>(['providers'])
      if (prev) {
        queryClient.setQueryData<ProvidersResponse>(['providers'], {
          ...prev,
          custom: prev.custom.map((c) => (c.id === p.id ? { ...c, enabled: next } : c)),
        })
      }
      return { prev }
    },
    onError: (e, _next, ctx) => {
      if (ctx?.prev) queryClient.setQueryData(['providers'], ctx.prev)
      toast.error(e instanceof ApiError ? e.message : `Could not update ${p.name}`)
    },
    onSettled: () => invalidate(),
  })

  const removeMutation = useMutation({
    mutationFn: () => api.delete<{ ok: boolean; id: string }>(`/api/v1/providers/custom/${p.id}`),
    onSuccess: () => {
      setRemoveOpen(false)
      toast.success(`${p.name} deleted`, {
        description:
          'The encrypted credential, settings and health data were permanently removed.',
      })
      invalidate()
    },
    onError: (e) => {
      toast.error(e instanceof ApiError ? e.message : `Could not delete ${p.name}`)
    },
  })

  const status = p.status ?? 'unknown'
  const isPrimary = primary?.custom === true && primary.name === p.name

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.04, ease: [0.16, 1, 0.3, 1] }}
    >
      <Card
        className={cn(
          'alpha-panel border-0 transition-opacity',
          !p.enabled && 'opacity-55',
        )}
      >
        <CardHeader className="border-b border-border/60 py-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-2">
              <StatusDot status={status} />
              <CardTitle className="text-sm">{p.name}</CardTitle>
              <span className="font-mono text-[10px] uppercase tracking-[0.06em] text-muted-foreground">{status}</span>
              <Badge
                variant="outline"
                className="rounded-md px-1.5 py-0 font-mono text-[10px] font-normal tracking-[0.04em] text-muted-foreground"
                title="Custom provider priority — lower = tried earlier"
              >
                #{p.priority}
              </Badge>
              {isPrimary && (
                <Badge
                  variant="outline"
                  className="rounded-md border-accent/40 px-1.5 py-0 font-mono text-[10px] font-normal tracking-[0.04em] text-accent"
                >
                  Primary
                </Badge>
              )}
              {customCapabilityLabels(p.capabilities).map((label) => (
                <Badge
                  key={label}
                  variant="outline"
                  className="rounded-md px-1.5 py-0 font-mono text-[10px] font-normal tracking-[0.04em] text-muted-foreground"
                >
                  {label}
                </Badge>
              ))}
            </div>
            <div className="flex items-center gap-2">
              <Label
                htmlFor={`custom-enabled-${p.id}`}
                className="text-xs text-muted-foreground"
              >
                {p.enabled ? 'Enabled' : 'Disabled'}
              </Label>
              <Switch
                id={`custom-enabled-${p.id}`}
                checked={p.enabled}
                disabled={toggleMutation.isPending}
                onCheckedChange={(v) => toggleMutation.mutate(v)}
                aria-label={`Enable ${p.name} for routing`}
              />
            </div>
          </div>
          <CardDescription className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
            <span>
              Model: <span className="font-mono">{p.model}</span>
            </span>
            <span className="font-mono text-muted-foreground">{p.baseUrl}</span>
            {p.latencyMs != null && (
              <span className="flex items-center gap-1">
                <Activity className="size-3" aria-hidden /> {p.latencyMs} ms
              </span>
            )}
            <span className="flex items-center gap-1 font-mono text-muted-foreground">
              <EyeOff className="size-3" aria-hidden /> {p.maskedKey}
            </span>
            {p.lastErrorCategory && (
              <span className="text-amber-600 dark:text-amber-400">
                last error: {p.lastErrorCategory}
              </span>
            )}
            {p.lastTestedAt && (
              <span>
                tested {timeAgo(p.lastTestedAt)}
                {p.lastTestStatus === 'success' ? ' ✓' : p.lastTestStatus === 'failed' ? ' ✗' : ''}
              </span>
            )}
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-3 p-4">
          <div className="flex flex-wrap items-center gap-2">
            <Button size="sm" variant="secondary" disabled={testing} onClick={() => void runTest()}>
              {testing ? (
                <Loader2 className="size-3.5 animate-spin" aria-hidden />
              ) : (
                <Plug className="size-3.5" aria-hidden />
              )}
              Test
            </Button>
            <Button size="sm" variant="outline" onClick={onEdit}>
              <Pencil className="size-3.5" aria-hidden />
              Edit
            </Button>
            <Button
              size="sm"
              variant="ghost"
              disabled={toggleMutation.isPending}
              onClick={() => toggleMutation.mutate(!p.enabled)}
            >
              <Power className="size-3.5" aria-hidden />
              {p.enabled ? 'Disable' : 'Enable'}
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="text-red-500 hover:bg-red-500/10 hover:text-red-400"
              disabled={removeMutation.isPending}
              onClick={() => setRemoveOpen(true)}
            >
              <Trash2 className="size-3.5" aria-hidden />
              Delete
            </Button>
            <TestResultView result={testResult} />
          </div>
          {!p.enabled && (
            <p className="text-xs text-muted-foreground">
              Disabled — excluded from routing until re-enabled.
            </p>
          )}

          <AlertDialog open={removeOpen} onOpenChange={setRemoveOpen}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete {p.name}?</AlertDialogTitle>
                <AlertDialogDescription>
                  This permanently removes the encrypted credential, settings and health data.
                  The provider becomes unavailable immediately. This cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  className="bg-red-500 text-white hover:bg-red-600"
                  onClick={() => removeMutation.mutate()}
                >
                  {removeMutation.isPending ? 'Deleting…' : 'Delete provider'}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>
    </motion.div>
  )
}

// ---------- Built-in provider row ----------

function BuiltInProviderRow({
  p,
  index,
  primary,
  onEdit,
}: {
  p: ProviderInfo
  index: number
  primary: PrimaryChatProvider | null
  onEdit: () => void
}) {
  const queryClient = useQueryClient()
  const [removeOpen, setRemoveOpen] = React.useState(false)
  const { testing, testResult, runTest } = useProviderTest(
    `/api/v1/providers/${p.id}/test`,
    p.name,
  )

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ['providers'] })
    void queryClient.invalidateQueries({ queryKey: ['system-health'] })
  }

  const removeMutation = useMutation({
    mutationFn: () => api.delete<{ provider: ProviderInfo }>(`/api/v1/providers/${p.id}`),
    onSuccess: () => {
      setRemoveOpen(false)
      toast.success(`${p.name} key removed`, {
        description:
          'The dashboard credential was deleted. Environment credentials (if any) remain active.',
      })
      invalidate()
    },
    onError: (e) => {
      toast.error(e instanceof ApiError ? e.message : `Could not remove the ${p.name} key`)
    },
  })

  const status = p.status ?? 'unknown'
  const hasDashboardKey = p.source === 'dashboard'
  const sourceLabel =
    p.source === 'dashboard'
      ? 'Dashboard key'
      : p.source === 'environment'
        ? 'Environment key'
        : 'Not configured'
  const isPrimary = primary?.custom === false && primary.name === p.name

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.04, ease: [0.16, 1, 0.3, 1] }}
    >
      <Card
        className={cn(
          'alpha-panel border-0 transition-opacity',
          p.enabled === false && 'opacity-55',
        )}
      >
        <CardHeader className="border-b border-border/60 py-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-2">
              <StatusDot status={status} />
              <CardTitle className="text-sm">{p.name}</CardTitle>
              <span className="font-mono text-[10px] uppercase tracking-[0.06em] text-muted-foreground">{status}</span>
              <Badge
                variant="outline"
                className="rounded-md px-1.5 py-0 font-mono text-[10px] font-normal tracking-[0.04em] text-muted-foreground"
                title="Configured via AI_PRIMARY_PROVIDER / AI_FALLBACK_PROVIDERS"
              >
                #{p.priority ?? '—'}
              </Badge>
              {isPrimary && (
                <Badge
                  variant="outline"
                  className="rounded-md border-accent/40 px-1.5 py-0 font-mono text-[10px] font-normal tracking-[0.04em] text-accent"
                >
                  Primary
                </Badge>
              )}
              {builtinCapabilityLabels(p.capabilities).map((label) => (
                <Badge
                  key={label}
                  variant="outline"
                  className="rounded-md px-1.5 py-0 font-mono text-[10px] font-normal tracking-[0.04em] text-muted-foreground"
                >
                  {label}
                </Badge>
              ))}
              {hasDashboardKey ? (
                <Badge
                  variant="outline"
                  className="rounded-md border-emerald-500/30 px-1.5 py-0 font-mono text-[10px] font-normal tracking-[0.04em] text-emerald-600 dark:text-emerald-400"
                >
                  <ShieldCheck className="mr-1 size-3" aria-hidden />
                  {sourceLabel}
                </Badge>
              ) : (
                <Badge
                  variant="outline"
                  className={cn(
                    'px-1.5 py-0 text-[10px] font-normal',
                    p.source === 'environment'
                      ? 'text-muted-foreground'
                      : 'text-muted-foreground/70',
                  )}
                >
                  {sourceLabel}
                </Badge>
              )}
            </div>
            {/* Built-ins have no per-row switch — enable/priority are env-managed
                and editable via the dashboard-credential dialog. */}
            <span className="text-xs text-muted-foreground">
              {p.enabled === false ? 'Excluded from routing' : ''}
            </span>
          </div>
          <CardDescription className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
            <span>
              Model: <span className="font-mono">{p.model || p.defaultModel || '—'}</span>
            </span>
            {p.latencyMs != null && (
              <span className="flex items-center gap-1">
                <Activity className="size-3" aria-hidden /> {p.latencyMs} ms
              </span>
            )}
            {p.maskedKey && (
              <span className="flex items-center gap-1 font-mono text-muted-foreground">
                <EyeOff className="size-3" aria-hidden /> {p.maskedKey}
              </span>
            )}
            {p.lastErrorCategory && (
              <span className="text-amber-600 dark:text-amber-400">
                last error: {p.lastErrorCategory}
              </span>
            )}
            {p.lastTestedAt && (
              <span>
                tested {timeAgo(p.lastTestedAt)}
                {p.lastTestStatus === 'success' ? ' ✓' : p.lastTestStatus === 'failed' ? ' ✗' : ''}
              </span>
            )}
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-3 p-4">
          <div className="flex flex-wrap items-center gap-2">
            <Button
              size="sm"
              variant="secondary"
              disabled={!p.configured || testing}
              onClick={() => void runTest()}
            >
              {testing ? (
                <Loader2 className="size-3.5 animate-spin" aria-hidden />
              ) : (
                <Plug className="size-3.5" aria-hidden />
              )}
              Test
            </Button>
            <Button size="sm" variant="outline" onClick={onEdit}>
              <Pencil className="size-3.5" aria-hidden />
              Edit
            </Button>
            {hasDashboardKey && (
              <Button
                size="sm"
                variant="ghost"
                className="text-red-500 hover:bg-red-500/10 hover:text-red-400"
                disabled={removeMutation.isPending}
                onClick={() => setRemoveOpen(true)}
              >
                <Trash2 className="size-3.5" aria-hidden />
                Remove key
              </Button>
            )}
            <TestResultView result={testResult} />
          </div>
          {!p.configured && (
            <p className="text-xs text-muted-foreground">
              Not used for routing until a key is saved (or an environment credential exists).
            </p>
          )}

          <AlertDialog open={removeOpen} onOpenChange={setRemoveOpen}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Remove the stored {p.name} key?</AlertDialogTitle>
                <AlertDialogDescription>
                  Alpha falls back to the environment credential for this provider, if one is
                  configured. This cannot be undone — you will need to paste the key again to
                  restore it.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  className="bg-red-500 text-white hover:bg-red-600"
                  onClick={() => removeMutation.mutate()}
                >
                  {removeMutation.isPending ? 'Removing…' : 'Remove key'}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>
    </motion.div>
  )
}

// ---------- Panel ----------

export function AiProvidersPanel() {
  const [dialog, setDialog] = React.useState<{ open: boolean; target: AddProviderTarget }>({
    open: false,
    target: { kind: 'add' },
  })

  const providersQuery = useQuery({
    queryKey: ['providers'],
    queryFn: () => api.get<ProvidersResponse>('/api/v1/providers'),
  })

  if (providersQuery.isLoading) {
    return (
      <div className="space-y-4" aria-busy="true" aria-label="Loading AI providers">
        {[0, 1, 2, 3].map((i) => (
          <Card key={i} className="alpha-panel border-0" aria-hidden>
            <CardContent className="space-y-3 p-4">
              <div className="h-5 w-40 animate-pulse rounded bg-muted/50" />
              <div className="h-4 w-64 animate-pulse rounded bg-muted/50" />
              <div className="h-8 w-56 animate-pulse rounded-lg bg-muted/50" />
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  if (providersQuery.isError) {
    return (
      <Card className="border-destructive/40 bg-destructive/5">
        <CardContent className="p-4 sm:p-6">
          <p className="text-sm text-destructive">
            Could not load AI providers —{' '}
            {providersQuery.error instanceof ApiError
              ? providersQuery.error.message
              : 'unexpected error'}
            .
          </p>
        </CardContent>
      </Card>
    )
  }

  // Custom providers first (by priority), then built-ins (by priority).
  const custom = [...(providersQuery.data?.custom ?? [])].sort((a, b) => a.priority - b.priority)
  const builtins = [...(providersQuery.data?.providers ?? [])].sort(
    (a, b) => (a.priority ?? 99) - (b.priority ?? 99),
  )
  const primary = providersQuery.data?.primary ?? null

  return (
    <div className="space-y-4">
      <Card className="alpha-panel border-0">
        <CardHeader className="border-b border-border/60 py-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <CardTitle className="flex items-center gap-2 text-sm">
              <ServerCog className="size-4 text-accent" aria-hidden />
              AI Providers
            </CardTitle>
            <Button
              size="sm"
              className="bg-accent text-accent-foreground hover:bg-accent/90"
              onClick={() => setDialog({ open: true, target: { kind: 'add' } })}
            >
              <Plus className="size-3.5" aria-hidden />
              Add API
            </Button>
          </div>
          <CardDescription className="mt-1 text-xs">
            Add unlimited OpenAI-compatible providers — OpenRouter, Gemini, local models, anything
            with an <span className="font-mono">/chat/completions</span> endpoint. Keys are
            encrypted (AES-GCM) before storage and never shown again. Routing is capability-aware
            with automatic fallback: providers are tried in priority order (lower first)
            {primary
              ? ` — chat currently routes via ${primary.name} (${primary.model})`
              : ''}
            .
          </CardDescription>
        </CardHeader>
      </Card>

      {custom.map((p, i) => (
        <CustomProviderRow
          key={p.id}
          p={p}
          index={i}
          primary={primary}
          onEdit={() => setDialog({ open: true, target: { kind: 'edit-custom', provider: p } })}
        />
      ))}
      {builtins.map((p, i) => (
        <BuiltInProviderRow
          key={p.id}
          p={p}
          index={custom.length + i}
          primary={primary}
          onEdit={() => setDialog({ open: true, target: { kind: 'edit-builtin', provider: p } })}
        />
      ))}

      <AddProviderDialog
        target={dialog.target}
        open={dialog.open}
        onOpenChange={(open) => setDialog((d) => ({ ...d, open }))}
      />
    </div>
  )
}
