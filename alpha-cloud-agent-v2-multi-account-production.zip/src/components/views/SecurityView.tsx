'use client'

import * as React from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import {
  ChevronDown,
  ChevronUp,
  KeyRound,
  Loader2,
  Lock,
  MonitorSmartphone,
  ShieldCheck,
  Trash2,
} from 'lucide-react'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { EmptyState } from '@/components/common/EmptyState'
import { api, ApiError, type AuditEvent, type SessionInfo } from '@/lib/api'

// ============================================================
// Security — lock, password, real sessions, real audit log.
// ============================================================

/** Simple, honest user-agent label (e.g. "Chrome on Linux"). */
function parseUserAgent(ua: string | null): string {
  if (!ua) return 'Unknown device'
  let browser = ''
  if (/Edg\//.test(ua)) browser = 'Edge'
  else if (/OPR\//.test(ua)) browser = 'Opera'
  else if (/SamsungBrowser\//.test(ua)) browser = 'Samsung Internet'
  else if (/Chrome\//.test(ua) && !/Chromium\//.test(ua)) browser = 'Chrome'
  else if (/Firefox\//.test(ua)) browser = 'Firefox'
  else if (/Safari\//.test(ua) && /Version\//.test(ua)) browser = 'Safari'
  else if (/curl\//i.test(ua)) browser = 'curl'

  let os = ''
  if (/Windows NT/.test(ua)) os = 'Windows'
  else if (/Android/.test(ua)) os = 'Android'
  else if (/iPhone|iPad|iPod/.test(ua)) os = 'iOS'
  else if (/Mac OS X/.test(ua)) os = 'macOS'
  else if (/Linux/.test(ua)) os = 'Linux'

  if (browser && os) return `${browser} on ${os}`
  if (browser) return browser
  return ua.length > 48 ? `${ua.slice(0, 48)}…` : ua
}

function prettyDetails(details: string | null): string {
  if (!details) return '(no details)'
  try {
    return JSON.stringify(JSON.parse(details), null, 2)
  } catch {
    return details
  }
}

export function SecurityView() {
  const queryClient = useQueryClient()
  const [lockConfirm, setLockConfirm] = React.useState(false)
  const [locking, setLocking] = React.useState(false)

  const [currentPassword, setCurrentPassword] = React.useState('')
  const [newPassword, setNewPassword] = React.useState('')
  const [changing, setChanging] = React.useState(false)

  const [revokeTarget, setRevokeTarget] = React.useState<SessionInfo | null>(null)
  const [revoking, setRevoking] = React.useState(false)
  const [expandedLog, setExpandedLog] = React.useState<string | null>(null)

  const sessionsQuery = useQuery({
    queryKey: ['sessions'],
    queryFn: () => api.get<{ sessions: SessionInfo[] }>('/api/v1/sessions'),
  })
  const sessions = sessionsQuery.data?.sessions ?? []

  const auditQuery = useQuery({
    queryKey: ['audit', 100],
    queryFn: () => api.get<{ events: AuditEvent[] }>('/api/v1/audit?limit=100'),
  })
  const events = auditQuery.data?.events ?? []

  async function lockNow() {
    setLocking(true)
    try {
      await api.post('/api/v1/auth/lock')
      toast.success('Alpha locked — your password is required to resume')
      await queryClient.invalidateQueries({ queryKey: ['auth-status'] })
      await queryClient.invalidateQueries({ queryKey: ['sessions'] })
    } catch (e) {
      toast.error(e instanceof ApiError ? e.message : 'Failed to lock')
    } finally {
      setLocking(false)
      setLockConfirm(false)
    }
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault()
    if (changing) return
    if (newPassword.length < 8) {
      toast.error('New password must be at least 8 characters')
      return
    }
    setChanging(true)
    try {
      await api.post('/api/v1/auth/password', { currentPassword, newPassword })
      setCurrentPassword('')
      setNewPassword('')
      toast.success('Password changed — other sessions signed out')
      await queryClient.invalidateQueries({ queryKey: ['sessions'] })
    } catch (e) {
      toast.error(
        e instanceof ApiError ? e.message : 'Could not change password',
      )
    } finally {
      setChanging(false)
    }
  }

  async function revokeSession(session: SessionInfo) {
    setRevoking(true)
    try {
      await api.delete(`/api/v1/sessions/${session.id}`)
      await queryClient.invalidateQueries({ queryKey: ['sessions'] })
      await queryClient.invalidateQueries({ queryKey: ['audit'] })
      toast.success('Session revoked')
    } catch (e) {
      toast.error(e instanceof ApiError ? e.message : 'Failed to revoke session')
    } finally {
      setRevoking(false)
      setRevokeTarget(null)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="flex flex-col gap-6"
    >
      {/* Lock */}
      <Card className="alpha-panel border-0">
        <CardContent className="flex flex-col items-center gap-4 p-6 text-center">
          <div className="flex size-16 items-center justify-center rounded-lg bg-accent/10 text-accent">
            <ShieldCheck className="size-8" aria-hidden />
          </div>
          <div>
            <p className="text-base font-semibold">Alpha is operational</p>
            <p className="mx-auto mt-1 max-w-md text-xs leading-relaxed text-muted-foreground">
              Locking immediately secures this session — Alpha stays locked until
              you re-enter your password. Locking requires your password to
              resume.
            </p>
          </div>
          <Button
            variant="destructive"
            onClick={() => setLockConfirm(true)}
            className="gap-2"
          >
            <Lock className="size-4" aria-hidden /> Lock Alpha now
          </Button>
        </CardContent>
      </Card>

      {/* Change password */}
      <Card className="alpha-panel border-0">
        <CardHeader className="border-b border-border/60 py-3">
          <CardTitle className="flex items-center gap-2 text-sm">
            <KeyRound className="size-4 text-accent" aria-hidden /> Change password
          </CardTitle>
          <CardDescription className="text-xs">
            Changing your password signs out every other session.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-4">
          <form onSubmit={changePassword} className="flex flex-col gap-3 sm:flex-row sm:items-end">
            <div className="min-w-0 flex-1">
              <Label htmlFor="current-password" className="text-xs text-muted-foreground">
                Current password
              </Label>
              <Input
                id="current-password"
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                autoComplete="current-password"
                className="mt-1"
                required
              />
            </div>
            <div className="min-w-0 flex-1">
              <Label htmlFor="new-password" className="text-xs text-muted-foreground">
                New password (min 8 chars)
              </Label>
              <Input
                id="new-password"
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                autoComplete="new-password"
                minLength={8}
                className="mt-1"
                required
              />
            </div>
            <Button type="submit" disabled={changing || !currentPassword || newPassword.length < 8} className="gap-2">
              {changing ? (
                <Loader2 className="size-4 animate-spin" aria-hidden />
              ) : (
                <KeyRound className="size-4" aria-hidden />
              )}
              Update password
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Sessions */}
      <Card className="alpha-panel border-0">
        <CardHeader className="border-b border-border/60 py-3">
          <CardTitle className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-2">
              <MonitorSmartphone className="size-4 text-accent" aria-hidden /> Active sessions
            </span>
            <Badge variant="outline" className="text-[10px]">
              {sessions.length} session{sessions.length === 1 ? '' : 's'}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-3">
          {sessionsQuery.isLoading ? (
            <div className="space-y-2" aria-hidden>
              {Array.from({ length: 2 }).map((_, i) => (
                <div key={i} className="h-12 animate-pulse rounded-lg bg-muted/50" />
              ))}
            </div>
          ) : sessions.length === 0 ? (
            <p className="px-2 py-6 text-center text-xs text-muted-foreground">
              No active sessions.
            </p>
          ) : (
            <ul className="flex max-h-72 flex-col gap-1 overflow-y-auto alpha-scroll">
              {sessions.map((s) => (
                <li
                  key={s.id}
                  className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-lg p-2.5 transition-colors hover:bg-accent/5 sm:flex-nowrap"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="truncate text-xs font-semibold">{parseUserAgent(s.userAgent)}</p>
                      {s.current && (
                        <Badge variant="outline" className="border-accent/40 bg-accent/10 text-[10px] text-accent">
                          This device
                        </Badge>
                      )}
                      {s.locked && (
                        <Badge variant="outline" className="gap-1 text-[10px] text-muted-foreground">
                          <Lock className="size-2.5" aria-hidden /> Locked
                        </Badge>
                      )}
                    </div>
                    <p className="mt-0.5 truncate font-mono text-[10px] text-muted-foreground">
                      {s.ip ?? 'no IP'} · created {new Date(s.createdAt).toLocaleDateString()} ·
                      last seen {new Date(s.lastSeenAt).toLocaleString()}
                    </p>
                  </div>
                  {!s.current && (
                    <Button
                      size="icon"
                      variant="ghost"
                      className="size-7 shrink-0 text-destructive hover:bg-destructive/10"
                      onClick={() => setRevokeTarget(s)}
                      aria-label={`Revoke session from ${parseUserAgent(s.userAgent)}`}
                    >
                      <Trash2 className="size-3.5" aria-hidden />
                    </Button>
                  )}
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      {/* Audit log */}
      <Card className="alpha-panel border-0">
        <CardHeader className="border-b border-border/60 py-3">
          <CardTitle className="flex items-center justify-between text-sm">
            <span>Audit log</span>
            <Badge variant="outline" className="text-[10px]">
              {events.length} entr{events.length === 1 ? 'y' : 'ies'}
            </Badge>
          </CardTitle>
          <CardDescription className="text-xs">
            Audit log records security-relevant actions.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-3">
          {auditQuery.isLoading ? (
            <div className="space-y-2" aria-hidden>
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-9 animate-pulse rounded-lg bg-muted/50" />
              ))}
            </div>
          ) : events.length === 0 ? (
            <EmptyState
              icon={ShieldCheck}
              title="No audit entries yet"
              description="Security-relevant actions across Alpha — sign-ins, locks, password changes, deletions — will be recorded here."
            />
          ) : (
            <div className="max-h-96 overflow-y-auto alpha-scroll">
              {events.map((ev) => {
                const open = expandedLog === ev.id
                return (
                  <div key={ev.id}>
                    <button
                      type="button"
                      onClick={() => setExpandedLog(open ? null : ev.id)}
                      aria-expanded={open}
                      className="flex w-full items-center gap-3 rounded-lg py-2 pr-2 text-left transition-colors hover:bg-accent/5"
                    >
                      <Badge variant="outline" className="shrink-0 text-[10px] capitalize">
                        {ev.category}
                      </Badge>
                      <span className="min-w-0 flex-1 truncate text-xs font-medium">
                        {ev.action}
                      </span>
                      <span className="shrink-0 text-[10px] text-muted-foreground">
                        {new Date(ev.createdAt).toLocaleString()}
                      </span>
                      {ev.details ? (
                        open ? (
                          <ChevronUp className="size-3.5 shrink-0 text-muted-foreground" aria-hidden />
                        ) : (
                          <ChevronDown className="size-3.5 shrink-0 text-muted-foreground" aria-hidden />
                        )
                      ) : (
                        <span className="w-3.5 shrink-0" aria-hidden />
                      )}
                    </button>
                    {open && (
                      <div className="mb-1 rounded-lg border border-border/50 bg-muted/20 p-2.5">
                        <pre className="overflow-x-auto text-[10px] leading-relaxed text-muted-foreground">
                          {prettyDetails(ev.details)}
                        </pre>
                        <p className="mt-1.5 font-mono text-[10px] text-muted-foreground">
                          ip: {ev.ip ?? 'unknown'}
                        </p>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Lock confirm */}
      <AlertDialog open={lockConfirm} onOpenChange={setLockConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Lock Alpha now?</AlertDialogTitle>
            <AlertDialogDescription>
              This session is secured immediately. You will need to enter your
              password to resume using Alpha on this device.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={locking}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={locking}
              className={cn('gap-2 bg-destructive text-white hover:bg-destructive/90')}
              onClick={(e) => {
                e.preventDefault()
                void lockNow()
              }}
            >
              {locking ? (
                <Loader2 className="size-4 animate-spin" aria-hidden />
              ) : (
                <Lock className="size-4" aria-hidden />
              )}
              Lock now
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Revoke confirm */}
      <AlertDialog open={!!revokeTarget} onOpenChange={(o) => !o && setRevokeTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Revoke this session?</AlertDialogTitle>
            <AlertDialogDescription>
              {revokeTarget
                ? `${parseUserAgent(revokeTarget.userAgent)} (${revokeTarget.ip ?? 'no IP'}) will be signed out immediately.`
                : ''}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={revoking}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={revoking}
              className="gap-2 bg-destructive text-white hover:bg-destructive/90"
              onClick={(e) => {
                e.preventDefault()
                if (revokeTarget) void revokeSession(revokeTarget)
              }}
            >
              {revoking ? (
                <Loader2 className="size-4 animate-spin" aria-hidden />
              ) : (
                <Trash2 className="size-4" aria-hidden />
              )}
              Revoke session
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  )
}
