'use client'

import * as React from 'react'
import { keepPreviousData, useQuery } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import {
  Activity,
  CheckCircle2,
  Cpu,
  Database,
  Gauge,
  HardDrive,
  Loader2,
  RefreshCw,
  XCircle,
} from 'lucide-react'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { cn } from '@/lib/utils'
import { api, type ProviderInfo, type SystemHealth } from '@/lib/api'

// ============================================================
// System — REAL health. Every latency here is measured live by
// the server (D1 query, R2 head, optional live AI ping).
// Nothing is simulated.
// ============================================================

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  const units = ['KB', 'MB', 'GB', 'TB']
  let value = bytes / 1024
  let i = 0
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024
    i++
  }
  return `${value < 10 ? value.toFixed(1) : Math.round(value)} ${units[i]}`
}

function timeAgo(iso: string): string {
  const s = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000))
  if (s < 5) return 'just now'
  if (s < 60) return `${s}s ago`
  if (s < 3600) return `${Math.floor(s / 60)}m ago`
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`
  return `${Math.floor(s / 86400)}d ago`
}

function latencyColor(ms: number): string {
  if (ms < 200) return 'bg-emerald-500'
  if (ms < 500) return 'bg-amber-500'
  return 'bg-destructive'
}

function LatencyBar({ latencyMs }: { latencyMs: number }) {
  const pct = Math.min(100, (latencyMs / 800) * 100)
  return (
    <div className="mt-2 h-1 w-full overflow-hidden rounded-full bg-muted/40" aria-hidden>
      <div
        className={cn('h-full rounded-full transition-all', latencyColor(latencyMs))}
        style={{ width: `${pct}%` }}
      />
    </div>
  )
}

function StatusDot({ ok }: { ok: boolean }) {
  return (
    <span
      className={cn(
        'alpha-status-dot shrink-0',
        ok ? 'bg-emerald-500 text-emerald-500' : 'bg-destructive text-destructive',
      )}
      role="status"
      aria-label={ok ? 'healthy' : 'unhealthy'}
    />
  )
}

const PROVIDER_STATUS_COLORS: Record<string, string> = {
  healthy: 'bg-emerald-500 text-emerald-500',
  degraded: 'bg-amber-500 text-amber-500',
  offline: 'bg-destructive text-destructive',
  unknown: 'bg-accent text-accent',
}

/** Compact per-provider row — real router status, never a fabricated metric. */
function ProviderRow({ p }: { p: ProviderInfo }) {
  const status = p.configured ? (p.status ?? 'unknown') : 'offline'
  return (
    <li className="flex items-center gap-2.5 rounded-lg px-1.5 py-1.5 transition-colors hover:bg-accent/5">
      <span
        className={cn('alpha-status-dot shrink-0', PROVIDER_STATUS_COLORS[status] ?? PROVIDER_STATUS_COLORS.unknown)}
        role="status"
        aria-label={`provider ${p.name}: ${status}`}
      />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-medium">{p.name}</span>
          {p.priority !== undefined && (
            <span className="font-mono text-[9px] text-muted-foreground">#{p.priority}</span>
          )}
        </div>
        <p className="truncate font-mono text-[10px] text-muted-foreground">
          {p.configured ? (p.model ?? '—') : 'not configured'}
        </p>
      </div>
      <div className="flex shrink-0 items-center gap-2">
        {p.lastErrorCategory && (
          <Badge variant="outline" className="border-destructive/30 text-[9px] text-destructive">
            {p.lastErrorCategory}
          </Badge>
        )}
        {p.configured && p.latencyMs != null ? (
          <span className="font-mono text-[10px] text-muted-foreground">{p.latencyMs}ms</span>
        ) : (
          <span className="text-[10px] capitalize text-muted-foreground">
            {p.configured ? status : 'offline'}
          </span>
        )}
      </div>
    </li>
  )
}

const JOB_STATUS_COLORS: Record<string, string> = {
  done: 'text-emerald-600 dark:text-emerald-400 border-emerald-500/30',
  failed: 'text-destructive border-destructive/30',
  running: 'text-amber-600 dark:text-amber-400 border-amber-500/30',
  queued: 'text-muted-foreground border-border/60',
}

export function SystemView() {
  const [aiPing, setAiPing] = React.useState(false)

  const healthQuery = useQuery({
    queryKey: ['system-health', aiPing ? 'ai' : 'basic'],
    queryFn: () =>
      api.get<SystemHealth>(`/api/v1/system/health${aiPing ? '?ai=1' : ''}`),
    refetchInterval: 30_000,
    placeholderData: keepPreviousData,
  })
  const health = healthQuery.data

  const providersQuery = useQuery({
    queryKey: ['providers'],
    queryFn: () => api.get<{ providers: ProviderInfo[] }>('/api/v1/providers'),
  })
  const activeProvider = providersQuery.data?.providers.find(
    (p) => p.id === health?.ai.provider,
  )

  const refreshing = healthQuery.isFetching
  const jobs = health?.jobs.recent ?? []

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="flex flex-col gap-6"
    >
      {/* Summary banner */}
      <Card className="alpha-panel border-0">
        <CardContent className="flex flex-wrap items-center justify-between gap-4 p-4">
          <div className="flex items-center gap-3">
            <div className="flex size-10 items-center justify-center rounded-lg bg-accent/10 text-accent">
              <Activity className="size-5" aria-hidden />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <p className="text-sm font-semibold">System health</p>
                {health && (
                  <Badge
                    variant="outline"
                    className={cn(
                      'text-[10px] capitalize',
                      health.status === 'healthy'
                        ? 'text-emerald-600 dark:text-emerald-400 border-emerald-500/30'
                        : 'text-amber-600 dark:text-amber-400 border-amber-500/30',
                    )}
                  >
                    {health.status}
                  </Badge>
                )}
              </div>
              <p className="text-xs text-muted-foreground">
                {health
                  ? `Checked ${timeAgo(health.checkedAt)} · auto-refreshes every 30s`
                  : 'Checking…'}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              <Switch
                id="ai-ping"
                checked={aiPing}
                onCheckedChange={setAiPing}
                aria-label="Run live AI ping"
              />
              <Label htmlFor="ai-ping" className="text-xs text-muted-foreground">
                Live AI ping
              </Label>
            </div>
            <Button
              variant="outline"
              onClick={() => void healthQuery.refetch()}
              disabled={refreshing}
              className="gap-2"
            >
              {refreshing ? (
                <Loader2 className="size-4 animate-spin" aria-hidden />
              ) : (
                <RefreshCw className="size-4" aria-hidden />
              )}
              Refresh
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Infrastructure cards */}
      {healthQuery.isLoading && !health ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3" aria-hidden>
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-36 animate-pulse rounded-xl bg-muted/50" />
          ))}
        </div>
      ) : health ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {/* D1 */}
          <Card className="alpha-panel border-0">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-sm">
                <Database className="size-4 text-accent" aria-hidden /> D1 database
              </CardTitle>
              <CardDescription className="text-xs">Cloudflare D1 (SQLite)</CardDescription>
            </CardHeader>
            <CardContent className="pt-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <StatusDot ok={health.db.ok} />
                  <span className="text-xs font-medium">
                    {health.db.ok ? 'Responsive' : 'Unreachable'}
                  </span>
                </div>
                <span className="font-mono text-xs text-muted-foreground">
                  {health.db.latencyMs}ms
                </span>
              </div>
              <LatencyBar latencyMs={health.db.latencyMs} />
              {health.db.error && (
                <p className="mt-2 break-words text-[10px] text-destructive">{health.db.error}</p>
              )}
            </CardContent>
          </Card>

          {/* R2 */}
          <Card className="alpha-panel border-0">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-sm">
                <HardDrive className="size-4 text-accent" aria-hidden /> R2 storage
              </CardTitle>
              <CardDescription className="text-xs">Object storage for files &amp; media</CardDescription>
            </CardHeader>
            <CardContent className="pt-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <StatusDot ok={health.storage.ok} />
                  <span className="text-xs font-medium">
                    {health.storage.ok ? 'Responsive' : 'Unreachable'}
                  </span>
                </div>
                <span className="font-mono text-xs text-muted-foreground">
                  {health.storage.latencyMs}ms
                </span>
              </div>
              <LatencyBar latencyMs={health.storage.latencyMs} />
              <p className="mt-2 text-[11px] text-muted-foreground">
                {health.storageUsage.count} object{health.storageUsage.count === 1 ? '' : 's'} ·{' '}
                {formatBytes(health.storageUsage.bytes)} stored
              </p>
              {health.storage.error && (
                <p className="mt-2 break-words text-[10px] text-destructive">
                  {health.storage.error}
                </p>
              )}
            </CardContent>
          </Card>

          {/* AI provider */}
          <Card className="alpha-panel border-0">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-sm">
                <Cpu className="size-4 text-accent" aria-hidden /> AI provider
              </CardTitle>
              <CardDescription className="text-xs font-mono">{health.ai.provider}</CardDescription>
            </CardHeader>
            <CardContent className="pt-2">
              {health.ai.configured ? (
                <>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {health.ai.ok !== undefined ? (
                        <>
                          <StatusDot ok={health.ai.ok} />
                          <span className="text-xs font-medium">
                            {health.ai.ok ? 'Responding' : 'Ping failed'}
                          </span>
                        </>
                      ) : (
                        <>
                          <span className="alpha-status-dot bg-accent text-accent" role="status" aria-label="configured" />
                          <span className="text-xs font-medium">Configured</span>
                        </>
                      )}
                    </div>
                    {health.ai.latencyMs !== undefined && (
                      <span className="font-mono text-xs text-muted-foreground">
                        {health.ai.latencyMs}ms
                      </span>
                    )}
                  </div>
                  {health.ai.latencyMs !== undefined ? (
                    <LatencyBar latencyMs={health.ai.latencyMs} />
                  ) : (
                    <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">
                      Config-only view — enable live AI ping above to measure a
                      real round-trip.
                    </p>
                  )}
                  {health.ai.error && (
                    <p className="mt-2 break-words text-[10px] text-destructive">
                      {health.ai.error}
                    </p>
                  )}
                </>
              ) : (
                <>
                  <div className="flex items-center gap-2">
                    <XCircle className="size-4 shrink-0 text-muted-foreground" aria-hidden />
                    <span className="text-xs font-medium text-muted-foreground">
                      Not configured
                    </span>
                  </div>
                  <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">
                    {activeProvider?.guide ?? 'AI provider credentials are not set in this environment.'}
                  </p>
                </>
              )}
              {/* Router providers — real per-provider health from the AI router */}
              {health.ai.providers && health.ai.providers.length > 0 && (
                <div className="mt-3 border-t border-border/60 pt-2">
                  <p className="mb-1 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
                    AI router · {health.ai.providers.filter((p) => p.configured && p.enabled !== false).length} configured
                  </p>
                  <ul className="flex flex-col">
                    {health.ai.providers.map((p) => (
                      <ProviderRow key={p.id} p={p} />
                    ))}
                  </ul>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      ) : null}

      {/* Jobs */}
      <Card className="alpha-panel border-0">
        <CardHeader className="border-b border-border/60 py-3">
          <CardTitle className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-2">
              <Gauge className="size-4 text-accent" aria-hidden /> Background jobs
            </span>
            {health && (
              <span className="text-xs font-normal text-muted-foreground">
                {Object.values(health.jobs.counts).reduce((a, b) => a + b, 0)} total
              </span>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          {health && (
            <div className="mb-3 flex flex-wrap gap-2">
              {(['queued', 'running', 'done', 'failed'] as const).map((status) => (
                <Badge key={status} variant="outline" className={cn('gap-1.5 text-[10px] capitalize', JOB_STATUS_COLORS[status])}>
                  {status}
                  <span className="font-mono">{health.jobs.counts[status] ?? 0}</span>
                </Badge>
              ))}
            </div>
          )}
          {healthQuery.isLoading && !health ? (
            <div className="space-y-2" aria-hidden>
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="h-9 animate-pulse rounded-lg bg-muted/50" />
              ))}
            </div>
          ) : jobs.length === 0 ? (
            <p className="px-2 py-6 text-center text-xs text-muted-foreground">
              No jobs yet — image generations and other background work will be
              tracked here.
            </p>
          ) : (
            <ul className="flex max-h-72 flex-col gap-1 overflow-y-auto alpha-scroll">
              {jobs.map((j) => (
                <li
                  key={j.id}
                  className="flex items-center gap-3 rounded-lg p-2 text-xs transition-colors hover:bg-accent/5"
                >
                  <span className="rounded border border-border/60 bg-muted/30 px-1.5 py-0.5 font-mono text-[10px]">
                    {j.kind}
                  </span>
                  {j.status === 'done' ? (
                    <CheckCircle2 className="size-3.5 shrink-0 text-emerald-500" aria-hidden />
                  ) : j.status === 'failed' ? (
                    <XCircle className="size-3.5 shrink-0 text-destructive" aria-hidden />
                  ) : (
                    <Loader2 className="size-3.5 shrink-0 animate-spin text-accent" aria-hidden />
                  )}
                  <span className="flex-1 truncate text-muted-foreground">
                    {j.kind.replace(/_/g, ' ')}
                  </span>
                  <Badge
                    variant="outline"
                    className={cn('shrink-0 text-[10px] capitalize', JOB_STATUS_COLORS[j.status] ?? '')}
                  >
                    {j.status}
                  </Badge>
                  <span className="shrink-0 text-[10px] text-muted-foreground">
                    {timeAgo(j.createdAt)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      {/* Version footer note */}
      {health && (
        <p className="text-center text-[11px] text-muted-foreground">
          Alpha v{health.version} · {health.users} registered user
          {health.users === 1 ? '' : 's'} · checked{' '}
          {new Date(health.checkedAt).toLocaleString()}
        </p>
      )}
    </motion.div>
  )
}
