'use client'

import * as React from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import {
  Bell,
  BellOff,
  CalendarClock,
  CalendarDays,
  Check,
  Clock,
  MapPin,
  Pencil,
  Plus,
  Trash2,
  Users,
  AlertTriangle,
} from 'lucide-react'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { api, ApiError, type CalendarEvent, type Reminder } from '@/lib/api'
import { EmptyState } from '@/components/common/EmptyState'
import { CardSkeleton } from '@/components/common/Skeletons'

// ============================================================
// Planner — full reminders + calendar management.
// Every item is real data from D1 via /api/v1/reminders & /api/v1/calendar.
// ============================================================

const DAY_MS = 24 * 60 * 60 * 1000

function startOfToday(): Date {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  return d
}

/** Format an epoch-ms instant for display. */
function fmtInstant(ts: number): string {
  const d = new Date(ts)
  return d.toLocaleString([], {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

function fmtTime(ts: number): string {
  return new Date(ts).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  })
}

/** Value for <Input type="datetime-local"> from epoch ms (or ''). */
function toLocalInput(ts: number | null | undefined): string {
  if (!ts) return ''
  const d = new Date(ts)
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`
}

/** Parse a datetime-local input value to epoch ms (or null). */
function fromLocalInput(value: string): number | null {
  if (!value) return null
  const ts = new Date(value).getTime()
  return Number.isFinite(ts) ? ts : null
}

type DueBucket = 'overdue' | 'today' | 'upcoming' | 'someday'

function dueBucket(r: Reminder): DueBucket {
  if (r.dueAt === null) return 'someday'
  const today = startOfToday().getTime()
  if (r.dueAt < today) return 'overdue'
  if (r.dueAt < today + DAY_MS) return 'today'
  return 'upcoming'
}

const DUE_META: Record<DueBucket, { label: string; className: string }> = {
  overdue: {
    label: 'Overdue',
    className: 'border-destructive/40 bg-destructive/10 text-destructive',
  },
  today: {
    label: 'Today',
    className: 'border-accent/40 bg-accent/10 text-accent',
  },
  upcoming: { label: 'Upcoming', className: 'border-border bg-muted/50' },
  someday: { label: 'No date', className: 'border-border bg-muted/50' },
}

const PRIORITY_META: Record<Reminder['priority'], { label: string; className: string }> = {
  high: {
    label: 'High',
    className: 'border-destructive/40 bg-destructive/10 text-destructive',
  },
  normal: { label: 'Normal', className: 'border-border/70 bg-muted/50 text-muted-foreground' },
  low: { label: 'Low', className: 'border-border/70 bg-muted/30 text-muted-foreground/80' },
}

// ============================================================
// Reminder dialog (add + edit)
// ============================================================

interface ReminderDraft {
  id?: string
  title: string
  note: string
  dueAt: string // datetime-local value
  priority: Reminder['priority']
}

const EMPTY_REMINDER_DRAFT: ReminderDraft = {
  title: '',
  note: '',
  dueAt: '',
  priority: 'normal',
}

function ReminderDialog({
  open,
  onOpenChange,
  draft,
  onSaved,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  draft: ReminderDraft
  onSaved: () => void
}) {
  const [form, setForm] = React.useState<ReminderDraft>(draft)
  const [saving, setSaving] = React.useState(false)

  React.useEffect(() => {
    if (open) setForm(draft)
  }, [open, draft])

  async function save() {
    if (!form.title.trim()) {
      toast.error('Title is required')
      return
    }
    setSaving(true)
    try {
      const body = {
        title: form.title.trim(),
        note: form.note.trim() || undefined,
        dueAt: fromLocalInput(form.dueAt) ?? undefined,
        priority: form.priority,
      }
      if (form.id) {
        await api.patch(`/api/v1/reminders/${form.id}`, body)
        toast.success('Reminder updated')
      } else {
        await api.post('/api/v1/reminders', body)
        toast.success('Reminder created')
      }
      onSaved()
      onOpenChange(false)
    } catch (e) {
      toast.error(e instanceof ApiError ? e.message : 'Could not save the reminder')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{form.id ? 'Edit reminder' : 'New reminder'}</DialogTitle>
          <DialogDescription>
            Reminders persist in your Alpha database. Ask Alpha in chat to set
            one for you, too.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid gap-2">
            <Label htmlFor="reminder-title">Title</Label>
            <Input
              id="reminder-title"
              value={form.title}
              onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
              placeholder="e.g. Review the deployment checklist"
              maxLength={300}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="reminder-note">Note (optional)</Label>
            <Textarea
              id="reminder-note"
              value={form.note}
              onChange={(e) => setForm((f) => ({ ...f, note: e.target.value }))}
              placeholder="Details…"
              rows={3}
              maxLength={2000}
            />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="reminder-due">Due (optional)</Label>
              <Input
                id="reminder-due"
                type="datetime-local"
                value={form.dueAt}
                onChange={(e) => setForm((f) => ({ ...f, dueAt: e.target.value }))}
              />
            </div>
            <div className="grid gap-2">
              <Label>Priority</Label>
              <Select
                value={form.priority}
                onValueChange={(v) =>
                  setForm((f) => ({ ...f, priority: v as Reminder['priority'] }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={save} disabled={saving || !form.title.trim()} className="gap-2">
            {saving && <Clock className="size-4 animate-pulse" />}
            {form.id ? 'Save changes' : 'Create reminder'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

// ============================================================
// Event dialog (add + edit)
// ============================================================

interface EventDraft {
  id?: string
  title: string
  location: string
  startAt: string
  endAt: string
  attendees: string // comma-separated
}

const EMPTY_EVENT_DRAFT: EventDraft = {
  title: '',
  location: '',
  startAt: '',
  endAt: '',
  attendees: '',
}

function EventDialog({
  open,
  onOpenChange,
  draft,
  onSaved,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  draft: EventDraft
  onSaved: () => void
}) {
  const [form, setForm] = React.useState<EventDraft>(draft)
  const [saving, setSaving] = React.useState(false)

  React.useEffect(() => {
    if (open) setForm(draft)
  }, [open, draft])

  async function save() {
    if (!form.title.trim()) {
      toast.error('Title is required')
      return
    }
    const startAt = fromLocalInput(form.startAt)
    if (!startAt) {
      toast.error('A start date and time is required')
      return
    }
    const endAt = fromLocalInput(form.endAt)
    if (endAt !== null && endAt <= startAt) {
      toast.error('End must be after the start')
      return
    }
    const attendees = form.attendees
      .split(',')
      .map((a) => a.trim())
      .filter((a) => a.length > 0 && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(a))
    const rejected = form.attendees
      .split(',')
      .map((a) => a.trim())
      .filter((a) => a.length > 0 && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(a))
    if (rejected.length > 0) {
      toast.error(`Invalid email address: ${rejected[0]}`)
      return
    }

    setSaving(true)
    try {
      const body = {
        title: form.title.trim(),
        location: form.location.trim() || undefined,
        startAt,
        endAt: endAt ?? undefined,
        attendees: attendees.length > 0 ? attendees : undefined,
      }
      if (form.id) {
        await api.patch(`/api/v1/calendar/${form.id}`, body)
        toast.success('Event updated')
      } else {
        await api.post('/api/v1/calendar', body)
        toast.success('Event created')
      }
      onSaved()
      onOpenChange(false)
    } catch (e) {
      toast.error(e instanceof ApiError ? e.message : 'Could not save the event')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{form.id ? 'Edit event' : 'New calendar event'}</DialogTitle>
          <DialogDescription>
            Events persist in your Alpha database and appear on Home and in chat
            when relevant.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid gap-2">
            <Label htmlFor="event-title">Title</Label>
            <Input
              id="event-title"
              value={form.title}
              onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
              placeholder="e.g. Design review"
              maxLength={300}
            />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="event-start">Starts</Label>
              <Input
                id="event-start"
                type="datetime-local"
                value={form.startAt}
                onChange={(e) => setForm((f) => ({ ...f, startAt: e.target.value }))}
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="event-end">Ends (optional)</Label>
              <Input
                id="event-end"
                type="datetime-local"
                value={form.endAt}
                onChange={(e) => setForm((f) => ({ ...f, endAt: e.target.value }))}
              />
            </div>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="event-location">Location (optional)</Label>
            <Input
              id="event-location"
              value={form.location}
              onChange={(e) => setForm((f) => ({ ...f, location: e.target.value }))}
              placeholder="e.g. Zoom, Conference Room A"
              maxLength={300}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="event-attendees">Attendees (optional, comma-separated emails)</Label>
            <Input
              id="event-attendees"
              value={form.attendees}
              onChange={(e) => setForm((f) => ({ ...f, attendees: e.target.value }))}
              placeholder="a@example.com, b@example.com"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={save} disabled={saving || !form.title.trim()} className="gap-2">
            {saving && <Clock className="size-4 animate-pulse" />}
            {form.id ? 'Save changes' : 'Create event'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

// ============================================================
// Reminder row
// ============================================================

function ReminderRow({
  reminder,
  onEdit,
  onDelete,
}: {
  reminder: Reminder
  onEdit: () => void
  onDelete: () => void
}) {
  const queryClient = useQueryClient()
  const [toggling, setToggling] = React.useState(false)
  const bucket = dueBucket(reminder)
  const due = DUE_META[bucket]

  async function toggleDone() {
    setToggling(true)
    try {
      await api.patch(`/api/v1/reminders/${reminder.id}`, { done: !reminder.done })
      await queryClient.invalidateQueries({ queryKey: ['reminders'] })
    } catch (e) {
      toast.error(e instanceof ApiError ? e.message : 'Could not update the reminder')
    } finally {
      setToggling(false)
    }
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className={cn(
        'group flex items-start gap-3 rounded-md border border-border/60 bg-card/40 p-3.5 transition-colors hover:border-accent/30',
        reminder.done && 'opacity-60',
      )}
    >
      <button
        onClick={toggleDone}
        disabled={toggling}
        aria-label={reminder.done ? 'Mark as not done' : 'Mark as done'}
        className={cn(
          'mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-md border transition-colors',
          reminder.done
            ? 'border-accent bg-accent text-accent-foreground'
            : 'border-border hover:border-accent/60',
        )}
      >
        {reminder.done && <Check className="size-3.5" />}
      </button>
      <div className="min-w-0 flex-1">
        <p
          className={cn(
            'text-sm font-medium leading-snug',
            reminder.done && 'line-through decoration-muted-foreground/50',
          )}
        >
          {reminder.title}
        </p>
        {reminder.note && (
          <p className="mt-0.5 truncate text-xs text-muted-foreground">{reminder.note}</p>
        )}
        <div className="mt-2 flex flex-wrap items-center gap-1.5">
          <span
            className={cn(
              'inline-flex items-center gap-1 rounded-md border px-2 py-0.5 font-mono text-[10px] font-medium tracking-[0.03em]',
              due.className,
            )}
          >
            {bucket === 'overdue' && <AlertTriangle className="size-3" />}
            {bucket === 'today' && <Clock className="size-3" />}
            {bucket === 'upcoming' && <CalendarClock className="size-3" />}
            {bucket === 'someday' && <CalendarDays className="size-3" />}
            {bucket === 'someday' ? 'No due date' : fmtInstant(reminder.dueAt!)}
          </span>
          <span
            className={cn(
              'rounded-md border px-2 py-0.5 font-mono text-[10px] font-medium tracking-[0.03em]',
              PRIORITY_META[reminder.priority].className,
            )}
          >
            {PRIORITY_META[reminder.priority].label}
          </span>
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100 focus-within:opacity-100">
        <Button variant="ghost" size="icon" className="size-8" onClick={onEdit} aria-label="Edit reminder">
          <Pencil className="size-3.5" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="size-8 text-destructive hover:text-destructive"
          onClick={onDelete}
          aria-label="Delete reminder"
        >
          <Trash2 className="size-3.5" />
        </Button>
      </div>
    </motion.div>
  )
}

// ============================================================
// Event card
// ============================================================

function EventCard({
  event,
  onEdit,
  onDelete,
}: {
  event: CalendarEvent
  onEdit: () => void
  onDelete: () => void
}) {
  const today = startOfToday().getTime()
  const isToday = event.startAt >= today && event.startAt < today + DAY_MS
  const isPast = event.startAt < today

  const dayLabel = isToday
    ? 'Today'
    : new Date(event.startAt).toLocaleDateString([], {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
      })

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className={cn(
        'group relative overflow-hidden rounded-md border border-border/60 bg-card/40 p-4 transition-colors hover:border-accent/30',
        isPast && 'opacity-60',
      )}
    >
      {/* Accent day rail */}
      <div className="absolute inset-y-0 left-0 w-1 bg-gradient-to-b from-accent/70 to-accent/20" />
      <div className="flex items-start gap-4 pl-2">
        <div className="w-16 shrink-0 text-center">
          <p
            className={cn(
              'text-[10px] font-semibold uppercase tracking-wider',
              isToday ? 'text-accent' : 'text-muted-foreground',
            )}
          >
            {dayLabel.split(' ')[0]}
          </p>
          <p className="text-lg font-semibold leading-none">
            {new Date(event.startAt).toLocaleDateString([], { day: 'numeric' })}
          </p>
          <p className="mt-1 text-[10px] text-muted-foreground">
            {fmtTime(event.startAt)}
            {event.endAt ? `–${fmtTime(event.endAt)}` : ''}
          </p>
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium leading-snug">{event.title}</p>
          <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
            {event.location && (
              <span className="inline-flex items-center gap-1">
                <MapPin className="size-3" />
                {event.location}
              </span>
            )}
            {event.attendees.length > 0 && (
              <span className="inline-flex items-center gap-1">
                <Users className="size-3" />
                {event.attendees.length}{' '}
                {event.attendees.length === 1 ? 'attendee' : 'attendees'}
              </span>
            )}
            {event.source !== 'manual' && (
              <Badge variant="secondary" className="text-[10px]">
                {event.source}
              </Badge>
            )}
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100 focus-within:opacity-100">
          <Button variant="ghost" size="icon" className="size-8" onClick={onEdit} aria-label="Edit event">
            <Pencil className="size-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="size-8 text-destructive hover:text-destructive"
            onClick={onDelete}
            aria-label="Delete event"
          >
            <Trash2 className="size-3.5" />
          </Button>
        </div>
      </div>
    </motion.div>
  )
}

// ============================================================
// Planner view
// ============================================================

type ReminderFilter = 'open' | 'done' | 'all'

export function PlannerView() {
  const queryClient = useQueryClient()
  const [tab, setTab] = React.useState<'reminders' | 'calendar'>('reminders')
  const [reminderFilter, setReminderFilter] = React.useState<ReminderFilter>('open')

  const [reminderDialogOpen, setReminderDialogOpen] = React.useState(false)
  const [reminderDraft, setReminderDraft] = React.useState<ReminderDraft>(EMPTY_REMINDER_DRAFT)
  const [eventDialogOpen, setEventDialogOpen] = React.useState(false)
  const [eventDraft, setEventDraft] = React.useState<EventDraft>(EMPTY_EVENT_DRAFT)

  const [deleteTarget, setDeleteTarget] = React.useState<
    { kind: 'reminder' | 'event'; id: string; title: string } | null
  >(null)
  const [deleting, setDeleting] = React.useState(false)

  const remindersQuery = useQuery({
    queryKey: ['reminders', 'all'],
    queryFn: () => api.get<{ reminders: Reminder[] }>('/api/v1/reminders'),
  })
  const eventsQuery = useQuery({
    queryKey: ['calendar', 'all'],
    queryFn: () => api.get<{ events: CalendarEvent[] }>('/api/v1/calendar'),
  })

  const reminders = remindersQuery.data?.reminders ?? []
  const events = eventsQuery.data?.events ?? []

  const openReminders = reminders.filter((r) => !r.done)
  const overdue = openReminders.filter((r) => dueBucket(r) === 'overdue')
  const dueToday = openReminders.filter((r) => dueBucket(r) === 'today')
  const todayEvents = events.filter((e) => {
    const t = startOfToday().getTime()
    return e.startAt >= t && e.startAt < t + DAY_MS
  })

  const visibleReminders = reminders.filter((r) =>
    reminderFilter === 'all' ? true : reminderFilter === 'open' ? !r.done : r.done,
  )

  // Sort: overdue → today → upcoming → no date; done items last within filter.
  const sortedReminders = [...visibleReminders].sort((a, b) => {
    const order = (r: Reminder) => {
      const b = dueBucket(r)
      if (r.done) return 5
      if (b === 'overdue') return 0
      if (b === 'today') return 1
      if (b === 'upcoming') return 2
      return 3
    }
    const oa = order(a)
    const ob = order(b)
    if (oa !== ob) return oa - ob
    return (a.dueAt ?? Infinity) - (b.dueAt ?? Infinity)
  })

  const sortedEvents = [...events].sort((a, b) => a.startAt - b.startAt)
  const upcomingEvents = sortedEvents.filter((e) => e.startAt >= startOfToday().getTime())
  const pastEvents = sortedEvents
    .filter((e) => e.startAt < startOfToday().getTime())
    .reverse()

  function openNewReminder() {
    setReminderDraft(EMPTY_REMINDER_DRAFT)
    setReminderDialogOpen(true)
  }

  function openEditReminder(r: Reminder) {
    setReminderDraft({
      id: r.id,
      title: r.title,
      note: r.note ?? '',
      dueAt: toLocalInput(r.dueAt),
      priority: r.priority,
    })
    setReminderDialogOpen(true)
  }

  function openNewEvent() {
    setEventDraft(EMPTY_EVENT_DRAFT)
    setEventDialogOpen(true)
  }

  function openEditEvent(ev: CalendarEvent) {
    setEventDraft({
      id: ev.id,
      title: ev.title,
      location: ev.location ?? '',
      startAt: toLocalInput(ev.startAt),
      endAt: toLocalInput(ev.endAt),
      attendees: ev.attendees.join(', '),
    })
    setEventDialogOpen(true)
  }

  async function confirmDelete() {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      if (deleteTarget.kind === 'reminder') {
        await api.delete(`/api/v1/reminders/${deleteTarget.id}`)
        await queryClient.invalidateQueries({ queryKey: ['reminders'] })
      } else {
        await api.delete(`/api/v1/calendar/${deleteTarget.id}`)
        await queryClient.invalidateQueries({ queryKey: ['calendar'] })
      }
      toast.success(`${deleteTarget.kind === 'reminder' ? 'Reminder' : 'Event'} deleted`)
      setDeleteTarget(null)
    } catch (e) {
      toast.error(e instanceof ApiError ? e.message : 'Delete failed')
    } finally {
      setDeleting(false)
    }
  }

  function refresh() {
    void queryClient.invalidateQueries({ queryKey: ['reminders'] })
    void queryClient.invalidateQueries({ queryKey: ['calendar'] })
  }

  const loading = remindersQuery.isLoading || eventsQuery.isLoading

  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Planner</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Reminders and calendar events — persisted in your Alpha database.
            Ask Alpha in chat to schedule things for you.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" className="gap-2" onClick={openNewReminder}>
            <Bell className="size-4" />
            New reminder
          </Button>
          <Button className="alpha-ripple gap-2" onClick={openNewEvent}>
            <Plus className="size-4" />
            New event
          </Button>
        </div>
      </div>

      {/* Stat pills */}
      <div className="grid grid-cols-3 gap-3">
        <Card className="alpha-panel border-0">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="alpha-empty-halo shrink-0">
              <Bell className="size-4" />
            </div>
            <div className="min-w-0">
              <p className="text-lg font-semibold leading-none">{openReminders.length}</p>
              <p className="mt-1 truncate text-[11px] text-muted-foreground">
                open {openReminders.length === 1 ? 'reminder' : 'reminders'}
              </p>
            </div>
            {overdue.length > 0 && (
              <Badge
                variant="outline"
                className="ml-auto border-destructive/40 bg-destructive/10 text-destructive"
              >
                {overdue.length} overdue
              </Badge>
            )}
          </CardContent>
        </Card>
        <Card className="alpha-panel border-0">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="alpha-empty-halo shrink-0">
              <CalendarClock className="size-4" />
            </div>
            <div className="min-w-0">
              <p className="text-lg font-semibold leading-none">{dueToday.length}</p>
              <p className="mt-1 truncate text-[11px] text-muted-foreground">due today</p>
            </div>
          </CardContent>
        </Card>
        <Card className="alpha-panel border-0">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="alpha-empty-halo shrink-0">
              <CalendarDays className="size-4" />
            </div>
            <div className="min-w-0">
              <p className="text-lg font-semibold leading-none">{todayEvents.length}</p>
              <p className="mt-1 truncate text-[11px] text-muted-foreground">events today</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
        <TabsList>
          <TabsTrigger value="reminders" className="gap-2">
            <Bell className="size-3.5" />
            Reminders
            <Badge variant="secondary" className="ml-1 text-[10px]">
              {openReminders.length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="calendar" className="gap-2">
            <CalendarDays className="size-3.5" />
            Calendar
            <Badge variant="secondary" className="ml-1 text-[10px]">
              {upcomingEvents.length}
            </Badge>
          </TabsTrigger>
        </TabsList>

        {/* ---------- Reminders tab ---------- */}
        <TabsContent value="reminders" className="mt-4 flex flex-col gap-4">
          <div className="flex flex-wrap items-center gap-2">
            {(['open', 'done', 'all'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setReminderFilter(f)}
                className={cn(
                  'rounded-md border px-3 py-1 text-xs font-medium transition-colors',
                  reminderFilter === f
                    ? 'border-accent/50 bg-accent/10 text-accent'
                    : 'border-border/70 bg-card/40 text-muted-foreground hover:border-accent/40 hover:text-foreground',
                )}
                aria-pressed={reminderFilter === f}
              >
                {f === 'open' ? 'Open' : f === 'done' ? 'Completed' : 'All'}
              </button>
            ))}
            <Button
              variant="ghost"
              size="sm"
              className="ml-auto text-xs text-muted-foreground"
              onClick={() => refresh()}
            >
              Refresh
            </Button>
          </div>

          {loading ? (
            <div className="flex flex-col gap-3">
              <CardSkeleton lines={2} />
              <CardSkeleton lines={2} />
              <CardSkeleton lines={2} />
            </div>
          ) : sortedReminders.length === 0 ? (
            <EmptyState
              icon={reminderFilter === 'done' ? BellOff : Bell}
              title={
                reminderFilter === 'done'
                  ? 'No completed reminders yet'
                  : 'No reminders yet'
              }
              description={
                reminderFilter === 'done'
                  ? 'Reminders you complete will be listed here.'
                  : 'Create a reminder here, from Home, or just ask Alpha in chat — “remind me to review the deployment tomorrow at 9”.'
              }
              action={
                reminderFilter !== 'done' ? (
                  <Button variant="outline" size="sm" className="gap-2" onClick={openNewReminder}>
                    <Plus className="size-4" />
                    New reminder
                  </Button>
                ) : undefined
              }
            />
          ) : (
            <div className="flex max-h-[52vh] flex-col gap-2.5 overflow-y-auto alpha-scroll pr-1">
              {sortedReminders.map((r) => (
                <ReminderRow
                  key={r.id}
                  reminder={r}
                  onEdit={() => openEditReminder(r)}
                  onDelete={() =>
                    setDeleteTarget({ kind: 'reminder', id: r.id, title: r.title })
                  }
                />
              ))}
            </div>
          )}
        </TabsContent>

        {/* ---------- Calendar tab ---------- */}
        <TabsContent value="calendar" className="mt-4 flex flex-col gap-5">
          {loading ? (
            <div className="flex flex-col gap-3">
              <CardSkeleton lines={2} />
              <CardSkeleton lines={2} />
            </div>
          ) : upcomingEvents.length === 0 && pastEvents.length === 0 ? (
            <EmptyState
              icon={CalendarDays}
              title="No events yet"
              description="Create a calendar event here, or ask Alpha in chat — “schedule a design review Friday 2pm”."
              action={
                <Button variant="outline" size="sm" className="gap-2" onClick={openNewEvent}>
                  <Plus className="size-4" />
                  New event
                </Button>
              }
            />
          ) : (
            <>
              {upcomingEvents.length > 0 && (
                <section className="flex flex-col gap-3">
                  <CardHeader className="p-0 pb-0">
                    <CardTitle className="flex items-center gap-2 text-sm">
                      <CalendarClock className="size-4 text-accent" />
                      Upcoming
                    </CardTitle>
                    <CardDescription>
                      {upcomingEvents.length}{' '}
                      {upcomingEvents.length === 1 ? 'event' : 'events'} ahead
                    </CardDescription>
                  </CardHeader>
                  <div className="flex max-h-[38vh] flex-col gap-2.5 overflow-y-auto alpha-scroll pr-1">
                    {upcomingEvents.map((ev) => (
                      <EventCard
                        key={ev.id}
                        event={ev}
                        onEdit={() => openEditEvent(ev)}
                        onDelete={() =>
                          setDeleteTarget({ kind: 'event', id: ev.id, title: ev.title })
                        }
                      />
                    ))}
                  </div>
                </section>
              )}
              {pastEvents.length > 0 && (
                <section className="flex flex-col gap-3">
                  <CardHeader className="p-0 pb-0">
                    <CardTitle className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="size-4" />
                      Past
                    </CardTitle>
                    <CardDescription>Previously held events</CardDescription>
                  </CardHeader>
                  <div className="flex max-h-[30vh] flex-col gap-2.5 overflow-y-auto alpha-scroll pr-1">
                    {pastEvents.map((ev) => (
                      <EventCard
                        key={ev.id}
                        event={ev}
                        onEdit={() => openEditEvent(ev)}
                        onDelete={() =>
                          setDeleteTarget({ kind: 'event', id: ev.id, title: ev.title })
                        }
                      />
                    ))}
                  </div>
                </section>
              )}
            </>
          )}
        </TabsContent>
      </Tabs>

      {/* Dialogs */}
      <ReminderDialog
        open={reminderDialogOpen}
        onOpenChange={setReminderDialogOpen}
        draft={reminderDraft}
        onSaved={refresh}
      />
      <EventDialog
        open={eventDialogOpen}
        onOpenChange={setEventDialogOpen}
        draft={eventDraft}
        onSaved={refresh}
      />

      <AlertDialog
        open={deleteTarget !== null}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Delete {deleteTarget?.kind === 'reminder' ? 'reminder' : 'event'}?
            </AlertDialogTitle>
            <AlertDialogDescription>
              “{deleteTarget?.title}” will be permanently removed. This cannot
              be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              disabled={deleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? 'Deleting…' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
