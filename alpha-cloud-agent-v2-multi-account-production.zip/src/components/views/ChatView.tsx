'use client'

import * as React from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Plus,
  Search,
  Send,
  Mic,
  Loader2,
  Volume2,
  MoreHorizontal,
  Trash2,
  Pencil,
  X,
  Check,
  Copy,
  BrainCircuit,
  Pin,
  PinOff,
  Archive,
  ArchiveRestore,
  Inbox,
  MessageSquare,
  AlertCircle,
  PanelLeft,
  Settings as SettingsIcon,
  Paperclip,
  ArrowDown,
  Square,
} from 'lucide-react'
import { api, apiUpload } from '@/lib/api'
import type {
  Conversation,
  ChatMessage,
  FileRecord,
  ProvidersResponse,
} from '@/lib/api'
import { useAlpha } from '@/lib/store'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu'
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Badge } from '@/components/ui/badge'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { Markdown } from '@/components/common/Markdown'
import { EmptyState } from '@/components/common/EmptyState'
import { ChatListSkeleton, ChatThreadSkeleton } from '@/components/common/Skeletons'

const SUGGESTIONS = [
  'What can you do?',
  'Search the web for today’s top AI news',
  'Create a note about weekend plans',
  'Generate an image of a mountain sunrise',
]

/** Must match the chat API's attachment limit (see /api/v1/chat). */
const MAX_ATTACHMENT_BYTES = 10 * 1024 * 1024 // 10 MB

/** Composer textarea caps at 160px (max-h-40), then scrolls internally. */
const COMPOSER_MAX_HEIGHT = 160

/** Context assembly stats reported by the chat API via X-Alpha-Context. */
interface ContextStats {
  recent: number
  summary: boolean
  relevant: number
  memories: number
}

/** "recent=N; summary=0|1; relevant=N; memories=N" → stats, or null. */
function parseContextStats(raw: string | null): ContextStats | null {
  if (!raw) return null
  const parts = raw.split(';').map((p) => p.trim())
  const num = (key: string) => {
    const part = parts.find((p) => p.startsWith(`${key}=`))
    if (!part) return null
    const n = Number.parseInt(part.slice(key.length + 1), 10)
    return Number.isFinite(n) ? n : null
  }
  const recent = num('recent')
  const summary = num('summary')
  const relevant = num('relevant')
  const memories = num('memories')
  if (recent === null || summary === null || relevant === null || memories === null) {
    return null
  }
  return { recent, summary: summary === 1, relevant, memories }
}

/** Compact relative time for conversation rows ("2h ago", "Mar 3"). */
function relativeTime(iso: string): string {
  const d = new Date(iso)
  const mins = Math.floor((Date.now() - d.getTime()) / 60_000)
  if (mins < 1) return 'now'
  if (mins < 60) return `${mins}m ago`
  const hours = Math.floor(mins / 60)
  if (hours < 24) return `${hours}h ago`
  const days = Math.floor(hours / 24)
  if (days < 7) return `${days}d ago`
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })
}

/** An uploaded image waiting to be sent with the next message. */
interface PendingAttachment {
  id: string
  filename: string
  /** Local blob preview URL (revoked when the chip is cleared/replaced). */
  url: string
}

export function ChatView() {
  const queryClient = useQueryClient()
  const selectedConversationId = useAlpha((s) => s.selectedConversationId)
  const setConversation = useAlpha((s) => s.setConversation)
  const user = useAlpha((s) => s.user)

  const [search, setSearch] = React.useState('')
  const [input, setInput] = React.useState('')
  const [streaming, setStreaming] = React.useState(false)
  const [streamText, setStreamText] = React.useState('')
  const [activeConvId, setActiveConvId] = React.useState<string | null>(
    selectedConversationId,
  )
  const [renameId, setRenameId] = React.useState<string | null>(null)
  const [renameTitle, setRenameTitle] = React.useState('')
  const [deleteId, setDeleteId] = React.useState<string | null>(null)
  const [recording, setRecording] = React.useState(false)
  const [asrBusy, setAsrBusy] = React.useState(false)
  const [ttsUrl, setTtsUrl] = React.useState<string | null>(null)
  const [ttsBusyId, setTtsBusyId] = React.useState<string | null>(null)
  const [configError, setConfigError] = React.useState<string | null>(null)
  const [showArchived, setShowArchived] = React.useState(false)
  const [listSheetOpen, setListSheetOpen] = React.useState(false)

  // --- Composer / scroll additions -----------------------------------------
  const [attachment, setAttachment] = React.useState<PendingAttachment | null>(null)
  const [uploading, setUploading] = React.useState(false)
  const [showJump, setShowJump] = React.useState(false)
  /** Display name of the provider that actually served the last turn. */
  const [lastServedBy, setLastServedBy] = React.useState<string | null>(null)
  /** Context stats from the last turn's X-Alpha-Context header (if sent). */
  const [lastContextStats, setLastContextStats] = React.useState<ContextStats | null>(null)
  /** Fine-pointer (desktop) devices get Enter-to-send; touch gets newlines. */
  const [finePointer, setFinePointer] = React.useState(false)

  const scrollRef = React.useRef<HTMLDivElement>(null)
  const textareaRef = React.useRef<HTMLTextAreaElement>(null)
  const composerRef = React.useRef<HTMLDivElement>(null)
  const fileInputRef = React.useRef<HTMLInputElement>(null)
  const abortRef = React.useRef<AbortController | null>(null)
  const mediaRecorderRef = React.useRef<MediaRecorder | null>(null)
  const audioChunksRef = React.useRef<Blob[]>([])
  /** Live "is the thread pinned to the bottom?" flag (no re-render on scroll). */
  const atBottomRef = React.useRef(true)

  // Real conversation list — includes archived so the toggle can filter
  // client-side without a second request.
  const { data: conversationsData, isLoading: loadingConversations } = useQuery({
    queryKey: ['conversations'],
    queryFn: () =>
      api.get<{ conversations: Conversation[] }>('/api/v1/conversations?archived=1'),
  })
  const conversations = conversationsData?.conversations ?? []

  const { data: threadData, isLoading: loadingMessages } = useQuery({
    queryKey: ['messages', activeConvId],
    // Only runs when activeConvId is set (see enabled below).
    queryFn: () =>
      api.get<{ conversation: Conversation; messages: ChatMessage[] }>(
        `/api/v1/conversations/${activeConvId}`,
      ),
    enabled: activeConvId !== null,
  })
  const messages = activeConvId ? (threadData?.messages ?? []) : []

  // Which provider the composer indicator should show (metadata only —
  // the endpoint NEVER returns credential material).
  const providersQuery = useQuery({
    queryKey: ['providers'],
    queryFn: () => api.get<ProvidersResponse>('/api/v1/providers'),
    staleTime: 30_000,
    retry: 1,
  })
  const primaryProvider = providersQuery.data?.primary ?? null

  // Pick pending prompt from Home (the composer hands off here).
  React.useEffect(() => {
    const pending = sessionStorage.getItem('alpha:pending-prompt')
    if (pending) {
      sessionStorage.removeItem('alpha:pending-prompt')
      setInput(pending)
    }
  }, [])

  // Keep local selection in sync with the global store (command palette,
  // Home recent cards, global search).
  React.useEffect(() => {
    if (selectedConversationId !== activeConvId) {
      setActiveConvId(selectedConversationId)
      setStreamText('')
    }
  }, [selectedConversationId, activeConvId])

  // Enter-to-send only makes sense with a real keyboard (fine pointer).
  React.useEffect(() => {
    const mq = window.matchMedia('(pointer: fine)')
    const update = () => setFinePointer(mq.matches)
    update()
    mq.addEventListener('change', update)
    return () => mq.removeEventListener('change', update)
  }, [])

  // Revoke the local preview blob URL whenever the chip is cleared/replaced
  // (and on unmount) so we never leak object URLs.
  React.useEffect(() => {
    if (!attachment) return
    return () => URL.revokeObjectURL(attachment.url)
  }, [attachment])

  // --- Scroll behavior ------------------------------------------------------
  // The message viewport is the ONLY scroll container for messages. The
  // composer lives outside it (shrink-0), so it can NEVER be pushed down.

  function handleMessagesScroll() {
    const el = scrollRef.current
    if (!el) return
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 80
    atBottomRef.current = atBottom
    setShowJump(!atBottom)
  }

  function scrollToBottom(behavior: ScrollBehavior = 'auto') {
    const el = scrollRef.current
    if (!el) return
    atBottomRef.current = true
    setShowJump(false)
    if (behavior === 'smooth') {
      el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' })
    } else {
      el.scrollTop = el.scrollHeight
    }
  }

  // Streaming follow: direct scrollTop assignment inside a single rAF (smooth
  // scrolling on every chunk is janky) — and only while the user is already
  // at/near the bottom, so we never fight the reader.
  React.useEffect(() => {
    if (!streamText) return
    const el = scrollRef.current
    if (!el) return
    if (atBottomRef.current) {
      const raf = requestAnimationFrame(() => {
        el.scrollTop = el.scrollHeight
      })
      return () => cancelAnimationFrame(raf)
    }
    // The user scrolled up while content streams in — surface the jump button.
    setShowJump(true)
  }, [streamText])

  // Persisted messages changed (optimistic add / refetch) — follow when at
  // the bottom, otherwise offer the jump affordance.
  React.useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    if (atBottomRef.current) {
      const raf = requestAnimationFrame(() => {
        el.scrollTop = el.scrollHeight
      })
      return () => cancelAnimationFrame(raf)
    }
    setShowJump(true)
  }, [messages.length])

  // Conversation switch → land instantly at the bottom once the thread loads.
  React.useEffect(() => {
    if (loadingMessages) return
    const el = scrollRef.current
    if (!el) return
    const raf = requestAnimationFrame(() => {
      el.scrollTop = el.scrollHeight
      atBottomRef.current = true
      setShowJump(false)
    })
    return () => cancelAnimationFrame(raf)
  }, [activeConvId, loadingMessages])

  // --- Composer textarea: auto-grow (1 row → 160px, then scroll inside) ----
  const resizeTextarea = React.useCallback(() => {
    const el = textareaRef.current
    if (!el) return
    el.style.height = 'auto'
    // scrollHeight excludes the border — compensate so no phantom scrollbar
    // appears at exactly one row.
    const borders = el.offsetHeight - el.clientHeight
    el.style.height = `${Math.min(el.scrollHeight + borders, COMPOSER_MAX_HEIGHT)}px`
  }, [])

  React.useEffect(() => {
    resizeTextarea()
  }, [input, resizeTextarea])

  const filteredConvs = conversations
    .filter((c) => (showArchived ? c.archived : !c.archived))
    .filter((c) =>
      !search ? true : c.title.toLowerCase().includes(search.toLowerCase()),
    )
    .sort((a, b) => {
      if (a.pinned && !b.pinned) return -1
      if (!a.pinned && b.pinned) return 1
      return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    })

  async function patchConversation(
    id: string,
    body: { title?: string; pinned?: boolean; archived?: boolean },
  ) {
    const { conversation } = await api.patch<{ conversation: Conversation }>(
      `/api/v1/conversations/${id}`,
      body,
    )
    await queryClient.invalidateQueries({ queryKey: ['conversations'] })
    return conversation
  }

  async function togglePin(c: Conversation) {
    try {
      await patchConversation(c.id, { pinned: !c.pinned })
      toast.success(c.pinned ? 'Unpinned' : 'Pinned')
    } catch {
      toast.error('Failed to toggle pin')
    }
  }

  async function toggleArchive(c: Conversation) {
    try {
      await patchConversation(c.id, { archived: !c.archived })
      toast.success(c.archived ? 'Unarchived' : 'Archived')
      if (activeConvId === c.id && !c.archived) {
        // Just archived the active conversation — start fresh.
        newConversation()
      }
    } catch {
      toast.error('Failed to toggle archive')
    }
  }

  function newConversation() {
    setActiveConvId(null)
    setConversation(null)
    setInput('')
    setStreamText('')
    setListSheetOpen(false)
  }

  function selectConversation(id: string) {
    setActiveConvId(id)
    setConversation(id)
    setStreamText('')
    setListSheetOpen(false)
  }

  function stopGeneration() {
    abortRef.current?.abort()
  }

  async function sendMessage() {
    const m = input.trim()
    if (!m || streaming) return
    const attachmentId = attachment?.id
    setInput('')
    setAttachment(null) // chip clears as soon as the message is sent
    setStreaming(true)
    setStreamText('')
    setConfigError(null)
    // A message the user just sent always lands at the bottom.
    scrollToBottom('smooth')

    // Optimistically show the user message.
    type ThreadData = { conversation: Conversation | null; messages: ChatMessage[] }
    const prevKey = ['messages', activeConvId]
    const prevMessages = queryClient.getQueryData<ThreadData>(prevKey)
    queryClient.setQueryData<ThreadData>(prevKey, (old) => ({
      conversation: old?.conversation ?? null,
      messages: [
        ...(old?.messages ?? []),
        {
          id: 'pending-user',
          conversationId: activeConvId ?? '',
          role: 'user' as const,
          content: m,
          model: null,
          createdAt: new Date().toISOString(),
        },
      ],
    }))

    const controller = new AbortController()
    abortRef.current = controller
    let convId = activeConvId ?? ''
    let responseArrived = false
    let handled = false // set when the error was surfaced via banner/toast
    try {
      const res = await fetch('/api/v1/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversationId: activeConvId ?? undefined,
          message: m,
          ...(attachmentId ? { attachmentId } : {}),
        }),
        signal: controller.signal,
      })
      responseArrived = true
      convId = res.headers.get('X-Conversation-Id') ?? convId
      if (convId && convId !== activeConvId) {
        setActiveConvId(convId)
        setConversation(convId)
      }

      // Which provider actually served this turn (display name only).
      const servedBy = res.headers.get('X-AI-Provider')
      if (servedBy) setLastServedBy(servedBy)
      // Context assembly stats for the turn (rendered only when present).
      setLastContextStats(parseContextStats(res.headers.get('X-Alpha-Context')))

      if (!res.ok) {
        const data = (await res.json().catch(() => null)) as { error?: string } | null
        if (res.status === 423) {
          // Session got locked — flip AuthGate to the UnlockScreen.
          await queryClient.invalidateQueries({ queryKey: ['auth-status'] })
          toast.error('Alpha is locked. Enter your password to continue.')
          handled = true
        } else if (res.status === 503) {
          setConfigError(
            data?.error ??
              'The AI provider is not configured on this deployment.',
          )
          handled = true
        } else {
          toast.error(data?.error ?? `Chat failed (${res.status})`)
          handled = true
        }
        throw new Error(data?.error ?? `Chat failed (${res.status})`)
      }

      // Stream the real provider answer as it arrives.
      const reader = res.body?.getReader()
      if (!reader) throw new Error('No response stream')
      const decoder = new TextDecoder()
      let acc = ''
      for (;;) {
        const { value, done } = await reader.read()
        if (done) break
        acc += decoder.decode(value, { stream: true })
        setStreamText(acc)
      }

      // Refetch so the persisted messages (incl. tool turns) show.
      setStreamText('')
      await queryClient.invalidateQueries({ queryKey: ['messages', convId] })
      await queryClient.invalidateQueries({ queryKey: ['conversations'] })
    } catch (e) {
      const aborted =
        controller.signal.aborted ||
        (e instanceof DOMException && e.name === 'AbortError')
      if (aborted && responseArrived) {
        // Stop pressed mid-stream: the server persists the FULL message
        // before streaming, so a refetch shows the real content — never a
        // fake "stopped" bubble.
        setStreamText('')
        if (convId) {
          await queryClient.invalidateQueries({ queryKey: ['messages', convId] })
          await queryClient.invalidateQueries({ queryKey: ['conversations'] })
        }
      } else {
        // Roll the optimistic message back on failure (undefined clears the
        // optimistic cache entry when there was nothing before).
        queryClient.setQueryData(prevKey, prevMessages)
        if (aborted) {
          // Aborted before the server confirmed the turn — roll back, but
          // still refetch the truth (the server may have persisted anyway).
          if (activeConvId) {
            await queryClient.invalidateQueries({ queryKey: ['messages', activeConvId] })
          }
          await queryClient.invalidateQueries({ queryKey: ['conversations'] })
        } else if (!handled) {
          toast.error(e instanceof Error ? e.message : 'Chat failed')
        }
      }
    } finally {
      abortRef.current = null
      setStreaming(false)
    }
  }

  // --- Attachments ----------------------------------------------------------

  function pickAttachment() {
    fileInputRef.current?.click()
  }

  async function onAttachmentSelected(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    // Allow re-selecting the same file right after a removal.
    e.target.value = ''
    if (!file) return
    if (!file.type.startsWith('image/')) {
      toast.error('Only image attachments are supported')
      return
    }
    if (file.size > MAX_ATTACHMENT_BYTES) {
      toast.error(`Image exceeds the ${Math.round(MAX_ATTACHMENT_BYTES / 1024 / 1024)} MB limit`)
      return
    }
    setUploading(true)
    try {
      const data = await apiUpload<{ file: FileRecord }>('/api/v1/files', file)
      // ONE attached image at a time — a new selection replaces the old one.
      setAttachment({
        id: data.file.id,
        filename: data.file.filename,
        url: URL.createObjectURL(file),
      })
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Upload failed')
    } finally {
      setUploading(false)
    }
  }

  function clearAttachment() {
    setAttachment(null)
  }

  function onComposerKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key !== 'Enter' || e.shiftKey) return
    // Touch devices: Enter inserts a newline; sending happens via the button.
    if (!window.matchMedia('(pointer: fine)').matches) return
    // Never hijack IME composition (CJK input).
    if (e.nativeEvent.isComposing) return
    e.preventDefault()
    void sendMessage()
  }

  async function confirmDelete() {
    if (!deleteId) return
    try {
      await api.delete(`/api/v1/conversations/${deleteId}`)
      if (activeConvId === deleteId) newConversation()
      await queryClient.invalidateQueries({ queryKey: ['conversations'] })
      toast.success('Conversation deleted')
    } catch {
      toast.error('Failed to delete conversation')
    } finally {
      setDeleteId(null)
    }
  }

  async function renameConversation() {
    if (!renameId) return
    const title = renameTitle.trim()
    if (!title) return
    try {
      await patchConversation(renameId, { title })
      setRenameId(null)
      toast.success('Renamed')
    } catch {
      toast.error('Failed to rename')
    }
  }

  async function startRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mr = new MediaRecorder(stream)
      audioChunksRef.current = []
      mr.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data)
      }
      mr.onstop = async () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' })
        await transcribe(blob)
        stream.getTracks().forEach((t) => t.stop())
      }
      mr.start()
      mediaRecorderRef.current = mr
      setRecording(true)
    } catch {
      toast.error('Microphone access denied')
    }
  }

  function stopRecording() {
    if (mediaRecorderRef.current && recording) {
      mediaRecorderRef.current.stop()
      setRecording(false)
    }
  }

  async function transcribe(blob: Blob) {
    setAsrBusy(true)
    try {
      const file = new File([blob], 'recording.webm', { type: 'audio/webm' })
      const data = await apiUpload<{ text: string }>('/api/v1/voice/asr', file)
      const text = data.text ?? ''
      setInput((prev) => (prev ? prev + ' ' + text : text))
      if (!text) toast.info('No speech detected in the recording.')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Transcription failed')
    } finally {
      setAsrBusy(false)
    }
  }

  async function playTTS(msg: ChatMessage) {
    if (ttsBusyId === msg.id) {
      setTtsBusyId(null)
      setTtsUrl(null)
      return
    }
    setTtsBusyId(msg.id)
    setTtsUrl(null)
    try {
      const data = await api.post<{ audio: string; mime: string }>(
        '/api/v1/voice/tts',
        { text: msg.content },
      )
      setTtsUrl(data.audio)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Speech failed')
      setTtsBusyId(null)
    }
  }

  const activeConv = conversations.find((c) => c.id === activeConvId)

  const listToolbar = (
    <>
      <div className="relative mt-2">
        <Search className="absolute left-2 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search chats…"
          className="h-8 pl-7 pr-8 text-xs"
          aria-label="Search conversations"
        />
        <button
          onClick={() => setShowArchived((v) => !v)}
          className={cn(
            'absolute right-2 top-1/2 -translate-y-1/2 rounded p-0.5 transition-colors',
            showArchived ? 'text-accent' : 'text-muted-foreground hover:text-foreground',
          )}
          title={showArchived ? 'Showing archived' : 'Show archived'}
          aria-pressed={showArchived}
          aria-label="Toggle archived conversations"
        >
          <Inbox className="size-3.5" />
        </button>
      </div>
      {showArchived && (
        <p className="mt-1 px-2 text-[10px] text-accent">
          Showing archived conversations
        </p>
      )}
    </>
  )

  const listBody = loadingConversations ? (
    <ChatListSkeleton />
  ) : (
    <div className="flex flex-col gap-0.5 p-2">
      {filteredConvs.length === 0 ? (
        <p className="px-2 py-6 text-center text-xs text-muted-foreground">
          {conversations.length === 0
            ? 'No conversations yet — start one below.'
            : 'No matching conversations.'}
        </p>
      ) : (
        filteredConvs.map((c) => (
          <ConversationRow
            key={c.id}
            conversation={c}
            active={activeConvId === c.id}
            onSelect={() => selectConversation(c.id)}
            onRename={() => {
              setRenameId(c.id)
              setRenameTitle(c.title)
            }}
            onPin={() => void togglePin(c)}
            onArchive={() => void toggleArchive(c)}
            onDelete={() => setDeleteId(c.id)}
          />
        ))
      )}
    </div>
  )

  // Compact provider indicator for the composer (metadata only — never keys).
  let providerPill: React.ReactNode = null
  if (providersQuery.isLoading) {
    providerPill = (
      <span
        className="inline-flex items-center gap-1.5 rounded-md border border-border/60 bg-background/40 px-2.5 py-1 text-[11px] text-muted-foreground"
        aria-live="polite"
      >
        <span className="alpha-status-dot bg-muted-foreground/40" aria-hidden />
        provider…
      </span>
    )
  } else if (providersQuery.isError) {
    providerPill = (
      <span
        className="inline-flex items-center gap-1.5 rounded-md border border-border/60 bg-background/40 px-2.5 py-1 text-[11px] text-muted-foreground"
        title="Provider status is unavailable right now"
      >
        <span className="alpha-status-dot bg-muted-foreground/40" aria-hidden />
        provider status unavailable
      </span>
    )
  } else if (primaryProvider) {
    const servingNow = streaming && lastServedBy && lastServedBy !== primaryProvider.name
    const servedBefore =
      !streaming && lastServedBy && lastServedBy !== primaryProvider.name
    providerPill = (
      <span
        className="inline-flex min-w-0 items-center gap-1.5 rounded-md border border-border/60 bg-background/40 px-2.5 py-1 text-[11px]"
        title={`Primary chat provider: ${primaryProvider.name}${primaryProvider.model ? ` (${primaryProvider.model})` : ''}`}
      >
        <span className="alpha-status-dot shrink-0 bg-emerald-500" aria-hidden />
        <span className="truncate font-medium">{primaryProvider.name}</span>
        {primaryProvider.model && (
          <span className="truncate font-mono text-muted-foreground">
            {primaryProvider.model}
          </span>
        )}
        {servingNow && (
          <span className="truncate text-muted-foreground/70">
            · serving via {lastServedBy}
          </span>
        )}
        {servedBefore && (
          <span className="truncate text-muted-foreground/70">
            · served by {lastServedBy}
          </span>
        )}
      </span>
    )
  } else {
    providerPill = (
      <button
        type="button"
        onClick={() => useAlpha.getState().setView('settings')}
        title="No configured provider supports chat — add one in Settings → AI Providers"
        className="inline-flex items-center gap-1.5 rounded-md border border-amber-500/40 bg-amber-500/10 px-2.5 py-1 text-[11px] text-amber-600 transition-colors hover:bg-amber-500/20 dark:text-amber-400"
      >
        <span className="alpha-status-dot shrink-0 bg-amber-500" aria-hidden />
        No configured provider — open Settings
      </button>
    )
  }

  return (
    /* Stable viewport layout: the root fills the shell's fixed-height column
       (flex-1 + min-h-0) — it NEVER grows with content, so the composer
       cannot be pushed down. Only the message viewport scrolls. */
    <div className="flex min-h-0 flex-1 gap-4">
      {/* Conversation list (desktop) */}
      <Card className="alpha-panel hidden w-64 shrink-0 gap-0 overflow-hidden py-0 md:flex">
        <CardHeader className="shrink-0 border-b border-border/60 pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm">Conversations</CardTitle>
            <Button size="sm" variant="default" onClick={newConversation} className="h-7 gap-1">
              <Plus className="size-3.5" /> New
            </Button>
          </div>
          {listToolbar}
        </CardHeader>
        <div className="alpha-scroll min-h-0 flex-1 overflow-y-auto">{listBody}</div>
      </Card>

      {/* Main chat panel */}
      <Card className="alpha-panel flex min-h-0 min-w-0 flex-1 flex-col gap-0 overflow-hidden py-0">
        <CardHeader className="shrink-0 border-b border-border/60 py-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex min-w-0 items-center gap-2">
              {/* Mobile: open conversation list */}
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setListSheetOpen(true)}
                className="h-8 gap-1.5 md:hidden"
                aria-label="Open conversations"
              >
                <PanelLeft className="size-4" />
              </Button>
              <div className="min-w-0">
                <CardTitle className="truncate text-sm">
                  {activeConv?.title || 'New conversation'}
                </CardTitle>
                <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                  <span>
                    {streaming ? 'Streaming a real answer…' : 'Live AI assistant'}
                  </span>
                  {activeConvId && messages.length > 0 && (
                    <>
                      <span className="text-muted-foreground/40">·</span>
                      <span>{messages.length} messages</span>
                    </>
                  )}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <Button size="sm" variant="ghost" onClick={newConversation} className="h-8 gap-1">
                <Plus className="size-3.5" /> New
              </Button>
              <Badge variant="outline" className="gap-1.5 bg-background/40">
                <span
                  className={cn(
                    'alpha-status-dot',
                    streaming ? 'bg-amber-500 alpha-status-pulse' : 'bg-emerald-500',
                  )}
                />
                {streaming ? 'streaming' : 'idle'}
              </Badge>
            </div>
          </div>
        </CardHeader>

        {/* Message viewport — the ONLY scroll container for messages. */}
        <CardContent className="relative min-h-0 flex-1 overflow-hidden p-0">
          <div
            ref={scrollRef}
            onScroll={handleMessagesScroll}
            className="alpha-scroll h-full overflow-y-auto px-4 py-4 sm:px-6"
          >
            {loadingMessages && activeConvId ? (
              <ChatThreadSkeleton />
            ) : !activeConvId && messages.length === 0 && !streamText ? (
              <div className="flex h-full items-center justify-center">
                <div className="w-full max-w-md">
                  <EmptyState
                    icon={MessageSquare}
                    title={
                      conversations.length === 0
                        ? 'No conversations yet — start one below'
                        : 'Start a new conversation'
                    }
                    description="Ask anything. Alpha can search the web, create notes, remember facts, and generate images."
                  />
                  <div className="mt-4 flex flex-wrap justify-center gap-2">
                    {SUGGESTIONS.map((s) => (
                      <button
                        key={s}
                        onClick={() => {
                          setInput(s)
                          textareaRef.current?.focus()
                        }}
                        className="rounded-md border border-border/60 px-3 py-1.5 font-mono text-[11px] text-muted-foreground transition-colors hover:border-accent/40 hover:text-foreground"
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="mx-auto flex max-w-3xl flex-col gap-4 pb-1">
                {messages.map((msg) => (
                  <MessageBubble
                    key={msg.id}
                    msg={msg}
                    userInitial={user?.name.slice(0, 1).toUpperCase() ?? 'Y'}
                    ttsBusy={ttsBusyId === msg.id}
                    onPlay={() => void playTTS(msg)}
                  />
                ))}
                {streamText && (
                  <MessageBubble
                    msg={{
                      id: 'streaming',
                      conversationId: activeConvId ?? '',
                      role: 'assistant',
                      content: streamText,
                      model: null,
                      createdAt: new Date().toISOString(),
                    }}
                    userInitial={user?.name.slice(0, 1).toUpperCase() ?? 'Y'}
                    streaming
                    onPlay={() => {}}
                    ttsBusy={false}
                  />
                )}
                {ttsUrl && (
                  <audio
                    autoPlay
                    src={ttsUrl}
                    className="hidden"
                    onEnded={() => {
                      setTtsUrl(null)
                      setTtsBusyId(null)
                    }}
                  />
                )}
              </div>
            )}
          </div>

          {/* Jump to latest — appears when the reader scrolled up while new
              content arrives; hidden while a thread is loading. */}
          {showJump && !loadingMessages && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => scrollToBottom('smooth')}
              className="absolute bottom-4 right-1/2 h-9 translate-x-1/2 rounded-md border-border/60 bg-card/90 px-3 text-xs font-medium shadow-lg backdrop-blur-sm hover:bg-card"
              aria-label="Jump to the latest message"
            >
              <ArrowDown className="size-3.5" aria-hidden />
              Jump to latest
            </Button>
          )}
        </CardContent>

        {/* Composer — pinned (shrink-0) at the panel bottom. It NEVER moves
            when messages grow; long input grows the textarea up to 160px
            (then scrolls internally). */}
        <div ref={composerRef} className="shrink-0 border-t border-border/60 p-3 sm:px-4">
          {/* Provider-not-configured banner — honest, actionable. */}
          {configError && (
            <div className="mb-3 flex items-start gap-3 rounded-lg border border-amber-500/40 bg-amber-500/10 p-2.5">
              <AlertCircle className="mt-0.5 size-4 shrink-0 text-amber-500" />
              <div className="min-w-0 flex-1">
                <p className="text-xs font-medium text-amber-600 dark:text-amber-400">
                  AI provider not configured
                </p>
                <p className="text-xs text-muted-foreground">{configError}</p>
              </div>
              <Button
                size="sm"
                variant="outline"
                className="h-7 shrink-0 gap-1 text-xs"
                onClick={() => useAlpha.getState().setView('settings')}
              >
                <SettingsIcon className="size-3" />
                Settings
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="h-7 shrink-0 text-xs"
                onClick={() => setConfigError(null)}
                aria-label="Dismiss"
              >
                <X className="size-3" />
              </Button>
            </div>
          )}

          {/* Attachment chips (ONE image at a time). */}
          {uploading && (
            <div
              className="mb-2 inline-flex items-center gap-2 rounded-lg border border-border/60 bg-card/60 px-3 py-2 text-xs text-muted-foreground"
              role="status"
            >
              <Loader2 className="size-3.5 animate-spin" aria-hidden />
              Uploading image…
            </div>
          )}
          {!uploading && attachment && (
            <div className="mb-2 inline-flex max-w-full items-center gap-2 rounded-lg border border-border/60 bg-card/60 p-1.5 pr-1.5">
              {/* Local object-URL thumbnail (the uploaded bytes live in R2). */}
              <img
                src={attachment.url}
                alt={`Attached image: ${attachment.filename}`}
                className="size-10 shrink-0 rounded-md border border-border/60 object-cover"
              />
              <span
                className="max-w-[160px] truncate text-xs text-muted-foreground"
                title={attachment.filename}
              >
                {attachment.filename}
              </span>
              <Button
                variant="ghost"
                size="icon"
                className="size-8 shrink-0 rounded-md"
                onClick={clearAttachment}
                aria-label="Remove attachment"
              >
                <X className="size-3.5" />
              </Button>
            </div>
          )}

          {/* Premium single-bar composer: one crafted input panel — hairline
              container, borderless textarea, quiet utility buttons, solid
              accent send. */}
          <div className="alpha-panel alpha-composer flex items-end gap-1.5 rounded-lg p-2">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => void onAttachmentSelected(e)}
              tabIndex={-1}
              aria-hidden
            />
            <Button
              variant="ghost"
              size="icon"
              className="size-9 shrink-0 rounded-md text-muted-foreground hover:text-foreground"
              onClick={pickAttachment}
              disabled={uploading}
              aria-label="Attach an image"
              title="Attach an image (max 10 MB)"
            >
              {uploading ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Paperclip className="size-4" />
              )}
            </Button>
            <Textarea
              ref={textareaRef}
              value={input}
              rows={1}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={onComposerKeyDown}
              onFocus={() => composerRef.current?.scrollIntoView({ block: 'nearest' })}
              placeholder={
                recording ? 'Recording — stop and it will be transcribed' : 'Message Alpha…'
              }
              aria-label="Message Alpha"
              className="alpha-scroll field-sizing-fixed min-h-9 max-h-40 flex-1 resize-none overflow-y-auto border-0 bg-transparent px-2 py-1.5 text-base shadow-none focus-visible:ring-0 dark:bg-transparent md:text-base"
            />
            <Button
              variant={recording ? 'destructive' : 'ghost'}
              size="icon"
              className="size-9 shrink-0 rounded-md text-muted-foreground hover:text-foreground"
              onClick={recording ? stopRecording : () => void startRecording()}
              disabled={asrBusy}
              aria-label={recording ? 'Stop recording' : 'Voice input'}
            >
              {asrBusy ? (
                <Loader2 className="size-4 animate-spin" />
              ) : recording ? (
                <X className="size-4" />
              ) : (
                <Mic className="size-4" />
              )}
            </Button>
            {streaming ? (
              <Button
                onClick={stopGeneration}
                variant="destructive"
                className="alpha-ripple size-9 shrink-0 gap-1.5 rounded-md px-0 sm:h-9 sm:w-auto sm:px-3"
                aria-label="Stop generating"
                title="Stop generating"
              >
                <Square className="size-3.5" fill="currentColor" aria-hidden />
                <span className="hidden sm:inline">Stop</span>
              </Button>
            ) : (
              <Button
                onClick={() => void sendMessage()}
                disabled={!input.trim() || uploading}
                size="icon"
                className="alpha-ripple size-9 shrink-0 rounded-md transition-shadow hover:shadow-[0_0_18px_-4px_var(--accent)]"
                aria-label="Send message"
              >
                {uploading ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  <Send className="size-4" />
                )}
              </Button>
            )}
          </div>

          {/* Provider indicator + context stats + keyboard hint */}
          <div className="mt-2 flex flex-wrap items-center justify-between gap-x-3 gap-y-1">
            <div className="flex min-w-0 items-center gap-2">
              <div className="min-w-0">{providerPill}</div>
              {lastContextStats && (
                <span
                  className="shrink-0 font-mono text-[10px] text-muted-foreground/70"
                  title={`Context: ${lastContextStats.recent} recent messages · ${
                    lastContextStats.summary ? 'summary active' : 'no summary'
                  } · ${lastContextStats.relevant} retrieved · ${lastContextStats.memories} memories`}
                >
                  ctx {lastContextStats.recent}·
                  {lastContextStats.summary ? 's' : '–'}·
                  {lastContextStats.relevant}·{lastContextStats.memories}
                </span>
              )}
            </div>
            {finePointer && !recording && (
              <span className="hidden shrink-0 text-[10px] text-muted-foreground/60 sm:block" aria-hidden>
                Enter ↵ to send · Shift+Enter for a new line
              </span>
            )}
          </div>
          {recording && (
            <div className="mt-2 flex items-center justify-center gap-2 text-xs text-destructive">
              <span className="alpha-pulse">●</span> Recording… click stop to transcribe.
            </div>
          )}
        </div>
      </Card>

      {/* Mobile conversation list */}
      <Sheet open={listSheetOpen} onOpenChange={setListSheetOpen}>
        <SheetContent side="left" className="flex w-80 max-w-[85vw] flex-col bg-card p-0">
          <SheetHeader className="border-b border-border/60 text-left">
            <SheetTitle className="flex items-center justify-between text-base">
              Conversations
              <Button size="sm" onClick={newConversation} className="h-7 gap-1">
                <Plus className="size-3.5" /> New
              </Button>
            </SheetTitle>
          </SheetHeader>
          <div className="border-b border-border/60 p-4 pb-3">
            {listToolbar}
          </div>
          <div className="alpha-scroll min-h-0 flex-1 overflow-y-auto">{listBody}</div>
        </SheetContent>
      </Sheet>

      {/* Rename dialog */}
      <Dialog open={!!renameId} onOpenChange={(o) => !o && setRenameId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Rename conversation</DialogTitle>
          </DialogHeader>
          <Input
            value={renameTitle}
            onChange={(e) => setRenameTitle(e.target.value)}
            placeholder="Conversation title"
            maxLength={200}
          />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setRenameId(null)}>
              Cancel
            </Button>
            <Button onClick={() => void renameConversation()} className="gap-2">
              <Check className="size-4" /> Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this conversation?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently removes the conversation and all its messages
              from the database. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => void confirmDelete()}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

function ConversationRow({
  conversation: c,
  active,
  onSelect,
  onRename,
  onPin,
  onArchive,
  onDelete,
}: {
  conversation: Conversation
  active: boolean
  onSelect: () => void
  onRename: () => void
  onPin: () => void
  onArchive: () => void
  onDelete: () => void
}) {
  return (
    <button
      className={cn(
        'group flex w-full items-center gap-2 rounded-md p-2 text-left transition-colors',
        active ? 'alpha-conv-active' : 'hover:bg-accent/10',
      )}
      onClick={onSelect}
    >
      <Avatar className="size-6 shrink-0 rounded-[5px]">
        <AvatarFallback className="rounded-[5px] border border-border/60 bg-transparent font-mono text-[8px]">
          {c.title.slice(0, 2).toUpperCase()}
        </AvatarFallback>
      </Avatar>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1">
          {c.pinned && (
            <Pin className="alpha-pin-glow size-2.5 shrink-0 text-accent" fill="currentColor" />
          )}
          <p className="truncate text-xs font-medium">{c.title}</p>
        </div>
        <p className="font-mono text-[9px] uppercase tracking-[0.04em] text-muted-foreground">
          {relativeTime(c.updatedAt)}
          {c.archived && ' · archived'}
        </p>
      </div>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <span
            role="button"
            tabIndex={0}
            aria-label="Conversation actions"
            className="inline-flex size-7 items-center justify-center rounded-md opacity-0 transition-opacity focus:opacity-100 group-hover:opacity-100"
            onClick={(e) => e.stopPropagation()}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') e.stopPropagation()
            }}
          >
            <MoreHorizontal className="size-3.5" />
          </span>
        </DropdownMenuTrigger>
        <DropdownMenuContent
          align="end"
          onClick={(e) => e.stopPropagation()}
        >
          <DropdownMenuItem onClick={onRename}>
            <Pencil className="size-3.5" /> Rename
          </DropdownMenuItem>
          <DropdownMenuItem onClick={onPin}>
            {c.pinned ? (
              <>
                <PinOff className="size-3.5" /> Unpin
              </>
            ) : (
              <>
                <Pin className="size-3.5" /> Pin
              </>
            )}
          </DropdownMenuItem>
          <DropdownMenuItem onClick={onArchive}>
            {c.archived ? (
              <>
                <ArchiveRestore className="size-3.5" /> Unarchive
              </>
            ) : (
              <>
                <Archive className="size-3.5" /> Archive
              </>
            )}
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem className="text-destructive" onClick={onDelete}>
            <Trash2 className="size-3.5" /> Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </button>
  )
}

function MessageBubble({
  msg,
  streaming,
  ttsBusy,
  onPlay,
  userInitial,
}: {
  msg: ChatMessage
  streaming?: boolean
  ttsBusy: boolean
  onPlay: () => void
  userInitial: string
}) {
  const [copied, setCopied] = React.useState(false)
  const copyTimerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null)

  React.useEffect(() => {
    return () => {
      if (copyTimerRef.current) clearTimeout(copyTimerRef.current)
    }
  }, [])

  async function copyContent() {
    try {
      await navigator.clipboard.writeText(msg.content)
      setCopied(true)
      if (copyTimerRef.current) clearTimeout(copyTimerRef.current)
      copyTimerRef.current = setTimeout(() => setCopied(false), 1500)
    } catch {
      toast.error('Could not copy — clipboard access was denied')
    }
  }

  const isUser = msg.role === 'user'
  const isTool = msg.role === 'tool'
  if (isTool) {
    return (
      <div className="alpha-msg-in mx-auto flex max-w-3xl items-center gap-2 rounded-md border border-border/50 bg-transparent px-3 py-1.5 font-mono text-[10px] text-muted-foreground">
        <BrainCircuit className="size-3.5 shrink-0 text-accent" />
        <span className="truncate">{msg.content}</span>
      </div>
    )
  }
  return (
    <div
      className={cn(
        'alpha-msg-in group/msg flex w-full gap-3',
        isUser ? 'flex-row-reverse' : 'flex-row',
      )}
    >
      <Avatar
        className={cn(
          'size-7 shrink-0 rounded-md ring-1',
          isUser ? 'ring-accent/30' : 'ring-border/70',
        )}
      >
        <AvatarFallback
          className={cn(
            'rounded-md font-mono text-[10px]',
            isUser ? 'bg-accent/15' : 'bg-card text-foreground',
          )}
        >
          {isUser ? userInitial : 'α'}
        </AvatarFallback>
      </Avatar>
      <div
        className={cn(
          'relative max-w-[85%] overflow-hidden rounded-lg border px-4 py-3 text-sm',
          isUser ? 'alpha-bubble-user' : 'alpha-bubble-assistant',
        )}
      >
        {streaming ? (
          <div className="alpha-markdown alpha-caret">{msg.content || '…'}</div>
        ) : (
          <Markdown>{msg.content}</Markdown>
        )}
        {/* Hover actions: always visible on touch, revealed on hover/focus
            on pointer devices. */}
        {!isUser && !streaming && (
          <div className="mt-2 flex items-center justify-end gap-2 text-[10px] text-muted-foreground transition-opacity md:pointer-events-none md:opacity-0 md:focus-within:pointer-events-auto md:focus-within:opacity-100 md:group-hover/msg:pointer-events-auto md:group-hover/msg:opacity-100">
            <button
              onClick={() => void copyContent()}
              className="inline-flex items-center gap-1 rounded-md border border-border/60 px-2 py-0.5 transition-colors hover:bg-accent/10"
              aria-label="Copy message text"
            >
              {copied ? (
                <Check className="size-3 text-emerald-500" aria-hidden />
              ) : (
                <Copy className="size-3" aria-hidden />
              )}
              {copied ? 'Copied' : 'Copy'}
            </button>
            <button
              onClick={onPlay}
              className="inline-flex items-center gap-1 rounded-md border border-border/60 px-2 py-0.5 transition-colors hover:bg-accent/10"
              aria-label="Read this message aloud"
            >
              <Volume2 className={cn('size-3', ttsBusy && 'text-accent')} />
              {ttsBusy ? 'Loading…' : 'Speak'}
            </button>
            <span>{new Date(msg.createdAt).toLocaleTimeString()}</span>
          </div>
        )}
        {isUser && (
          <p className="mt-1 text-right text-[10px] text-muted-foreground">
            {new Date(msg.createdAt).toLocaleTimeString()}
          </p>
        )}
      </div>
    </div>
  )
}
