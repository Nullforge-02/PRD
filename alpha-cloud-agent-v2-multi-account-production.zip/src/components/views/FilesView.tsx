'use client'

import * as React from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Upload,
  Search,
  Trash2,
  Download,
  FileIcon,
  FileText,
  FileAudio,
  FileVideo,
  FileArchive,
  Grid3x3,
  List as ListIcon,
  Loader2,
} from 'lucide-react'
import { api, apiUpload } from '@/lib/api'
import type { FileRecord } from '@/lib/api'
import {
  Card,
  CardContent,
  CardHeader,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  ToggleGroup,
  ToggleGroupItem,
} from '@/components/ui/toggle-group'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { EmptyState } from '@/components/common/EmptyState'
import { FilesListSkeleton, FilesGridSkeleton } from '@/components/common/Skeletons'

const MAX_UPLOAD_BYTES = 50 * 1024 * 1024 // matches the server limit
const SOURCE_FILTERS = ['all', 'upload', 'generated'] as const
type SourceFilter = (typeof SOURCE_FILTERS)[number]

function formatSize(bytes: number) {
  if (!bytes) return '—'
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(2)} MB`
  return `${(bytes / 1024 / 1024 / 1024).toFixed(2)} GB`
}

function mimeIcon(mime: string, className: string): React.ReactNode {
  if (mime.startsWith('audio/')) return <FileAudio className={className} />
  if (mime.startsWith('video/')) return <FileVideo className={className} />
  if (mime.startsWith('text/') || mime === 'application/json') return <FileText className={className} />
  if (
    mime === 'application/zip' ||
    mime === 'application/x-tar' ||
    mime === 'application/gzip'
  )
    return <FileArchive className={className} />
  return <FileIcon className={className} />
}

export function FilesView() {
  const queryClient = useQueryClient()
  const [search, setSearch] = React.useState('')
  const [sourceFilter, setSourceFilter] = React.useState<SourceFilter>('all')
  const [view, setView] = React.useState<'list' | 'grid'>('list')
  const [uploading, setUploading] = React.useState(false)
  const [deleteId, setDeleteId] = React.useState<string | null>(null)
  const [deleting, setDeleting] = React.useState(false)
  const fileInputRef = React.useRef<HTMLInputElement>(null)

  const { data: filesData, isLoading } = useQuery({
    queryKey: ['files'],
    queryFn: () => api.get<{ files: FileRecord[] }>('/api/v1/files'),
  })
  const files = filesData?.files ?? []

  // REAL upload — bytes go to R2, metadata to D1.
  async function onPickFiles(list: FileList | null) {
    if (!list || list.length === 0) return
    setUploading(true)
    let ok = 0
    try {
      for (const f of Array.from(list)) {
        if (f.size > MAX_UPLOAD_BYTES) {
          toast.error(`${f.name} exceeds the 50 MB limit`, {
            description: 'Choose a smaller file.',
          })
          continue
        }
        try {
          await apiUpload<{ file: FileRecord }>('/api/v1/files', f)
          ok++
        } catch (e) {
          toast.error(`${f.name} failed`, {
            description: e instanceof Error ? e.message : 'Upload failed',
          })
        }
      }
      if (ok > 0) {
        await queryClient.invalidateQueries({ queryKey: ['files'] })
        toast.success(`Uploaded ${ok} file${ok > 1 ? 's' : ''}`)
      }
    } finally {
      setUploading(false)
      if (fileInputRef.current) fileInputRef.current.value = ''
    }
  }

  async function confirmDelete() {
    if (!deleteId) return
    setDeleting(true)
    try {
      await api.delete(`/api/v1/files/${deleteId}`)
      await queryClient.invalidateQueries({ queryKey: ['files'] })
      toast.success('File deleted')
    } catch {
      toast.error('Failed to delete file')
    } finally {
      setDeleting(false)
      setDeleteId(null)
    }
  }

  const filtered = files.filter((f) => {
    if (sourceFilter !== 'all') {
      const want = sourceFilter === 'upload' ? 'upload' : 'generated'
      if (f.source !== want) return false
    }
    if (search) {
      if (!f.filename.toLowerCase().includes(search.toLowerCase())) return false
    }
    return true
  })

  return (
    <div className="flex flex-col gap-6">
      <Card className="alpha-panel border-0">
        <CardHeader className="border-b border-border/60 py-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative min-w-[200px] flex-1">
              <Search className="absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search files by name…"
                className="pl-8"
                aria-label="Search files"
              />
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <ToggleGroup
                type="single"
                value={sourceFilter}
                onValueChange={(v) => setSourceFilter((v as SourceFilter) || 'all')}
                variant="outline"
                size="sm"
                aria-label="Filter by source"
              >
                {SOURCE_FILTERS.map((s) => (
                  <ToggleGroupItem key={s} value={s} className="text-xs capitalize">
                    {s === 'upload' ? 'uploaded' : s}
                  </ToggleGroupItem>
                ))}
              </ToggleGroup>
              <ToggleGroup
                type="single"
                value={view}
                onValueChange={(v) => setView((v as 'list' | 'grid') || 'list')}
                variant="outline"
                size="sm"
                aria-label="Toggle layout"
              >
                <ToggleGroupItem value="list" aria-label="List view">
                  <ListIcon className="size-3.5" />
                </ToggleGroupItem>
                <ToggleGroupItem value="grid" aria-label="Grid view">
                  <Grid3x3 className="size-3.5" />
                </ToggleGroupItem>
              </ToggleGroup>
              <Button
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="gap-2"
              >
                {uploading ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  <Upload className="size-4" />
                )}
                {uploading ? 'Uploading…' : 'Upload'}
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                hidden
                onChange={(e) => void onPickFiles(e.target.files)}
                aria-label="Choose files to upload"
              />
            </div>
          </div>
        </CardHeader>
      </Card>

      <Card className="alpha-panel border-0">
        <CardContent className="p-4 sm:p-6">
          {isLoading ? (
            view === 'grid' ? (
              <FilesGridSkeleton />
            ) : (
              <FilesListSkeleton />
            )
          ) : filtered.length === 0 ? (
            <EmptyState
              icon={FileIcon}
              title={files.length === 0 ? 'No files uploaded' : 'Nothing matches these filters'}
              description={
                files.length === 0
                  ? 'Upload files up to 50 MB — they are stored in your cloud bucket, not on this device. AI-generated images appear here too.'
                  : 'Try a different search term or source filter.'
              }
              action={
                files.length === 0 ? (
                  <Button onClick={() => fileInputRef.current?.click()} className="gap-2">
                    <Upload className="size-4" /> Upload a file
                  </Button>
                ) : undefined
              }
            />
          ) : view === 'grid' ? (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {filtered.map((f) => (
                <FileGridCard
                  key={f.id}
                  file={f}
                  onDelete={() => setDeleteId(f.id)}
                />
              ))}
            </div>
          ) : (
            <div className="overflow-hidden rounded-lg border border-border/60">
              <table className="w-full text-sm">
                <caption className="sr-only">Uploaded and generated files</caption>
                <thead className="bg-muted/40">
                  <tr>
                    <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-muted-foreground">
                      Name
                    </th>
                    <th scope="col" className="hidden px-3 py-2 text-left text-xs font-medium text-muted-foreground sm:table-cell">
                      Source
                    </th>
                    <th scope="col" className="px-3 py-2 text-right text-xs font-medium text-muted-foreground">
                      Size
                    </th>
                    <th scope="col" className="hidden px-3 py-2 text-right text-xs font-medium text-muted-foreground md:table-cell">
                      Uploaded
                    </th>
                    <th scope="col" className="px-3 py-2 text-right text-xs font-medium text-muted-foreground">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {filtered.map((f) => (
                    <tr key={f.id} className="hover:bg-accent/5">
                      <td className="px-3 py-2">
                        <div className="flex min-w-0 items-center gap-2">
                          {f.mimeType.startsWith('image/') ? (
                            <img
                              src={`/api/v1/files/${f.id}`}
                              alt=""
                              className="size-6 shrink-0 rounded object-cover"
                              loading="lazy"
                            />
                          ) : (
                            mimeIcon(f.mimeType, 'size-4 shrink-0 text-muted-foreground')
                          )}
                          <span className="truncate">{f.filename}</span>
                        </div>
                      </td>
                        <td className="hidden px-3 py-2 sm:table-cell">
                          <SourceBadge source={f.source} />
                        </td>
                        <td className="px-3 py-2 text-right text-xs text-muted-foreground">
                          {formatSize(f.size)}
                        </td>
                        <td className="hidden px-3 py-2 text-right text-xs text-muted-foreground md:table-cell">
                          {new Date(f.createdAt).toLocaleDateString()}
                        </td>
                        <td className="px-3 py-2">
                          <div className="flex items-center justify-end gap-1">
                            {/* Direct link — the auth cookie rides along and the
                                server sets Content-Disposition: attachment. */}
                            <a
                              href={`/api/v1/files/${f.id}?download=1`}
                              className="inline-flex size-7 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent/10 hover:text-foreground"
                              aria-label={`Download ${f.filename}`}
                            >
                              <Download className="size-3.5" />
                            </a>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="size-7 text-destructive"
                              onClick={() => setDeleteId(f.id)}
                              aria-label={`Delete ${f.filename}`}
                            >
                              <Trash2 className="size-3.5" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this file?</AlertDialogTitle>
            <AlertDialogDescription>
              This removes the file and its stored bytes from your cloud bucket.
              This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => void confirmDelete()}
              disabled={deleting}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {deleting ? 'Deleting…' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

function FileGridCard({
  file,
  onDelete,
}: {
  file: FileRecord
  onDelete: () => void
}) {
  const isImage = file.mimeType?.startsWith('image/')
  return (
    <div className="alpha-file-card flex flex-col gap-2 rounded-lg border border-border/60 bg-card/40 p-2">
      <div className="relative aspect-square overflow-hidden rounded-md bg-muted">
        {isImage ? (
          /* Streams the real object bytes (auth cookie rides along). */
          <img
            src={`/api/v1/files/${file.id}`}
            alt={file.filename}
            className="size-full object-cover"
            loading="lazy"
          />
        ) : (
          <div className="flex size-full items-center justify-center text-muted-foreground">
            {mimeIcon(file.mimeType, 'size-8')}
          </div>
        )}
      </div>
      <div className="flex items-center justify-between gap-2">
        <p className="truncate text-xs font-medium">{file.filename}</p>
        <Button
          size="icon"
          variant="ghost"
          className="size-6 text-destructive"
          onClick={onDelete}
          aria-label={`Delete ${file.filename}`}
        >
          <Trash2 className="size-3" />
        </Button>
      </div>
      <div className="flex items-center justify-between text-[10px] text-muted-foreground">
        <SourceBadge source={file.source} />
        <span>{formatSize(file.size)}</span>
      </div>
    </div>
  )
}

function SourceBadge({ source }: { source: FileRecord['source'] }) {
  return (
    <Badge
      variant="outline"
      className={cn(
        'text-[10px] capitalize',
        source === 'generated' ? 'bg-accent/20 text-accent-foreground' : '',
      )}
    >
      {source}
    </Badge>
  )
}
