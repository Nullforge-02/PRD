'use client'

import * as React from 'react'
import { motion, useReducedMotion } from 'framer-motion'
import { cn } from '@/lib/utils'

/**
 * NULLFORGE — text wordmark brand.
 *
 * Understated, terminal-like identity: mono caps, wide tracking, high
 * contrast, a single thin amber accent underscore. No circular marks, no
 * conic gradients, no chunky containers.
 */

const WORD = 'NULLFORGE'

const SIZES = {
  sm: {
    wordmark: 'text-sm tracking-[0.14em]',
    subline: 'text-[9px] tracking-[0.24em]',
    settled: '0.14em',
  },
  md: {
    wordmark: 'text-lg tracking-[0.18em]',
    subline: 'text-[10px] tracking-[0.26em]',
    settled: '0.18em',
  },
  lg: {
    wordmark: 'text-2xl tracking-[0.22em]',
    subline: 'text-[11px] tracking-[0.3em]',
    settled: '0.22em',
  },
} as const

export type NullForgeMarkSize = keyof typeof SIZES

export function NullForgeMark({
  variant = 'static',
  size = 'md',
  subline = 'ALPHA · PERSONAL CLOUD AGENT',
  /** Renders the sub-line even in tight contexts (default true). */
  showSubline = true,
  /** Gentle opacity breathe on the amber underscore (splash only). */
  accentPulse = false,
  align = 'center',
  className,
}: {
  variant?: 'static' | 'animated'
  size?: NullForgeMarkSize
  subline?: string
  showSubline?: boolean
  accentPulse?: boolean
  align?: 'center' | 'left'
  className?: string
}) {
  const reduced = useReducedMotion()
  const animate = variant === 'animated' && !reduced
  const s = SIZES[size]
  const letters = React.useMemo(() => WORD.split(''), [])

  return (
    <div
      className={cn(
        'flex flex-col gap-2',
        align === 'center' ? 'items-center text-center' : 'items-start text-left',
        className,
      )}
    >
      {/* The word itself stays available to screen readers. */}
      <span className="sr-only">NullForge</span>
      <motion.div
        initial={animate ? { letterSpacing: '0.35em', opacity: 0 } : false}
        animate={
          animate
            ? { letterSpacing: s.settled, opacity: 1 }
            : { letterSpacing: s.settled }
        }
        transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
        className={cn('relative font-mono font-semibold uppercase', s.wordmark)}
        aria-hidden
      >
        {letters.map((ch, i) => {
          const isLast = i === letters.length - 1
          const letter = (
            <span
              aria-hidden
              className={cn(
                'inline-block',
                // Faint amber tint on the final "E" — the only color detail.
                isLast && 'text-accent/90',
              )}
            >
              {ch}
            </span>
          )
          if (!animate) return <span key={i}>{letter}</span>
          return (
            <motion.span
              key={i}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.5,
                ease: [0.16, 1, 0.3, 1],
                delay: 0.05 * i,
              }}
              className="inline-block"
            >
              {letter}
            </motion.span>
          )
        })}
        {/* Thin amber underscore — a restrained forge seam. */}
        <motion.span
          aria-hidden
          initial={animate ? { scaleX: 0, opacity: 0 } : false}
          animate={animate ? { scaleX: 1, opacity: 1 } : { opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.55, ease: [0.16, 1, 0.3, 1] }}
          className={cn(
            'absolute -bottom-1 left-0 h-px w-full origin-left bg-accent/70',
            accentPulse && !reduced && 'alpha-breathe',
          )}
        />
      </motion.div>
      {showSubline && (
        <p className={cn('font-mono uppercase text-muted-foreground', s.subline)}>
          {subline}
        </p>
      )}
    </div>
  )
}

/**
 * NF — compact monogram for collapsed rails. Mono, hairline-bordered,
 * button-styled but non-interactive; the "F" carries the amber tint.
 */
export function NullForgeMonogram({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        'inline-flex size-8 shrink-0 items-center justify-center rounded-md border border-border/70 bg-card/60 font-mono text-[11px] font-semibold tracking-[0.06em] text-foreground',
        className,
      )}
      aria-hidden
    >
      N<span className="text-accent/90">F</span>
    </span>
  )
}
