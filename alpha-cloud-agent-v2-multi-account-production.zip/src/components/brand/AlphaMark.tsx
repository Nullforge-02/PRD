import { cn } from '@/lib/utils'

/**
 * Small inline brand mark — the NULLFORGE "N" glyph (matches /logo.svg):
 * near-black plate, hairline edge, geometric N, single amber seam.
 * Kept for compact inline uses; the full identity is the NullForgeMark
 * wordmark and the NullForgeMonogram.
 */
export function AlphaMark({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        'relative inline-flex size-8 items-center justify-center overflow-hidden rounded-md bg-[#0a0a0a] ring-1 ring-white/10',
        className,
      )}
      aria-hidden
    >
      <svg
        viewBox="0 0 32 32"
        className="size-[18px]"
        fill="none"
        aria-hidden
      >
        <path
          d="M10 22V10L22 22V10"
          stroke="#fafafa"
          strokeWidth="2.4"
          strokeLinecap="square"
          strokeLinejoin="miter"
        />
        <path
          d="M10 25.5H16"
          stroke="#d9a53c"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
      </svg>
    </span>
  )
}
