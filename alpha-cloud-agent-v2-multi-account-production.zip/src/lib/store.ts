'use client'

import { create } from 'zustand'

export type ViewKey =
  | 'home'
  | 'chat'
  | 'files'
  | 'notes'
  | 'planner'
  | 'gmail'
  | 'media'
  | 'memory'
  | 'github'
  | 'tools'
  | 'system'
  | 'security'
  | 'settings'

export interface CurrentUser {
  id: string
  email: string
  name: string
}

interface AlphaState {
  activeView: ViewKey
  selectedConversationId: string | null
  sidebarOpen: boolean
  sidebarCollapsed: boolean
  shortcutsOpen: boolean
  user: CurrentUser | null
  setView: (v: ViewKey) => void
  setConversation: (id: string | null) => void
  setSidebar: (open: boolean) => void
  toggleSidebarCollapsed: () => void
  setShortcutsOpen: (open: boolean) => void
  setUser: (user: CurrentUser | null) => void
}

export const useAlpha = create<AlphaState>((set) => ({
  activeView: 'home',
  selectedConversationId: null,
  sidebarOpen: false,
  sidebarCollapsed: false,
  shortcutsOpen: false,
  user: null,
  setView: (v) => set({ activeView: v, sidebarOpen: false }),
  setConversation: (id) => set({ selectedConversationId: id }),
  setSidebar: (open) => set({ sidebarOpen: open }),
  toggleSidebarCollapsed: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  setShortcutsOpen: (open) => set({ shortcutsOpen: open }),
  setUser: (user) => set({ user }),
}))

// Shortcut definitions — used by both the global key handler and the overlay.
export interface ShortcutDef {
  keys: string // display string, e.g. "⌘K" or "g h"
  description: string
  group: 'Navigation' | 'Actions' | 'Chat' | 'Security'
}

export const SHORTCUTS: ShortcutDef[] = [
  { keys: '⌘K', description: 'Open command palette / unified search', group: 'Actions' },
  { keys: '⌘/', description: 'Show this keyboard shortcuts overlay', group: 'Actions' },
  { keys: '⌘L', description: 'Lock Alpha (password to unlock)', group: 'Security' },
  { keys: 'g h', description: 'Go to Home', group: 'Navigation' },
  { keys: 'g c', description: 'Go to Chat', group: 'Navigation' },
  { keys: 'g f', description: 'Go to Files', group: 'Navigation' },
  { keys: 'g n', description: 'Go to Notes', group: 'Navigation' },
  { keys: 'g p', description: 'Go to Planner (reminders + calendar)', group: 'Navigation' },
  { keys: 'g m', description: 'Go to Gmail', group: 'Navigation' },
  { keys: 'g i', description: 'Go to Media', group: 'Navigation' },
  { keys: 'g b', description: 'Go to Memory', group: 'Navigation' },
  { keys: 'g g', description: 'Go to GitHub Archive', group: 'Navigation' },
  { keys: 'g t', description: 'Go to Tools', group: 'Navigation' },
  { keys: 'g s', description: 'Go to System Health', group: 'Navigation' },
  { keys: 'g x', description: 'Go to Security', group: 'Navigation' },
  { keys: 'g ,', description: 'Go to Settings', group: 'Navigation' },
  { keys: '⌘Enter', description: 'Send chat message (in Chat view)', group: 'Chat' },
  { keys: '⌘⇧V', description: 'Toggle voice input (in Chat view)', group: 'Chat' },
]
