'use client'

import * as React from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { api } from '@/lib/api'
import { useAlpha, type ViewKey } from '@/lib/store'

// Global keyboard shortcuts for ALPHA.
//   ⌘K / Ctrl+K → command palette (handled by CommandPalette component)
//   ⌘/ / Ctrl+/ → keyboard shortcuts overlay
//   ⌘L / Ctrl+L → lock Alpha (server-side soft lock; unlock needs the password)
//   g h / g c / g f / … → go to view (Gmail-style two-key sequence)
//
// The "g" prefix starts an 800ms window during which the next key determines
// the target view.
export function useGlobalShortcuts() {
  const setView = useAlpha((s) => s.setView)
  const setShortcutsOpen = useAlpha((s) => s.setShortcutsOpen)
  const shortcutsOpen = useAlpha((s) => s.shortcutsOpen)
  const queryClient = useQueryClient()

  const gPressedRef = React.useRef(false)
  const gTimerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null)

  React.useEffect(() => {
    async function lockAlpha() {
      try {
        await api.post('/api/v1/auth/lock')
        // AuthGate polls /api/v1/auth/status — invalidate so the lock screen
        // appears immediately instead of on the next poll.
        await queryClient.invalidateQueries({ queryKey: ['auth-status'] })
        toast.warning('Alpha locked — enter your password to unlock.')
      } catch {
        toast.error('Could not lock Alpha right now.')
      }
    }

    function onKey(e: KeyboardEvent) {
      const target = e.target as HTMLElement | null
      const isInput =
        target?.tagName === 'INPUT' ||
        target?.tagName === 'TEXTAREA' ||
        target?.isContentEditable

      // ⌘/ → shortcuts overlay (works even in inputs)
      if ((e.metaKey || e.ctrlKey) && (e.key === '/' || e.key === '?')) {
        e.preventDefault()
        setShortcutsOpen(!shortcutsOpen)
        return
      }

      // ⌘L → lock Alpha (works even in inputs)
      if ((e.metaKey || e.ctrlKey) && (e.key === 'l' || e.key === 'L')) {
        e.preventDefault()
        void lockAlpha()
        return
      }

      // ⌘K → command palette (CommandPalette handles this — don't intercept)
      if ((e.metaKey || e.ctrlKey) && (e.key === 'k' || e.key === 'K')) {
        return
      }

      // Don't interfere with inputs for the "g" sequences
      if (isInput) return

      // "g" prefix → start sequence window
      if (e.key === 'g' && !e.metaKey && !e.ctrlKey && !e.altKey) {
        gPressedRef.current = true
        if (gTimerRef.current) clearTimeout(gTimerRef.current)
        gTimerRef.current = setTimeout(() => {
          gPressedRef.current = false
        }, 800)
        return
      }

      // If "g" was pressed, map the next key to a view
      if (gPressedRef.current) {
        gPressedRef.current = false
        if (gTimerRef.current) clearTimeout(gTimerRef.current)
        const viewMap: Record<string, ViewKey> = {
          h: 'home',
          c: 'chat',
          f: 'files',
          n: 'notes',
          p: 'planner',
          m: 'gmail',
          i: 'media',
          b: 'memory',
          g: 'github',
          t: 'tools',
          s: 'system',
          x: 'security',
          ',': 'settings',
        }
        const view = viewMap[e.key.toLowerCase()]
        if (view) {
          e.preventDefault()
          setView(view)
        }
      }
    }

    window.addEventListener('keydown', onKey)
    return () => {
      window.removeEventListener('keydown', onKey)
      if (gTimerRef.current) clearTimeout(gTimerRef.current)
    }
  }, [setView, setShortcutsOpen, shortcutsOpen, queryClient])
}
