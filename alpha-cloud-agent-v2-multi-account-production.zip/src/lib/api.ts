// ALPHA — typed client API helpers
//
// All requests are same-origin (cookies ride along automatically).
// JSON responses raise on non-2xx; callers handle errors.

export class ApiError extends Error {
  status: number;
  body: unknown;
  constructor(status: number, message: string, body?: unknown) {
    super(message);
    this.status = status;
    this.body = body;
  }
}

async function request<T>(method: string, path: string, body?: unknown, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    method,
    ...init,
    headers: {
      ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
      ...(init?.headers ?? {}),
    },
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
  });
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    throw new ApiError(
      res.status,
      (data && typeof data === "object" && "error" in data && typeof data.error === "string"
        ? data.error
        : `Request failed (${res.status})`) || `Request failed (${res.status})`,
      data,
    );
  }
  return data as T;
}

export const api = {
  get: <T>(path: string) => request<T>("GET", path),
  post: <T>(path: string, body?: unknown) => request<T>("POST", path, body),
  patch: <T>(path: string, body?: unknown) => request<T>("PATCH", path, body),
  delete: <T>(path: string) => request<T>("DELETE", path),
};

/** Multipart upload. */
export async function apiUpload<T>(path: string, file: File, fields?: Record<string, string>): Promise<T> {
  const form = new FormData();
  form.append("file", file);
  for (const [k, v] of Object.entries(fields ?? {})) form.append(k, v);
  const res = await fetch(path, { method: "POST", body: form });
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    throw new ApiError(
      res.status,
      (data && typeof data === "object" && "error" in data && typeof data.error === "string"
        ? data.error
        : `Upload failed (${res.status})`),
      data,
    );
  }
  return data as T;
}

/** POST /api/v1/chat — streams the (real) provider answer as text. */
export async function streamChat(
  message: string,
  conversationId?: string,
): Promise<{ text: string; conversationId: string }> {
  const res = await fetch("/api/v1/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message, conversationId }),
  });
  const conversationIdOut = res.headers.get("X-Conversation-Id") ?? conversationId ?? "";
  if (!res.ok) {
    const data = await res.json().catch(() => null);
    throw new ApiError(
      res.status,
      (data && typeof data === "object" && "error" in data && typeof data.error === "string"
        ? data.error
        : `Chat failed (${res.status})`),
      data,
    );
  }
  if (!res.body) return { text: "", conversationId: conversationIdOut };
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let text = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    text += decoder.decode(value, { stream: true });
  }
  return { text, conversationId: conversationIdOut };
}

// ---------- Shared response types (mirrors src/server/types.ts) ----------

export interface AuthStatus {
  setupNeeded: boolean;
  authenticated: boolean;
  locked: boolean;
  user: { id: string; email: string; name: string } | null;
}

export interface Conversation {
  id: string;
  title: string;
  pinned: boolean;
  archived: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  role: "user" | "assistant" | "tool";
  content: string;
  model: string | null;
  createdAt: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Memory {
  id: string;
  category: string;
  content: string;
  source: string;
  confidence: number;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface FileRecord {
  id: string;
  filename: string;
  mimeType: string;
  size: number;
  r2Key: string;
  source: "upload" | "generated";
  createdAt: string;
  updatedAt: string;
}

export interface Reminder {
  id: string;
  title: string;
  note: string | null;
  dueAt: number | null;
  priority: "low" | "normal" | "high";
  done: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  location: string | null;
  startAt: number;
  endAt: number | null;
  attendees: string[];
  source: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditEvent {
  id: string;
  userId: string | null;
  action: string;
  category: string;
  details: string | null;
  ip: string | null;
  createdAt: string;
}

export interface SessionInfo {
  id: string;
  userAgent: string | null;
  ip: string | null;
  createdAt: string;
  lastSeenAt: string;
  expiresAt: string;
  locked: boolean;
  current: boolean;
}

export interface SystemHealth {
  status: "healthy" | "degraded";
  checkedAt: string;
  db: { ok: boolean; latencyMs: number; error?: string };
  storage: { ok: boolean; latencyMs: number; error?: string };
  ai: {
    configured: boolean;
    provider: string;
    ok?: boolean;
    latencyMs?: number;
    error?: string;
    /** Per-provider health list (real observations only). */
    providers?: ProviderInfo[];
  };
  jobs: { counts: Record<string, number>; recent: Array<{ id: string; kind: string; status: string; createdAt: string; finishedAt: string | null }> };
  storageUsage: { count: number; bytes: number };
  users: number;
  version: string;
}

export interface ProviderInfo {
  id: string;
  name: string;
  configured: boolean;
  capabilities: string[];
  guide: string;
  /** Included in routing decisions. */
  enabled?: boolean;
  /** Real health from actual requests — "unknown" until first observation. */
  status?: "healthy" | "degraded" | "offline" | "unknown";
  healthy?: boolean;
  /** Last real measured latency (ms). */
  latencyMs?: number | null;
  /** Env-configured model for this provider. */
  model?: string;
  priority?: number;
  lastErrorCategory?: string | null;
  /** Where the active credential comes from (never the credential itself). */
  source?: "dashboard" | "environment" | null;
  /** Masked dashboard key (••••••••••••abcd) — null for env credentials. */
  maskedKey?: string | null;
  /** Effective vision model (dashboard override → env → default). */
  visionModel?: string | null;
  /** Dashboard-configured base URL (null when not overridden). */
  baseUrl?: string | null;
  /** UI-safe placeholder defaults (public endpoints, no secrets). */
  defaultBaseUrl?: string;
  defaultModel?: string;
  defaultVisionModel?: string;
  supportsBaseUrl?: boolean;
  supportsVisionModel?: boolean;
  /** Last Test Connection outcome (real requests only). */
  lastTestedAt?: string | null;
  lastTestStatus?: "success" | "failed" | null;
  /** True when this is a user-added custom provider row. */
  custom?: boolean;
}

/** Custom (user-added) AI provider — safe metadata, NEVER key material. */
export interface CustomProviderInfo {
  id: string;
  name: string;
  protocol: string;
  configured: true;
  enabled: boolean;
  priority: number;
  /** Masked key (••••••••••••••abcd) — the plaintext is never returned. */
  maskedKey: string;
  baseUrl: string;
  model: string;
  visionModel: string | null;
  imageModel: string | null;
  videoModel: string | null;
  capabilities: string[];
  status: "healthy" | "degraded" | "offline" | "unknown";
  latencyMs: number | null;
  lastErrorCategory: string | null;
  lastTestedAt: string | null;
  lastTestStatus: "success" | "failed" | null;
  createdAt: string;
  updatedAt: string;
}

/** The provider the chat composer indicator shows (metadata only). */
export interface PrimaryChatProvider {
  name: string;
  model: string;
  custom: boolean;
  enabled: boolean;
  configured: boolean;
}

export interface ProvidersResponse {
  providers: ProviderInfo[];
  custom: CustomProviderInfo[];
  primary: PrimaryChatProvider | null;
}

export interface ProviderSaveResult {
  provider: ProviderInfo;
}

export interface CustomProviderSaveResult {
  provider: CustomProviderInfo;
}

export interface ProviderTestResult {
  success: boolean;
  provider: string;
  latencyMs?: number;
  error?: string;
}

export interface ModelsDiscoveryResult {
  models: string[];
  error?: string;
}

export interface ToolInfo {
  name: string;
  description: string;
  permission: "low" | "medium" | "high";
}

// ---------- OAuth / connected integrations ----------

/** GitHub account purposes (multi-account roles). */
export type GithubAccountRole = "storage" | "scripts" | "general";

/**
 * ONE connected OAuth account (multi-account: a user may hold several Google
 * and several GitHub accounts). Metadata ONLY — tokens never leave the server.
 */
export interface ConnectedAccountInfo {
  id: string;
  provider: "google" | "github";
  /** External account identity (Google sub / GitHub numeric id). */
  providerAccountId: string;
  /** Display identity (email address / GitHub login). */
  accountName: string | null;
  avatarUrl: string | null;
  status: "connected" | "needs_reauthorization";
  /** GitHub purpose: storage | scripts | general. null for Google accounts. */
  role: GithubAccountRole | null;
  /** The user's explicitly selected default account for this provider. */
  isDefault: boolean;
  createdAt: string;
  lastUsedAt: string | null;
}

/** Real integration status (env-config check + D1 connection rows). */
export interface IntegrationInfo {
  id: "gmail" | "github";
  name: string;
  /** OAuth client credentials exist in the environment. */
  configured: boolean;
  /** A REAL connection exists in D1 (never faked). */
  connected: boolean;
  /** Status of the DEFAULT account (null = not connected) — legacy field. */
  status: "connected" | "needs_reauthorization" | null;
  /** Default account identity (email / login) — legacy field. */
  accountName: string | null;
  avatarUrl: string | null;
  /** ALL connected accounts for this provider (multi-account). */
  accounts: ConnectedAccountInfo[];
  /** The explicit default account id (null = none connected). */
  defaultAccountId: string | null;
  /** Human-readable setup guidance. */
  setup: string;
}

// ---------- Gmail (real Google OAuth) ----------

export interface GmailMessageSummary {
  id: string;
  threadId: string | null;
  from: string;
  to: string;
  subject: string;
  date: string | null;
  snippet: string;
  unread: boolean;
}

export interface GmailMessageDetail extends GmailMessageSummary {
  body: string;
}

// ---------- GitHub (real GitHub OAuth) ----------

export interface GitHubRepo {
  id: number;
  name: string;
  fullName: string;
  owner: string;
  description: string | null;
  private: boolean;
  url: string;
  stars: number;
  forks: number;
  issues: number;
  language: string | null;
  updatedAt: string | null;
}

export interface GitHubIssue {
  id: number;
  number: number;
  title: string;
  state: string;
  user: string;
  url: string;
  isPullRequest: boolean;
  createdAt: string | null;
  updatedAt: string | null;
}

export interface Settings {
  chat_model: string;
  voice: string;
  voice_speed: string;
  memory_enabled: string;
  memory_auto_learn: string;
  notifications: string;
  density: string;
  accent: string;
}
