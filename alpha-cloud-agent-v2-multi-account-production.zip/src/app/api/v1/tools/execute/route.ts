// POST /api/v1/tools/execute — execute a REAL tool with permission tiers.
// Medium/high permission tools require confirmed=true; otherwise 409.

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, json, serverError } from "@/server/http";
import { executeTool } from "@/server/tools";
import { recordAudit } from "@/server/repos/system";
import { ProviderNotConfiguredError } from "@/server/ai/types";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

const bodySchema = z.object({
  name: z.string().min(1).max(100),
  args: z.record(z.string(), z.unknown()).optional(),
  confirmed: z.boolean().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { user } = guard.ctx;

    const parsed = bodySchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return badRequest("Tool name is required");

    const result = await executeTool(user.id, parsed.data);
    if (!result.ok) {
      if (result.status === 409) {
        return json(
          {
            requiresConfirmation: true,
            permission: result.permission,
            tool: result.tool,
            args: result.args,
            message: result.message,
          },
          { status: 409 },
        );
      }
      return json({ error: result.error }, { status: result.status });
    }

    void recordAudit({
      userId: user.id,
      action: `tools.${parsed.data.name}`,
      category: "tools",
      details: { confirmed: parsed.data.confirmed === true },
    });
    return json({ result: result.result });
  } catch (e) {
    if (e instanceof ProviderNotConfiguredError) {
      return json({ error: e.message }, { status: 503 });
    }
    return serverError(e);
  }
}
