// GET /api/v1/tools — tool registry (name, description, permission).

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { json, serverError } from "@/server/http";
import { TOOLS } from "@/server/tools";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    return json({
      tools: TOOLS.map((t) => ({
        name: t.name,
        description: t.description,
        permission: t.permission,
      })),
    });
  } catch (e) {
    return serverError(e);
  }
}
