// GET /api/v1/system/health — REAL health checks.
//
// Every number here is measured live: D1 query latency, R2 head latency and
// (optionally, ?ai=1) a live ping of every CONFIGURED AI provider. Nothing
// is simulated — an unconfigured provider is reported as configured:false /
// offline and is never pinged.
//
// The `ai` object keeps the legacy single-provider fields (configured,
// provider, ok, latencyMs, error — provider = the router's current primary)
// and adds `providers`: the full per-provider health list the System view
// renders.

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { json, serverError } from "@/server/http";
import { getDb } from "@/server/db";
import { getR2 } from "@/server/storage";
import { listProviders, pingAllProviders } from "@/server/ai";
import { countJobsByStatus, listRecentJobs } from "@/server/repos/system";
import { storageUsage } from "@/server/repos/files";
import { countUsers } from "@/server/repos/users";

export const dynamic = "force-dynamic";

async function checkDb(): Promise<{ ok: boolean; latencyMs: number; error?: string }> {
  const start = Date.now();
  try {
    const db = await getDb();
    const row = await db.prepare("SELECT 1 AS one").first<{ one: number }>();
    if (row?.one !== 1) throw new Error("unexpected query result");
    return { ok: true, latencyMs: Date.now() - start };
  } catch (e) {
    return { ok: false, latencyMs: Date.now() - start, error: e instanceof Error ? e.message : String(e) };
  }
}

async function checkStorage(): Promise<{ ok: boolean; latencyMs: number; error?: string }> {
  const start = Date.now();
  try {
    const r2 = await getR2();
    // List a non-existent prefix — cheap way to verify the binding answers.
    await r2.list({ prefix: "__healthcheck__", limit: 1 });
    return { ok: true, latencyMs: Date.now() - start };
  } catch (e) {
    return { ok: false, latencyMs: Date.now() - start, error: e instanceof Error ? e.message : String(e) };
  }
}

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const userId = guard.ctx.user.id;

    const withAiPing = new URL(req.url).searchParams.get("ai") === "1";

    const [db, storage, jobs, usage, userCount] = await Promise.all([
      checkDb(),
      checkStorage(),
      countJobsByStatus(),
      storageUsage(userId),
      countUsers(),
    ]);

    // AI providers: with ?ai=1 every CONFIGURED provider is pinged for real
    // (unconfigured ones are skipped — never reported healthy without creds).
    // Dashboard-managed credentials (per-user) are honored for both listing
    // and pinging — environment credentials remain the fallback.
    const providers = withAiPing
      ? await pingAllProviders({ userId })
      : await listProviders({ userId });

    // Legacy single-provider view of the routed primary provider.
    let ai: Record<string, unknown>;
    const primary = providers.find((p) => p.configured && p.enabled) ?? null;
    if (withAiPing && primary) {
      const pinged = providers.find((p) => p.id === primary.id) ?? primary;
      ai = {
        configured: true,
        provider: pinged.id,
        ok: pinged.status === "healthy",
        latencyMs: pinged.latencyMs ?? undefined,
        error: pinged.status !== "healthy" ? `${pinged.status}${pinged.lastErrorCategory ? ` (${pinged.lastErrorCategory})` : ""}` : undefined,
      };
    } else {
      ai = {
        configured: primary !== null,
        provider: primary?.id ?? "none",
      };
    }
    ai.providers = providers;

    const recentJobs = await listRecentJobs(userId, 10);

    return json({
      status: db.ok && storage.ok ? "healthy" : "degraded",
      checkedAt: new Date().toISOString(),
      db,
      storage,
      ai,
      jobs: { counts: jobs, recent: recentJobs },
      storageUsage: usage,
      users: userCount,
      version: "2.0.0",
    });
  } catch (e) {
    return serverError(e);
  }
}
