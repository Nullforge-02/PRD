// GET /api/v1/audit — real audit events (security-relevant actions only).

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { json, serverError } from "@/server/http";
import { listAudit } from "@/server/repos/system";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const limit = Number(new URL(req.url).searchParams.get("limit") ?? "100");
    const events = await listAudit(
      guard.ctx.user.id,
      Number.isFinite(limit) ? limit : 100,
    );
    return json({ events });
  } catch (e) {
    return serverError(e);
  }
}
