// POST /api/v1/chat — send a message, get a REAL provider response (streamed).
//
// Flow: persist user message → (optional) analyze an attached image with the
// real vision router → run chat turn (LAYERED context: memories + rolling
// summary + relevant older messages + verbatim recent window; see
// src/server/context/) → persist assistant message → stream the final text
// to the client → post-response maintenance via after(): rolling summary
// update + semantic memory extraction (never block the streamed answer).
//
// The X-Conversation-Id header lets the client track the conversation;
// X-AI-Provider tells the composer indicator which provider actually served
// the turn (display name only — never any credential material);
// X-Alpha-Context reports the layered-context stats consumed by the UI:
//   recent=<n>; summary=<0|1>; relevant=<n>; memories=<n>
//
// Attachments (optional): `attachmentId` references an image the client
// uploaded first via POST /api/v1/files. The image is read from R2, analyzed
// through the vision-capable provider router (real analysis), and the result
// is injected as context for the chat model — an honest multimodal path that
// works with every chat-capable provider.

import { NextRequest, after } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, serverError } from "@/server/http";
import {
  createConversation,
  findConversation,
  listMessages,
} from "@/server/repos/conversations";
import { updateConversation } from "@/server/repos/conversations";
import { findFile } from "@/server/repos/files";
import { getR2 } from "@/server/storage";
import { recordAudit } from "@/server/repos/system";
import {
  deriveTitle,
  isPlaceholderTitle,
  persistMessage,
  runChatTurn,
  streamText,
} from "@/server/chat-engine";
import { maybeUpdateSummary } from "@/server/context/summarizer";
import { maybeExtractMemory } from "@/server/context/memory-extract";
import { withFallback } from "@/server/ai";
import { ProviderNotConfiguredError } from "@/server/ai/types";
import {
  AllProvidersUnavailableError,
  CapabilityUnavailableError,
  ProviderError,
} from "@/server/ai/errors";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

const MAX_ATTACHMENT_BYTES = 10 * 1024 * 1024; // 10 MB

const bodySchema = z.object({
  conversationId: z.string().min(1).optional(),
  message: z.string().min(1).max(32_000),
  /** Optional uploaded image (files table id, image/*, owned by the user). */
  attachmentId: z.string().min(1).max(64).optional(),
});

/** Read an owned image file from R2 and return base64 + mime. */
async function readAttachment(
  userId: string,
  attachmentId: string,
): Promise<{ base64: string; mime: string; filename: string } | null> {
  const file = await findFile(attachmentId, userId);
  if (!file) return null;
  if (!file.mimeType.startsWith("image/")) return null;
  if (file.size > MAX_ATTACHMENT_BYTES) return null;
  const r2 = await getR2();
  const obj = await r2.get(file.r2Key);
  if (!obj) return null;
  const buffer = new Uint8Array(await obj.arrayBuffer());
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < buffer.length; i += chunk) {
    binary += String.fromCharCode(...buffer.subarray(i, i + chunk));
  }
  return { base64: btoa(binary), mime: file.mimeType, filename: file.filename };
}

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { user } = guard.ctx;

    const parsed = bodySchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return badRequest("Message is required");
    const { conversationId, message, attachmentId } = parsed.data;

    // Resolve or create the conversation.
    let conversation = conversationId
      ? await findConversation(conversationId, user.id)
      : null;
    if (!conversation) {
      conversation = await createConversation(user.id, deriveTitle(message));
    }

    // Persist the user message first (before calling the provider).
    await persistMessage(conversation.id, "user", message);

    // FULL history INCLUDING the just-persisted user message (the context
    // engine expects it as the last element and never duplicates it).
    const allMessages = await listMessages(conversation.id);
    // No hardcoded model — the router picks the provider, each provider uses
    // its own configured model.
    const modelPreference = undefined;

    // Optional attachment: REAL vision analysis becomes message context.
    let attachmentContext = "";
    let attachmentError: string | null = null;
    if (attachmentId) {
      const attachment = await readAttachment(user.id, attachmentId);
      if (!attachment) {
        return badRequest("Attachment not found (it must be an image you uploaded, under 10 MB)");
      }
      try {
        const analysis = await withFallback(
          "vision",
          (p) => {
            if (!p.analyzeImage) throw new Error("Provider does not support vision");
            return p.analyzeImage(
              attachment.base64,
              attachment.mime,
              "Describe this image precisely and concisely for context: subjects, text, data, notable details.",
            );
          },
          { userId: user.id },
        );
        attachmentContext =
          `\n\n[The user attached an image: ${attachment.filename}. ` +
          `Vision analysis of the image: ${analysis.slice(0, 4000)}]`;
      } catch (e) {
        // The chat still works without vision — report honestly inline.
        if (e instanceof CapabilityUnavailableError) {
          attachmentError = "No configured provider supports vision — the image was not analyzed.";
        } else if (
          e instanceof AllProvidersUnavailableError ||
          e instanceof ProviderNotConfiguredError ||
          e instanceof ProviderError
        ) {
          attachmentError = "Image analysis failed — the message was sent without it.";
        } else {
          throw e;
        }
      }
    }

    let result;
    try {
      result = await runChatTurn({
        userId: user.id,
        userName: user.name,
        model: modelPreference,
        conversationId: conversation.id,
        allMessages,
        userMessage: message,
        attachmentContext,
      });
    } catch (e) {
      const aiConfigError =
        e instanceof ProviderNotConfiguredError ||
        e instanceof AllProvidersUnavailableError ||
        e instanceof CapabilityUnavailableError ||
        e instanceof ProviderError;
      if (aiConfigError) {
        return new Response(JSON.stringify({ error: e.message }), {
          status: 503,
          headers: {
            "Content-Type": "application/json",
            "Cache-Control": "no-store",
            "X-Conversation-Id": conversation.id,
          },
        });
      }
      throw e;
    }

    // Persist the assistant answer (and annotate tool usage in-line).
    let finalContent = result.content;
    if (attachmentError) {
      finalContent = `> ⚠️ ${attachmentError}\n\n${finalContent}`;
    }
    if (result.toolExecutions.length > 0) {
      const toolLines = result.toolExecutions
        .map((t) => `> 🛠 \`${t.tool}\` — ${t.ok ? "executed" : `failed: ${t.error}`}`)
        .join("\n");
      finalContent = `${toolLines}\n\n${finalContent}`;
    }
    await persistMessage(conversation.id, "assistant", finalContent, result.model);

    // Title conversations deterministically from the first MEANINGFUL user
    // message (no AI call): greeting-only first messages keep the placeholder
    // so a later substantive message can still name the thread.
    if (isPlaceholderTitle(conversation.title)) {
      const candidate = deriveTitle(message);
      if (!isPlaceholderTitle(candidate)) {
        await updateConversation(conversation.id, user.id, { title: candidate });
      }
    }

    void recordAudit({
      userId: user.id,
      action: "chat.message",
      category: "chat",
      details: { conversationId: conversation.id, tools: result.toolExecutions.map((t) => t.tool) },
    });

    // Post-response context maintenance (Next after() → waitUntil on
    // Cloudflare): rolling summary update + semantic memory extraction.
    // Neither ever throws and neither ever blocks the streamed answer.
    after(async () => {
      await maybeUpdateSummary({ userId: user.id, conversationId: conversation.id });
    });
    after(async () => {
      await maybeExtractMemory({ userId: user.id, userMessage: message });
    });

    const stats = result.contextStats;
    return new Response(streamText(finalContent), {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Cache-Control": "no-store",
        "X-Conversation-Id": conversation.id,
        // Display name of the provider that actually served this turn.
        "X-AI-Provider": result.provider || "router",
        // Layered context transparency (consumed by the UI agent's Task 2-b).
        "X-Alpha-Context": `recent=${stats.recent}; summary=${stats.summary ? 1 : 0}; relevant=${stats.relevant}; memories=${stats.memories}`,
      },
    });
  } catch (e) {
    return serverError(e);
  }
}
