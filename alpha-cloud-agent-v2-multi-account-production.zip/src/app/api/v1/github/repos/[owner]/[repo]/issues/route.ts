// GET /api/v1/github/repos/[owner]/[repo]/issues?accountId= — list OPEN issues
// (and pull requests — GitHub's issues API includes PRs, flagged via
// isPullRequest) for one repository.
//
// Account resolution (multi-account): explicit accountId → the user's default
// GitHub account; ambiguous selection → 400.
//
// Guards (in order):
//   400  owner/repo fail the [A-Za-z0-9_.-]{1,100} sanity check (before any
//        upstream URL is built)
//   503  GitHub OAuth not configured / No GitHub account connected
//   401  { code: "reauthorization_needed" } — reconnect required

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { badRequest, json, serverError } from "@/server/http";
import {
  getValidGithubToken,
  githubConfigured,
  listGithubIssues,
} from "@/server/integrations/github";
import { resolveGithubAccount } from "@/server/integrations/account-resolver";
import { accountResolutionResponse } from "@/server/integrations/account-resolver";
import { integrationErrorResponse } from "@/server/integrations/errors";

export const dynamic = "force-dynamic";

const NAME_RE = /^[A-Za-z0-9_.-]{1,100}$/;

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ owner: string; repo: string }> },
) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const userId = guard.ctx.user.id;

    const { owner, repo } = await params;
    if (!NAME_RE.test(owner) || !NAME_RE.test(repo)) {
      return badRequest("Invalid owner or repository name");
    }

    if (!(await githubConfigured())) {
      return json(
        {
          error:
            "GitHub OAuth is not configured — set GITHUB_CLIENT_ID and GITHUB_CLIENT_SECRET as Worker secrets",
        },
        { status: 503 },
      );
    }

    const accountId = new URL(req.url).searchParams.get("accountId");
    const pick = await resolveGithubAccount(userId, { accountId });
    if (!pick) {
      return json(
        { error: "GitHub is not connected — connect your GitHub account first." },
        { status: 503 },
      );
    }

    const accessToken = await getValidGithubToken(userId, pick.account);
    const issues = await listGithubIssues(accessToken, owner, repo);
    return json({ issues });
  } catch (e) {
    const mapped = accountResolutionResponse(e) ?? integrationErrorResponse(e);
    if (mapped) return mapped;
    return serverError(e);
  }
}
