// GET /api/v1/github/repos?accountId= — list a connected GitHub account's
// repositories (most recently pushed first, 50 per page).
//
// Account resolution (multi-account, centralized in account-resolver.ts):
//   • accountId  → that exact GitHub account
//   • (none)     → the user's explicit DEFAULT GitHub account
//   • ambiguous (several connected, none selected) → 400 asking to select
// GitHub account ROLES (storage/scripts/general) are user-editable via
// PATCH /api/v1/integrations/accounts/[id] and used by role-aware operations.
//
// Guards (in order):
//   503  GitHub OAuth not configured in the environment (Worker secrets)
//   503  No GitHub account connected (no D1 row)
//   401  { code: "reauthorization_needed" } — reconnect required
//
// The token is decrypted server-side for this request only.

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { json, serverError } from "@/server/http";
import { githubConfigured, getValidGithubToken, listGithubRepos } from "@/server/integrations/github";
import { resolveGithubAccount } from "@/server/integrations/account-resolver";
import { accountResolutionResponse } from "@/server/integrations/account-resolver";
import { integrationErrorResponse } from "@/server/integrations/errors";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const userId = guard.ctx.user.id;

    if (!(await githubConfigured())) {
      return json(
        {
          error:
            "GitHub OAuth is not configured — set GITHUB_CLIENT_ID and GITHUB_CLIENT_SECRET as Worker secrets",
        },
        { status: 503 },
      );
    }

    const accountId = new URL(req.url).searchParams.get("accountId");
    const pick = await resolveGithubAccount(userId, { accountId });
    if (!pick) {
      return json(
        { error: "GitHub is not connected — connect your GitHub account first." },
        { status: 503 },
      );
    }

    const accessToken = await getValidGithubToken(userId, pick.account);
    const repos = await listGithubRepos(accessToken);
    return json({
      repos,
      account: { id: pick.account.id, accountName: pick.account.accountName, role: pick.account.role },
      resolution: pick.resolution,
    });
  } catch (e) {
    const mapped = accountResolutionResponse(e) ?? integrationErrorResponse(e);
    if (mapped) return mapped;
    return serverError(e);
  }
}
