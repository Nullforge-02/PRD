// POST /api/v1/vision/analyze — real image understanding via the AI router.
// Routed to the highest-priority provider that declares the vision capability.
// Accepts multipart/form-data with 'file' (image) and optional 'prompt'.

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { badRequest, json, serverError } from "@/server/http";
import { withFallback } from "@/server/ai";
import { ProviderNotConfiguredError } from "@/server/ai/types";
import {
  AllProvidersUnavailableError,
  CapabilityUnavailableError,
  ProviderError,
} from "@/server/ai/errors";
import { MAX_UPLOAD_BYTES } from "@/server/storage";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const MAX_IMAGE_BYTES = 10 * 1024 * 1024; // 10 MB

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;

    const form = await req.formData().catch(() => null);
    const file = form?.get("file");
    const prompt = (form?.get("prompt") as string) || "Describe this image in detail.";
    if (!form || !(file instanceof File)) {
      return badRequest("Multipart form with a 'file' (image) field is required");
    }
    if (file.size > MAX_IMAGE_BYTES) {
      return badRequest("Image exceeds the 10 MB limit");
    }
    const mime = file.type || "image/png";
    if (!mime.startsWith("image/")) {
      return badRequest("Only image files can be analyzed");
    }

    const buffer = new Uint8Array(await file.arrayBuffer());
    let binary = "";
    const chunk = 0x8000;
    for (let i = 0; i < buffer.length; i += chunk) {
      binary += String.fromCharCode(...buffer.subarray(i, i + chunk));
    }
    const base64 = btoa(binary);

    const description = await withFallback(
      "vision",
      (p) => {
        if (!p.analyzeImage) throw new Error("Provider does not support vision");
        return p.analyzeImage(base64, mime, prompt.slice(0, 1000));
      },
      { userId: guard.ctx.user.id },
    );
    return json({ description });
  } catch (e) {
    if (e instanceof CapabilityUnavailableError) {
      return json({ error: e.message }, { status: 501 });
    }
    if (
      e instanceof AllProvidersUnavailableError ||
      e instanceof ProviderNotConfiguredError ||
      e instanceof ProviderError
    ) {
      return json({ error: e.message }, { status: 503 });
    }
    return serverError(e);
  }
}
