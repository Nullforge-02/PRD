// GET /api/v1/integrations/github/connect — start the GitHub OAuth web-server
// flow.
//
// Requires a session. When GitHub OAuth client credentials are missing the
// honest answer is 503. On success: 302 to GitHub's authorize screen with a
// single-use OAuth state cookie (HttpOnly, 10 min TTL, SameSite=Lax).
//
// Security: the state cookie is the CSRF guard for the callback; the client
// secret is used only server-side (at token exchange) and never appears in a
// URL the browser sees.

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { json, serverError } from "@/server/http";
import { buildGithubAuthUrl, githubConfigured } from "@/server/integrations/github";
import { generateState, stateCookieHeader } from "@/server/integrations/oauth-state";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;

    if (!(await githubConfigured())) {
      return json(
        {
          error:
            "GitHub OAuth is not configured — set GITHUB_CLIENT_ID and GITHUB_CLIENT_SECRET as Worker secrets",
        },
        { status: 503 },
      );
    }

    const state = generateState("github");
    const authorizeUrl = await buildGithubAuthUrl(req, state);
    return new Response(null, {
      status: 302,
      headers: {
        Location: authorizeUrl,
        "Set-Cookie": stateCookieHeader("github", state, req),
        "Cache-Control": "no-store",
      },
    });
  } catch (e) {
    return serverError(e);
  }
}
