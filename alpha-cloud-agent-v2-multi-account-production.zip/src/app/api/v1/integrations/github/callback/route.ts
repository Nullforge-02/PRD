// GET /api/v1/integrations/github/callback — finish the GitHub OAuth flow.
//
// NOT requireAuth: failures must REDIRECT back to the app (with ?view=github
// &oauth=… for the shell toast) instead of answering with a JSON 401.
//
// Flow:
//   error=access_denied      → 302 /?view=github&oauth=error:denied
//   missing code/state       → 302 …&oauth=error:state
//   state cookie mismatch    → 302 …&oauth=error:state   (CSRF guard)
//   no valid session         → 302 …&oauth=error:session
//   exchange/identity fails  → 302 …&oauth=error
//   success                  → upsert encrypted token in D1 + audit →
//                              302 /?view=github&oauth=connected
//
// Security:
//   • The state cookie (alpha_oauth_state) must match the round-tripped state
//     — compared without logging, and ALWAYS cleared afterwards.
//   • The authorization code is exchanged server-side; the final redirect
//     carries NO code, NO token — only the view + result flags.
//   • The access token is encrypted (AES-256-GCM, OAuth HKDF purpose) before
//     storage and never appears in responses, logs, or audit details.
//   • GitHub tokens do not expire → expiresAt is null.

import { NextRequest } from "next/server";
import { getAuthContext } from "@/server/auth";
import { getClientIp } from "@/server/http";
import {
  encryptOAuthToken,
  upsertConnectedAccount,
} from "@/server/repos/connected-accounts";
import { recordAudit } from "@/server/repos/system";
import { exchangeGithubCode, fetchGithubUser } from "@/server/integrations/github";
import { clearStateCookieHeader, verifyState } from "@/server/integrations/oauth-state";

export const dynamic = "force-dynamic";

/** 302 back to the app shell with a result flag; always clears the state cookie. */
function redirectResult(req: NextRequest, oauth: string): Response {
  return new Response(null, {
    status: 302,
    headers: {
      Location: `/?view=github&oauth=${encodeURIComponent(oauth)}`,
      "Set-Cookie": clearStateCookieHeader(req),
      "Cache-Control": "no-store",
    },
  });
}

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);

    if (url.searchParams.get("error") === "access_denied") {
      return redirectResult(req, "error:denied");
    }

    const code = url.searchParams.get("code");
    const stateParam = url.searchParams.get("state");
    if (!code || !stateParam) {
      return redirectResult(req, "error:state");
    }
    if (!verifyState(req, "github", stateParam)) {
      return redirectResult(req, "error:state");
    }

    const ctx = await getAuthContext(req);
    if (!ctx) {
      return redirectResult(req, "error:session");
    }

    const tokens = await exchangeGithubCode(req, code);
    const user = await fetchGithubUser(tokens.accessToken);

    const encryptedAccessToken = await encryptOAuthToken(tokens.accessToken);
    const accountName = user.login;

    await upsertConnectedAccount({
      userId: ctx.user.id,
      provider: "github",
      providerAccountId: user.id,
      accountName,
      avatarUrl: user.avatarUrl,
      encryptedAccessToken,
      encryptedRefreshToken: null,
      expiresAt: null, // GitHub tokens do not expire
      scopes: tokens.scope ?? "",
    });

    // Audit WITHOUT tokens — identity metadata only.
    await recordAudit({
      userId: ctx.user.id,
      action: "integration.github_connected",
      category: "integrations",
      ip: getClientIp(req),
      details: { provider: "github", accountName },
    });

    return redirectResult(req, "connected");
  } catch (e) {
    // Sanitized log: the error classes carry fixed messages, never tokens.
    // The request URL (which contains the authorization code) is NOT logged.
    console.error(
      "[alpha] github oauth callback failed:",
      e instanceof Error ? e.name : "unknown error",
    );
    return redirectResult(req, "error");
  }
}
