// GET /api/v1/integrations/google/connect — start the Google OAuth web-server
// flow.
//
// Requires a session. When Google OAuth client credentials are missing the
// honest answer is 503. On success: 302 to Google's consent screen with a
// single-use OAuth state cookie (HttpOnly, 10 min TTL, SameSite=Lax).
//
// Security: the state cookie is the CSRF guard for the callback; the client
// secret is used only server-side (at token exchange) and never appears in a
// URL the browser sees.

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { json, serverError } from "@/server/http";
import { buildGoogleAuthUrl, googleConfigured } from "@/server/integrations/google";
import { generateState, stateCookieHeader } from "@/server/integrations/oauth-state";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;

    if (!(await googleConfigured())) {
      return json(
        {
          error:
            "Google OAuth is not configured — set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET as Worker secrets",
        },
        { status: 503 },
      );
    }

    const state = generateState("google");
    const authorizeUrl = await buildGoogleAuthUrl(req, state);
    return new Response(null, {
      status: 302,
      headers: {
        Location: authorizeUrl,
        "Set-Cookie": stateCookieHeader("google", state, req),
        "Cache-Control": "no-store",
      },
    });
  } catch (e) {
    return serverError(e);
  }
}
