// GET /api/v1/integrations/google/callback — finish the Google OAuth flow.
//
// NOT requireAuth: failures must REDIRECT back to the app (with ?view=gmail
// &oauth=… for the shell toast) instead of answering with a JSON 401.
//
// Flow:
//   error=access_denied      → 302 /?view=gmail&oauth=error:denied
//   missing code/state       → 302 …&oauth=error:state
//   state cookie mismatch    → 302 …&oauth=error:state   (CSRF guard)
//   no valid session         → 302 …&oauth=error:session
//   exchange/identity fails  → 302 …&oauth=error
//   success                  → upsert encrypted tokens in D1 + audit →
//                              302 /?view=gmail&oauth=connected
//
// Security:
//   • The state cookie (alpha_oauth_state) must match the round-tripped state
//     — compared without logging, and ALWAYS cleared afterwards.
//   • The authorization code is exchanged server-side; the final redirect
//     carries NO code, NO token — only the view + result flags.
//   • Tokens are encrypted (AES-256-GCM, OAuth HKDF purpose) before storage
//     and never appear in responses, logs, or audit details.

import { NextRequest } from "next/server";
import { getAuthContext } from "@/server/auth";
import { getClientIp } from "@/server/http";
import {
  encryptOAuthToken,
  upsertConnectedAccount,
} from "@/server/repos/connected-accounts";
import { recordAudit } from "@/server/repos/system";
import { exchangeGoogleCode, fetchGoogleUserinfo } from "@/server/integrations/google";
import { clearStateCookieHeader, verifyState } from "@/server/integrations/oauth-state";

export const dynamic = "force-dynamic";

/** 302 back to the app shell with a result flag; always clears the state cookie. */
function redirectResult(req: NextRequest, oauth: string): Response {
  return new Response(null, {
    status: 302,
    headers: {
      Location: `/?view=gmail&oauth=${encodeURIComponent(oauth)}`,
      "Set-Cookie": clearStateCookieHeader(req),
      "Cache-Control": "no-store",
    },
  });
}

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);

    if (url.searchParams.get("error") === "access_denied") {
      return redirectResult(req, "error:denied");
    }

    const code = url.searchParams.get("code");
    const stateParam = url.searchParams.get("state");
    if (!code || !stateParam) {
      return redirectResult(req, "error:state");
    }
    if (!verifyState(req, "google", stateParam)) {
      return redirectResult(req, "error:state");
    }

    const ctx = await getAuthContext(req);
    if (!ctx) {
      return redirectResult(req, "error:session");
    }

    const tokens = await exchangeGoogleCode(req, code);
    const userinfo = await fetchGoogleUserinfo(tokens.accessToken);

    const encryptedAccessToken = await encryptOAuthToken(tokens.accessToken);
    const encryptedRefreshToken = tokens.refreshToken
      ? await encryptOAuthToken(tokens.refreshToken)
      : null;
    const expiresAt = tokens.expiresIn
      ? new Date(Date.now() + tokens.expiresIn * 1000).toISOString()
      : null;
    const accountName = userinfo.email ?? userinfo.name ?? null;

    await upsertConnectedAccount({
      userId: ctx.user.id,
      provider: "google",
      providerAccountId: userinfo.sub,
      accountName,
      avatarUrl: userinfo.picture ?? null,
      encryptedAccessToken,
      encryptedRefreshToken,
      expiresAt,
      scopes: tokens.scope ?? "",
    });

    // Audit WITHOUT tokens — identity metadata only.
    await recordAudit({
      userId: ctx.user.id,
      action: "integration.google_connected",
      category: "integrations",
      ip: getClientIp(req),
      details: { provider: "google", accountName },
    });

    return redirectResult(req, "connected");
  } catch (e) {
    // Sanitized log: the error classes carry fixed messages, never tokens.
    // The request URL (which contains the authorization code) is NOT logged.
    console.error(
      "[alpha] google oauth callback failed:",
      e instanceof Error ? e.name : "unknown error",
    );
    return redirectResult(req, "error");
  }
}
