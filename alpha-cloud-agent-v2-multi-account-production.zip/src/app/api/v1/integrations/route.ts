// GET /api/v1/integrations — honest integration status (env-driven, userId-scoped).

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { json, serverError } from "@/server/http";
import { getIntegrationsStatus } from "@/server/integrations";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const integrations = await getIntegrationsStatus(guard.ctx.user.id);
    return json({ integrations });
  } catch (e) {
    return serverError(e);
  }
}
