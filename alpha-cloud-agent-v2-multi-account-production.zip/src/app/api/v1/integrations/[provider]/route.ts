// DELETE /api/v1/integrations/[provider] — disconnect ALL accounts of Google
// or GitHub ("disconnect everything" — per-account disconnects use
// DELETE /api/v1/integrations/accounts/[id]).
//
// For EVERY connected account of the provider:
//   1. Revoke the stored token at the provider (BEST-EFFORT — a failed or
//      skipped revoke never blocks the local disconnect; when a stored token
//      cannot be decrypted, e.g. a rotated AI_CREDENTIALS_SECRET, that revoke
//      is skipped silently).
//   2. Delete the D1 connection rows (and their encrypted tokens with it).
//   3. Record an audit event (provider + count + account names only — never
//      tokens).
//
// Idempotent: deleting when nothing is connected still returns {ok: true}.

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { getClientIp, json, notFound, serverError } from "@/server/http";
import {
  decryptOAuthToken,
  deleteAllAccounts,
  isOAuthProvider,
} from "@/server/repos/connected-accounts";
import { recordAudit } from "@/server/repos/system";
import { revokeGoogleToken } from "@/server/integrations/google";
import { revokeGithubToken } from "@/server/integrations/github";

export const dynamic = "force-dynamic";

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ provider: string }> },
) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { user } = guard.ctx;
    const ip = getClientIp(req);

    const { provider } = await params;
    if (!isOAuthProvider(provider)) {
      return notFound("Unknown integration — supported: google, github");
    }

    // Best-effort revocation of every stored token (never blocks deletion).
    const accounts = await deleteAllAccounts(user.id, provider);
    for (const account of accounts) {
      try {
        const accessToken = await decryptOAuthToken(account.encryptedAccessToken);
        if (provider === "google") {
          await revokeGoogleToken(accessToken);
        } else {
          await revokeGithubToken(accessToken);
        }
      } catch {
        // Token unusable (e.g. rotated encryption secret) — skip the revoke.
      }
    }

    await recordAudit({
      userId: user.id,
      action: `integration.${provider}_disconnected_all`,
      category: "integrations",
      ip,
      details: {
        provider,
        count: accounts.length,
        accountNames: accounts.map((a) => a.accountName).filter(Boolean),
      },
    });

    return json({ ok: true, disconnected: accounts.length });
  } catch (e) {
    return serverError(e);
  }
}
