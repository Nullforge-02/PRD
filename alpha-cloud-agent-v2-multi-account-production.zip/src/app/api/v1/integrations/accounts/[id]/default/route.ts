// POST /api/v1/integrations/accounts/[id]/default — make ONE account the
// user's explicit default for its provider ("Use" in the UI).
//
//   • Clears the default flag from every sibling of the same provider first —
//     the invariant is exactly ONE default per (user, provider).
//   • Ownership-scoped: the account must belong to the session user.
//   • Audited (account identity only — never tokens).
//
// The default is what the account resolver uses when an operation does not
// name an explicit account (e.g. "check my email" → the DEFAULT Google
// account — never an arbitrary "most recently updated" one).

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { getClientIp, json, notFound, serverError } from "@/server/http";
import { getAccountById, setDefaultAccount } from "@/server/repos/connected-accounts";
import { recordAudit } from "@/server/repos/system";

export const dynamic = "force-dynamic";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { user } = guard.ctx;

    const { id } = await params;
    const account = await getAccountById(user.id, id);
    if (!account) {
      return notFound("Account not found — it may already be disconnected.");
    }

    const updated = await setDefaultAccount(user.id, id);
    if (!updated) {
      return notFound("Account not found — it may already be disconnected.");
    }

    await recordAudit({
      userId: user.id,
      action: "integration.account_default_set",
      category: "integrations",
      ip: getClientIp(req),
      details: { accountId: id, accountName: updated.accountName, provider: updated.provider },
    });

    return json({
      account: {
        id: updated.id,
        provider: updated.provider,
        accountName: updated.accountName,
        isDefault: updated.isDefault,
      },
    });
  } catch (e) {
    return serverError(e);
  }
}
