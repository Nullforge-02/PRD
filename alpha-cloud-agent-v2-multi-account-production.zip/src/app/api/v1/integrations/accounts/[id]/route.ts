// PATCH  /api/v1/integrations/accounts/[id] — set the ROLE of a GitHub account
// DELETE /api/v1/integrations/accounts/[id] — disconnect ONE account.
//
// PATCH body: { role: "storage" | "scripts" | "general" }
//   • Only GitHub accounts carry roles — PATCHing a Google account → 400.
//   • The role is user-editable at any time and is used by the centralized
//     account resolver when an operation asks for a role.
//
// DELETE:
//   1. Revoke the stored token at the provider (BEST-EFFORT — a failed or
//      skipped revoke never blocks the local disconnect).
//   2. Delete the D1 connection row (and its encrypted tokens with it). Other
//      connected accounts of the same provider are UNTOUCHED.
//   3. When the deleted account was the provider default, the earliest
//      remaining sibling is promoted so an explicit default always exists.
//   4. Audit (account identity only — never tokens).
//
// Idempotent: deleting a non-existent account still returns {ok: true}.

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, getClientIp, json, serverError } from "@/server/http";
import {
  decryptOAuthToken,
  deleteAccount,
  getAccountById,
  isGithubAccountRole,
  setAccountRole,
} from "@/server/repos/connected-accounts";
import { recordAudit } from "@/server/repos/system";
import { revokeGoogleToken } from "@/server/integrations/google";
import { revokeGithubToken } from "@/server/integrations/github";

export const dynamic = "force-dynamic";

const roleSchema = z.object({
  role: z.enum(["storage", "scripts", "general"]),
});

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { user } = guard.ctx;

    const { id } = await params;
    const account = await getAccountById(user.id, id);
    if (!account) {
      return badRequest("Account not found — it may already be disconnected.");
    }
    if (account.provider !== "github") {
      return badRequest("Roles apply to GitHub accounts only.");
    }

    const raw = await req.json().catch(() => null);
    const parsed = roleSchema.safeParse(raw);
    if (!parsed.success) {
      return badRequest('Role must be one of "storage", "scripts" or "general".');
    }
    const role = parsed.data.role;
    if (!isGithubAccountRole(role)) {
      return badRequest('Role must be one of "storage", "scripts" or "general".');
    }

    const updated = await setAccountRole(user.id, id, role);
    if (!updated) {
      return badRequest("Account not found — it may already be disconnected.");
    }

    await recordAudit({
      userId: user.id,
      action: "integration.account_role_updated",
      category: "integrations",
      ip: getClientIp(req),
      details: { accountId: id, accountName: updated.accountName, role },
    });

    return json({
      account: {
        id: updated.id,
        provider: updated.provider,
        accountName: updated.accountName,
        role: updated.role,
        isDefault: updated.isDefault,
      },
    });
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { user } = guard.ctx;
    const ip = getClientIp(req);

    const { id } = await params;
    const account = await getAccountById(user.id, id);
    if (!account) {
      // Idempotent — deleting a non-existent account is a no-op success.
      return json({ ok: true });
    }

    // Best-effort revoke (never blocks the local disconnect).
    try {
      const accessToken = await decryptOAuthToken(account.encryptedAccessToken);
      if (account.provider === "google") {
        await revokeGoogleToken(accessToken);
      } else {
        await revokeGithubToken(accessToken);
      }
    } catch {
      // Token unusable (e.g. rotated encryption secret) — skip the revoke.
    }

    const result = await deleteAccount(user.id, id);

    await recordAudit({
      userId: user.id,
      action: `integration.${account.provider}_account_disconnected`,
      category: "integrations",
      ip,
      details: {
        accountId: id,
        accountName: account.accountName,
        promotedDefaultId: result.promotedDefaultId,
      },
    });

    return json({ ok: true, promotedDefaultId: result.promotedDefaultId });
  } catch (e) {
    return serverError(e);
  }
}
