// PATCH  /api/v1/providers/custom/[id] — EDIT a custom provider.
// DELETE /api/v1/providers/custom/[id] — DELETE a custom provider.
//
// Edit semantics:
//   - Omitting apiKey PRESERVES the existing encrypted credential (the user
//     never has to re-enter a key to change models or capabilities).
//   - Changing name/baseUrl/models/capabilities/priority/enabled does NOT
//     force a retest — [Test] is a separate action (real request).
//   - The key is NEVER returned; masked display only.
//
// Delete semantics (after an explicit UI confirmation):
//   - encrypted credential + metadata + health history removed together
//   - the provider is immediately unavailable for routing — no orphans.

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, conflict, json, notFound, serverError } from "@/server/http";
import { getClientIp } from "@/server/http";
import { encryptApiKey, CredentialSecretMissingError } from "@/server/ai/credentials";
import { USER_CAPABILITIES, isUserCapability, type UserCapability } from "@/server/ai/capabilities";
import { listCustomProviderStatuses } from "@/server/ai";
import {
  findCustomProvider,
  updateCustomProvider,
  deleteCustomProvider,
  findCustomProviderByName,
} from "@/server/repos/custom-providers";
import { recordAudit } from "@/server/repos/system";

export const dynamic = "force-dynamic";

const MIN_API_KEY_LENGTH = 4;

const patchSchema = z.object({
  name: z.string().trim().min(1).max(60).optional(),
  apiKey: z.string().min(MIN_API_KEY_LENGTH).max(512).optional(),
  baseUrl: z.string().trim().min(1).max(300).optional(),
  model: z.string().trim().min(1).max(200).optional(),
  visionModel: z.string().trim().max(200).nullable().optional(),
  imageModel: z.string().trim().max(200).nullable().optional(),
  videoModel: z.string().trim().max(200).nullable().optional(),
  capabilities: z.array(z.string()).min(1).max(USER_CAPABILITIES.length).optional(),
  priority: z.number().int().min(1).max(99).optional(),
  enabled: z.boolean().optional(),
});

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { user } = guard.ctx;
    const ip = getClientIp(req);
    const { id } = await params;

    const existing = await findCustomProvider(id, user.id);
    if (!existing) return notFound("Provider not found");

    const parsed = patchSchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) {
      return badRequest("Invalid provider configuration");
    }
    const body = parsed.data;

    if (body.baseUrl !== undefined) {
      try {
        const url = new URL(body.baseUrl);
        if (url.protocol !== "https:" && url.protocol !== "http:") throw new Error("bad protocol");
      } catch {
        return badRequest("Base URL must be a valid http(s) URL");
      }
    }

    if (body.name && body.name !== existing.name) {
      const clash = await findCustomProviderByName(user.id, body.name);
      if (clash && clash.id !== existing.id) {
        return conflict(`A provider named "${body.name}" already exists`);
      }
    }

    let capabilities: UserCapability[] | undefined;
    if (body.capabilities) {
      const invalid = body.capabilities.find((c) => !isUserCapability(c));
      if (invalid) return badRequest(`Unknown capability "${invalid}"`);
      capabilities = Array.from(new Set(body.capabilities)) as UserCapability[];
    }

    // Re-encrypt only when a NEW key was supplied.
    let encrypted: string | undefined;
    let keyHint: string | undefined;
    if (body.apiKey) {
      try {
        ({ encrypted, keyHint } = await encryptApiKey(body.apiKey));
      } catch (e) {
        if (e instanceof CredentialSecretMissingError) {
          return json({ error: e.message }, { status: 503 });
        }
        throw e;
      }
    }

    await updateCustomProvider(id, user.id, {
      ...(body.name !== undefined ? { name: body.name } : {}),
      ...(encrypted !== undefined ? { encryptedApiKey: encrypted, keyHint } : {}),
      ...(body.baseUrl !== undefined ? { baseUrl: body.baseUrl } : {}),
      ...(body.model !== undefined ? { model: body.model } : {}),
      visionModel: body.visionModel !== undefined ? body.visionModel || null : undefined,
      imageModel: body.imageModel !== undefined ? body.imageModel || null : undefined,
      videoModel: body.videoModel !== undefined ? body.videoModel || null : undefined,
      ...(capabilities ? { capabilities } : {}),
      ...(body.priority !== undefined ? { priority: body.priority } : {}),
      ...(body.enabled !== undefined ? { enabled: body.enabled } : {}),
    });

    await recordAudit({
      userId: user.id,
      action: "provider.custom_updated",
      category: "providers",
      ip,
      details: {
        providerId: id,
        name: body.name ?? existing.name,
        keyChanged: Boolean(body.apiKey),
        enabled: body.enabled ?? existing.enabled,
      },
    });

    const statuses = await listCustomProviderStatuses({ userId: user.id });
    const status = statuses.find((p) => p.id === id);
    return json({ provider: status });
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { user } = guard.ctx;
    const ip = getClientIp(req);
    const { id } = await params;

    const existing = await findCustomProvider(id, user.id);
    if (!existing) return notFound("Provider not found");

    // Credential + metadata + health history go together — no orphans.
    await deleteCustomProvider(id, user.id);

    await recordAudit({
      userId: user.id,
      action: "provider.custom_removed",
      category: "providers",
      ip,
      details: { providerId: id, name: existing.name },
    });

    return json({ ok: true, id });
  } catch (e) {
    return serverError(e);
  }
}
