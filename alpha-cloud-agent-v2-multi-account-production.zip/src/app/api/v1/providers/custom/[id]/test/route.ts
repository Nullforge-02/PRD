// POST /api/v1/providers/custom/[id]/test — REAL connection test.
//
// Makes an actual server-side request using the STORED credential:
//   - decrypts the key at test time (and only for this test)
//   - TEXT capability  → minimal chat completion (real provider answer)
//   - otherwise        → GET {baseUrl}/models (real connectivity + auth)
//   - measures real wall-clock latency
//   - records the real health observation + last_tested_at/status in D1
//   - audits provider.custom_test_succeeded / custom_test_failed
//
// NOTHING is simulated. Failure responses are SANITIZED (category-mapped
// fixed messages) — raw upstream bodies and the API key never reach the client.

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { badRequest, json, notFound, serverError } from "@/server/http";
import { getClientIp } from "@/server/http";
import { decryptApiKey, CredentialSecretMissingError } from "@/server/ai/credentials";
import { buildGenericProvider } from "@/server/ai/providers/generic";
import { recordSuccess, recordFailure } from "@/server/ai/health";
import { inferCategory, safeCategoryMessage, type ErrorCategory } from "@/server/ai/errors";
import { findCustomProvider, recordCustomTestResult } from "@/server/repos/custom-providers";
import { recordAudit } from "@/server/repos/system";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { user } = guard.ctx;
    const ip = getClientIp(req);
    const { id } = await params;

    const row = await findCustomProvider(id, user.id);
    if (!row) return notFound("Provider not found");

    if (!row.enabled) {
      return json({
        success: false,
        provider: id,
        error: "Provider is disabled — enable it before testing",
      });
    }

    // Decrypt ONLY now (test time), use once, discard.
    let instance;
    try {
      const apiKey = await decryptApiKey(row.encryptedApiKey);
      instance = buildGenericProvider({
        id: row.id,
        name: row.name,
        apiKey,
        baseUrl: row.baseUrl,
        model: row.model,
        visionModel: row.visionModel,
        imageModel: row.imageModel,
        capabilities: row.capabilities,
      });
    } catch (e) {
      if (e instanceof CredentialSecretMissingError) {
        return json({ success: false, provider: id, error: e.message }, { status: 503 });
      }
      recordFailure(row.id, "configuration", e instanceof Error ? e.message : String(e));
      await recordCustomTestResult(id, user.id, "failed");
      await recordAudit({
        userId: user.id,
        action: "provider.custom_test_failed",
        category: "providers",
        ip,
        details: { providerId: id, name: row.name, category: "configuration" },
      });
      return json({
        success: false,
        provider: id,
        error:
          "The stored key could not be decrypted — AI_CREDENTIALS_SECRET may have " +
          "changed. Delete and re-add the provider.",
      });
    }

    // REAL request — real latency, real provider answer.
    const start = Date.now();
    try {
      const latency = await instance.ping();
      const wallClock = latency || Date.now() - start;
      recordSuccess(row.id, wallClock);
      await recordCustomTestResult(id, user.id, "success");
      await recordAudit({
        userId: user.id,
        action: "provider.custom_test_succeeded",
        category: "providers",
        ip,
        details: { providerId: id, name: row.name, latencyMs: wallClock },
      });
      return json({ success: true, provider: id, latencyMs: wallClock });
    } catch (e) {
      const category: ErrorCategory = inferCategory(e);
      const wallClock = Date.now() - start;
      recordFailure(row.id, category, e instanceof Error ? e.message : String(e));
      await recordCustomTestResult(id, user.id, "failed");
      await recordAudit({
        userId: user.id,
        action: "provider.custom_test_failed",
        category: "providers",
        ip,
        details: { providerId: id, name: row.name, category, latencyMs: wallClock },
      });
      // SANITIZED failure — fixed category message, never the raw body.
      return json({ success: false, provider: id, error: safeCategoryMessage(category) });
    }
  } catch (e) {
    return serverError(e);
  }
}
