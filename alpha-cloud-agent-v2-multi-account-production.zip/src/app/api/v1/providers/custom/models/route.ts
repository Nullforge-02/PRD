// POST /api/v1/providers/custom/models — model discovery (server-side).
//
// Body (one of):
//   { baseUrl, apiKey }  — during Add API (nothing saved yet)
//   { providerId }       — for a SAVED custom provider (key decrypted at
//                          call time, used once, discarded)
//
// Calls GET {baseUrl}/models with the credential server-side and returns the
// model ids for a searchable dropdown. NOT every provider implements /models —
// an unavailable endpoint returns a sanitized soft error and the UI falls back
// to manual model entry. The API key is NEVER echoed, logged or audited.

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, json, serverError } from "@/server/http";
import { fetchModelIds, ModelDiscoveryError } from "@/server/ai/model-discovery";
import { decryptApiKey } from "@/server/ai/credentials";
import { findCustomProvider } from "@/server/repos/custom-providers";
import { safeCategoryMessage } from "@/server/ai/errors";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

const bodySchema = z.union([
  z.object({
    baseUrl: z.string().trim().min(1).max(300),
    apiKey: z.string().min(1).max(512),
  }),
  z.object({
    providerId: z.string().min(1).max(64),
  }),
]);

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const user = guard.ctx.user;

    const parsed = bodySchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) {
      return badRequest("Provide {baseUrl, apiKey} or {providerId}");
    }
    const body = parsed.data;

    let baseUrl: string;
    let apiKey: string;
    if ("providerId" in body) {
      const row = await findCustomProvider(body.providerId, user.id);
      if (!row) return badRequest("Provider not found");
      baseUrl = row.baseUrl;
      // Decrypt ONLY now, use once, discard.
      apiKey = await decryptApiKey(row.encryptedApiKey);
    } else {
      baseUrl = body.baseUrl;
      apiKey = body.apiKey;
    }

    try {
      const models = await fetchModelIds(baseUrl, apiKey);
      return json({ models });
    } catch (e) {
      if (e instanceof ModelDiscoveryError) {
        // Soft, sanitized failure — the UI falls back to manual entry.
        return json({ models: [], error: e.message }, { status: 200 });
      }
      throw e;
    }
  } catch (e) {
    return serverError(e);
  }
}
