// POST /api/v1/providers/custom — ADD a custom AI provider (Test & Add).
// GET  /api/v1/providers/custom — list custom providers (safe metadata).
//
// Test & Add flow (nothing is saved unless the provider REALLY answers):
//   1. Validate fields (name / protocol / key / baseUrl / model / capabilities)
//   2. Validate the base URL is a proper http(s) URL
//   3. Build a TRANSIENT provider instance from the SUPPLIED key + model
//   4. Make a REAL request:
//        - TEXT capability  → minimal chat completion ("Reply with: ok")
//        - otherwise        → GET {baseUrl}/models (real connectivity + auth)
//   5. Measure real wall-clock latency
//   6. Only on success: encrypt the key (AES-256-GCM, random IV), save the
//      provider, record the real health observation, audit (no key material)
//   7. On failure: return a SANITIZED error and create NOTHING
//
// Security:
//   - requireAuth (session + CSRF same-origin enforcement)
//   - The API key never appears in responses, logs, audit events or errors
//   - Unlimited custom providers — no artificial count limit
//   - userId-scoped rows (user isolation)

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, conflict, json, serverError } from "@/server/http";
import { getClientIp } from "@/server/http";
import { encryptApiKey, CredentialSecretMissingError } from "@/server/ai/credentials";
import { buildGenericProvider } from "@/server/ai/providers/generic";
import { USER_CAPABILITIES, isUserCapability, type UserCapability } from "@/server/ai/capabilities";
import { recordSuccess } from "@/server/ai/health";
import { inferCategory, safeCategoryMessage } from "@/server/ai/errors";
import { listCustomProviderStatuses } from "@/server/ai";
import {
  insertCustomProvider,
  findCustomProviderByName,
} from "@/server/repos/custom-providers";
import { recordAudit } from "@/server/repos/system";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const MIN_API_KEY_LENGTH = 4;

const bodySchema = z.object({
  name: z.string().trim().min(1).max(60),
  protocol: z.literal("openai-compatible").optional().default("openai-compatible"),
  apiKey: z.string().min(MIN_API_KEY_LENGTH).max(512),
  baseUrl: z.string().trim().min(1).max(300),
  model: z.string().trim().min(1).max(200),
  visionModel: z.string().trim().max(200).nullable().optional(),
  imageModel: z.string().trim().max(200).nullable().optional(),
  videoModel: z.string().trim().max(200).nullable().optional(),
  capabilities: z.array(z.string()).min(1).max(USER_CAPABILITIES.length).optional(),
  priority: z.number().int().min(1).max(99).optional(),
  enabled: z.boolean().optional(),
});

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const custom = await listCustomProviderStatuses({ userId: guard.ctx.user.id });
    return json({ custom });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { user } = guard.ctx;
    const ip = getClientIp(req);

    const parsed = bodySchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) {
      return badRequest(
        "Invalid provider configuration — name, API key, base URL and model are required",
      );
    }
    const body = parsed.data;

    // Capabilities: validate + normalize against the canonical 6.
    let capabilities: UserCapability[];
    if (!body.capabilities || body.capabilities.length === 0) {
      capabilities = ["TEXT"];
    } else {
      const invalid = body.capabilities.find((c) => !isUserCapability(c));
      if (invalid) return badRequest(`Unknown capability "${invalid}"`);
      capabilities = Array.from(new Set(body.capabilities)) as UserCapability[];
    }

    // Base URL must be a valid http(s) URL (http allowed for local/self-hosted).
    let baseUrl: URL;
    try {
      baseUrl = new URL(body.baseUrl);
    } catch {
      return badRequest("Base URL must be a valid http(s) URL");
    }
    if (baseUrl.protocol !== "https:" && baseUrl.protocol !== "http:") {
      return badRequest("Base URL must be a valid http(s) URL");
    }

    // Unique name per user.
    if (await findCustomProviderByName(user.id, body.name)) {
      return conflict(`A provider named "${body.name}" already exists`);
    }

    // ---- REAL connection test (before anything is saved) ----
    // Transient instance — nothing persisted yet, key used once.
    const testStart = Date.now();
    try {
      const instance = buildGenericProvider({
        id: "pending",
        name: body.name,
        apiKey: body.apiKey,
        baseUrl: body.baseUrl,
        model: body.model,
        visionModel: body.visionModel ?? null,
        imageModel: body.imageModel ?? null,
        capabilities,
      });
      await instance.ping();
    } catch (e) {
      const category = inferCategory(e);
      const latency = Date.now() - testStart;
      await recordAudit({
        userId: user.id,
        action: "provider.custom_test_failed",
        category: "providers",
        ip,
        details: { name: body.name, category, latencyMs: latency },
      });
      // SANITIZED failure — fixed category message; the raw upstream body and
      // the API key never reach the client. No provider is created.
      return json(
        { error: safeCategoryMessage(category), category },
        { status: 502 },
      );
    }

    // ---- Success: encrypt + persist ----
    let encrypted: string;
    let keyHint: string;
    try {
      ({ encrypted, keyHint } = await encryptApiKey(body.apiKey));
    } catch (e) {
      if (e instanceof CredentialSecretMissingError) {
        return json({ error: e.message }, { status: 503 });
      }
      throw e;
    }

    const saved = await insertCustomProvider({
      userId: user.id,
      name: body.name,
      protocol: "openai-compatible",
      encryptedApiKey: encrypted,
      keyHint,
      baseUrl: body.baseUrl,
      model: body.model,
      visionModel: body.visionModel || null,
      imageModel: body.imageModel || null,
      videoModel: body.videoModel || null,
      capabilities,
      enabled: body.enabled ?? true,
      priority: body.priority ?? 1,
      lastTestStatus: "success",
    });

    // Real health observation from the real test request.
    recordSuccess(saved.id, Date.now() - testStart);

    await recordAudit({
      userId: user.id,
      action: "provider.custom_added",
      category: "providers",
      ip,
      details: {
        providerId: saved.id,
        name: saved.name,
        capabilities,
        baseUrl: saved.baseUrl,
        latencyMs: Date.now() - testStart,
      },
    });

    const statuses = await listCustomProviderStatuses({ userId: user.id });
    const status = statuses.find((p) => p.id === saved.id);
    return json({ provider: status }, { status: 201 });
  } catch (e) {
    return serverError(e);
  }
}
