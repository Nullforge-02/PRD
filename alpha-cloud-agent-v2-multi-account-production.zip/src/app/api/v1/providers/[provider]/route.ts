// POST /api/v1/providers/[provider]   — save (add/update) a dashboard credential
// DELETE /api/v1/providers/[provider] — remove a dashboard credential
//
// Security:
//   - requireAuth (session + CSRF same-origin enforcement)
//   - The API key is encrypted (AES-256-GCM, per-key random IV) BEFORE it is
//     stored in D1 and is NEVER echoed back in any response.
//   - Omitting apiKey on update PRESERVES the existing encrypted key.
//   - Audit events record the provider and what changed — never key material.
//   - The environment credential (e.g. OPENAI_API_KEY) remains the fallback
//     when no dashboard credential exists (and is never exposed here).

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, json, notFound, serverError } from "@/server/http";
import { isProviderId, PROVIDER_IDS } from "@/server/ai/registry";
import { listProviders } from "@/server/ai";
import { encryptApiKey, CredentialSecretMissingError } from "@/server/ai/credentials";
import {
  findCredential,
  insertCredential,
  updateCredential,
  deleteCredential,
} from "@/server/repos/provider-credentials";
import { recordAudit } from "@/server/repos/system";
import { getClientIp } from "@/server/http";

export const dynamic = "force-dynamic";

// Minimum length sanity floor. Real provider keys are longer, but the actual
// validator is Test Connection against the live provider — the local dev Z.ai
// credential, for example, is a short token.
const MIN_API_KEY_LENGTH = 4;

const bodySchema = z.object({
  apiKey: z.string().min(MIN_API_KEY_LENGTH).max(512).optional(),
  enabled: z.boolean().optional(),
  model: z.string().trim().max(120).nullable().optional(),
  visionModel: z.string().trim().max(120).nullable().optional(),
  baseUrl: z.string().trim().max(300).nullable().optional(),
});

/**
 * Validate an optional base URL. Returns:
 *   undefined → field absent (preserve on update)
 *   null      → explicitly cleared (or invalid → badRequest upstream)
 *   string    → a valid http(s) URL
 */
function parseBaseUrl(value: string | null | undefined): { ok: true; value: string | null | undefined } | { ok: false } {
  if (value === undefined) return { ok: true, value: undefined };
  if (value === null || value === "") return { ok: true, value: null };
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" && url.protocol !== "http:") return { ok: false };
    return { ok: true, value };
  } catch {
    return { ok: false };
  }
}

function normalizeModel(value: string | null | undefined): string | null | undefined {
  if (value === undefined) return undefined;
  if (value === null || value === "") return null;
  return value;
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ provider: string }> },
) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { user } = guard.ctx;
    const ip = getClientIp(req);

    const { provider } = await params;
    if (!isProviderId(provider)) {
      return notFound(`Unknown provider. Supported: ${PROVIDER_IDS.join(", ")}`);
    }

    const parsed = bodySchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) {
      return badRequest(`Invalid provider settings (apiKey must be ${MIN_API_KEY_LENGTH}-512 characters)`);
    }
    const body = parsed.data;

    const baseUrl = parseBaseUrl(body.baseUrl);
    if (!baseUrl.ok) {
      return badRequest("Base URL must be a valid http(s) URL (or empty)");
    }
    const model = normalizeModel(body.model);
    const visionModel = normalizeModel(body.visionModel);

    const existing = await findCredential(user.id, provider);

    // A brand-new credential requires a key; an update may omit it (preserve).
    if (!existing && !body.apiKey) {
      return badRequest("An API key is required to add a provider credential");
    }

    let encrypted: string | undefined;
    let keyHint: string | undefined;
    if (body.apiKey) {
      try {
        ({ encrypted, keyHint } = await encryptApiKey(body.apiKey));
      } catch (e) {
        if (e instanceof CredentialSecretMissingError) {
          return json({ error: e.message }, { status: 503 });
        }
        throw e;
      }
    }

    let saved;
    if (existing) {
      saved = await updateCredential(user.id, provider, {
        ...(encrypted !== undefined ? { encryptedApiKey: encrypted, keyHint } : {}),
        enabled: body.enabled ?? undefined,
        baseUrl: baseUrl.value,
        model,
        visionModel,
      });
    } else {
      if (!encrypted || keyHint === undefined) {
        // Unreachable given the !existing && !body.apiKey guard — fail loudly.
        return badRequest("An API key is required to add a provider credential");
      }
      saved = await insertCredential({
        userId: user.id,
        provider,
        encryptedApiKey: encrypted,
        keyHint,
        baseUrl: baseUrl.value ?? null,
        model: model ?? null,
        visionModel: visionModel ?? null,
        enabled: body.enabled ?? true,
      });
    }

    // Audit WITHOUT the key — only what changed.
    await recordAudit({
      userId: user.id,
      action: existing ? "provider.credential_updated" : "provider.credential_added",
      category: "providers",
      ip,
      details: {
        provider,
        keyChanged: Boolean(body.apiKey),
        enabled: saved?.enabled ?? body.enabled ?? true,
      },
    });

    const providers = await listProviders({ userId: user.id });
    const status = providers.find((p) => p.id === provider);
    return json({ provider: status }, { status: existing ? 200 : 201 });
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ provider: string }> },
) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { user } = guard.ctx;
    const ip = getClientIp(req);

    const { provider } = await params;
    if (!isProviderId(provider)) {
      return notFound(`Unknown provider. Supported: ${PROVIDER_IDS.join(", ")}`);
    }

    const deleted = await deleteCredential(user.id, provider);
    if (!deleted) {
      return notFound("No dashboard credential is stored for this provider");
    }

    await recordAudit({
      userId: user.id,
      action: "provider.credential_removed",
      category: "providers",
      ip,
      details: { provider },
    });

    const providers = await listProviders({ userId: user.id });
    const status = providers.find((p) => p.id === provider);
    return json({ provider: status });
  } catch (e) {
    return serverError(e);
  }
}
