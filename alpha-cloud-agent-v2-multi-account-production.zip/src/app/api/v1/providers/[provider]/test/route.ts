// POST /api/v1/providers/[provider]/test — REAL connection test.
//
// Makes an actual server-side request to the provider using the RESOLVED
// credential (dashboard key first, environment fallback):
//   - a minimal chat completion ("Reply with the single word: ok")
//   - measures real wall-clock latency
//   - records the real health observation (success/failure) per provider
//   - stores last_tested_at / last_test_status in D1 (never the key)
//   - audits provider.test_succeeded / provider.test_failed
//
// NOTHING is simulated: success is only reported when the provider actually
// answers. Failure responses are SANITIZED (category-mapped fixed messages) —
// raw upstream response bodies never reach the client, and the API key is
// never echoed in any form.

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { badRequest, json, notFound, serverError } from "@/server/http";
import { isProviderId, PROVIDER_IDS, getRegistry, buildProviderInstance } from "@/server/ai/registry";
import { recordSuccess, recordFailure } from "@/server/ai/health";
import { inferCategory, safeCategoryMessage, type ErrorCategory } from "@/server/ai/errors";
import { decryptApiKey, CredentialSecretMissingError } from "@/server/ai/credentials";
import { findCredential, recordTestResult } from "@/server/repos/provider-credentials";
import { recordAudit } from "@/server/repos/system";
import { getClientIp } from "@/server/http";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ provider: string }> },
) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { user } = guard.ctx;
    const ip = getClientIp(req);

    const { provider } = await params;
    if (!isProviderId(provider)) {
      return notFound(`Unknown provider. Supported: ${PROVIDER_IDS.join(", ")}`);
    }

    // Resolve the credential: dashboard row first, environment fallback.
    const row = await findCredential(user.id, provider);
    const registry = await getRegistry();
    const entry = registry.find((r) => r.provider.id === provider);
    if (!entry) return notFound("Unknown provider");

    let instance;
    let usingDashboardKey = false;
    if (row) {
      if (!row.enabled) {
        return json({
          success: false,
          provider,
          error: "Provider is disabled — enable it before testing",
        });
      }
      try {
        // Decrypt ONLY now (test time), use once, discard.
        const apiKey = await decryptApiKey(row.encryptedApiKey);
        instance = await buildProviderInstance(provider, {
          apiKey,
          baseUrl: row.baseUrl,
          model: row.model,
          visionModel: row.visionModel,
        });
        usingDashboardKey = true;
      } catch (e) {
        if (e instanceof CredentialSecretMissingError) {
          return json({ success: false, provider, error: e.message }, { status: 503 });
        }
        recordFailure(provider, "configuration", e instanceof Error ? e.message : String(e));
        await recordTestResult(user.id, provider, "failed");
        await recordAudit({
          userId: user.id,
          action: "provider.test_failed",
          category: "providers",
          ip,
          details: { provider, category: "configuration" },
        });
        return json({
          success: false,
          provider,
          error:
            "The stored key could not be decrypted — AI_CREDENTIALS_SECRET may have " +
            "changed. Remove and re-add the key.",
        });
      }
    } else if (await entry.provider.isConfigured()) {
      instance = entry.provider; // environment credential
    } else {
      return badRequest("No credential is configured for this provider");
    }

    // REAL request — a minimal chat completion against the live provider.
    const start = Date.now();
    try {
      const latency = await instance.ping();
      const wallClock = latency || Date.now() - start;
      recordSuccess(provider, wallClock);
      if (row) await recordTestResult(user.id, provider, "success");
      await recordAudit({
        userId: user.id,
        action: "provider.test_succeeded",
        category: "providers",
        ip,
        details: { provider, latencyMs: wallClock, source: usingDashboardKey ? "dashboard" : "environment" },
      });
      return json({ success: true, provider, latencyMs: wallClock });
    } catch (e) {
      const category: ErrorCategory = inferCategory(e);
      const wallClock = Date.now() - start;
      recordFailure(provider, category, e instanceof Error ? e.message : String(e));
      if (row) await recordTestResult(user.id, provider, "failed");
      await recordAudit({
        userId: user.id,
        action: "provider.test_failed",
        category: "providers",
        ip,
        details: { provider, category, latencyMs: wallClock },
      });
      // SANITIZED failure — fixed category message, never the raw body.
      return json({ success: false, provider, error: safeCategoryMessage(category) });
    }
  } catch (e) {
    return serverError(e);
  }
}
