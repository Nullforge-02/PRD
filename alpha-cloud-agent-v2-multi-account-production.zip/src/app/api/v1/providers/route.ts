// GET  /api/v1/providers — provider registry + dashboard credential status
//                         (built-ins) AND the user's custom providers.
//
// Reports every provider honestly: configured/enabled/status/model/capabilities
// from REAL observations only. NEVER includes API keys, tokens, secrets,
// encrypted ciphertexts or authorization headers — keys appear ONLY as a
// masked form (••••••••••••<last-4>); environment keys are never echoed at all.
//
// Response shape (additive — `custom` is new, `providers` unchanged):
//   { providers: ProviderStatus[], custom: CustomProviderStatus[], primary: {…}|null }

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { json, serverError } from "@/server/http";
import { listProviders, listCustomProviderStatuses, getPrimaryChatProvider } from "@/server/ai";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const routing = { userId: guard.ctx.user.id };
    const [providers, custom, primary] = await Promise.all([
      listProviders(routing),
      listCustomProviderStatuses(routing),
      getPrimaryChatProvider(routing),
    ]);
    return json({ providers, custom, primary });
  } catch (e) {
    return serverError(e);
  }
}
