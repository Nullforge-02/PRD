// PATCH  /api/v1/memory/[id]
// DELETE /api/v1/memory/[id]

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, json, notFound, serverError } from "@/server/http";
import { deleteMemory, findMemory, updateMemory } from "@/server/repos/memories";
import { recordAudit } from "@/server/repos/system";
import { MEMORY_CATEGORIES } from "@/server/constants";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  category: z.enum(MEMORY_CATEGORIES).optional(),
  content: z.string().min(1).max(2000).optional(),
  confidence: z.number().min(0).max(1).optional(),
  pinned: z.boolean().optional(),
});

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { id } = await ctx.params;

    const parsed = patchSchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return badRequest("Invalid patch body");

    const memory = await updateMemory(id, guard.ctx.user.id, parsed.data);
    if (!memory) return notFound("Memory not found");
    return json({ memory });
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { id } = await ctx.params;

    const memory = await findMemory(id, guard.ctx.user.id);
    if (!memory) return notFound("Memory not found");
    await deleteMemory(id, guard.ctx.user.id);
    void recordAudit({
      userId: guard.ctx.user.id,
      action: "memory.deleted",
      category: "memory",
      details: { memoryId: id },
    });
    return json({ ok: true });
  } catch (e) {
    return serverError(e);
  }
}
