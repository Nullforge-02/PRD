// GET  /api/v1/memory — list memories (?category= &q=)
// POST /api/v1/memory — create a memory

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, json, serverError } from "@/server/http";
import { createMemory, listMemories } from "@/server/repos/memories";
import { recordAudit } from "@/server/repos/system";
import { MEMORY_CATEGORIES } from "@/server/constants";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const params = new URL(req.url).searchParams;
    const memories = await listMemories(guard.ctx.user.id, {
      category: params.get("category") ?? undefined,
      query: params.get("q") ?? undefined,
    });
    return json({ memories, categories: MEMORY_CATEGORIES });
  } catch (e) {
    return serverError(e);
  }
}

const createSchema = z.object({
  category: z.enum(MEMORY_CATEGORIES),
  content: z.string().min(1).max(2000),
  confidence: z.number().min(0).max(1).optional(),
  pinned: z.boolean().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;

    const parsed = createSchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return badRequest("Category and content are required");

    const memory = await createMemory(guard.ctx.user.id, {
      ...parsed.data,
      source: "manual",
    });
    void recordAudit({
      userId: guard.ctx.user.id,
      action: "memory.created",
      category: "memory",
      details: { memoryId: memory.id },
    });
    return json({ memory }, { status: 201 });
  } catch (e) {
    return serverError(e);
  }
}
