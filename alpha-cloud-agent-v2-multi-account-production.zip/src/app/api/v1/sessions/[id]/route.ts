// DELETE /api/v1/sessions/[id] — revoke a session (logout that device).

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { badRequest, json, notFound, serverError } from "@/server/http";
import { revokeSession } from "@/server/repos/sessions";
import { listActiveSessions } from "@/server/repos/sessions";
import { recordAudit } from "@/server/repos/system";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function DELETE(req: NextRequest, ctx: Ctx) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { id } = await ctx.params;

    if (!id || id === "undefined") return badRequest("Session id is required");

    // Only allow revoking the user's own sessions.
    const own = await listActiveSessions(guard.ctx.user.id);
    if (!own.some((s) => s.id === id)) {
      return notFound("Session not found");
    }

    await revokeSession(id);
    void recordAudit({
      userId: guard.ctx.user.id,
      action: "security.session_revoked",
      category: "security",
      details: { sessionId: id },
    });
    return json({ ok: true });
  } catch (e) {
    return serverError(e);
  }
}
