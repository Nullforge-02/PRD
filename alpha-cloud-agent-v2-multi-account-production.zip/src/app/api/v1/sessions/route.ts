// GET /api/v1/sessions — list active sessions for the current user.

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { json, serverError } from "@/server/http";
import { listActiveSessions } from "@/server/repos/sessions";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req, { allowLocked: true });
    if (!guard.ok) return guard.response;
    const sessions = await listActiveSessions(guard.ctx.user.id);
    return json({
      sessions: sessions.map((s) => ({
        id: s.id,
        userAgent: s.userAgent,
        ip: s.ip,
        createdAt: s.createdAt,
        lastSeenAt: s.lastSeenAt,
        expiresAt: s.expiresAt,
        locked: s.lockedAt !== null,
        current: s.id === guard.ctx.session.id,
      })),
    });
  } catch (e) {
    return serverError(e);
  }
}
