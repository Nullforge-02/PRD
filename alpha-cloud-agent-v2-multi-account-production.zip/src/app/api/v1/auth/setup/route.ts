// POST /api/v1/auth/setup — first-run owner account creation.
// Only available while NO user exists. After that, it returns 409 forever.

import { NextRequest } from "next/server";
import { z } from "zod";
import { isSameOrigin, setup } from "@/server/auth";
import { badRequest, json, serverError } from "@/server/http";

export const dynamic = "force-dynamic";

const bodySchema = z.object({
  email: z.string().email().max(200),
  name: z.string().min(1).max(80),
  password: z.string().min(8).max(200),
});

export async function POST(req: NextRequest) {
  try {
    if (!isSameOrigin(req)) {
      return json({ error: "Cross-origin request rejected" }, { status: 403 });
    }
    const parsed = bodySchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) {
      return badRequest(
        parsed.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; "),
      );
    }

    const result = await setup(req, parsed.data.email, parsed.data.name, parsed.data.password);
    if (!result.ok) {
      return json({ error: result.error }, { status: result.status });
    }
    return json(
      { user: { id: result.user.id, email: result.user.email, name: result.user.name } },
      { status: 201, headers: { "Set-Cookie": result.cookie } },
    );
  } catch (e) {
    return serverError(e);
  }
}
