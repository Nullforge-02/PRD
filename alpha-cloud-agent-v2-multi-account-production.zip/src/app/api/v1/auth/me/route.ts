// GET /api/v1/auth/me — current user + session info.

import { NextRequest } from "next/server";
import { publicUser } from "@/server/auth";
import { requireAuth } from "@/server/guard";
import { json, serverError } from "@/server/http";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req, { allowLocked: true });
    if (!guard.ok) return guard.response;
    const { user, session } = guard.ctx;
    return json({
      user: publicUser(user),
      session: {
        id: session.id,
        createdAt: session.createdAt,
        expiresAt: session.expiresAt,
        locked: session.lockedAt !== null,
      },
    });
  } catch (e) {
    return serverError(e);
  }
}
