// POST /api/v1/auth/lock — soft-lock the current session (password to unlock).

import { NextRequest } from "next/server";
import { lockCurrentSession } from "@/server/auth";
import { requireAuth } from "@/server/guard";
import { json, serverError } from "@/server/http";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req, { allowLocked: true });
    if (!guard.ok) return guard.response;
    await lockCurrentSession(req, guard.ctx);
    return json({ ok: true, locked: true });
  } catch (e) {
    return serverError(e);
  }
}
