// POST /api/v1/auth/password — change password (revokes all other sessions).

import { NextRequest } from "next/server";
import { z } from "zod";
import { changePassword } from "@/server/auth";
import { requireAuth } from "@/server/guard";
import { badRequest, json, serverError } from "@/server/http";

export const dynamic = "force-dynamic";

const bodySchema = z.object({
  currentPassword: z.string().min(1).max(200),
  newPassword: z.string().min(8).max(200),
});

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;

    const parsed = bodySchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) {
      return badRequest(
        "Current password and a new password (min 8 chars) are required",
      );
    }

    const ok = await changePassword(
      req,
      guard.ctx,
      parsed.data.currentPassword,
      parsed.data.newPassword,
    );
    if (!ok) {
      return json({ error: "Current password is incorrect" }, { status: 401 });
    }
    return json({ ok: true });
  } catch (e) {
    return serverError(e);
  }
}
