// POST /api/v1/auth/logout — revokes the server-side session.

import { NextRequest } from "next/server";
import { buildClearCookie, getAuthContext, isSameOrigin, logout } from "@/server/auth";
import { json, serverError, unauthorized } from "@/server/http";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    if (!isSameOrigin(req)) {
      return new Response("Cross-origin request rejected", { status: 403 });
    }
    const ctx = await getAuthContext(req);
    if (!ctx) {
      // Still clear the cookie even if the session is already gone.
      return json({ ok: true }, { headers: { "Set-Cookie": buildClearCookie(req) } });
    }
    await logout(req, ctx);
    return json({ ok: true }, { headers: { "Set-Cookie": buildClearCookie(req) } });
  } catch (e) {
    return serverError(e);
  }
}
