// GET /api/v1/auth/status
// Public endpoint the shell polls: is setup needed, are we signed in, is the
// session locked. Never returns sensitive data.

import { NextRequest } from "next/server";
import { getAuthContext, publicUser, sessionIsLocked } from "@/server/auth";
import { json } from "@/server/http";
import { countUsers } from "@/server/repos/users";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const [userCount, ctx] = await Promise.all([countUsers(), getAuthContext(req)]);
  return json({
    setupNeeded: userCount === 0,
    authenticated: !!ctx,
    locked: ctx ? sessionIsLocked(ctx.session) : false,
    user: ctx ? publicUser(ctx.user) : null,
  });
}
