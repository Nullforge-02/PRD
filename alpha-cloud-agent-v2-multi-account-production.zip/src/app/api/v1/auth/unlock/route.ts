// POST /api/v1/auth/unlock — verify account password to unlock the session.

import { NextRequest } from "next/server";
import { z } from "zod";
import { unlockCurrentSession } from "@/server/auth";
import { requireAuth } from "@/server/guard";
import { badRequest, json, serverError } from "@/server/http";

export const dynamic = "force-dynamic";

const bodySchema = z.object({ password: z.string().min(1).max(200) });

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req, { allowLocked: true });
    if (!guard.ok) return guard.response;

    const parsed = bodySchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return badRequest("Password is required");

    const ok = await unlockCurrentSession(req, guard.ctx, parsed.data.password);
    if (!ok) {
      return json({ error: "Incorrect password" }, { status: 401 });
    }
    return json({ ok: true, locked: false });
  } catch (e) {
    return serverError(e);
  }
}
