// POST /api/v1/auth/login — real password verification.

import { NextRequest } from "next/server";
import { z } from "zod";
import { isSameOrigin, login } from "@/server/auth";
import { badRequest, json, serverError } from "@/server/http";

export const dynamic = "force-dynamic";

const bodySchema = z.object({
  email: z.string().email().max(200),
  password: z.string().min(1).max(200),
});

export async function POST(req: NextRequest) {
  try {
    if (!isSameOrigin(req)) {
      return json({ error: "Cross-origin request rejected" }, { status: 403 });
    }
    const parsed = bodySchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) {
      return badRequest("Email and password are required");
    }

    const result = await login(req, parsed.data.email, parsed.data.password);
    if (!result.ok) {
      return json({ error: result.error }, { status: result.status });
    }
    return json(
      { user: { id: result.user.id, email: result.user.email, name: result.user.name } },
      { headers: { "Set-Cookie": result.cookie } },
    );
  } catch (e) {
    return serverError(e);
  }
}
