// GET    /api/v1/files/[id] — download/stream the file (from R2)
// DELETE /api/v1/files/[id] — delete from R2 + D1

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { json, notFound, serverError } from "@/server/http";
import { deleteFile, findFile } from "@/server/repos/files";
import { recordAudit } from "@/server/repos/system";
import { contentDisposition, deleteObject, getObject } from "@/server/storage";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(req: NextRequest, ctx: Ctx) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { id } = await ctx.params;

    const file = await findFile(id, guard.ctx.user.id);
    if (!file) return notFound("File not found");

    // Metadata-only variant
    if (new URL(req.url).searchParams.get("meta") === "1") {
      return json({ file });
    }

    const object = await getObject(file.r2Key);
    if (!object) return notFound("Object missing from storage");

    const download = new URL(req.url).searchParams.get("download") === "1";
    return new Response(object.body, {
      headers: {
        "Content-Type": object.httpMetadata?.contentType ?? file.mimeType,
        "Content-Length": String(object.size),
        "Content-Disposition": contentDisposition(file.filename, download),
        "Cache-Control": "private, max-age=3600",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { id } = await ctx.params;

    const file = await findFile(id, guard.ctx.user.id);
    if (!file) return notFound("File not found");

    await deleteObject(file.r2Key);
    await deleteFile(id, guard.ctx.user.id);
    void recordAudit({
      userId: guard.ctx.user.id,
      action: "files.deleted",
      category: "files",
      details: { fileId: id, filename: file.filename },
    });
    return json({ ok: true });
  } catch (e) {
    return serverError(e);
  }
}
