// GET  /api/v1/files — list file metadata
// POST /api/v1/files — multipart upload (bytes → R2, metadata → D1)

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { badRequest, json, serverError } from "@/server/http";
import { createFile, listFiles } from "@/server/repos/files";
import { recordAudit } from "@/server/repos/system";
import {
  MAX_UPLOAD_BYTES,
  buildR2Key,
  isAllowedMime,
  putObject,
  sanitizeFilename,
} from "@/server/storage";
import { ProviderNotConfiguredError } from "@/server/ai/types";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const params = new URL(req.url).searchParams;
    const sourceParam = params.get("source");
    const files = await listFiles(guard.ctx.user.id, {
      source: sourceParam === "generated" || sourceParam === "upload" ? sourceParam : undefined,
      query: params.get("q") ?? undefined,
    });
    return json({ files });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { user } = guard.ctx;

    const form = await req.formData().catch(() => null);
    const file = form?.get("file");
    if (!form || !(file instanceof File)) {
      return badRequest("Multipart form with a 'file' field is required");
    }

    if (file.size > MAX_UPLOAD_BYTES) {
      return badRequest(`File exceeds the ${Math.round(MAX_UPLOAD_BYTES / 1024 / 1024)} MB limit`);
    }
    const mime = (file.type || "application/octet-stream").toLowerCase();
    if (!isAllowedMime(mime)) {
      return badRequest(`Files of type ${mime} are not allowed`);
    }

    const filename = sanitizeFilename(file.name || "file");
    const r2Key = buildR2Key(user.id, filename, "upload");
    const bytes = new Uint8Array(await file.arrayBuffer());

    await putObject(r2Key, bytes, mime);
    const record = await createFile({
      userId: user.id,
      filename,
      mimeType: mime,
      size: bytes.length,
      r2Key,
      source: "upload",
    });

    void recordAudit({
      userId: user.id,
      action: "files.uploaded",
      category: "files",
      details: { fileId: record.id, filename, size: bytes.length },
    });

    return json({ file: record }, { status: 201 });
  } catch (e) {
    if (e instanceof ProviderNotConfiguredError) {
      return json({ error: e.message }, { status: 503 });
    }
    return serverError(e);
  }
}
