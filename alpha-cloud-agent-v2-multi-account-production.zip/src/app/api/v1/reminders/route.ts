// GET  /api/v1/reminders
// POST /api/v1/reminders

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, json, serverError } from "@/server/http";
import { createReminder, listReminders } from "@/server/repos/reminders";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const doneParam = new URL(req.url).searchParams.get("done");
    const reminders = await listReminders(guard.ctx.user.id, {
      done: doneParam === "0" ? false : doneParam === "1" ? true : undefined,
    });
    return json({ reminders });
  } catch (e) {
    return serverError(e);
  }
}

const createSchema = z.object({
  title: z.string().min(1).max(300),
  note: z.string().max(2000).optional(),
  dueAt: z.number().int().positive().nullable().optional(),
  priority: z.enum(["low", "normal", "high"]).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;

    const parsed = createSchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return badRequest("Title is required");

    const reminder = await createReminder(guard.ctx.user.id, parsed.data);
    return json({ reminder }, { status: 201 });
  } catch (e) {
    return serverError(e);
  }
}
