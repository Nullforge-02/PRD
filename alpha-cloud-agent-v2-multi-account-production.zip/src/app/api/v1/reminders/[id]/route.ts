// PATCH  /api/v1/reminders/[id]
// DELETE /api/v1/reminders/[id]

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, json, notFound, serverError } from "@/server/http";
import { deleteReminder, findReminder, updateReminder } from "@/server/repos/reminders";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  title: z.string().min(1).max(300).optional(),
  note: z.string().max(2000).nullable().optional(),
  dueAt: z.number().int().positive().nullable().optional(),
  priority: z.enum(["low", "normal", "high"]).optional(),
  done: z.boolean().optional(),
});

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { id } = await ctx.params;

    const parsed = patchSchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return badRequest("Invalid patch body");

    const reminder = await updateReminder(id, guard.ctx.user.id, parsed.data);
    if (!reminder) return notFound("Reminder not found");
    return json({ reminder });
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { id } = await ctx.params;

    const reminder = await findReminder(id, guard.ctx.user.id);
    if (!reminder) return notFound("Reminder not found");
    await deleteReminder(id, guard.ctx.user.id);
    return json({ ok: true });
  } catch (e) {
    return serverError(e);
  }
}
