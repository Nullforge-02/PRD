// GET /api/v1/search?q= — unified search across real user data.

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { badRequest, json, serverError } from "@/server/http";
import { listConversations } from "@/server/repos/conversations";
import { listNotes } from "@/server/repos/notes";
import { listMemories } from "@/server/repos/memories";
import { listFiles } from "@/server/repos/files";

export const dynamic = "force-dynamic";

const LIMIT = 15;

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;

    const q = new URL(req.url).searchParams.get("q")?.trim();
    if (!q) return badRequest("Query parameter 'q' is required");

    const userId = guard.ctx.user.id;
    // Run real LIKE searches across domains in parallel.
    const [conversations, notes, memories, files] = await Promise.all([
      listConversations(userId, { includeArchived: true }).then((rows) =>
        rows.filter((c) => c.title.toLowerCase().includes(q.toLowerCase())).slice(0, LIMIT),
      ),
      listNotes(userId, { query: q }).then((rows) => rows.slice(0, LIMIT)),
      listMemories(userId, { query: q }).then((rows) => rows.slice(0, LIMIT)),
      listFiles(userId, { query: q }).then((rows) => rows.slice(0, LIMIT)),
    ]);

    return json({
      query: q,
      conversations,
      notes,
      memories,
      files,
      total: conversations.length + notes.length + memories.length + files.length,
    });
  } catch (e) {
    return serverError(e);
  }
}
