// GET  /api/v1/notes — list (optionally filtered by ?q=)
// POST /api/v1/notes — create

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, json, serverError } from "@/server/http";
import { createNote, listNotes } from "@/server/repos/notes";
import { recordAudit } from "@/server/repos/system";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const query = new URL(req.url).searchParams.get("q") ?? undefined;
    const notes = await listNotes(guard.ctx.user.id, { query });
    return json({ notes });
  } catch (e) {
    return serverError(e);
  }
}

const createSchema = z.object({
  title: z.string().min(1).max(300),
  content: z.string().max(100_000).optional(),
  pinned: z.boolean().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;

    const parsed = createSchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return badRequest("Title is required");

    const note = await createNote(guard.ctx.user.id, parsed.data);
    void recordAudit({
      userId: guard.ctx.user.id,
      action: "notes.created",
      category: "notes",
      details: { noteId: note.id },
    });
    return json({ note }, { status: 201 });
  } catch (e) {
    return serverError(e);
  }
}
