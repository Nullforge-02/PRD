// GET    /api/v1/notes/[id]
// PATCH  /api/v1/notes/[id]
// DELETE /api/v1/notes/[id]

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, json, notFound, serverError } from "@/server/http";
import { deleteNote, findNote, updateNote } from "@/server/repos/notes";
import { recordAudit } from "@/server/repos/system";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(req: NextRequest, ctx: Ctx) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { id } = await ctx.params;
    const note = await findNote(id, guard.ctx.user.id);
    if (!note) return notFound("Note not found");
    return json({ note });
  } catch (e) {
    return serverError(e);
  }
}

const patchSchema = z.object({
  title: z.string().min(1).max(300).optional(),
  content: z.string().max(100_000).optional(),
  pinned: z.boolean().optional(),
});

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { id } = await ctx.params;

    const parsed = patchSchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return badRequest("Invalid patch body");

    const note = await updateNote(id, guard.ctx.user.id, parsed.data);
    if (!note) return notFound("Note not found");
    return json({ note });
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { id } = await ctx.params;

    const note = await findNote(id, guard.ctx.user.id);
    if (!note) return notFound("Note not found");
    await deleteNote(id, guard.ctx.user.id);
    void recordAudit({
      userId: guard.ctx.user.id,
      action: "notes.deleted",
      category: "notes",
      details: { noteId: id },
    });
    return json({ ok: true });
  } catch (e) {
    return serverError(e);
  }
}
