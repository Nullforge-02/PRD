// PATCH  /api/v1/calendar/[id]
// DELETE /api/v1/calendar/[id]

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, json, notFound, serverError } from "@/server/http";
import { deleteEvent, findEvent, updateEvent } from "@/server/repos/calendar";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  title: z.string().min(1).max(300).optional(),
  location: z.string().max(300).nullable().optional(),
  startAt: z.number().int().positive().optional(),
  endAt: z.number().int().positive().nullable().optional(),
  attendees: z.array(z.string().email()).max(50).optional(),
});

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { id } = await ctx.params;

    const parsed = patchSchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return badRequest("Invalid patch body");

    const event = await updateEvent(id, guard.ctx.user.id, parsed.data);
    if (!event) return notFound("Event not found");
    return json({ event });
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { id } = await ctx.params;

    const event = await findEvent(id, guard.ctx.user.id);
    if (!event) return notFound("Event not found");
    await deleteEvent(id, guard.ctx.user.id);
    return json({ ok: true });
  } catch (e) {
    return serverError(e);
  }
}
