// GET  /api/v1/calendar
// POST /api/v1/calendar

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, json, serverError } from "@/server/http";
import { createEvent, listEvents } from "@/server/repos/calendar";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const params = new URL(req.url).searchParams;
    const fromParam = params.get("from");
    const toParam = params.get("to");
    const events = await listEvents(guard.ctx.user.id, {
      from: fromParam ? Number(fromParam) : undefined,
      to: toParam ? Number(toParam) : undefined,
    });
    return json({ events });
  } catch (e) {
    return serverError(e);
  }
}

const createSchema = z.object({
  title: z.string().min(1).max(300),
  location: z.string().max(300).nullable().optional(),
  startAt: z.number().int().positive(),
  endAt: z.number().int().positive().nullable().optional(),
  attendees: z.array(z.string().email()).max(50).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;

    const parsed = createSchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) {
      return badRequest("Title and startAt (epoch ms) are required");
    }

    const event = await createEvent(guard.ctx.user.id, parsed.data);
    return json({ event }, { status: 201 });
  } catch (e) {
    return serverError(e);
  }
}
