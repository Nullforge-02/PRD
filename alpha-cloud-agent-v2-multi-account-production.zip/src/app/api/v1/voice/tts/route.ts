// POST /api/v1/voice/tts — real text-to-speech via the AI router.
// Routed to the highest-priority provider that declares the tts capability.

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, json, serverError } from "@/server/http";
import { withFallback } from "@/server/ai";
import { ProviderNotConfiguredError } from "@/server/ai/types";
import {
  AllProvidersUnavailableError,
  CapabilityUnavailableError,
  ProviderError,
} from "@/server/ai/errors";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const bodySchema = z.object({
  text: z.string().min(1).max(1000),
  voice: z.string().max(50).optional(),
  speed: z.number().min(0.5).max(2).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;

    const parsed = bodySchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return badRequest("Text is required (max 1000 chars)");

    const { base64, mime } = await withFallback(
      "tts",
      (p) => {
        if (!p.tts) throw new Error("Provider does not support text-to-speech");
        return p.tts(parsed.data.text, parsed.data.voice, parsed.data.speed);
      },
      { userId: guard.ctx.user.id },
    );
    return json({ audio: `data:${mime};base64,${base64}`, mime });
  } catch (e) {
    if (e instanceof CapabilityUnavailableError) {
      return json({ error: e.message }, { status: 501 });
    }
    if (
      e instanceof AllProvidersUnavailableError ||
      e instanceof ProviderNotConfiguredError ||
      e instanceof ProviderError
    ) {
      return json({ error: e.message }, { status: 503 });
    }
    return serverError(e);
  }
}
