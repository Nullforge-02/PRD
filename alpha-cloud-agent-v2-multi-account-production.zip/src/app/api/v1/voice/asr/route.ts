// POST /api/v1/voice/asr — real speech-to-text via the AI router.
// Routed to the highest-priority provider that declares the asr capability.
// Accepts multipart/form-data with a 'file' field.

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { badRequest, json, serverError } from "@/server/http";
import { withFallback } from "@/server/ai";
import { ProviderNotConfiguredError } from "@/server/ai/types";
import {
  AllProvidersUnavailableError,
  CapabilityUnavailableError,
  ProviderError,
} from "@/server/ai/errors";
import { MAX_UPLOAD_BYTES } from "@/server/storage";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;

    const form = await req.formData().catch(() => null);
    const file = form?.get("file");
    if (!form || !(file instanceof File)) {
      return badRequest("Multipart form with a 'file' field is required");
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      return badRequest("Audio file exceeds the size limit");
    }

    const buffer = new Uint8Array(await file.arrayBuffer());
    // base64 encode (chunked to avoid call-stack limits)
    let binary = "";
    const chunk = 0x8000;
    for (let i = 0; i < buffer.length; i += chunk) {
      binary += String.fromCharCode(...buffer.subarray(i, i + chunk));
    }
    const base64 = btoa(binary);

    const { text } = await withFallback(
      "asr",
      (p) => {
        if (!p.asr) throw new Error("Provider does not support speech-to-text");
        return p.asr(base64, file.type || "audio/wav");
      },
      { userId: guard.ctx.user.id },
    );
    return json({ text });
  } catch (e) {
    if (e instanceof CapabilityUnavailableError) {
      return json({ error: e.message }, { status: 501 });
    }
    if (
      e instanceof AllProvidersUnavailableError ||
      e instanceof ProviderNotConfiguredError ||
      e instanceof ProviderError
    ) {
      return json({ error: e.message }, { status: 503 });
    }
    return serverError(e);
  }
}
