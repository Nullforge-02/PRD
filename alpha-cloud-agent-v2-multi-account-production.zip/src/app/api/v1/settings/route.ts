// GET   /api/v1/settings — read user settings (merged with defaults)
// PATCH /api/v1/settings — update whitelisted keys

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, json, serverError } from "@/server/http";
import { getSettings, upsertSettings } from "@/server/repos/system";
import { settingKeySchema } from "@/server/constants";

export const dynamic = "force-dynamic";

const DEFAULTS: Record<string, string> = {
  chat_model: "glm-4.6",
  voice: "tongtong",
  voice_speed: "1.0",
  memory_enabled: "true",
  memory_auto_learn: "false",
  notifications: "true",
  density: "comfortable",
  accent: "amber",
};

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const stored = await getSettings(guard.ctx.user.id);
    return json({ settings: { ...DEFAULTS, ...stored } });
  } catch (e) {
    return serverError(e);
  }
}

const patchSchema = z.record(z.string(), z.string().max(500));

export async function PATCH(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;

    const parsed = patchSchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return badRequest("Body must be a flat key/value object");

    // Whitelist keys — reject anything unknown.
    const entries = Object.entries(parsed.data);
    for (const [key] of entries) {
      if (!settingKeySchema.safeParse(key).success) {
        return badRequest(`Unknown setting key: ${key}`);
      }
    }

    await upsertSettings(guard.ctx.user.id, parsed.data);
    const stored = await getSettings(guard.ctx.user.id);
    return json({ settings: { ...DEFAULTS, ...stored } });
  } catch (e) {
    return serverError(e);
  }
}
