// POST /api/v1/media/generate — real AI image generation → R2 + D1 + job row.

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, json, serverError } from "@/server/http";
import { withFallback } from "@/server/ai";
import { ProviderNotConfiguredError } from "@/server/ai/types";
import {
  AllProvidersUnavailableError,
  CapabilityUnavailableError,
  ProviderError,
} from "@/server/ai/errors";
import { imageSizeSchema } from "@/server/constants";
import { createFile } from "@/server/repos/files";
import { createJob, finishJob, recordAudit } from "@/server/repos/system";
import { buildR2Key, putObject } from "@/server/storage";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

const bodySchema = z.object({
  prompt: z.string().min(1).max(2000),
  size: imageSizeSchema.optional(),
});

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { user } = guard.ctx;

    const parsed = bodySchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return badRequest("A prompt is required");
    const { prompt, size } = parsed.data;

    const job = await createJob({
      userId: user.id,
      kind: "image_generation",
      payload: { prompt, size: size ?? "1024x1024" },
    });

    try {
      // Routed: only providers with the imageGeneration capability are eligible.
      const { base64, mime } = await withFallback(
        "imageGeneration",
        (p) => {
          if (!p.generateImage) throw new Error("Provider does not support image generation");
          return p.generateImage(prompt, size ?? "1024x1024");
        },
        { userId: user.id },
      );
      const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
      const ext = mime === "image/jpeg" ? "jpg" : mime === "image/webp" ? "webp" : mime === "image/gif" ? "gif" : "png";
      const r2Key = buildR2Key(user.id, `generated.${ext}`, "generated");
      await putObject(r2Key, bytes, mime);
      const file = await createFile({
        userId: user.id,
        filename: `generated-${Date.now()}.${ext}`,
        mimeType: mime,
        size: bytes.length,
        r2Key,
        source: "generated",
      });
      await finishJob(job.id, { result: { fileId: file.id } });
      void recordAudit({
        userId: user.id,
        action: "media.generated",
        category: "media",
        details: { fileId: file.id, prompt: prompt.slice(0, 100) },
      });
      return json({ file }, { status: 201 });
    } catch (e) {
      await finishJob(job.id, { error: e instanceof Error ? e.message : String(e) });
      throw e;
    }
  } catch (e) {
    if (e instanceof CapabilityUnavailableError) {
      return json({ error: e.message }, { status: 501 });
    }
    if (
      e instanceof AllProvidersUnavailableError ||
      e instanceof ProviderNotConfiguredError ||
      e instanceof ProviderError
    ) {
      return json({ error: e.message }, { status: 503 });
    }
    return serverError(e);
  }
}
