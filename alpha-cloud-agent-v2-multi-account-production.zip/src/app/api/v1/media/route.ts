// GET /api/v1/media — list AI-generated media (files with source=generated)

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { json, serverError } from "@/server/http";
import { listFiles } from "@/server/repos/files";
import { listRecentJobs } from "@/server/repos/system";
import { IMAGE_SIZES } from "@/server/constants";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const media = await listFiles(guard.ctx.user.id, { source: "generated" });
    const jobs = await listRecentJobs(guard.ctx.user.id, 10);
    return json({ media, jobs, sizes: IMAGE_SIZES });
  } catch (e) {
    return serverError(e);
  }
}
