// GET  /api/v1/conversations — list conversations
// POST /api/v1/conversations — create a new (empty) conversation

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { json, serverError } from "@/server/http";
import { createConversation, listConversations } from "@/server/repos/conversations";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const includeArchived =
      new URL(req.url).searchParams.get("archived") === "1";
    const conversations = await listConversations(guard.ctx.user.id, { includeArchived });
    return json({ conversations });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const conversation = await createConversation(guard.ctx.user.id);
    return json({ conversation });
  } catch (e) {
    return serverError(e);
  }
}
