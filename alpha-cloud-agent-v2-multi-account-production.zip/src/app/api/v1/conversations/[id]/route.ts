// GET    /api/v1/conversations/[id] — conversation + messages + summary
// PATCH  /api/v1/conversations/[id] — rename / pin / archive
// DELETE /api/v1/conversations/[id] — delete conversation and messages

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, json, notFound, serverError } from "@/server/http";
import {
  deleteConversation,
  findConversation,
  listMessages,
  updateConversation,
} from "@/server/repos/conversations";
import { getSummary } from "@/server/repos/conversation-summaries";
import { recordAudit } from "@/server/repos/system";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(req: NextRequest, ctx: Ctx) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { id } = await ctx.params;

    const conversation = await findConversation(id, guard.ctx.user.id);
    if (!conversation) return notFound("Conversation not found");
    const messages = await listMessages(conversation.id);

    // Rolling summary transparency (metadata + text only — never tokens).
    const summaryRow = await getSummary(conversation.id, guard.ctx.user.id);
    const summary = summaryRow
      ? {
          text: summaryRow.summary,
          coveredMessages: summaryRow.lastMessageCount,
          version: summaryRow.version,
          updatedAt: summaryRow.updatedAt,
        }
      : null;

    return json({ conversation, messages, summary });
  } catch (e) {
    return serverError(e);
  }
}

const patchSchema = z.object({
  title: z.string().min(1).max(200).optional(),
  pinned: z.boolean().optional(),
  archived: z.boolean().optional(),
});

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { id } = await ctx.params;

    const parsed = patchSchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return badRequest("Invalid patch body");

    const conversation = await updateConversation(id, guard.ctx.user.id, parsed.data);
    if (!conversation) return notFound("Conversation not found");
    return json({ conversation });
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const { id } = await ctx.params;

    const conversation = await findConversation(id, guard.ctx.user.id);
    if (!conversation) return notFound("Conversation not found");
    await deleteConversation(id, guard.ctx.user.id);
    void recordAudit({
      userId: guard.ctx.user.id,
      action: "chat.conversation_deleted",
      category: "chat",
      details: { conversationId: id },
    });
    return json({ ok: true });
  } catch (e) {
    return serverError(e);
  }
}
