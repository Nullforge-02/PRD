// GET /api/v1/gmail/messages/[id]?accountId= — fetch one message (format=full,
// body extracted server-side).
//
// Account resolution (multi-account): explicit accountId → the user's default
// Google account; ambiguous selection → 400. Same guards as /gmail/messages
// (503 not configured / 503 not connected / 401 reauthorization_needed). The
// message id is validated before it is used in an upstream URL.

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { badRequest, json, serverError } from "@/server/http";
import { getGmailMessage, googleConfigured } from "@/server/integrations/google";
import { resolveGoogleAccount } from "@/server/integrations/account-resolver";
import { accountResolutionResponse } from "@/server/integrations/account-resolver";
import { integrationErrorResponse } from "@/server/integrations/errors";

export const dynamic = "force-dynamic";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const userId = guard.ctx.user.id;

    if (!(await googleConfigured())) {
      return json(
        {
          error:
            "Gmail OAuth is not configured — set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET as Worker secrets",
        },
        { status: 503 },
      );
    }

    const accountId = new URL(req.url).searchParams.get("accountId");
    const pick = await resolveGoogleAccount(userId, { accountId });
    if (!pick) {
      return json(
        { error: "Gmail is not connected — connect your Google account first." },
        { status: 503 },
      );
    }

    const { id } = await params;
    if (!/^[A-Za-z0-9_-]{1,100}$/.test(id)) {
      return badRequest("Invalid message id");
    }

    const message = await getGmailMessage(userId, pick.account, id);
    return json({ message });
  } catch (e) {
    const mapped = accountResolutionResponse(e) ?? integrationErrorResponse(e);
    if (mapped) return mapped;
    return serverError(e);
  }
}
