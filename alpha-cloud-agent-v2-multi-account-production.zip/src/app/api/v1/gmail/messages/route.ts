// GET /api/v1/gmail/messages?q=&max=&accountId= — search a Gmail account.
//
// Account resolution (multi-account, centralized in account-resolver.ts):
//   • accountId  → that exact Google account
//   • (none)     → the user's explicit DEFAULT Google account
//   • ambiguous (several connected, none selected) → 400 asking to select
//
// Guards (in order):
//   501/503  Gmail OAuth not configured in the environment (Worker secrets)
//   503      No Google account connected (no D1 row)
//   400      Account selection invalid/ambiguous
//   401      { code: "reauthorization_needed" } — reconnect required
//
// `max` is clamped to 1–25 (default 10). The Gmail access token is resolved
// server-side (refreshed when expired) and never leaves this request. The
// response names the account that was used (identity only — never tokens).

import { NextRequest } from "next/server";
import { requireAuth } from "@/server/guard";
import { json, serverError } from "@/server/http";
import { googleConfigured, listGmailMessages } from "@/server/integrations/google";
import { resolveGoogleAccount } from "@/server/integrations/account-resolver";
import { accountResolutionResponse } from "@/server/integrations/account-resolver";
import { integrationErrorResponse } from "@/server/integrations/errors";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const userId = guard.ctx.user.id;

    if (!(await googleConfigured())) {
      return json(
        {
          error:
            "Gmail OAuth is not configured — set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET as Worker secrets",
        },
        { status: 503 },
      );
    }

    const url = new URL(req.url);
    const accountId = url.searchParams.get("accountId");
    const pick = await resolveGoogleAccount(userId, { accountId });
    if (!pick) {
      return json(
        { error: "Gmail is not connected — connect your Google account first." },
        { status: 503 },
      );
    }

    const q = url.searchParams.get("q") ?? "";
    const maxRaw = parseInt(url.searchParams.get("max") ?? "", 10);
    const max = Number.isFinite(maxRaw) ? Math.min(Math.max(maxRaw, 1), 25) : 10;

    const messages = await listGmailMessages(userId, pick.account, q, max);
    return json({
      messages,
      account: { id: pick.account.id, accountName: pick.account.accountName },
      resolution: pick.resolution,
    });
  } catch (e) {
    const mapped = accountResolutionResponse(e) ?? integrationErrorResponse(e);
    if (mapped) return mapped;
    return serverError(e);
  }
}
