// POST /api/v1/gmail/send — send an email through a connected Gmail account.
//
// Sending email is a CONSEQUENTIAL action:
//   • `confirmed: true` is REQUIRED — a request without it is rejected with
//     400 even when every other field is valid.
//   • Rate limited: 10 sends per minute per user (429).
//
// MULTI-ACCOUNT: an optional `accountId` selects the sending Google account
// (the compose dialog names the exact account so the user never sends from
// the wrong one). Without accountId the user's explicit DEFAULT account is
// used; an ambiguous selection (several accounts, none chosen) is a 400 —
// never a silent guess.
//
// Guards: 503 Gmail OAuth not configured / 503 not connected / 400 invalid or
// ambiguous account / 401 reauthorization_needed. The MIME message is built
// and base64url-encoded server-side; the audit event records recipient +
// subject + the sending ACCOUNT IDENTITY but NEVER the body, and tokens never
// appear anywhere.
//
// CSRF: enforced by requireAuth (same-origin Origin/Referer on POST).

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireAuth } from "@/server/guard";
import { badRequest, getClientIp, json, serverError } from "@/server/http";
import { rateLimit } from "@/server/auth";
import { googleConfigured, sendGmail } from "@/server/integrations/google";
import { resolveGoogleAccount } from "@/server/integrations/account-resolver";
import { accountResolutionResponse } from "@/server/integrations/account-resolver";
import { integrationErrorResponse } from "@/server/integrations/errors";
import { recordAudit } from "@/server/repos/system";

export const dynamic = "force-dynamic";

const EMAIL_RE = /^[A-Za-z0-9._%+'-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+$/;

const bodySchema = z.object({
  to: z.string().trim().min(3).max(320).regex(EMAIL_RE),
  subject: z
    .string()
    .min(1)
    .max(200)
    .refine((s) => !/[\r\n\u0000-\u001F]/.test(s), "Subject must be a single line"),
  body: z.string().min(1).max(50_000),
  confirmed: z.literal(true),
  accountId: z.string().trim().max(64).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const guard = await requireAuth(req);
    if (!guard.ok) return guard.response;
    const userId = guard.ctx.user.id;
    const ip = getClientIp(req);

    if (!rateLimit(`gmail-send:${userId}`, 10, 60_000)) {
      return json(
        { error: "Too many send requests — wait a moment and try again." },
        { status: 429 },
      );
    }

    const raw = await req.json().catch(() => null);
    const parsed = bodySchema.safeParse(raw);
    if (!parsed.success) {
      const confirmed =
        typeof raw === "object" &&
        raw !== null &&
        (raw as { confirmed?: unknown }).confirmed === true;
      if (!confirmed) {
        return badRequest("Explicit confirmation (confirmed: true) is required to send email");
      }
      return badRequest(
        "Invalid send request — provide a valid recipient email, a single-line subject " +
          "(1–200 chars) and a body (1–50,000 chars)",
      );
    }
    const { to, subject, body, accountId } = parsed.data;

    if (!(await googleConfigured())) {
      return json(
        {
          error:
            "Gmail OAuth is not configured — set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET as Worker secrets",
        },
        { status: 503 },
      );
    }

    const pick = await resolveGoogleAccount(userId, { accountId });
    if (!pick) {
      return json(
        { error: "Gmail is not connected — connect your Google account first." },
        { status: 503 },
      );
    }

    await sendGmail(userId, pick.account, to, subject, body);

    // Audit: recipient + subject + account identity — NEVER the body, NEVER tokens.
    await recordAudit({
      userId,
      action: "gmail.sent",
      category: "integrations",
      ip,
      details: { to, subject, accountId: pick.account.id, accountName: pick.account.accountName },
    });

    return json({
      ok: true,
      account: { id: pick.account.id, accountName: pick.account.accountName },
    });
  } catch (e) {
    const mapped = accountResolutionResponse(e) ?? integrationErrorResponse(e);
    if (mapped) return mapped;
    return serverError(e);
  }
}
