// ALPHA — GitHub OAuth integration — REAL web-server flow
//
// Cloudflare-Workers compatible: native fetch only. No Node APIs, no SDKs.
//
// Security:
//   • Client credentials live ONLY in Worker secrets
//     (GITHUB_CLIENT_ID / GITHUB_CLIENT_SECRET).
//   • Access tokens exist in plaintext only inside a single request. They are
//     AES-256-GCM encrypted before storage (repos/connected-accounts) and are
//     NEVER logged, echoed in responses, or written to the audit log.
//   • Upstream errors are reduced to fixed messages + the upstream HTTP
//     status — response bodies (which can reflect request parameters) are
//     discarded.
//
// GitHub OAuth access tokens do not expire, so there is no refresh flow —
// a connection stays valid until the user revokes it (disconnect revokes
// best-effort via the application/token endpoint) or deletes it on GitHub.

import { NextRequest } from "next/server";
import { getEnv } from "../env";
import {
  decryptOAuthToken,
  markAccountNeedsReauthorization,
} from "../repos/connected-accounts";
import type { ConnectedAccount } from "../repos/connected-accounts";
import type { GitHubIssue, GitHubRepo } from "@/lib/api";
import { ReauthorizationNeededError, UpstreamIntegrationError } from "./errors";

const GITHUB_AUTHORIZE_URL = "https://github.com/login/oauth/authorize";
const GITHUB_TOKEN_URL = "https://github.com/login/oauth/access_token";
const GITHUB_API_BASE = "https://api.github.com";

export const GITHUB_SCOPES = "read:user repo";

const REAUTH_MESSAGE = "GitHub needs reauthorization — reconnect your GitHub account.";

// ============================================================
// Client credentials (Worker secrets)
// ============================================================

interface GithubClientCredentials {
  clientId: string;
  clientSecret: string;
}

async function githubClientCredentials(): Promise<GithubClientCredentials | null> {
  const env = await getEnv();
  const clientId = env.GITHUB_CLIENT_ID || "";
  const clientSecret = env.GITHUB_CLIENT_SECRET || "";
  if (!clientId || !clientSecret) return null;
  return { clientId, clientSecret };
}

/** True when GitHub OAuth client credentials are present in the environment. */
export async function githubConfigured(): Promise<boolean> {
  return (await githubClientCredentials()) !== null;
}

/** Base origin for OAuth redirect URIs (OAUTH_CALLBACK_ORIGIN override → request origin). */
export async function callbackOrigin(req: NextRequest): Promise<string> {
  const env = await getEnv();
  if (env.OAUTH_CALLBACK_ORIGIN) {
    return env.OAUTH_CALLBACK_ORIGIN.replace(/\/+$/, "");
  }
  return new URL(req.url).origin;
}

function githubCallbackUrl(origin: string): string {
  return `${origin}/api/v1/integrations/github/callback`;
}

// ============================================================
// OAuth web-server flow
// ============================================================

/** Build the GitHub authorize URL (scope "read:user repo"). */
export async function buildGithubAuthUrl(req: NextRequest, state: string): Promise<string> {
  const creds = await githubClientCredentials();
  if (!creds) {
    throw new UpstreamIntegrationError("GitHub OAuth is not configured", 0);
  }
  const origin = await callbackOrigin(req);
  const params = new URLSearchParams({
    client_id: creds.clientId,
    redirect_uri: githubCallbackUrl(origin),
    scope: GITHUB_SCOPES,
    state,
  });
  // Percent-encode spaces (%20, not "+") — the scope value is "read:user repo".
  return `${GITHUB_AUTHORIZE_URL}?${params.toString().replace(/\+/g, "%20")}`;
}

export interface GithubTokenSet {
  accessToken: string;
  scope: string | null;
}

/** Exchange an authorization code for a token (POST, JSON-accepting). */
export async function exchangeGithubCode(req: NextRequest, code: string): Promise<GithubTokenSet> {
  const creds = await githubClientCredentials();
  if (!creds) {
    throw new UpstreamIntegrationError("GitHub OAuth is not configured", 0);
  }
  const origin = await callbackOrigin(req);
  const res = await fetch(GITHUB_TOKEN_URL, {
    method: "POST",
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({
      client_id: creds.clientId,
      client_secret: creds.clientSecret,
      code,
      redirect_uri: githubCallbackUrl(origin),
    }),
  });
  const data = (await res.json().catch(() => null)) as {
    access_token?: string;
    scope?: string;
  } | null;
  if (!res.ok || !data?.access_token) {
    // GitHub sometimes answers 200 with an error body — both paths land here.
    throw new UpstreamIntegrationError(
      `GitHub token exchange failed (HTTP ${res.status})`,
      res.status,
    );
  }
  return { accessToken: data.access_token, scope: data.scope ?? null };
}

export interface GithubUser {
  id: string;
  login: string;
  name: string | null;
  avatarUrl: string | null;
}

/** Fetch the GitHub account identity. */
export async function fetchGithubUser(accessToken: string): Promise<GithubUser> {
  const res = await fetch(`${GITHUB_API_BASE}/user`, {
    headers: githubHeaders(accessToken),
  });
  if (!res.ok) {
    throw new UpstreamIntegrationError(
      `GitHub user request failed (HTTP ${res.status})`,
      res.status,
    );
  }
  const data = (await res.json().catch(() => null)) as {
    id?: number;
    login?: string;
    name?: string;
    avatar_url?: string;
  } | null;
  if (typeof data?.id !== "number" || !data.login) {
    throw new UpstreamIntegrationError("GitHub user request returned no account id", res.status);
  }
  return {
    id: String(data.id),
    login: data.login,
    name: data.name ?? null,
    avatarUrl: data.avatar_url ?? null,
  };
}

/**
 * A usable GitHub token for ONE resolved account. GitHub tokens do not expire
 * — there is no refresh flow; this decrypts the stored token and refuses when
 * the account is marked needs_reauthorization or undecryptable (only THAT
 * account is marked — other connected GitHub accounts are untouched).
 * Callers receive the account from the account resolver
 * (integrations/account-resolver.ts) — never a "latest account" guess.
 */
export async function getValidGithubToken(
  userId: string,
  account: ConnectedAccount,
): Promise<string> {
  if (account.status === "needs_reauthorization") {
    throw new ReauthorizationNeededError(REAUTH_MESSAGE);
  }
  try {
    return await decryptOAuthToken(account.encryptedAccessToken);
  } catch {
    // e.g. AI_CREDENTIALS_SECRET rotated since the account was connected.
    await markAccountNeedsReauthorization(userId, account.id);
    throw new ReauthorizationNeededError(REAUTH_MESSAGE);
  }
}

/**
 * Revoke a GitHub OAuth token (best-effort, never throws). Uses the
 * application/token endpoint with HTTP Basic auth — client credentials are
 * read from the environment at call time and never appear in logs.
 */
export async function revokeGithubToken(token: string): Promise<void> {
  try {
    const env = await getEnv();
    const clientId = env.GITHUB_CLIENT_ID;
    const clientSecret = env.GITHUB_CLIENT_SECRET;
    if (!clientId || !clientSecret) return;
    const basic = btoa(`${clientId}:${clientSecret}`);
    await fetch(`${GITHUB_API_BASE}/applications/${encodeURIComponent(clientId)}/token`, {
      method: "DELETE",
      headers: {
        Authorization: `Basic ${basic}`,
        Accept: "application/vnd.github+json",
        "Content-Type": "application/json",
        "User-Agent": "Alpha-Cloud-Agent",
      },
      body: JSON.stringify({ access_token: token }),
    });
  } catch {
    // Best effort — network/HTTP failures never block a local disconnect.
  }
}

// ============================================================
// GitHub REST API helpers
// ============================================================

function githubHeaders(accessToken: string): Record<string, string> {
  return {
    Authorization: `Bearer ${accessToken}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    // GitHub requires a User-Agent on every API call.
    "User-Agent": "Alpha-Cloud-Agent",
  };
}

interface GithubRepoApi {
  id?: number;
  name?: string;
  full_name?: string;
  owner?: { login?: string };
  description?: string | null;
  private?: boolean;
  html_url?: string;
  stargazers_count?: number;
  forks_count?: number;
  open_issues_count?: number;
  language?: string | null;
  updated_at?: string;
}

interface GithubIssueApi {
  id?: number;
  number?: number;
  title?: string;
  state?: string;
  user?: { login?: string };
  html_url?: string;
  pull_request?: unknown;
  created_at?: string;
  updated_at?: string;
}

/** List the connected account's repositories (most recently pushed first). */
export async function listGithubRepos(accessToken: string): Promise<GitHubRepo[]> {
  const res = await fetch(`${GITHUB_API_BASE}/user/repos?sort=pushed&per_page=50`, {
    headers: githubHeaders(accessToken),
  });
  if (!res.ok) {
    throw new UpstreamIntegrationError(
      `GitHub request failed (HTTP ${res.status})`,
      res.status,
    );
  }
  const data = (await res.json().catch(() => null)) as GithubRepoApi[] | null;
  if (!Array.isArray(data)) return [];
  return data.map((r) => ({
    id: r.id ?? 0,
    name: r.name ?? "",
    fullName: r.full_name ?? "",
    owner: r.owner?.login ?? "",
    description: r.description ?? null,
    private: r.private === true,
    url: r.html_url ?? "",
    stars: r.stargazers_count ?? 0,
    forks: r.forks_count ?? 0,
    issues: r.open_issues_count ?? 0,
    language: r.language ?? null,
    updatedAt: r.updated_at ?? null,
  }));
}

/** List open issues (and pull requests — GitHub's issues API includes PRs)
 *  for one repository. `owner`/`repo` must be pre-sanized by the caller. */
export async function listGithubIssues(
  accessToken: string,
  owner: string,
  repo: string,
): Promise<GitHubIssue[]> {
  const res = await fetch(
    `${GITHUB_API_BASE}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/issues` +
      `?state=open&per_page=30`,
    { headers: githubHeaders(accessToken) },
  );
  if (!res.ok) {
    if (res.status === 404) {
      throw new UpstreamIntegrationError("Repository or issues not found", 404);
    }
    throw new UpstreamIntegrationError(
      `GitHub request failed (HTTP ${res.status})`,
      res.status,
    );
  }
  const data = (await res.json().catch(() => null)) as GithubIssueApi[] | null;
  if (!Array.isArray(data)) return [];
  return data.map((i) => ({
    id: i.id ?? 0,
    number: i.number ?? 0,
    title: i.title ?? "",
    state: i.state ?? "open",
    user: i.user?.login ?? "",
    url: i.html_url ?? "",
    isPullRequest: i.pull_request != null,
    createdAt: i.created_at ?? null,
    updatedAt: i.updated_at ?? null,
  }));
}
