// ALPHA — Google (Gmail) OAuth integration — REAL web-server flow
//
// Cloudflare-Workers compatible: native fetch + Web Crypto + TextEncoder /
// btoa / atob only. No Node APIs, no filesystem, no SDKs.
//
// Security:
//   • Client credentials live ONLY in Worker secrets (GOOGLE_CLIENT_ID /
//     GOOGLE_CLIENT_SECRET; GMAIL_CLIENT_ID / GMAIL_CLIENT_SECRET are
//     accepted as legacy aliases).
//   • Access/refresh tokens exist in plaintext only inside a single request.
//     They are AES-256-GCM encrypted before storage (repos/connected-accounts,
//     dedicated HKDF purpose) and are NEVER logged, echoed in responses, or
//     written to the audit log.
//   • Upstream errors are reduced to fixed messages + the upstream HTTP
//     status — response bodies (which can reflect request parameters) are
//     discarded.

import { NextRequest } from "next/server";
import { getEnv } from "../env";
import type { ConnectedAccount } from "../repos/connected-accounts";
import {
  decryptOAuthToken,
  encryptOAuthToken,
  markAccountNeedsReauthorization,
  updateAccountTokens,
} from "../repos/connected-accounts";
import type { GmailMessageDetail, GmailMessageSummary } from "@/lib/api";
import { ReauthorizationNeededError, UpstreamIntegrationError } from "./errors";

const GOOGLE_AUTH_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth";
const GOOGLE_TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token";
const GOOGLE_REVOKE_ENDPOINT = "https://oauth2.googleapis.com/revoke";
const GOOGLE_USERINFO_ENDPOINT = "https://openidconnect.googleapis.com/v1/userinfo";
const GMAIL_API_BASE = "https://gmail.googleapis.com/gmail/v1/users/me";

export const GOOGLE_SCOPES =
  "openid email profile https://www.googleapis.com/auth/gmail.readonly " +
  "https://www.googleapis.com/auth/gmail.send";

const REAUTH_MESSAGE = "Gmail needs reauthorization — reconnect your Google account.";

// ============================================================
// Client credentials (Worker secrets)
// ============================================================

interface GoogleClientCredentials {
  clientId: string;
  clientSecret: string;
}

async function googleClientCredentials(): Promise<GoogleClientCredentials | null> {
  const env = await getEnv();
  // GOOGLE_* is canonical; GMAIL_* is the legacy alias kept for compatibility.
  const clientId = env.GOOGLE_CLIENT_ID || env.GMAIL_CLIENT_ID || "";
  const clientSecret = env.GOOGLE_CLIENT_SECRET || env.GMAIL_CLIENT_SECRET || "";
  if (!clientId || !clientSecret) return null;
  return { clientId, clientSecret };
}

/** True when Google OAuth client credentials are present in the environment. */
export async function googleConfigured(): Promise<boolean> {
  return (await googleClientCredentials()) !== null;
}

/** Base origin for OAuth redirect URIs (OAUTH_CALLBACK_ORIGIN override → request origin). */
export async function callbackOrigin(req: NextRequest): Promise<string> {
  const env = await getEnv();
  if (env.OAUTH_CALLBACK_ORIGIN) {
    return env.OAUTH_CALLBACK_ORIGIN.replace(/\/+$/, "");
  }
  return new URL(req.url).origin;
}

function googleCallbackUrl(origin: string): string {
  return `${origin}/api/v1/integrations/google/callback`;
}

// ============================================================
// OAuth web-server flow
// ============================================================

/**
 * Build the Google consent-screen URL. access_type=offline +
 * `prompt=select_account consent` so that:
 *   • a refresh token is issued (including on re-connect of an account that
 *     already granted Alpha access), and
 *   • Google ALWAYS shows the account chooser — the user can connect a
 *     DIFFERENT Google account (multi-account support) instead of being
 *     silently logged into the account the browser session favors.
 * include_granted_scopes keeps previously granted scopes without listing them.
 */
export async function buildGoogleAuthUrl(req: NextRequest, state: string): Promise<string> {
  const creds = await googleClientCredentials();
  if (!creds) {
    throw new UpstreamIntegrationError("Google OAuth is not configured", 0);
  }
  const origin = await callbackOrigin(req);
  const params = new URLSearchParams({
    client_id: creds.clientId,
    redirect_uri: googleCallbackUrl(origin),
    response_type: "code",
    scope: GOOGLE_SCOPES,
    state,
    access_type: "offline",
    prompt: "select_account consent",
    include_granted_scopes: "true",
  });
  // Percent-encode spaces (%20, not "+") for strict OAuth compliance.
  return `${GOOGLE_AUTH_ENDPOINT}?${params.toString().replace(/\+/g, "%20")}`;
}

export interface GoogleTokenSet {
  accessToken: string;
  refreshToken: string | null;
  /** Seconds until the access token expires. */
  expiresIn: number | null;
  scope: string | null;
}

/** Exchange an authorization code for tokens (authorization_code grant). */
export async function exchangeGoogleCode(req: NextRequest, code: string): Promise<GoogleTokenSet> {
  const creds = await googleClientCredentials();
  if (!creds) {
    throw new UpstreamIntegrationError("Google OAuth is not configured", 0);
  }
  const origin = await callbackOrigin(req);
  const body = new URLSearchParams({
    code,
    client_id: creds.clientId,
    client_secret: creds.clientSecret,
    redirect_uri: googleCallbackUrl(origin),
    grant_type: "authorization_code",
  });
  const res = await fetch(GOOGLE_TOKEN_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: body.toString(),
  });
  if (!res.ok) {
    // Never include the upstream body — it can echo request parameters.
    throw new UpstreamIntegrationError(
      `Google token exchange failed (HTTP ${res.status})`,
      res.status,
    );
  }
  const data = (await res.json().catch(() => null)) as {
    access_token?: string;
    refresh_token?: string;
    expires_in?: number;
    scope?: string;
  } | null;
  if (!data?.access_token) {
    throw new UpstreamIntegrationError(
      "Google token exchange returned no access token",
      res.status,
    );
  }
  return {
    accessToken: data.access_token,
    refreshToken: data.refresh_token ?? null,
    expiresIn: typeof data.expires_in === "number" ? data.expires_in : null,
    scope: data.scope ?? null,
  };
}

/**
 * Refresh the stored access token of ONE account. Persists the newly
 * encrypted tokens to that account row and returns the new access token.
 * When Google rejects the refresh token (invalid_grant etc.) ONLY THIS
 * ACCOUNT is marked needs_reauthorization (multi-account: a failing grant
 * never poisons the user's other Google accounts) and
 * ReauthorizationNeededError is thrown.
 */
export async function refreshGoogleAccessToken(
  userId: string,
  account: ConnectedAccount,
): Promise<string> {
  const creds = await googleClientCredentials();
  if (!creds || !account.encryptedRefreshToken) {
    await markAccountNeedsReauthorization(userId, account.id);
    throw new ReauthorizationNeededError(REAUTH_MESSAGE);
  }
  let refreshToken: string;
  try {
    refreshToken = await decryptOAuthToken(account.encryptedRefreshToken);
  } catch {
    await markAccountNeedsReauthorization(userId, account.id);
    throw new ReauthorizationNeededError(REAUTH_MESSAGE);
  }
  const body = new URLSearchParams({
    refresh_token: refreshToken,
    client_id: creds.clientId,
    client_secret: creds.clientSecret,
    grant_type: "refresh_token",
  });
  const res = await fetch(GOOGLE_TOKEN_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: body.toString(),
  });
  if (!res.ok) {
    // invalid_grant & friends — the refresh token is no longer usable.
    await markAccountNeedsReauthorization(userId, account.id);
    throw new ReauthorizationNeededError(REAUTH_MESSAGE);
  }
  const data = (await res.json().catch(() => null)) as {
    access_token?: string;
    refresh_token?: string;
    expires_in?: number;
  } | null;
  if (!data?.access_token) {
    await markAccountNeedsReauthorization(userId, account.id);
    throw new ReauthorizationNeededError(REAUTH_MESSAGE);
  }
  const accessToken = data.access_token;
  const encryptedAccessToken = await encryptOAuthToken(accessToken);
  const encryptedRefreshToken = data.refresh_token
    ? await encryptOAuthToken(data.refresh_token)
    : null;
  const expiresAt =
    typeof data.expires_in === "number"
      ? new Date(Date.now() + data.expires_in * 1000).toISOString()
      : null;
  await updateAccountTokens(account.id, userId, {
    encryptedAccessToken,
    encryptedRefreshToken,
    expiresAt,
  });
  return accessToken;
}

/**
 * A usable Google access token for ONE resolved account — refreshing the
 * stored token when it is expired (or within 5 minutes of expiring). Throws
 * ReauthorizationNeededError when reconnection is required. Tokens are never
 * logged. Callers receive the account from the account resolver
 * (integrations/account-resolver.ts) — never a "latest account" guess.
 */
export async function getValidGoogleAccessToken(
  userId: string,
  account: ConnectedAccount,
): Promise<string> {
  if (account.status === "needs_reauthorization") {
    throw new ReauthorizationNeededError(REAUTH_MESSAGE);
  }
  let accessToken: string;
  try {
    accessToken = await decryptOAuthToken(account.encryptedAccessToken);
  } catch {
    // e.g. AI_CREDENTIALS_SECRET rotated since the account was connected.
    await markAccountNeedsReauthorization(userId, account.id);
    throw new ReauthorizationNeededError(REAUTH_MESSAGE);
  }
  const expiresAtMs = account.expiresAt ? Date.parse(account.expiresAt) : null;
  const expiring =
    expiresAtMs !== null && Number.isFinite(expiresAtMs)
      ? expiresAtMs - Date.now() < 5 * 60 * 1000
      : false;
  if (expiring) {
    if (!account.encryptedRefreshToken) {
      await markAccountNeedsReauthorization(userId, account.id);
      throw new ReauthorizationNeededError(REAUTH_MESSAGE);
    }
    return refreshGoogleAccessToken(userId, account);
  }
  return accessToken;
}

export interface GoogleUserinfo {
  sub: string;
  email: string | null;
  name: string | null;
  picture: string | null;
}

/** Fetch the Google account identity (openid userinfo endpoint). */
export async function fetchGoogleUserinfo(accessToken: string): Promise<GoogleUserinfo> {
  const res = await fetch(GOOGLE_USERINFO_ENDPOINT, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) {
    throw new UpstreamIntegrationError(
      `Google userinfo request failed (HTTP ${res.status})`,
      res.status,
    );
  }
  const data = (await res.json().catch(() => null)) as {
    sub?: string;
    email?: string;
    name?: string;
    picture?: string;
  } | null;
  if (!data?.sub) {
    throw new UpstreamIntegrationError("Google userinfo returned no account id", res.status);
  }
  return {
    sub: data.sub,
    email: data.email ?? null,
    name: data.name ?? null,
    picture: data.picture ?? null,
  };
}

/** Best-effort token revocation (never throws — used during disconnect). */
export async function revokeGoogleToken(token: string): Promise<void> {
  try {
    await fetch(GOOGLE_REVOKE_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ token }).toString(),
    });
  } catch {
    // Best effort — network/HTTP failures never block a local disconnect.
  }
}

// ============================================================
// Gmail API helpers (all resolve a valid token via getValidGoogleAccessToken)
// ============================================================

interface GmailHeader {
  name?: string;
  value?: string;
}

interface GmailMessagePayload {
  headers?: GmailHeader[];
  mimeType?: string;
  body?: { size?: number; data?: string };
  parts?: GmailMessagePayload[];
}

interface GmailMessage {
  id: string;
  threadId?: string;
  labelIds?: string[];
  snippet?: string;
  payload?: GmailMessagePayload;
}

function gmailHeaders(accessToken: string): Record<string, string> {
  return { Authorization: `Bearer ${accessToken}` };
}

function headerValue(headers: GmailHeader[] | undefined, name: string): string {
  const found = headers?.find((h) => h.name?.toLowerCase() === name.toLowerCase());
  return found?.value ?? "";
}

function toSummary(m: GmailMessage): GmailMessageSummary {
  const headers = m.payload?.headers;
  const rawDate = headerValue(headers, "Date");
  const dateMs = rawDate ? Date.parse(rawDate) : NaN;
  return {
    id: m.id,
    threadId: m.threadId ?? null,
    from: headerValue(headers, "From"),
    to: headerValue(headers, "To"),
    subject: headerValue(headers, "Subject"),
    date: Number.isFinite(dateMs) ? new Date(dateMs).toISOString() : null,
    snippet: m.snippet ?? "",
    unread: (m.labelIds ?? []).includes("UNREAD"),
  };
}

/** Decode a Gmail base64url payload (URL-safe base64) as UTF-8 text. */
function decodeBase64UrlUtf8(data: string): string {
  try {
    const b64 = data.replace(/-/g, "+").replace(/_/g, "/").replace(/=+$/, "");
    const padded = b64 + "=".repeat((4 - (b64.length % 4)) % 4);
    const bin = atob(padded);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder("utf-8").decode(bytes);
  } catch {
    return "";
  }
}

/** UTF-8-safe standard base64 (chunked — safe for large bodies). */
function encodeBase64Utf8(text: string): string {
  const bytes = new TextEncoder().encode(text);
  let bin = "";
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    bin += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  }
  return btoa(bin);
}

/** UTF-8-safe base64url (no padding) — Gmail `raw` message format. */
function encodeBase64UrlUtf8(text: string): string {
  return encodeBase64Utf8(text).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

/** RFC 2047 encode a header value when it contains non-ASCII characters. */
function encodeHeaderValue(value: string): string {
  if (/^[\x20-\x7E]*$/.test(value)) return value;
  return `=?UTF-8?B?${encodeBase64Utf8(value)}?=`;
}

/** Strip tags + decode common entities → readable plain text. */
function htmlToText(html: string): string {
  return html
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/(p|div|tr|li|h[1-6]|blockquote)\s*>/gi, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/gi, " ")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#0?39;/gi, "'")
    .replace(/&#x27;/gi, "'")
    .replace(/&amp;/gi, "&");
}

/** Recursively collect the first text/plain and first text/html body data. */
function collectBodyParts(
  part: GmailMessagePayload | undefined,
  out: { plain: string | null; html: string | null },
): void {
  if (!part) return;
  if (part.mimeType === "text/plain" && part.body?.data && out.plain === null) {
    out.plain = decodeBase64UrlUtf8(part.body.data);
  }
  if (part.mimeType === "text/html" && part.body?.data && out.html === null) {
    out.html = decodeBase64UrlUtf8(part.body.data);
  }
  for (const child of part.parts ?? []) collectBodyParts(child, out);
}

/**
 * Search ONE account's Gmail and map results to summaries. `max` defaults to
 * 10 and is capped at 25. Messages that vanish between the list and the
 * per-message metadata fetch are skipped, not fatal.
 */
export async function listGmailMessages(
  userId: string,
  account: ConnectedAccount,
  q: string,
  max = 10,
): Promise<GmailMessageSummary[]> {
  const accessToken = await getValidGoogleAccessToken(userId, account);
  const limit = Math.min(Math.max(Math.floor(max) || 10, 1), 25);

  const listParams = new URLSearchParams({ maxResults: String(limit) });
  const query = q.trim().slice(0, 512);
  if (query) listParams.set("q", query);
  const listRes = await fetch(`${GMAIL_API_BASE}/messages?${listParams}`, {
    headers: gmailHeaders(accessToken),
  });
  if (!listRes.ok) {
    throw new UpstreamIntegrationError(
      `Gmail request failed (HTTP ${listRes.status})`,
      listRes.status,
    );
  }
  const listData = (await listRes.json().catch(() => null)) as {
    messages?: Array<{ id: string }>;
  } | null;
  const entries = listData?.messages ?? [];
  if (entries.length === 0) return [];

  const metaParams = new URLSearchParams();
  for (const h of ["From", "To", "Subject", "Date"]) metaParams.append("metadataHeaders", h);
  const detailed = await Promise.allSettled(
    entries.map(async (entry): Promise<GmailMessageSummary> => {
      const res = await fetch(
        `${GMAIL_API_BASE}/messages/${encodeURIComponent(entry.id)}?format=metadata&${metaParams}`,
        { headers: gmailHeaders(accessToken) },
      );
      if (!res.ok) {
        throw new UpstreamIntegrationError(
          `Gmail request failed (HTTP ${res.status})`,
          res.status,
        );
      }
      const message = (await res.json()) as GmailMessage;
      return toSummary(message);
    }),
  );
  return detailed
    .filter((r): r is PromiseFulfilledResult<GmailMessageSummary> => r.status === "fulfilled")
    .map((r) => r.value);
}

/** Fetch one message with format=full → GmailMessageDetail. Body extraction
 *  prefers the text/plain part, falls back to tag-stripped text/html, then
 *  the snippet. Bodies are truncated to ~50k characters. */
export async function getGmailMessage(
  userId: string,
  account: ConnectedAccount,
  id: string,
): Promise<GmailMessageDetail> {
  const accessToken = await getValidGoogleAccessToken(userId, account);
  const res = await fetch(
    `${GMAIL_API_BASE}/messages/${encodeURIComponent(id)}?format=full`,
    { headers: gmailHeaders(accessToken) },
  );
  if (!res.ok) {
    if (res.status === 404) {
      throw new UpstreamIntegrationError("Gmail message not found", 404);
    }
    throw new UpstreamIntegrationError(
      `Gmail request failed (HTTP ${res.status})`,
      res.status,
    );
  }
  const message = (await res.json()) as GmailMessage;
  const summary = toSummary(message);
  const extracted: { plain: string | null; html: string | null } = { plain: null, html: null };
  collectBodyParts(message.payload, extracted);
  let body = extracted.plain;
  if (body === null && extracted.html !== null) body = htmlToText(extracted.html);
  if (body === null || body.length === 0) body = summary.snippet;
  return { ...summary, body: body.slice(0, 50_000) };
}

/**
 * Send a plain-text email through ONE account (the resolved selection — the
 * UI's compose confirmation names the exact sending account). Builds a minimal
 * MIME message (To / Subject / Content-Type / MIME-Version), base64url-encodes
 * it UTF-8-safely and posts it to the Gmail send endpoint. Returns the new
 * Gmail message id.
 */
export async function sendGmail(
  userId: string,
  account: ConnectedAccount,
  to: string,
  subject: string,
  body: string,
): Promise<{ id: string }> {
  const accessToken = await getValidGoogleAccessToken(userId, account);
  // Defense in depth: no header injection even if a caller skipped validation.
  const safeTo = to.replace(/[\r\n\u0000]+/g, " ");
  const safeSubject = subject.replace(/[\r\n\u0000]+/g, " ");
  const normalizedBody = body
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n")
    .replace(/\n/g, "\r\n");
  const mime = [
    `To: ${safeTo}`,
    `Subject: ${encodeHeaderValue(safeSubject)}`,
    'Content-Type: text/plain; charset="UTF-8"',
    "MIME-Version: 1.0",
    "",
    normalizedBody,
  ].join("\r\n");
  const res = await fetch(`${GMAIL_API_BASE}/messages/send`, {
    method: "POST",
    headers: { ...gmailHeaders(accessToken), "Content-Type": "application/json" },
    body: JSON.stringify({ raw: encodeBase64UrlUtf8(mime) }),
  });
  if (!res.ok) {
    throw new UpstreamIntegrationError(`Gmail send failed (HTTP ${res.status})`, res.status);
  }
  const data = (await res.json().catch(() => null)) as { id?: string } | null;
  if (!data?.id) {
    throw new UpstreamIntegrationError("Gmail send returned no message id", res.status);
  }
  return { id: data.id };
}
