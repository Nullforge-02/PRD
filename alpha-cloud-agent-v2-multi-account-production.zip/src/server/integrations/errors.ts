// ALPHA — OAuth integration errors (shared by the Google + GitHub modules)
//
// These classes exist so API routes can map integration failures to CLEAN,
// fixed responses:
//   • ReauthorizationNeededError → 401 { error, code: "reauthorization_needed" }
//     (the stored connection can no longer produce a usable token — the user
//     must click Reconnect)
//   • UpstreamIntegrationError → 502 { error } (the provider's API failed)
//
// Security: the messages these errors carry are FIXED strings built by the
// integration modules. Upstream response bodies (which can reflect request
// parameters) are never embedded, and OAuth tokens / client secrets never
// appear in any of them.

import { json } from "../http";

/** A stored connection can no longer produce a usable token — the user must
 *  reconnect (refresh failed/revoked, token undecryptable, or no connection). */
export class ReauthorizationNeededError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ReauthorizationNeededError";
  }
}

/** A call to the provider's API (Google/GitHub) failed. `upstreamStatus` is
 *  the HTTP status received from the provider (0 = network failure); the
 *  message is a fixed sanitized string — never the upstream body. */
export class UpstreamIntegrationError extends Error {
  readonly upstreamStatus: number;

  constructor(message: string, upstreamStatus: number) {
    super(message);
    this.name = "UpstreamIntegrationError";
    this.upstreamStatus = upstreamStatus;
  }
}

/**
 * Map an integration-layer error to a sanitized API response.
 * Returns null when the error is not one of ours — the caller then falls
 * back to serverError() (500) or its own handling.
 */
export function integrationErrorResponse(e: unknown): Response | null {
  if (e instanceof ReauthorizationNeededError) {
    return json(
      { error: e.message, code: "reauthorization_needed" },
      { status: 401 },
    );
  }
  if (e instanceof UpstreamIntegrationError) {
    return json({ error: e.message }, { status: 502 });
  }
  return null;
}
