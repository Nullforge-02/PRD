// ALPHA — centralized connected-account resolver.
//
// THE single boundary for deciding WHICH connected account an operation uses.
// Every Gmail / GitHub route resolves through this module — no route picks
// accounts on its own, so the policy cannot drift between features.
//
// Resolution policy (NEVER "most recently updated"):
//   1. EXPLICIT accountId  → that exact account (must exist + match provider)
//   2. GitHub ROLE request → accounts carrying that role; when several share
//                            the role, the user's default wins, else the
//                            oldest connection (stable, documented)
//   3. No selection        → the user's explicit default account
//                            (is_default = 1)
//   4. No default flagged  → when exactly ONE account exists it is PROMOTED to
//                            default; when several exist the call FAILS with a
//                            clear "select an account" error instead of
//                            silently guessing.
//
// The pure core (`pickAccount`) is a pure function over the account list —
// unit-testable without D1 (see scripts/test-multi-account.ts). The wrappers
// add the D1 reads + last_used_at touch.
//
// Security: this module only ever sees/returns account metadata + ENCRYPTED
// token blobs. It never decrypts and never logs.

import type {
  ConnectedAccount,
  GithubAccountRole,
  OAuthProvider,
} from "../repos/connected-accounts";
import {
  listAccountsByProvider,
  setDefaultAccount,
  touchAccountUsed,
} from "../repos/connected-accounts";

/** The caller must select an account (several connected, none chosen). */
export class AmbiguousAccountError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "AmbiguousAccountError";
  }
}

/** The requested accountId does not exist for this user+provider. */
export class UnknownAccountError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "UnknownAccountError";
  }
}

export interface AccountPick {
  account: ConnectedAccount;
  /** How the account was chosen — surfaced in X-Alpha-Account-Resolution. */
  resolution: "explicit" | "role" | "default" | "single-promoted";
}

function describe(account: ConnectedAccount): string {
  return account.accountName ?? account.id;
}

/**
 * PURE resolution core — no I/O. Given the user's accounts for ONE provider,
 * pick the account per the policy above. Exported for unit tests.
 */
export function pickAccount(
  accounts: ConnectedAccount[],
  provider: OAuthProvider,
  opts: { accountId?: string | null; role?: GithubAccountRole | null } = {},
): AccountPick | null {
  if (accounts.length === 0) return null;

  // 1) Explicit selection always wins (and must match the provider — the
  //    caller filters the list by provider first, so a mismatched id simply
  //    isn't found → UnknownAccountError below).
  if (opts.accountId) {
    const explicit = accounts.find((a) => a.id === opts.accountId);
    if (!explicit) {
      throw new UnknownAccountError(
        `Account not found — it may have been disconnected. Connected accounts: ${accounts
          .map((a) => describe(a))
          .join(", ")}`,
      );
    }
    return { account: explicit, resolution: "explicit" };
  }

  // 2) Role-based selection (GitHub only — Google accounts carry no role).
  if (opts.role && provider === "github") {
    const withRole = accounts.filter(
      (a) => (a.role ?? "general") === opts.role,
    );
    if (withRole.length === 0) {
      throw new AmbiguousAccountError(
        `No GitHub account with role "${opts.role}" is connected. Connected accounts: ${accounts
          .map((a) => `${describe(a)} (${a.role ?? "general"})`)
          .join(", ")}`,
      );
    }
    // Several accounts share the role: the user's default (if it is one of
    // them) wins, else the oldest connection. Never "most recently updated".
    const byDefault = withRole.find((a) => a.isDefault);
    const chosen = byDefault ?? withRole[0];
    return { account: chosen, resolution: "role" };
  }

  // 3) The explicit default account.
  const flagged = accounts.find((a) => a.isDefault);
  if (flagged) return { account: flagged, resolution: "default" };

  // 4) Exactly one account → use (and later promote) it.
  if (accounts.length === 1) {
    return { account: accounts[0], resolution: "single-promoted" };
  }

  // Ambiguous — several accounts, no default, no selection. FAIL LOUDLY.
  throw new AmbiguousAccountError(
    `Several ${provider === "google" ? "Google" : "GitHub"} accounts are connected ` +
      `( ${accounts.map((a) => describe(a)).join(", ")} ) — select which one to use.`,
  );
}

/**
 * Resolve a GOOGLE account for an operation. `accountId` is the optional
 * explicit selection (from the UI account picker / API parameter).
 * Returns null when NO Google account is connected at all.
 */
export async function resolveGoogleAccount(
  userId: string,
  opts: { accountId?: string | null } = {},
): Promise<AccountPick | null> {
  const accounts = await listAccountsByProvider(userId, "google");
  const pick = pickAccount(accounts, "google", opts);
  if (!pick) return null;
  if (pick.resolution === "single-promoted") {
    // Persist the promotion so the invariant "one default per provider" holds.
    await setDefaultAccount(userId, pick.account.id, accounts);
  }
  await touchAccountUsed(userId, pick.account.id);
  return pick;
}

/**
 * Resolve a GITHUB account for an operation, optionally by ROLE
 * ("storage" | "scripts" | "general") or by explicit accountId.
 * Returns null when NO GitHub account is connected at all.
 */
export async function resolveGithubAccount(
  userId: string,
  opts: { accountId?: string | null; role?: GithubAccountRole | null } = {},
): Promise<AccountPick | null> {
  const accounts = await listAccountsByProvider(userId, "github");
  const pick = pickAccount(accounts, "github", opts);
  if (!pick) return null;
  if (pick.resolution === "single-promoted") {
    await setDefaultAccount(userId, pick.account.id, accounts);
  }
  await touchAccountUsed(userId, pick.account.id);
  return pick;
}

/**
 * Map resolver errors to clean API responses. Returns null when the error is
 * not one of ours (caller falls back to its own handling).
 */
export function accountResolutionResponse(e: unknown): Response | null {
  if (e instanceof AmbiguousAccountError || e instanceof UnknownAccountError) {
    const status = e instanceof UnknownAccountError ? 404 : 400;
    return Response.json({ error: e.message }, { status });
  }
  return null;
}
