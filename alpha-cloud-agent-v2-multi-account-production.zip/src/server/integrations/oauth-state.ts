// ALPHA — OAuth state cookie management (Google + GitHub web-server flow)
//
// CSRF protection for the OAuth redirect: before sending the user to the
// provider's authorize URL we set a short-lived HttpOnly cookie containing
// `${provider}:${32 random bytes hex}`. The callback compares it (without
// ever logging it) against the `state` query parameter the provider
// round-trips. The callback ALWAYS clears the cookie (single use).
//
// The cookie value contains only [a-z0-9] plus the ":" separator — valid
// cookie-octets that survive every cookie parser unchanged.

import { NextRequest } from "next/server";
import { isHttps } from "../http";
import type { OAuthProvider } from "../repos/connected-accounts";

export const OAUTH_STATE_COOKIE = "alpha_oauth_state";
const STATE_TTL_SECONDS = 600; // 10 minutes to finish the consent flow

/** `${provider}:${64 hex chars}` — 32 cryptographically random bytes. */
export function generateState(provider: OAuthProvider): string {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  let hex = "";
  for (const b of bytes) hex += b.toString(16).padStart(2, "0");
  return `${provider}:${hex}`;
}

/** Set-Cookie header value for a freshly generated state (HttpOnly, Lax,
 *  Path=/, 10 min, Secure on https requests). */
export function stateCookieHeader(
  provider: OAuthProvider,
  state: string,
  req: NextRequest,
): string {
  if (!state.startsWith(`${provider}:`)) {
    throw new Error("OAuth state/provider mismatch — refusing to set state cookie");
  }
  const secure = isHttps(req) ? "; Secure" : "";
  return `${OAUTH_STATE_COOKIE}=${state}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${STATE_TTL_SECONDS}${secure}`;
}

/** Set-Cookie header value that clears the state cookie. */
export function clearStateCookieHeader(req: NextRequest): string {
  const secure = isHttps(req) ? "; Secure" : "";
  return `${OAUTH_STATE_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure}`;
}

/**
 * Verify the round-tripped `state` parameter against the state cookie.
 *
 * The `state` param the provider echoes back IS the full
 * `${provider}:${64 hex}` value that generateState() produced — the SAME
 * string stored in the cookie. So the check is:
 *   1. stateParam must be present and carry the expected `${provider}:`
 *      prefix (prevents cross-provider replay),
 *   2. stateParam must equal the cookie value (constant-time comparison).
 * The provider prefix must NEVER be prepended again — the callback state
 * already contains it.
 * The values are never logged.
 */
export function verifyState(
  req: NextRequest,
  provider: OAuthProvider,
  stateParam: string,
): boolean {
  if (!stateParam) return false;
  // The round-tripped state already carries the provider prefix.
  if (!stateParam.startsWith(`${provider}:`)) return false;
  const cookieValue = req.cookies.get(OAUTH_STATE_COOKIE)?.value;
  if (!cookieValue) return false;
  // Constant-time comparison of the two full `${provider}:${hex}` values.
  if (cookieValue.length !== stateParam.length) return false;
  let diff = 0;
  for (let i = 0; i < stateParam.length; i++) {
    diff |= stateParam.charCodeAt(i) ^ cookieValue.charCodeAt(i);
  }
  return diff === 0;
}
