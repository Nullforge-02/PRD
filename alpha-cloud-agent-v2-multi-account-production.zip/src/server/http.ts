// ALPHA — HTTP helpers for API routes

import { NextRequest } from "next/server";

export function json(body: unknown, init?: ResponseInit): Response {
  return new Response(JSON.stringify(body), {
    ...init,
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "no-store",
      ...(init?.headers ?? {}),
    },
  });
}

export function badRequest(message: string): Response {
  return json({ error: message }, { status: 400 });
}

export function unauthorized(message = "Not authenticated"): Response {
  return json({ error: message }, { status: 401 });
}

export function forbidden(message = "Forbidden"): Response {
  return json({ error: message }, { status: 403 });
}

export function notFound(message = "Not found"): Response {
  return json({ error: message }, { status: 404 });
}

/** 409 — the request conflicts with existing state (e.g. duplicate name). */
export function conflict(message = "Conflict"): Response {
  return json({ error: message }, { status: 409 });
}

/** 423 — session is soft-locked; unlock requires the account password. */
export function locked(): Response {
  return json(
    { error: "Alpha is locked. Unlock with your password.", code: "locked" },
    { status: 423 },
  );
}

export function serverError(e: unknown): Response {
  console.error("[alpha] api error:", e);
  const message = e instanceof Error ? e.message : "Internal server error";
  return json({ error: message }, { status: 500 });
}

export function getClientIp(req: NextRequest): string | null {
  return (
    req.headers.get("cf-connecting-ip") ??
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    null
  );
}

/** True when the request is an https request (directly or behind the proxy). */
export function isHttps(req: NextRequest): boolean {
  const proto =
    req.headers.get("x-forwarded-proto") ??
    new URL(req.url).protocol.replace(":", "");
  return proto === "https";
}
