// ALPHA — R2 object storage
//
// Production file/media storage is Cloudflare R2 (binding: STORAGE).
// Binary objects live in R2; metadata lives in D1 (files table).
//
// There is intentionally NO local-filesystem fallback for production: the R2
// binding is always present in both local dev (miniflare via
// initOpenNextCloudflareForDev) and on Workers.

import { getEnv } from "./env";

export type R2 = R2Bucket;

export async function getR2(): Promise<R2> {
  const env = await getEnv();
  if (!env.STORAGE) {
    throw new Error("R2 binding 'STORAGE' is not available — check wrangler.jsonc");
  }
  return env.STORAGE;
}

// ============================================================
// Safety limits
// ============================================================

export const MAX_UPLOAD_BYTES = 50 * 1024 * 1024; // 50 MB

/** MIME types that must never be stored (executable payload categories). */
const BLOCKED_MIME_PREFIXES = [
  "application/x-executable",
  "application/x-msdownload",
  "application/x-dos",
  "application/x-sharedlib",
  "application/x-mach-binary",
  "application/x-batch",
  "application/x-sh",
  "application/x-csh",
];

export function isAllowedMime(mime: string): boolean {
  const lower = mime.toLowerCase().split(";")[0].trim();
  if (!lower) return false;
  return !BLOCKED_MIME_PREFIXES.some((p) => lower.startsWith(p));
}

/** Sanitize a user-supplied filename into a safe single path segment. */
export function sanitizeFilename(name: string): string {
  const base = name.split(/[/\\]/).pop() ?? "file";
  const cleaned = base
    .replace(/[\x00-\x1f\x7f]/g, "")
    .replace(/[^a-zA-Z0-9._ -]/g, "_")
    .replace(/^\.+/, "")
    .slice(0, 120)
    .trim();
  return cleaned || "file";
}

/** Build a safe, namespaced object key. */
export function buildR2Key(
  userId: string,
  filename: string,
  source: "upload" | "generated",
): string {
  const safe = sanitizeFilename(filename);
  const unique = crypto.randomUUID().slice(0, 12);
  const folder = source === "generated" ? "generated" : "uploads";
  return `${folder}/${userId}/${unique}-${safe}`;
}

// ============================================================
// Object operations
// ============================================================

export async function putObject(
  key: string,
  data: ArrayBuffer | Uint8Array,
  contentType: string,
): Promise<{ key: string; size: number; etag?: string }> {
  const r2 = await getR2();
  const result = await r2.put(key, data as unknown as BufferSource, {
    httpMetadata: { contentType },
  });
  return { key, size: result.size, etag: result.etag };
}

export async function getObject(key: string) {
  const r2 = await getR2();
  return r2.get(key);
}

export async function headObject(key: string) {
  const r2 = await getR2();
  return r2.head(key);
}

export async function deleteObject(key: string) {
  const r2 = await getR2();
  await r2.delete(key);
}

/** Content-Disposition header value with a safely quoted filename. */
export function contentDisposition(filename: string, download: boolean): string {
  const safe = sanitizeFilename(filename).replace(/["\\]/g, "");
  return `${download ? "attachment" : "inline"}; filename="${safe}"`;
}
