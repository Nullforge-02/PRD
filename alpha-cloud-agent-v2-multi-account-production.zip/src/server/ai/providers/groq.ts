// ALPHA — Groq provider adapter
//
// Environment (fallback when no dashboard credential is stored):
//   GROQ_API_KEY      (required to enable the provider)
//   GROQ_BASE_URL     (optional — default: official Groq endpoint)
//   GROQ_MODEL        (optional — default: llama-3.3-70b-versatile)
//   GROQ_VISION_MODEL (optional — default: llama-4-scout, vision-capable)
//
// Dashboard (Settings → AI Providers) takes PRECEDENCE over the environment.
//
// Capabilities: chat, streaming, toolCalling (JSON protocol), vision.
// NOT implemented (declared false, never claimed): imageGeneration,
// webSearch, tts, asr.

import { getEnv } from "../../env";
import { createOpenAICompatibleProvider } from "./openai-compatible";
import type { AIProvider, ProviderOverrides } from "../types";

const GUIDANCE =
  "Set the GROQ_API_KEY secret (npx wrangler secret put GROQ_API_KEY) or add " +
  "the key in Settings → AI Providers. Optionally GROQ_BASE_URL, GROQ_MODEL " +
  "and GROQ_VISION_MODEL.";

/** Static defaults (also shown as placeholders in the dashboard UI). */
export const GROQ_META = {
  defaultBaseUrl: "https://api.groq.com/openai/v1",
  defaultModel: "llama-3.3-70b-versatile",
  defaultVisionModel: "meta-llama/llama-4-scout-17b-16e-instruct",
  envKeyVar: "GROQ_API_KEY",
} as const;

let cached: AIProvider | null = null;

/** Environment-configured singleton (existing behavior, unchanged). */
export async function groqProvider(): Promise<AIProvider> {
  if (cached) return cached;
  const env = await getEnv();
  cached = createOpenAICompatibleProvider({
    id: "groq",
    name: "Groq",
    apiKey: env.GROQ_API_KEY,
    baseUrl: env.GROQ_BASE_URL || GROQ_META.defaultBaseUrl,
    chatModel: env.GROQ_MODEL || GROQ_META.defaultModel,
    visionModel: env.GROQ_VISION_MODEL || GROQ_META.defaultVisionModel,
    modelHintPattern: /^(llama-|meta-llama\/|mixtral-|gemma-|qwen-|deepseek-)/,
    guidance: GUIDANCE,
  });
  return cached;
}

/** Build a per-request instance from dashboard-stored credentials. */
export async function buildGroqProvider(o: ProviderOverrides): Promise<AIProvider> {
  const env = await getEnv();
  return createOpenAICompatibleProvider({
    id: "groq",
    name: "Groq",
    apiKey: o.apiKey,
    baseUrl: o.baseUrl || env.GROQ_BASE_URL || GROQ_META.defaultBaseUrl,
    chatModel: o.model || env.GROQ_MODEL || GROQ_META.defaultModel,
    visionModel: o.visionModel || env.GROQ_VISION_MODEL || o.model || GROQ_META.defaultVisionModel,
    modelHintPattern: /^(llama-|meta-llama\/|mixtral-|gemma-|qwen-|deepseek-)/,
    guidance: GUIDANCE,
  });
}
