// ALPHA — OpenRouter provider adapter
//
// Environment (fallback when no dashboard credential is stored):
//   OPENROUTER_API_KEY      (required to enable the provider)
//   OPENROUTER_BASE_URL     (optional — default: official OpenRouter endpoint)
//   OPENROUTER_MODEL        (optional — default: openai/gpt-4o-mini; any
//                            OpenRouter model id "vendor/model" is valid)
//   OPENROUTER_VISION_MODEL (optional — default: openai/gpt-4o, vision-capable)
//
// Dashboard (Settings → AI Providers) takes PRECEDENCE over the environment.
// OpenRouter routes to thousands of upstream models — the model is fully
// configurable (any "vendor/model" id).
//
// Capabilities: chat, streaming, toolCalling (JSON protocol), vision.
// NOT implemented (declared false, never claimed): imageGeneration,
// webSearch, tts, asr.

import { getEnv } from "../../env";
import { createOpenAICompatibleProvider } from "./openai-compatible";
import type { AIProvider, ProviderOverrides } from "../types";

const GUIDANCE =
  "Set the OPENROUTER_API_KEY secret (npx wrangler secret put OPENROUTER_API_KEY) " +
  "or add the key in Settings → AI Providers. Optionally OPENROUTER_BASE_URL, " +
  "OPENROUTER_MODEL (any \"vendor/model\" id) and OPENROUTER_VISION_MODEL.";

/** Static defaults (also shown as placeholders in the dashboard UI). */
export const OPENROUTER_META = {
  defaultBaseUrl: "https://openrouter.ai/api/v1",
  defaultModel: "openai/gpt-4o-mini",
  defaultVisionModel: "openai/gpt-4o",
  envKeyVar: "OPENROUTER_API_KEY",
} as const;

let cached: AIProvider | null = null;

/** Environment-configured singleton (existing behavior, unchanged). */
export async function openrouterProvider(): Promise<AIProvider> {
  if (cached) return cached;
  const env = await getEnv();
  cached = createOpenAICompatibleProvider({
    id: "openrouter",
    name: "OpenRouter",
    apiKey: env.OPENROUTER_API_KEY,
    baseUrl: env.OPENROUTER_BASE_URL || OPENROUTER_META.defaultBaseUrl,
    chatModel: env.OPENROUTER_MODEL || OPENROUTER_META.defaultModel,
    visionModel: env.OPENROUTER_VISION_MODEL || OPENROUTER_META.defaultVisionModel,
    // OpenRouter model ids are "vendor/model" (or "vendor:model").
    modelHintPattern: /^[a-z0-9][a-z0-9.-]*\/[a-z0-9][a-z0-9./:-]*$/i,
    // OpenRouter recommends identifying the app (public values, no secrets).
    extraHeaders: {
      "HTTP-Referer": "https://alpha02.org",
      "X-Title": "ALPHA",
    },
    guidance: GUIDANCE,
  });
  return cached;
}

/** Build a per-request instance from dashboard-stored credentials. */
export async function buildOpenrouterProvider(o: ProviderOverrides): Promise<AIProvider> {
  const env = await getEnv();
  return createOpenAICompatibleProvider({
    id: "openrouter",
    name: "OpenRouter",
    apiKey: o.apiKey,
    baseUrl: o.baseUrl || env.OPENROUTER_BASE_URL || OPENROUTER_META.defaultBaseUrl,
    chatModel: o.model || env.OPENROUTER_MODEL || OPENROUTER_META.defaultModel,
    visionModel:
      o.visionModel || env.OPENROUTER_VISION_MODEL || o.model || OPENROUTER_META.defaultVisionModel,
    modelHintPattern: /^[a-z0-9][a-z0-9.-]*\/[a-z0-9][a-z0-9./:-]*$/i,
    extraHeaders: {
      "HTTP-Referer": "https://alpha02.org",
      "X-Title": "ALPHA",
    },
    guidance: GUIDANCE,
  });
}
