// ALPHA — Z.ai provider adapter
//
// Credentials come from the Worker environment:
//   ZAI_BASE_URL, ZAI_API_KEY, ZAI_TOKEN, ZAI_CHAT_ID, ZAI_USER_ID
// (set via `npx wrangler secret put ...`; use .dev.vars for local dev).
// Models: ZAI_MODEL (chat, default glm-4.6), ZAI_VISION_MODEL (default glm-4.5v).
//
// A dashboard credential (Settings → AI Providers) takes PRECEDENCE over the
// environment: apiKey + optional baseUrl/model/visionModel are passed in per
// request (see ZaiOverrides below). ZAI_TOKEN / ZAI_CHAT_ID / ZAI_USER_ID
// remain environment-provided (they are SDK session identifiers, not the API
// key). The SDK requires a baseUrl, so a dashboard credential resolves its
// baseUrl as: dashboard value → ZAI_BASE_URL env → not-configured error.
//
// In local development, when no ZAI_* env vars are present, the SDK's
// ZAI.create() config-file lookup is used (reads /etc/.z-ai-config or
// ./.z-ai-config). This development convenience is disabled in production —
// on Workers the ZAI_* secrets (or a dashboard key) are REQUIRED and a
// missing configuration returns a clear error instead of any fake response.
//
// Capabilities (all real, all verified):
//   chat, streaming, toolCalling (JSON protocol), vision, imageGeneration,
//   webSearch, tts, asr.

import ZAISDK from "z-ai-web-dev-sdk";
import type {
  ZAIConfig,
  CreateChatCompletionBody,
  CreateChatCompletionVisionBody,
  CreateAudioTTSBody,
  CreateAudioASRBody,
  CreateImageGenerationBody,
  ImageGenerationResponse,
  FunctionArgs,
  FunctionName,
  FunctionResult,
} from "z-ai-web-dev-sdk";
import { getEnv, isProduction } from "../../env";
import { ProviderNotConfiguredError } from "../types";
import type {
  AIProvider,
  ChatOptions,
  ChatResult,
  ProviderCapabilities,
  ProviderChatMessage,
  ProviderOverrides,
  SearchResultItem,
} from "../types";
import { ProviderError, inferCategory } from "../errors";

/** Structural type for the SDK client (its class has a private constructor). */
interface ZAI {
  chat: {
    completions: {
      create: (body: CreateChatCompletionBody) => Promise<unknown>;
      createVision: (body: CreateChatCompletionVisionBody) => Promise<unknown>;
    };
  };
  audio: {
    tts: { create: (body: CreateAudioTTSBody) => Promise<unknown> };
    asr: { create: (body: CreateAudioASRBody) => Promise<unknown> };
  };
  images: {
    generations: { create: (body: CreateImageGenerationBody) => Promise<ImageGenerationResponse> };
  };
  functions: {
    invoke: <T extends FunctionName>(name: T, args: FunctionArgs<T>) => Promise<FunctionResult<T>>;
  };
}

// The SDK's TS type declares the constructor private; at runtime it accepts a
// config object directly (see z-ai-web-dev-sdk/dist/index.js).
const ZAISDKCtor = ZAISDK as unknown as { new (c: ZAIConfig): ZAI };

const ZAI_GUIDANCE =
  "Set the ZAI_BASE_URL, ZAI_API_KEY, ZAI_TOKEN, ZAI_CHAT_ID and ZAI_USER_ID secrets " +
  "(npx wrangler secret put ZAI_BASE_URL, etc.), or add a Z.ai key in Settings → AI " +
  "Providers (a dashboard key still needs ZAI_BASE_URL or a dashboard base URL). " +
  "Local development may instead use a .z-ai-config file.";

const ZAI_DASH_NO_BASE_URL =
  "Z.ai requires a base URL for the SDK client. Set a base URL with the dashboard " +
  "key, or set the ZAI_BASE_URL secret.";

/** Wrap raw SDK errors into classified ProviderErrors for the router. */
function wrapError(error: unknown): never {
  if (error instanceof ProviderError || error instanceof ProviderNotConfiguredError) throw error;
  throw new ProviderError("zai", inferCategory(error), error instanceof Error ? error.message : String(error));
}

/** Wrap raw PCM in a 44-byte WAV (RIFF) header. */
function pcmToWav(pcm: Uint8Array, sampleRate: number): Uint8Array {
  const header = new ArrayBuffer(44);
  const view = new DataView(header);
  const writeString = (offset: number, s: string) => {
    for (let i = 0; i < s.length; i++) view.setUint8(offset + i, s.charCodeAt(i));
  };
  writeString(0, "RIFF");
  view.setUint32(4, 36 + pcm.length, true);
  writeString(8, "WAVE");
  writeString(12, "fmt ");
  view.setUint32(16, 16, true);          // fmt chunk size
  view.setUint16(20, 1, true);           // PCM
  view.setUint16(22, 1, true);           // mono
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true); // byte rate (16-bit mono)
  view.setUint16(32, 2, true);           // block align
  view.setUint16(34, 16, true);          // bits per sample
  writeString(36, "data");
  view.setUint32(40, pcm.length, true);
  const out = new Uint8Array(44 + pcm.length);
  out.set(new Uint8Array(header), 0);
  out.set(pcm, 44);
  return out;
}

const DEFAULT_CHAT_MODEL = "glm-4.6";
const DEFAULT_VISION_MODEL = "glm-4.5v";

/** Static model defaults (shown as placeholders in the dashboard UI). */
export const ZAI_META = {
  /** No static default — the Z.ai SDK requires an explicit baseUrl. */
  defaultBaseUrl: "",
  defaultModel: DEFAULT_CHAT_MODEL,
  defaultVisionModel: DEFAULT_VISION_MODEL,
  envKeyVar: "ZAI_API_KEY",
} as const;

let cached: ZAI | null = null;

/** Environment-configured client (existing behavior, unchanged). */
async function getEnvClient(): Promise<ZAI> {
  if (cached) return cached;

  const env = await getEnv();
  const config: ZAIConfig | null = env.ZAI_BASE_URL && env.ZAI_API_KEY
    ? {
        baseUrl: env.ZAI_BASE_URL,
        apiKey: env.ZAI_API_KEY,
        token: env.ZAI_TOKEN,
        chatId: env.ZAI_CHAT_ID,
        userId: env.ZAI_USER_ID,
      }
    : null;

  if (config) {
    cached = new ZAISDKCtor(config);
    return cached;
  }

  if (!isProduction()) {
    // Local dev: fall back to the SDK's config-file discovery.
    try {
      cached = (await ZAISDK.create()) as unknown as ZAI;
      return cached;
    } catch {
      // fall through to the not-configured error below
    }
  }

  throw new ProviderNotConfiguredError("zai", ZAI_GUIDANCE);
}

interface ZaiCompletionResponse {
  choices?: Array<{ message?: { content?: string } }>;
}

export class ZaiProvider implements AIProvider {
  readonly id = "zai";
  readonly name = "Z.ai";
  readonly capabilities: ProviderCapabilities = {
    chat: true,
    streaming: true,
    toolCalling: true,
    vision: true,
    imageGeneration: true,
    webSearch: true,
    tts: true,
    asr: true,
    reasoning: false,
    video: false,
    fast: false,
  };

  /** Dashboard-stored credentials (per-request instance; null = env mode). */
  private readonly overrides: ProviderOverrides | null;
  /** Per-instance SDK client cache (never shared across requests). */
  private client: ZAI | null = null;

  constructor(overrides?: ProviderOverrides) {
    this.overrides = overrides ?? null;
  }

  private async getClient(): Promise<ZAI> {
    if (this.client) return this.client;

    if (this.overrides) {
      const env = await getEnv();
      const baseUrl = this.overrides.baseUrl || env.ZAI_BASE_URL;
      if (!baseUrl) {
        throw new ProviderNotConfiguredError("zai", ZAI_DASH_NO_BASE_URL);
      }
      this.client = new ZAISDKCtor({
        baseUrl,
        apiKey: this.overrides.apiKey,
        token: env.ZAI_TOKEN,
        chatId: env.ZAI_CHAT_ID,
        userId: env.ZAI_USER_ID,
      });
      return this.client;
    }

    this.client = await getEnvClient();
    return this.client;
  }

  private async resolveChatModel(hint?: string): Promise<string> {
    if (this.overrides?.model) return this.overrides.model;
    if (hint && hint.startsWith("glm-")) return hint;
    const env = await getEnv();
    return env.ZAI_MODEL || DEFAULT_CHAT_MODEL;
  }

  private async resolveVisionModel(): Promise<string> {
    if (this.overrides?.visionModel) return this.overrides.visionModel;
    const env = await getEnv();
    return env.ZAI_VISION_MODEL || DEFAULT_VISION_MODEL;
  }

  async defaultModel(): Promise<string> {
    return this.resolveChatModel();
  }

  async isConfigured(): Promise<boolean> {
    try {
      await this.getClient();
      return true;
    } catch {
      return false;
    }
  }

  configurationGuide(): string {
    return ZAI_GUIDANCE;
  }

  async complete(messages: ProviderChatMessage[], options?: ChatOptions): Promise<ChatResult> {
    try {
      const client = await this.getClient();
      const model = await this.resolveChatModel(options?.model);
      const completion = (await client.chat.completions.create({
        model,
        messages,
        thinking: { type: "disabled" },
        ...(options?.temperature !== undefined ? { temperature: options.temperature } : {}),
      })) as ZaiCompletionResponse;

      const content = completion?.choices?.[0]?.message?.content;
      if (!content) {
        throw new ProviderError("zai", "server_error", "Z.ai returned an empty completion");
      }
      return { content, model, provider: this.name };
    } catch (e) {
      wrapError(e);
    }
  }

  async ping(): Promise<number> {
    const start = Date.now();
    await this.complete(
      [
        { role: "user", content: "Reply with the single word: ok" },
      ],
      { maxTokens: 8 },
    );
    return Date.now() - start;
  }

  async webSearch(query: string, num = 6): Promise<SearchResultItem[]> {
    try {
      const client = await this.getClient();
      const results = await client.functions.invoke("web_search", { query, num });
      return (results ?? []).slice(0, num) as SearchResultItem[];
    } catch (e) {
      wrapError(e);
    }
  }

  async generateImage(prompt: string, size: string): Promise<{ base64: string; mime: string }> {
    try {
      const client = await this.getClient();
      const sizeEnum = size as "1024x1024";
      const response = await client.images.generations.create({ prompt, size: sizeEnum });
      const base64 = response?.data?.[0]?.base64;
      if (!base64) {
        throw new ProviderError("zai", "server_error", "Z.ai image generation returned no image data");
      }
      // The API may return JPEG or PNG regardless of extension — sniff magic bytes.
      let mime = "image/png";
      if (base64.startsWith("/9j/")) mime = "image/jpeg";
      else if (base64.startsWith("R0lGOD")) mime = "image/gif";
      else if (base64.startsWith("UklGR")) mime = "image/webp";
      return { base64, mime };
    } catch (e) {
      wrapError(e);
    }
  }

  async tts(text: string, voice = "tongtong", speed = 1.0): Promise<{ base64: string; mime: string }> {
    try {
      const client = await this.getClient();
      // The SDK returns the raw fetch Response for TTS (raw PCM audio).
      const response = (await client.audio.tts.create({
        input: text.slice(0, 1000),
        voice,
        speed,
      })) as unknown as Response;

      const contentType = response.headers.get("content-type") ?? "";
      if (!contentType.includes("audio")) {
        const bodyText = (await response.text()).slice(0, 200);
        throw new ProviderError(
          "zai",
          inferCategory(bodyText),
          `Z.ai TTS returned a non-audio response (${contentType}): ${bodyText}`,
        );
      }

      const pcm = new Uint8Array(await response.arrayBuffer());
      const sampleRate = Number(response.headers.get("return-sample-rate")) || 24000;

      // Wrap raw PCM in a WAV (RIFF) container so browsers can play it directly.
      const wav = pcmToWav(pcm, sampleRate);
      let binary = "";
      const chunk = 0x8000;
      for (let i = 0; i < wav.length; i += chunk) {
        binary += String.fromCharCode(...wav.subarray(i, i + chunk));
      }
      return { base64: btoa(binary), mime: "audio/wav" };
    } catch (e) {
      wrapError(e);
    }
  }

  async asr(audioBase64: string, _mime: string): Promise<{ text: string }> {
    try {
      const client = await this.getClient();
      const response = (await client.audio.asr.create({
        file_base64: audioBase64,
      })) as unknown as { text?: string };
      if (!response?.text) {
        throw new ProviderError("zai", "server_error", "Z.ai ASR returned no transcript");
      }
      return { text: response.text };
    } catch (e) {
      wrapError(e);
    }
  }

  async analyzeImage(imageBase64: string, mime: string, prompt: string): Promise<string> {
    try {
      const client = await this.getClient();
      const response = (await client.chat.completions.createVision({
        model: await this.resolveVisionModel(),
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: prompt },
              {
                type: "image_url",
                image_url: { url: `data:${mime};base64,${imageBase64}` },
              },
            ],
          },
        ],
        thinking: { type: "disabled" },
      })) as ZaiCompletionResponse;
      const content = response?.choices?.[0]?.message?.content;
      if (!content) {
        throw new ProviderError("zai", "server_error", "Z.ai vision returned an empty analysis");
      }
      return content;
    } catch (e) {
      wrapError(e);
    }
  }
}

export const zaiProvider = new ZaiProvider();

/** Build a per-request instance from dashboard-stored credentials. */
export function buildZaiProvider(o: ProviderOverrides): AIProvider {
  return new ZaiProvider(o);
}
