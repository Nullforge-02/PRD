// ALPHA — OpenAI-compatible provider core
//
// OpenAI, Groq and OpenRouter all expose the same chat-completions HTTP
// protocol. This module implements it ONCE with native fetch (no SDK, no
// Node-only APIs — Cloudflare Workers safe) and the per-provider files
// (openai.ts / groq.ts / openrouter.ts) instantiate it with their own
// endpoints, credentials, model defaults and headers.
//
// Capabilities implemented here: chat, streaming (paced by the engine),
// toolCalling (Alpha's universal JSON tool protocol — the model is instructed
// by the chat engine, so any instruction-following model works), and vision
// via the standard content-parts format. Providers built on this core declare
// NO image-generation / web-search / TTS / ASR — they do not implement them.
//
// Errors are normalized into ProviderError with a category (errors.ts) so the
// router can make fallback decisions. Error text is truncated and never
// includes the Authorization header or API key.

import type {
  AIProvider,
  ChatOptions,
  ChatResult,
  ProviderCapabilities,
  ProviderChatMessage,
} from "../types";
import { ProviderError, categoryForStatus } from "../errors";

export interface OpenAICompatibleConfig {
  id: string;
  name: string;
  /** Resolved credentials (server-side env only; never the browser). */
  apiKey: string | undefined;
  baseUrl: string;
  /** Chat model (env-configured, provider default fallback). */
  chatModel: string;
  /** Vision-capable model for analyzeImage. */
  visionModel: string;
  /**
   * A model hint passed via ChatOptions.model is only honored when it matches
   * this provider's model family (e.g. /^gpt-|^o[134]-/ for OpenAI).
   */
  modelHintPattern: RegExp;
  /** Extra request headers (static, no secrets — e.g. OpenRouter referer). */
  extraHeaders?: Record<string, string>;
  guidance: string;
  requestTimeoutMs?: number;
}

interface ChatCompletionResponse {
  choices?: Array<{ message?: { content?: string | null } }>;
  error?: { message?: string } | string;
}

const CHAT_TIMEOUT_MS = 60_000;
const VISION_TIMEOUT_MS = 90_000;
const PING_TIMEOUT_MS = 20_000;

function resolveModel(cfg: OpenAICompatibleConfig, hint?: string): string {
  return hint && cfg.modelHintPattern.test(hint) ? hint : cfg.chatModel;
}

function headers(cfg: OpenAICompatibleConfig): Record<string, string> {
  return {
    Authorization: `Bearer ${cfg.apiKey}`,
    "Content-Type": "application/json",
    ...(cfg.extraHeaders ?? {}),
  };
}

async function readErrorMessage(response: Response): Promise<string> {
  try {
    const body = (await response.json()) as ChatCompletionResponse & { message?: string };
    const detail =
      typeof body?.error === "string"
        ? body.error
        : body?.error?.message ?? body?.message ?? "";
    return detail.slice(0, 300);
  } catch {
    return "";
  }
}

async function requestChatCompletion(
  cfg: OpenAICompatibleConfig,
  body: Record<string, unknown>,
  timeoutMs: number,
): Promise<ChatCompletionResponse> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  let response: Response;
  try {
    response = await fetch(`${cfg.baseUrl.replace(/\/$/, "")}/chat/completions`, {
      method: "POST",
      headers: headers(cfg),
      body: JSON.stringify(body),
      signal: controller.signal,
    });
  } catch (e) {
    clearTimeout(timer);
    const message = e instanceof Error ? e.message : String(e);
    const aborted = e instanceof Error && e.name === "AbortError";
    throw new ProviderError(
      cfg.id,
      aborted ? "timeout" : "network",
      aborted
        ? `${cfg.name} request timed out after ${timeoutMs}ms`
        : `${cfg.name} network error: ${message}`,
    );
  }
  clearTimeout(timer);

  if (!response.ok) {
    const detail = await readErrorMessage(response);
    throw new ProviderError(
      cfg.id,
      categoryForStatus(response.status),
      `${cfg.name} HTTP ${response.status}${detail ? `: ${detail}` : ""}`,
      response.status,
    );
  }

  const data = (await response.json().catch(() => null)) as ChatCompletionResponse | null;
  if (!data) {
    throw new ProviderError(cfg.id, "server_error", `${cfg.name} returned a non-JSON response`);
  }
  return data;
}

/** OpenAI "o-series" reasoning models require max_completion_tokens. */
function maxTokensParam(model: string, maxTokens?: number): Record<string, number> {
  if (maxTokens === undefined) return {};
  return /^o[134]/.test(model) ? { max_completion_tokens: maxTokens } : { max_tokens: maxTokens };
}

export function createOpenAICompatibleProvider(cfg: OpenAICompatibleConfig): AIProvider {
  const capabilities: ProviderCapabilities = {
    chat: true,
    streaming: true,
    toolCalling: true,
    vision: true,
    imageGeneration: false,
    webSearch: false,
    tts: false,
    asr: false,
    reasoning: false,
    video: false,
    fast: false,
  };

  return {
    id: cfg.id,
    name: cfg.name,
    capabilities,

    async defaultModel() {
      return cfg.chatModel;
    },

    async isConfigured() {
      return Boolean(cfg.apiKey && cfg.apiKey.length > 0);
    },

    configurationGuide() {
      return cfg.guidance;
    },

    async complete(messages: ProviderChatMessage[], options?: ChatOptions): Promise<ChatResult> {
      const model = resolveModel(cfg, options?.model);
      const data = await requestChatCompletion(
        cfg,
        {
          model,
          messages,
          ...maxTokensParam(model, options?.maxTokens),
          ...(options?.temperature !== undefined ? { temperature: options.temperature } : {}),
        },
        cfg.requestTimeoutMs ?? CHAT_TIMEOUT_MS,
      );
      const content = data?.choices?.[0]?.message?.content;
      if (!content) {
        throw new ProviderError(cfg.id, "server_error", `${cfg.name} returned an empty completion`);
      }
      return { content, model, provider: cfg.name };
    },

    async ping(): Promise<number> {
      const start = Date.now();
      await this.complete(
        [{ role: "user", content: "Reply with the single word: ok" }],
        { maxTokens: 8 },
      );
      return Date.now() - start;
    },

    async analyzeImage(imageBase64: string, mime: string, prompt: string): Promise<string> {
      // Universal OpenAI vision format: content parts with an image_url.
      const data = await requestChatCompletion(
        cfg,
        {
          model: cfg.visionModel,
          messages: [
            {
              role: "user",
              content: [
                { type: "text", text: prompt },
                {
                  type: "image_url",
                  image_url: { url: `data:${mime};base64,${imageBase64}` },
                },
              ],
            } as unknown as ProviderChatMessage,
          ],
        },
        VISION_TIMEOUT_MS,
      );
      const content = data?.choices?.[0]?.message?.content;
      if (!content) {
        throw new ProviderError(cfg.id, "server_error", `${cfg.name} vision returned an empty analysis`);
      }
      return content;
    },
  };
}
