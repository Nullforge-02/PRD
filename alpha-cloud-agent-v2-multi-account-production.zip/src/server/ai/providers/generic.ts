// ALPHA — generic user-configured AI provider adapter
//
// Powers UNLIMITED custom providers added from the dashboard (Settings → AI
// Providers → + Add API). Any OpenAI-compatible endpoint works: OpenRouter,
// Gemini-compatible gateways, DeepSeek, Mistral, Together, local/self-hosted
// servers… The system never assumes the provider IS OpenAI — the user gives
// it a name, an endpoint, a key and models; the protocol is the only contract.
//
// Implemented paths (declared capabilities come from the USER's selection —
// never invented):
//   complete()      → POST {baseUrl}/chat/completions          (TEXT)
//   analyzeImage()  → vision content-parts chat completion     (VISION)
//   generateImage() → POST {baseUrl}/images/generations       (IMAGE_GENERATION)
//   ping()          → minimal chat completion (real latency)
//
// VIDEO / REASONING / FAST are stored user-declared metadata: routing can
// filter by them, but no false protocol path is claimed for them.
//
// Cloudflare Workers safe: native fetch + Web APIs only, no Node crypto.

import type {
  AIProvider,
  ChatOptions,
  ChatResult,
  ProviderChatMessage,
} from "../types";
import { ProviderError, categoryForStatus } from "../errors";
import { capabilitiesToFlags, type UserCapability } from "../capabilities";

export interface GenericProviderConfig {
  /** D1 row id (health tracking key). */
  id: string;
  /** User-chosen display name — never assumed to be a known vendor. */
  name: string;
  /** Decrypted API key (server-side, request-local memory only). */
  apiKey: string;
  /** Endpoint root, e.g. https://openrouter.ai/api/v1 (no trailing slash). */
  baseUrl: string;
  /** Primary chat model id (explicit — no vendor pattern matching). */
  model: string;
  visionModel?: string | null;
  imageModel?: string | null;
  /** User-selected capabilities (authoritative). */
  capabilities: UserCapability[];
}

interface ChatCompletionResponse {
  choices?: Array<{ message?: { content?: string | null } }>;
  error?: { message?: string } | string;
}

interface ImagesResponse {
  data?: Array<{ b64_json?: string; url?: string }>;
  error?: { message?: string } | string;
}

const CHAT_TIMEOUT_MS = 60_000;
const VISION_TIMEOUT_MS = 90_000;
const IMAGE_TIMEOUT_MS = 120_000;

function root(cfg: GenericProviderConfig): string {
  return cfg.baseUrl.replace(/\/+$/, "");
}

function headers(cfg: GenericProviderConfig): Record<string, string> {
  return {
    Authorization: `Bearer ${cfg.apiKey}`,
    "Content-Type": "application/json",
  };
}

async function readErrorMessage(response: Response): Promise<string> {
  try {
    const body = (await response.json()) as { error?: { message?: string } | string; message?: string };
    const detail =
      typeof body?.error === "string"
        ? body.error
        : body?.error?.message ?? body?.message ?? "";
    return detail.slice(0, 300);
  } catch {
    return "";
  }
}

async function fetchJson<T>(
  cfg: GenericProviderConfig,
  path: string,
  body: Record<string, unknown> | null,
  timeoutMs: number,
): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  let response: Response;
  try {
    response = await fetch(`${root(cfg)}${path}`, {
      method: body ? "POST" : "GET",
      headers: headers(cfg),
      ...(body ? { body: JSON.stringify(body) } : {}),
      signal: controller.signal,
    });
  } catch (e) {
    clearTimeout(timer);
    const aborted = e instanceof Error && e.name === "AbortError";
    throw new ProviderError(
      cfg.id,
      aborted ? "timeout" : "network",
      aborted
        ? `${cfg.name} request timed out after ${timeoutMs}ms`
        : `${cfg.name} network error: ${e instanceof Error ? e.message : String(e)}`,
    );
  }
  clearTimeout(timer);

  if (!response.ok) {
    const detail = await readErrorMessage(response);
    throw new ProviderError(
      cfg.id,
      categoryForStatus(response.status),
      `${cfg.name} HTTP ${response.status}${detail ? `: ${detail}` : ""}`,
      response.status,
    );
  }
  const data = (await response.json().catch(() => null)) as T | null;
  if (!data) {
    throw new ProviderError(cfg.id, "server_error", `${cfg.name} returned a non-JSON response`);
  }
  return data;
}

export function buildGenericProvider(cfg: GenericProviderConfig): AIProvider {
  const flags = capabilitiesToFlags(cfg.capabilities);

  return {
    id: cfg.id,
    name: cfg.name,
    capabilities: flags,

    async defaultModel() {
      return cfg.model;
    },

    async isConfigured() {
      return Boolean(cfg.apiKey);
    },

    configurationGuide() {
      return `Custom provider "${cfg.name}" — configure it in Settings → AI Providers.`;
    },

    async complete(messages: ProviderChatMessage[], options?: ChatOptions): Promise<ChatResult> {
      if (!flags.chat) {
        throw new ProviderError(cfg.id, "capability_unavailable", `${cfg.name} is not configured for text chat`);
      }
      const data = await fetchJson<ChatCompletionResponse>(
        cfg,
        "/chat/completions",
        {
          model: cfg.model,
          messages,
          ...(options?.maxTokens !== undefined ? { max_tokens: options.maxTokens } : {}),
          ...(options?.temperature !== undefined ? { temperature: options.temperature } : {}),
        },
        CHAT_TIMEOUT_MS,
      );
      const content = data?.choices?.[0]?.message?.content;
      if (!content) {
        throw new ProviderError(cfg.id, "server_error", `${cfg.name} returned an empty completion`);
      }
      return { content, model: cfg.model, provider: cfg.name };
    },

    async ping(): Promise<number> {
      const start = Date.now();
      if (flags.chat) {
        await this.complete(
          [{ role: "user", content: "Reply with the single word: ok" }],
          { maxTokens: 8 },
        );
        return Date.now() - start;
      }
      // Non-text providers: prove endpoint + key with a real GET /models call.
      await fetchJson<unknown>(cfg, "/models", null, CHAT_TIMEOUT_MS);
      return Date.now() - start;
    },

    async analyzeImage(imageBase64: string, mime: string, prompt: string): Promise<string> {
      if (!flags.vision) {
        throw new ProviderError(cfg.id, "capability_unavailable", `${cfg.name} is not configured for vision`);
      }
      const model = cfg.visionModel || cfg.model;
      const data = await fetchJson<ChatCompletionResponse>(
        cfg,
        "/chat/completions",
        {
          model,
          messages: [
            {
              role: "user",
              content: [
                { type: "text", text: prompt },
                {
                  type: "image_url",
                  image_url: { url: `data:${mime};base64,${imageBase64}` },
                },
              ],
            } as unknown as ProviderChatMessage,
          ],
        },
        VISION_TIMEOUT_MS,
      );
      const content = data?.choices?.[0]?.message?.content;
      if (!content) {
        throw new ProviderError(cfg.id, "server_error", `${cfg.name} vision returned an empty analysis`);
      }
      return content;
    },

    async generateImage(prompt: string, size: string): Promise<{ base64: string; mime: string }> {
      if (!flags.imageGeneration) {
        throw new ProviderError(cfg.id, "capability_unavailable", `${cfg.name} is not configured for image generation`);
      }
      const model = cfg.imageModel || cfg.model;
      const data = await fetchJson<ImagesResponse>(
        cfg,
        "/images/generations",
        { model, prompt, n: 1, size, response_format: "b64_json" },
        IMAGE_TIMEOUT_MS,
      );
      const entry = data?.data?.[0];
      if (entry?.b64_json) {
        return { base64: entry.b64_json, mime: "image/png" };
      }
      // Some endpoints return a hosted URL instead of inline base64.
      if (entry?.url) {
        const res = await fetch(entry.url);
        if (!res.ok) {
          throw new ProviderError(cfg.id, "server_error", `${cfg.name} image URL fetch failed (HTTP ${res.status})`);
        }
        const buf = new Uint8Array(await res.arrayBuffer());
        let bin = "";
        for (const b of buf) bin += String.fromCharCode(b);
        return { base64: btoa(bin), mime: res.headers.get("content-type")?.split(";")[0] || "image/png" };
      }
      throw new ProviderError(cfg.id, "server_error", `${cfg.name} returned no image data`);
    },
  };
}
