// ALPHA — OpenAI provider adapter
//
// Environment (fallback when no dashboard credential is stored):
//   OPENAI_API_KEY   (required to enable the provider)
//   OPENAI_BASE_URL  (optional — default: official OpenAI endpoint)
//   OPENAI_MODEL     (optional — default: gpt-4o-mini)
//   OPENAI_VISION_MODEL (optional — default: gpt-4o-mini, vision-capable)
//
// Dashboard (Settings → AI Providers) takes PRECEDENCE over the environment:
// a stored key/baseUrl/model is used to build a per-request instance.
//
// Capabilities: chat, streaming, toolCalling (JSON protocol), vision.
// NOT implemented (declared false, never claimed): imageGeneration,
// webSearch, tts, asr.

import { getEnv } from "../../env";
import { createOpenAICompatibleProvider } from "./openai-compatible";
import type { AIProvider, ProviderOverrides } from "../types";

const GUIDANCE =
  "Set the OPENAI_API_KEY secret (npx wrangler secret put OPENAI_API_KEY) or add " +
  "the key in Settings → AI Providers. Optionally OPENAI_BASE_URL, OPENAI_MODEL " +
  "and OPENAI_VISION_MODEL.";

/** Static defaults (also shown as placeholders in the dashboard UI). */
export const OPENAI_META = {
  defaultBaseUrl: "https://api.openai.com/v1",
  defaultModel: "gpt-4o-mini",
  defaultVisionModel: "gpt-4o-mini",
  envKeyVar: "OPENAI_API_KEY",
} as const;

let cached: AIProvider | null = null;

/** Environment-configured singleton (existing behavior, unchanged). */
export async function openaiProvider(): Promise<AIProvider> {
  if (cached) return cached;
  const env = await getEnv();
  cached = createOpenAICompatibleProvider({
    id: "openai",
    name: "OpenAI",
    apiKey: env.OPENAI_API_KEY,
    baseUrl: env.OPENAI_BASE_URL || OPENAI_META.defaultBaseUrl,
    chatModel: env.OPENAI_MODEL || OPENAI_META.defaultModel,
    visionModel: env.OPENAI_VISION_MODEL || env.OPENAI_MODEL || OPENAI_META.defaultVisionModel,
    modelHintPattern: /^(gpt-|o[134]|chatgpt-)/,
    guidance: GUIDANCE,
  });
  return cached;
}

/**
 * Build a per-request instance from dashboard-stored credentials.
 * Dashboard fields win; unset fields fall back to env values then defaults.
 */
export async function buildOpenaiProvider(o: ProviderOverrides): Promise<AIProvider> {
  const env = await getEnv();
  return createOpenAICompatibleProvider({
    id: "openai",
    name: "OpenAI",
    apiKey: o.apiKey,
    baseUrl: o.baseUrl || env.OPENAI_BASE_URL || OPENAI_META.defaultBaseUrl,
    chatModel: o.model || env.OPENAI_MODEL || OPENAI_META.defaultModel,
    visionModel:
      o.visionModel || env.OPENAI_VISION_MODEL || o.model || OPENAI_META.defaultVisionModel,
    modelHintPattern: /^(gpt-|o[134]|chatgpt-)/,
    guidance: GUIDANCE,
  });
}
