// ALPHA — user-facing provider capabilities
//
// The 6 capabilities the OWNER selects when configuring a custom AI provider
// (Settings → AI Providers → + Add API). Manual selection is AUTHORITATIVE:
// the system never invents capabilities — if a provider exposes model
// metadata (e.g. via /models), it may only SUGGEST, never silently overwrite
// the user's configuration.
//
// Stored in D1 as a comma-separated string; validated everywhere against
// the canonical list below.

export const USER_CAPABILITIES = [
  "TEXT",
  "VISION",
  "IMAGE_GENERATION",
  "VIDEO",
  "REASONING",
  "FAST",
] as const;

export type UserCapability = (typeof USER_CAPABILITIES)[number];

/** Human labels for UI chips (e.g. "Image Generation"). */
export const CAPABILITY_LABELS: Record<UserCapability, string> = {
  TEXT: "Text",
  VISION: "Vision",
  IMAGE_GENERATION: "Image Generation",
  VIDEO: "Video",
  REASONING: "Reasoning",
  FAST: "Fast",
};

export function isUserCapability(value: string): value is UserCapability {
  return (USER_CAPABILITIES as readonly string[]).includes(value);
}

/** Parse + validate a CSV capability string from D1. Invalid entries dropped. */
export function parseCapabilities(csv: string): UserCapability[] {
  return Array.from(
    new Set(
      csv
        .split(",")
        .map((s) => s.trim().toUpperCase())
        .filter((s): s is UserCapability => isUserCapability(s)),
    ),
  );
}

/** Serialize capability list for D1 storage (canonical order). */
export function serializeCapabilities(caps: UserCapability[]): string {
  return USER_CAPABILITIES.filter((c) => caps.includes(c)).join(",");
}

/** Map user capabilities → internal ProviderCapabilities routing flags. */
export function capabilitiesToFlags(caps: UserCapability[]): {
  chat: boolean;
  streaming: boolean;
  toolCalling: boolean;
  vision: boolean;
  imageGeneration: boolean;
  webSearch: boolean;
  tts: boolean;
  asr: boolean;
  reasoning: boolean;
  video: boolean;
  fast: boolean;
} {
  const has = (c: UserCapability) => caps.includes(c);
  const text = has("TEXT");
  return {
    // Alpha's universal JSON tool protocol + engine-paced streaming work on
    // any instruction-following chat model → both follow TEXT.
    chat: text,
    streaming: text,
    toolCalling: text,
    vision: has("VISION"),
    imageGeneration: has("IMAGE_GENERATION"),
    webSearch: false,
    tts: false,
    asr: false,
    reasoning: has("REASONING"),
    video: has("VIDEO"),
    fast: has("FAST"),
  };
}

/** Map internal ProviderCapabilities → user-facing capability list. */
export function flagsToCapabilities(flags: {
  chat: boolean;
  vision: boolean;
  imageGeneration: boolean;
  webSearch: boolean;
  tts: boolean;
  asr: boolean;
  reasoning: boolean;
  video: boolean;
  fast: boolean;
}): UserCapability[] {
  const out: UserCapability[] = [];
  if (flags.chat) out.push("TEXT");
  if (flags.vision) out.push("VISION");
  if (flags.imageGeneration) out.push("IMAGE_GENERATION");
  if (flags.video) out.push("VIDEO");
  if (flags.reasoning) out.push("REASONING");
  if (flags.fast) out.push("FAST");
  return out;
}
