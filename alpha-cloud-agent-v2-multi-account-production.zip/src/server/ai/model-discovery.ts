// ALPHA — server-side model discovery for OpenAI-compatible providers
//
// GET {baseUrl}/models with the stored/supplied credential. Used by the
// Add API modal ([ Fetch Models ] button). NOT every provider implements
// /models — an unavailable endpoint is a SOFT failure (the user can always
// type a model id manually; provider creation never depends on this).
//
// SECURITY: the API key is used server-side only, is never echoed, and error
// responses are sanitized to fixed category messages — raw upstream bodies
// (which could reflect request content) never reach the client.

import { ProviderError, categoryForStatus, type ErrorCategory } from "./errors";

const MODELS_TIMEOUT_MS = 15_000;
const MAX_MODELS = 300;

interface ModelsListResponse {
  data?: Array<{ id?: string }>;
}

export class ModelDiscoveryError extends Error {
  readonly category: ErrorCategory;
  constructor(category: ErrorCategory, message: string) {
    super(message);
    this.name = "ModelDiscoveryError";
    this.category = category;
  }
}

/**
 * Fetch available model ids from an OpenAI-compatible endpoint.
 * Throws ModelDiscoveryError with a SANITIZED message on failure.
 */
export async function fetchModelIds(
  baseUrl: string,
  apiKey: string,
): Promise<string[]> {
  const root = baseUrl.replace(/\/+$/, "");
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), MODELS_TIMEOUT_MS);
  let response: Response;
  try {
    response = await fetch(`${root}/models`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        Accept: "application/json",
      },
      signal: controller.signal,
    });
  } catch (e) {
    clearTimeout(timer);
    const aborted = e instanceof Error && e.name === "AbortError";
    throw new ModelDiscoveryError(
      aborted ? "timeout" : "network",
      aborted
        ? "The provider timed out while listing models"
        : "Network error reaching the provider",
    );
  }
  clearTimeout(timer);

  if (!response.ok) {
    // Sanitized — never surface the upstream body here.
    throw new ModelDiscoveryError(
      categoryForStatus(response.status),
      response.status === 401 || response.status === 403
        ? "Authentication failed — check the API key"
        : response.status === 404
          ? "This provider does not expose a model list — enter the model id manually"
          : response.status === 429
            ? "Rate limited by the provider — try again shortly"
            : `The provider returned HTTP ${response.status} for the model list`,
    );
  }

  const data = (await response.json().catch(() => null)) as ModelsListResponse | null;
  if (!data || !Array.isArray(data.data)) {
    throw new ModelDiscoveryError(
      "server_error",
      "The provider returned an unexpected model-list format — enter the model id manually",
    );
  }
  return data.data
    .map((m) => (typeof m?.id === "string" ? m.id : ""))
    .filter(Boolean)
    .sort((a, b) => a.localeCompare(b))
    .slice(0, MAX_MODELS);
}

/** Re-export for callers that catch provider-shaped errors. */
export type { ProviderError };
