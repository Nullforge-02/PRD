// ALPHA — provider health tracking
//
// Real observations only: every success/failure of an actual provider request
// is recorded here. NOTHING is simulated — a fresh Worker isolate simply has
// no data yet (status "unknown") until the first real request.
//
// State is in-memory per Worker isolate (module scope on globalThis so it
// survives module reloads in dev). This is intentionally lightweight — no
// database, no fake metrics, no background pingers.

import type { ErrorCategory } from "./errors";
import { cooldownFor } from "./errors";

export type ProviderHealthStatus = "healthy" | "degraded" | "offline" | "unknown";

export interface ProviderHealthRecord {
  /** "healthy" — last observation succeeded (and was not slow). */
  /** "degraded" — last observation failed (cooldown expired) or was slow. */
  /** "offline"  — currently in failure cooldown (or never configured). */
  /** "unknown"  — configured but never observed in this isolate. */
  status: ProviderHealthStatus;
  /** Last REAL measured latency in ms (null when never succeeded). */
  latencyMs: number | null;
  lastCheckedAt: string | null;
  consecutiveFailures: number;
  cooldownUntil: number | null;
  lastErrorCategory: ErrorCategory | null;
  /** Safe, truncated error text (never contains credentials). */
  lastError: string | null;
  totalSuccesses: number;
  totalFailures: number;
}

interface HealthState {
  records: Map<string, ProviderHealthRecord>;
}

const SLOW_LATENCY_MS = 2_500;

function emptyRecord(): ProviderHealthRecord {
  return {
    status: "unknown",
    latencyMs: null,
    lastCheckedAt: null,
    consecutiveFailures: 0,
    cooldownUntil: null,
    lastErrorCategory: null,
    lastError: null,
    totalSuccesses: 0,
    totalFailures: 0,
  };
}

function state(): HealthState {
  const g = globalThis as { __ALPHA_PROVIDER_HEALTH__?: HealthState };
  if (!g.__ALPHA_PROVIDER_HEALTH__) {
    g.__ALPHA_PROVIDER_HEALTH__ = { records: new Map() };
  }
  return g.__ALPHA_PROVIDER_HEALTH__;
}

/** Record a successful real request. */
export function recordSuccess(providerId: string, latencyMs: number): void {
  const s = state();
  const rec = s.records.get(providerId) ?? emptyRecord();
  rec.status = latencyMs > SLOW_LATENCY_MS ? "degraded" : "healthy";
  rec.latencyMs = latencyMs;
  rec.lastCheckedAt = new Date().toISOString();
  rec.consecutiveFailures = 0;
  rec.cooldownUntil = null;
  rec.lastErrorCategory = null;
  rec.lastError = null;
  rec.totalSuccesses += 1;
  s.records.set(providerId, rec);
}

/** Record a failed real request (applies the category's cooldown policy). */
export function recordFailure(
  providerId: string,
  category: ErrorCategory,
  message: string,
): void {
  const s = state();
  const rec = s.records.get(providerId) ?? emptyRecord();
  rec.consecutiveFailures += 1;
  rec.totalFailures += 1;
  rec.lastCheckedAt = new Date().toISOString();
  rec.lastErrorCategory = category;
  rec.lastError = message.slice(0, 300);
  const cooldown = cooldownFor(category, rec.consecutiveFailures);
  rec.cooldownUntil = cooldown > 0 ? Date.now() + cooldown : null;
  rec.status = rec.cooldownUntil && rec.cooldownUntil > Date.now() ? "offline" : "degraded";
  s.records.set(providerId, rec);
}

/** True when the provider may currently be attempted (no active cooldown). */
export function isAvailable(providerId: string): boolean {
  const rec = state().records.get(providerId);
  if (!rec) return true;
  if (rec.cooldownUntil && rec.cooldownUntil > Date.now()) return false;
  return true;
}

/** Read-only health snapshot (safe to expose via APIs — no secrets stored). */
export function getHealth(providerId: string): ProviderHealthRecord {
  const rec = state().records.get(providerId);
  if (!rec) return emptyRecord();
  // Derive the live status from cooldown state.
  const live: ProviderHealthRecord = { ...rec };
  if (live.cooldownUntil && live.cooldownUntil > Date.now()) {
    live.status = "offline";
  } else if (live.status === "offline") {
    // Cooldown expired — the last observation still failed.
    live.status = "degraded";
  }
  return live;
}
