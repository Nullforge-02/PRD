// ALPHA — AI provider abstraction
//
// Providers implement a small interface. Credentials come from the
// server-side ONLY — never from the browser. Two sources (dashboard first):
//   1. Dashboard-managed credentials (D1, AES-GCM encrypted — see
//      ai/credentials.ts; the plaintext key NEVER touches the database)
//   2. Worker environment secrets (wrangler / .dev.vars)
//
// The AI router (router.ts) selects providers by capability, priority and
// health. Adapters declare exactly what they can do — a provider must never
// claim a capability it does not implement.
//
// Tool calling: Alpha uses a provider-AGNOSTIC JSON tool protocol. The chat
// engine instructs the model to answer with {"tool": ..., "args": {...}} and
// parses the reply itself (see chat-engine.ts). This is the single common
// internal tool-call format for every provider — the engine never needs to
// know which provider produced the answer.

export interface ProviderChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface ChatOptions {
  model?: string;
  maxTokens?: number;
  temperature?: number;
}

export interface ChatResult {
  content: string;
  model: string;
  /** Display name of the provider that produced this result. */
  provider: string;
}

export interface SearchResultItem {
  url: string;
  name: string;
  snippet: string;
  host_name: string;
  date?: string;
}

export interface ImageSize {
  width: number;
  height: number;
}

/** Capabilities a provider declares. Declared = truly implemented. */
export interface ProviderCapabilities {
  /** Standard chat completions. */
  chat: boolean;
  /**
   * Streaming to the client. Alpha streams the final provider answer in
   * paced chunks (chat-engine streamText) — every chat-capable provider
   * supports this; the pacing layer is provider-independent.
   */
  streaming: boolean;
  /** Tool calling via Alpha's universal JSON tool protocol. */
  toolCalling: boolean;
  /** Image understanding (analyzeImage). */
  vision: boolean;
  /** Image generation (generateImage). */
  imageGeneration: boolean;
  /** Web search (webSearch). */
  webSearch: boolean;
  /** Text-to-speech (tts). */
  tts: boolean;
  /** Speech-to-text (asr). */
  asr: boolean;
  /** Reasoning-class model (user-declared for custom providers). */
  reasoning: boolean;
  /** Video generation (user-declared capability — no adapter path yet). */
  video: boolean;
  /** Fast/low-latency tier (user-declared for custom providers). */
  fast: boolean;
}

/** Capability keys used for routing requests. */
export type CapabilityKey =
  | "chat"
  | "streaming"
  | "toolCalling"
  | "vision"
  | "imageGeneration"
  | "webSearch"
  | "tts"
  | "asr"
  | "reasoning"
  | "video"
  | "fast";

export class ProviderNotConfiguredError extends Error {
  constructor(provider: string, guidance: string) {
    super(
      `AI provider "${provider}" is not configured. ${guidance}`,
    );
    this.name = "ProviderNotConfiguredError";
  }
}

/**
 * Explicit per-request credentials (dashboard-managed). Used to build a
 * provider instance for a single attempt — the plaintext apiKey exists only
 * in request-local memory and is never persisted, logged or returned.
 */
export interface ProviderOverrides {
  /** Decrypted API key (server-side only, transient). */
  apiKey: string;
  /** Optional endpoint override (falls back to env / provider default). */
  baseUrl?: string | null;
  /** Optional chat model override. */
  model?: string | null;
  /** Optional vision model override. */
  visionModel?: string | null;
}

export interface AIProvider {
  readonly id: string;
  readonly name: string;
  /** Exactly what this provider can do — the router trusts this. */
  readonly capabilities: ProviderCapabilities;
  /** The model this provider uses for chat (resolved from env + defaults). */
  defaultModel(): Promise<string>;
  /** True when credentials exist in the environment. */
  isConfigured(): Promise<boolean>;
  /** Human-readable configuration guidance (safe to show in the UI). */
  configurationGuide(): string;
  /** Non-streaming chat completion. */
  complete(messages: ProviderChatMessage[], options?: ChatOptions): Promise<ChatResult>;
  /** Live health ping (returns latency in ms). */
  ping(): Promise<number>;
  /** Web search (optional capability). */
  webSearch?(query: string, num?: number): Promise<SearchResultItem[]>;
  /** Image generation (optional capability). */
  generateImage?(prompt: string, size: string): Promise<{ base64: string; mime: string }>;
  /** Text-to-speech (optional capability). */
  tts?(text: string, voice?: string, speed?: number): Promise<{ base64: string; mime: string }>;
  /** Speech-to-text (optional capability). */
  asr?(audioBase64: string, mime: string): Promise<{ text: string }>;
  /** Vision/image analysis (optional capability). */
  analyzeImage?(imageBase64: string, mime: string, prompt: string): Promise<string>;
}

/** Human-readable capability id list for status APIs. */
export function capabilityList(caps: ProviderCapabilities): string[] {
  return (Object.keys(caps) as CapabilityKey[]).filter((k) => caps[k]);
}
