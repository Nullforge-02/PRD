// ALPHA — provider registry
//
// Builds the provider list from the Worker environment on each request:
//   - Z.ai (providers/zai.ts — SDK-based, all capabilities)
//   - OpenAI / Groq / OpenRouter (OpenAI-compatible protocol via fetch)
//
// Routing order (priority):
//   1. AI_PRIMARY_PROVIDER (default: "zai")
//   2. AI_FALLBACK_PROVIDERS (comma-separated, in the given order;
//      default: the remaining providers in registration order)
//   3. any providers not mentioned above (registration order)
//
// AI_DISABLED_PROVIDERS (comma-separated ids) are excluded from routing but
// still reported by the status APIs with enabled: false.
//
// Credentials have TWO sources (dashboard first, environment fallback — see
// ai/credentials.ts). Dashboard keys are stored AES-GCM encrypted in D1
// (ai_provider_credentials) and are decrypted only when a provider is
// actually attempted. This registry provides:
//   getRegistry()          — env-priority routing table (unchanged behavior)
//   buildProviderInstance()— per-request instance from dashboard credentials
//   getProviderDescriptors()— UI-safe metadata (no secrets) for the dashboard

import { getEnv } from "../env";
import type { AIProvider, ProviderOverrides } from "./types";
import { zaiProvider, buildZaiProvider, ZAI_META } from "./providers/zai";
import { openaiProvider, buildOpenaiProvider, OPENAI_META } from "./providers/openai";
import { groqProvider, buildGroqProvider, GROQ_META } from "./providers/groq";
import {
  openrouterProvider,
  buildOpenrouterProvider,
  OPENROUTER_META,
} from "./providers/openrouter";

export interface ProviderRegistration {
  provider: AIProvider;
  /** 1 = highest — routing tries providers in ascending priority order. */
  priority: number;
  /** false → never routed to (AI_DISABLED_PROVIDERS), but still listed. */
  enabled: boolean;
}

/**
 * Static, secret-free provider metadata. Drives the dashboard UI field set
 * (which providers support base URL / vision model overrides) and the
 * placeholder defaults — the provider registry stays the single source of
 * truth for capabilities.
 */
export interface ProviderDescriptor {
  id: string;
  name: string;
  supportsBaseUrl: boolean;
  supportsVisionModel: boolean;
  /** Default endpoint ("" for Z.ai — the SDK has no static default). */
  defaultBaseUrl: string;
  defaultModel: string;
  defaultVisionModel: string;
  /** Environment variable that can also hold the key (guidance only). */
  envKeyVar: string;
}

function parseList(value: string | undefined): string[] {
  return (value ?? "")
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
}

/** All known provider ids in registration order. */
export const PROVIDER_IDS = ["zai", "openai", "groq", "openrouter"] as const;

export type ProviderId = (typeof PROVIDER_IDS)[number];

export function isProviderId(value: string): value is ProviderId {
  return (PROVIDER_IDS as readonly string[]).includes(value);
}

/** Static per-provider metadata (no secrets, safe for the dashboard UI). */
export function getProviderDescriptors(): ProviderDescriptor[] {
  return [
    {
      id: "zai",
      name: "Z.ai",
      supportsBaseUrl: true, // optional — SDK requires SOME baseUrl (dashboard or ZAI_BASE_URL)
      supportsVisionModel: true,
      defaultBaseUrl: ZAI_META.defaultBaseUrl,
      defaultModel: ZAI_META.defaultModel,
      defaultVisionModel: ZAI_META.defaultVisionModel,
      envKeyVar: ZAI_META.envKeyVar,
    },
    {
      id: "openai",
      name: "OpenAI",
      supportsBaseUrl: true,
      supportsVisionModel: true,
      defaultBaseUrl: OPENAI_META.defaultBaseUrl,
      defaultModel: OPENAI_META.defaultModel,
      defaultVisionModel: OPENAI_META.defaultVisionModel,
      envKeyVar: OPENAI_META.envKeyVar,
    },
    {
      id: "groq",
      name: "Groq",
      supportsBaseUrl: true,
      supportsVisionModel: true,
      defaultBaseUrl: GROQ_META.defaultBaseUrl,
      defaultModel: GROQ_META.defaultModel,
      defaultVisionModel: GROQ_META.defaultVisionModel,
      envKeyVar: GROQ_META.envKeyVar,
    },
    {
      id: "openrouter",
      name: "OpenRouter",
      supportsBaseUrl: true,
      supportsVisionModel: true,
      defaultBaseUrl: OPENROUTER_META.defaultBaseUrl,
      defaultModel: OPENROUTER_META.defaultModel,
      defaultVisionModel: OPENROUTER_META.defaultVisionModel,
      envKeyVar: OPENROUTER_META.envKeyVar,
    },
  ];
}

/**
 * Build the ordered registry from env routing configuration.
 * Unconfigured providers are included (the router filters by credential
 * state) so status APIs can report them honestly as configured: false.
 */
export async function getRegistry(): Promise<ProviderRegistration[]> {
  const env = await getEnv();

  const instances = new Map<string, AIProvider>();
  instances.set("zai", zaiProvider);
  instances.set("openai", await openaiProvider());
  instances.set("groq", await groqProvider());
  instances.set("openrouter", await openrouterProvider());

  const disabled = new Set(parseList(env.AI_DISABLED_PROVIDERS));
  const primary = (env.AI_PRIMARY_PROVIDER || "zai").trim().toLowerCase();
  const fallbacks = parseList(env.AI_FALLBACK_PROVIDERS).filter(
    (id) => id !== primary && !disabled.has(id),
  );

  // Deterministic priority order: primary → configured fallbacks → the rest.
  const order: string[] = [primary];
  for (const id of fallbacks) order.push(id);
  for (const id of PROVIDER_IDS) {
    if (!order.includes(id) && !disabled.has(id)) order.push(id);
  }

  const registry: ProviderRegistration[] = [];
  let priority = 1;
  for (const id of order) {
    const provider = instances.get(id);
    if (!provider) continue;
    registry.push({ provider, priority, enabled: !disabled.has(id) });
    priority += 1;
  }
  // Disabled providers keep their registration order at the end of the list.
  for (const id of PROVIDER_IDS) {
    if (disabled.has(id)) {
      const provider = instances.get(id);
      if (provider) {
        registry.push({ provider, priority, enabled: false });
        priority += 1;
      }
    }
  }
  return registry;
}

/**
 * Build a per-request provider instance from dashboard-stored credentials.
 * Called by the router ONLY at attempt time (lazy decrypt). Unset fields
 * fall back to env values then provider defaults.
 */
export async function buildProviderInstance(
  id: string,
  overrides: ProviderOverrides,
): Promise<AIProvider> {
  switch (id) {
    case "zai":
      return buildZaiProvider(overrides);
    case "openai":
      return buildOpenaiProvider(overrides);
    case "groq":
      return buildGroqProvider(overrides);
    case "openrouter":
      return buildOpenrouterProvider(overrides);
    default:
      throw new Error(`Unknown AI provider: ${id}`);
  }
}

/** AI_MAX_ATTEMPTS clamped to a strict 1..4 range (no retry loops). */
export async function getMaxAttempts(): Promise<number> {
  const env = await getEnv();
  const raw = Number.parseInt(env.AI_MAX_ATTEMPTS ?? "", 10);
  if (!Number.isFinite(raw)) return 3;
  return Math.min(Math.max(raw, 1), 4);
}
