// ALPHA — provider credential resolution (dashboard → environment)
//
// Precedence for every AI provider, evaluated per request:
//   1. DASHBOARD credential  (ai_provider_credentials row, AES-GCM encrypted)
//   2. ENVIRONMENT credential (ZAI_API_KEY / OPENAI_API_KEY / GROQ_API_KEY /
//      OPENROUTER_API_KEY — unchanged, existing deployments keep working)
//
// A dashboard row with enabled = 0 means the owner turned the provider OFF in
// the dashboard — it is excluded from routing entirely (no env fallback for a
// provider the owner explicitly disabled).
//
// SECURITY INVARIANTS:
//   - The encryption key (AI_CREDENTIALS_SECRET) never enters D1, logs or
//     responses. It is read from the Worker environment only.
//   - Decryption happens ONLY when a provider is actually attempted/tested;
//     eligibility checks read row metadata without decrypting.
//   - A decrypted key lives in request-local memory only — never in module
//     scope, never in globalThis, never persisted.

import { getEnv } from "../env";
import { encryptCredential, decryptCredential } from "./credential-crypto";

/** Clear, actionable error thrown when AI_CREDENTIALS_SECRET is missing. */
export class CredentialSecretMissingError extends Error {
  constructor() {
    super(
      "AI_CREDENTIALS_SECRET is not configured — stored provider keys cannot be " +
        "encrypted/decrypted. Run: npx wrangler secret put AI_CREDENTIALS_SECRET " +
        "(or set it in .dev.vars for local development).",
    );
    this.name = "CredentialSecretMissingError";
  }
}

async function getCredentialSecret(): Promise<string> {
  const env = await getEnv();
  const secret = env.AI_CREDENTIALS_SECRET;
  if (!secret || secret.length < 16) throw new CredentialSecretMissingError();
  return secret;
}

/** Encrypt an API key for storage. Returns the ciphertext + display hint. */
export async function encryptApiKey(
  plaintext: string,
): Promise<{ encrypted: string; keyHint: string }> {
  const secret = await getCredentialSecret();
  const encrypted = await encryptCredential(secret, plaintext);
  return { encrypted, keyHint: plaintext.slice(-4) };
}

/**
 * Decrypt a stored API key (server-side only, call-time only).
 * Throws CredentialSecretMissingError when the secret is not configured and a
 * plain Error when the ciphertext cannot be decrypted (wrong/tampered).
 */
export async function decryptApiKey(encrypted: string): Promise<string> {
  const secret = await getCredentialSecret();
  try {
    return await decryptCredential(secret, encrypted);
  } catch (e) {
    if (e instanceof CredentialSecretMissingError) throw e;
    throw new Error(
      "Stored provider credential could not be decrypted — AI_CREDENTIALS_SECRET " +
        "may have changed since the key was saved. Remove and re-add the key.",
    );
  }
}
