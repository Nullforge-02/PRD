// ALPHA — AI credential encryption (AES-256-GCM via Web Crypto)
//
// Dashboard-managed AI provider API keys are encrypted BEFORE they are stored
// in D1 and decrypted ONLY server-side, only when a provider is actually
// attempted. This module is deliberately dependency-free (pure Web Crypto +
// TextEncoder — the exact APIs Cloudflare Workers supports; no Node crypto).
//
// Construction:
//   key   = HKDF-SHA256(AI_CREDENTIALS_SECRET, salt="alpha-ai-credentials-v1",
//                       info=<purpose>)  → AES-256-GCM key
//   iv    = crypto.getRandomValues(12 bytes)  — UNIQUE per encryption
//   out   = "v1." + b64url(iv) + "." + b64url(ciphertext+GCM-tag)
//
// The `purpose` label provides key separation between credential classes
// (AI provider keys vs OAuth tokens) while deriving from the same Worker
// secret. The DEFAULT purpose is byte-identical to the original label, so
// all existing v1 ciphertexts keep decrypting unchanged.
//
// AES-GCM is authenticated encryption: a wrong secret, a tampered ciphertext
// or a truncated payload all fail decryption (throw) — they can never produce
// a different valid key. The encryption secret itself NEVER enters D1, logs,
// API responses or error messages.
//
// This module is pure (no Next.js / env imports) so it can be unit-tested
// directly with `bun run scripts/test-credential-crypto.ts`.

const IV_BYTES = 12;
const KEY_BITS = 256;
const HKDF_SALT = "alpha-ai-credentials-v1";
/** Default purpose — AI provider API keys (unchanged for existing ciphertexts). */
export const CRYPTO_PURPOSE_AI_CREDENTIALS = "alpha:ai-credential-encryption";
/** Dedicated purpose for OAuth access/refresh tokens (key separation). */
export const CRYPTO_PURPOSE_OAUTH_TOKENS = "alpha:oauth-token-encryption";
const FORMAT_PREFIX = "v1";

function toB64Url(bytes: Uint8Array): string {
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function fromB64Url(value: string): Uint8Array {
  const padded = value.replace(/-/g, "+").replace(/_/g, "/");
  const bin = atob(padded + "=".repeat((4 - (padded.length % 4)) % 4));
  return Uint8Array.from(bin, (c) => c.charCodeAt(0));
}

/**
 * Derive the AES-256-GCM key from the Worker secret via HKDF-SHA256.
 * HKDF is fast (one HMAC pass) so per-request decryption stays cheap, and it
 * is a standard Web Crypto algorithm fully supported on Cloudflare Workers.
 */
async function deriveKey(secret: string, purpose: string): Promise<CryptoKey> {
  const purposeLabel = purpose || CRYPTO_PURPOSE_AI_CREDENTIALS;
  const hkdfKey = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    "HKDF",
    false,
    ["deriveBits"],
  );
  const bits = await crypto.subtle.deriveBits(
    {
      name: "HKDF",
      hash: "SHA-256",
      salt: new TextEncoder().encode(HKDF_SALT),
      info: new TextEncoder().encode(purposeLabel),
    },
    hkdfKey,
    KEY_BITS,
  );
  return crypto.subtle.importKey("raw", bits, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt",
  ]);
}

/**
 * Encrypt a secret (API key / OAuth token). Every call uses a fresh random
 * IV, so encrypting the same plaintext twice produces different ciphertexts.
 * `purpose` selects the HKDF info label — use CRYPTO_PURPOSE_OAUTH_TOKENS for
 * OAuth tokens and the default for AI provider keys.
 */
export async function encryptCredential(
  secret: string,
  plaintext: string,
  purpose: string = CRYPTO_PURPOSE_AI_CREDENTIALS,
): Promise<string> {
  const key = await deriveKey(secret, purpose);
  const iv = crypto.getRandomValues(new Uint8Array(IV_BYTES));
  const ciphertext = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: iv as unknown as BufferSource },
    key,
    new TextEncoder().encode(plaintext),
  );
  return `${FORMAT_PREFIX}.${toB64Url(iv)}.${toB64Url(new Uint8Array(ciphertext))}`;
}

/**
 * Decrypt a credential produced by encryptCredential.
 * Throws when the payload is malformed, was encrypted with a different
 * secret, or was tampered with (GCM authentication failure).
 */
export async function decryptCredential(
  secret: string,
  payload: string,
  purpose: string = CRYPTO_PURPOSE_AI_CREDENTIALS,
): Promise<string> {
  const parts = payload.split(".");
  if (parts.length !== 3 || parts[0] !== FORMAT_PREFIX || !parts[1] || !parts[2]) {
    throw new Error("Invalid encrypted credential format");
  }
  const iv = fromB64Url(parts[1]);
  const data = fromB64Url(parts[2]);
  if (iv.length !== IV_BYTES) throw new Error("Invalid encrypted credential IV");
  const key = await deriveKey(secret, purpose);
  const plaintext = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: iv as unknown as BufferSource },
    key,
    data as unknown as BufferSource,
  );
  return new TextDecoder().decode(plaintext);
}
