// ALPHA — AI routing engine
//
// Every AI request flows through this router:
//
//   call site (chat engine, tools, media/voice/vision routes)
//     ↓ capability ("chat" | "vision" | "imageGeneration" | "webSearch" | "tts" | "asr" | …)
//     ↓ optional userId (enables dashboard-managed credentials + custom providers)
//   eligible providers = enabled + configured + capability + not in cooldown
//     ↓ priority order (see below)
//   execute on the first eligible provider
//     ↓ on a fallbackable failure (auth / rate-limit / timeout / network / 5xx)
//   mark unhealthy (cooldown), try the NEXT eligible provider
//     ↓ strict maximum: AI_MAX_ATTEMPTS distinct providers per request (default 3)
//
// TWO provider families, merged into ONE ordered candidate list:
//
//   1. CUSTOM providers (ai_custom_providers rows, D1 — unlimited, user
//      configured in Settings → AI Providers → + Add API, any
//      OpenAI-compatible endpoint). Credentials are AES-GCM encrypted;
//      decryption happens ONLY at attempt time.
//   2. BUILT-IN providers (zai / openai / groq / openrouter — unchanged,
//      including their dashboard credentials in ai_provider_credentials
//      with dashboard → environment precedence).
//
// Priority ordering (lower number = tried earlier):
//   - custom providers: their user-configured priority (default 1), then
//     created_at; a custom provider with the same priority as a built-in
//     sorts BEFORE it (an explicit user choice wins over env defaults).
//   - built-in providers: AI_PRIMARY_PROVIDER → AI_FALLBACK_PROVIDERS → rest.
//
// Guarantees (unchanged from the original router):
//   - A request is NEVER routed to a provider that lacks the capability.
//   - invalid_request errors (malformed input) are NOT retried elsewhere.
//   - No infinite retry loops — a bounded number of provider attempts.
//   - If no provider can serve the capability → CapabilityUnavailableError.
//   - If all capable providers are in cooldown → AllProvidersUnavailableError.
//   - Health is recorded from REAL request outcomes only.
//   - Decrypted keys live only in request-local memory — never in module
//     scope, never in globalThis, never logged.

import type { AIProvider, CapabilityKey, ChatOptions, ChatResult, ProviderChatMessage } from "./types";
import { getRegistry, getMaxAttempts, buildProviderInstance } from "./registry";
import { recordFailure, recordSuccess, isAvailable } from "./health";
import type { ProviderCredential } from "../repos/provider-credentials";
import { credentialMap } from "../repos/provider-credentials";
import { listCustomProviders, type CustomProvider } from "../repos/custom-providers";
import { decryptApiKey } from "./credentials";
import { buildGenericProvider } from "./providers/generic";
import { capabilitiesToFlags } from "./capabilities";
import {
  AllProvidersUnavailableError,
  CapabilityUnavailableError,
  ProviderError,
  isFallbackable,
} from "./errors";

/** Extra routing context (all optional — keeps existing call sites working). */
export interface RoutingOptions {
  /** Session user id — enables dashboard-managed + custom provider credentials. */
  userId?: string | null;
}

/**
 * A provider selected as eligible. Credential state was resolved from
 * METADATA only (configured/enabled); the actual instance (and key
 * decryption) happens lazily in build(), when the provider is actually
 * attempted. `priority`/`custom` drive the merged ordering.
 */
interface PreparedProvider {
  id: string;
  /** Display name (safe — no secrets). */
  name: string;
  custom: boolean;
  /** Sort key: lower = earlier. Custom providers win ties against built-ins. */
  order: number;
  /** Lazily build the attempt-time instance (decrypts credentials). */
  build: () => Promise<AIProvider>;
}

/** Merge custom D1 providers + built-in registry rows into one ordered list. */
async function prepareProviders(
  capability: CapabilityKey,
  routing: RoutingOptions,
): Promise<PreparedProvider[]> {
  // ---- Built-in providers (env registry + their dashboard credentials) ----
  const registry = await getRegistry();
  const rows = routing.userId ? await credentialMap(routing.userId) : null;

  const prepared: PreparedProvider[] = [];
  for (const { provider, enabled, priority } of registry) {
    if (!enabled) continue; // AI_DISABLED_PROVIDERS
    if (!provider.capabilities[capability]) continue;

    const row = rows?.get(provider.id) ?? null;
    if (row) {
      // Dashboard credential exists → it takes precedence. A disabled
      // dashboard row means the owner turned this provider OFF — excluded
      // entirely (no env fallback for an explicitly disabled provider).
      if (!row.enabled) continue;
    } else {
      // No dashboard credential → environment fallback.
      if (!(await provider.isConfigured())) continue;
    }

    if (!isAvailable(provider.id)) continue;
    const envProvider = provider;
    const cred = row;
    prepared.push({
      id: provider.id,
      name: provider.name,
      custom: false,
      order: priority,
      build: async () => {
        if (!cred) return envProvider;
        const apiKey = await decryptApiKey(cred.encryptedApiKey);
        return buildProviderInstance(provider.id, {
          apiKey,
          baseUrl: cred.baseUrl,
          model: cred.model,
          visionModel: cred.visionModel,
        });
      },
    });
  }

  // ---- Custom providers (D1 rows, unlimited) ----
  if (routing.userId) {
    const customs = await listCustomProviders(routing.userId);
    for (const custom of customs) {
      if (!custom.enabled) continue;
      // The user's capability selection is authoritative — routing honors
      // exactly what was configured (never invented).
      if (!capabilitiesToFlags(custom.capabilities)[capability]) continue;
      if (!isAvailable(custom.id)) continue;
      prepared.push(toPreparedCustom(custom));
    }
  }

  // Merged order: priority ASC; on ties custom providers come first
  // (explicit user choice wins over environment defaults).
  prepared.sort((a, b) => a.order - b.order || Number(b.custom) - Number(a.custom));
  return prepared;
}

/** Build the lazy attempt-time instance for a custom provider row. */
function toPreparedCustom(custom: CustomProvider): PreparedProvider {
  return {
    id: custom.id,
    name: custom.name,
    custom: true,
    order: custom.priority,
    build: async () => {
      // Decrypt ONLY now (attempt time), use once, discard.
      const apiKey = await decryptApiKey(custom.encryptedApiKey);
      return buildGenericProvider({
        id: custom.id,
        name: custom.name,
        apiKey,
        baseUrl: custom.baseUrl,
        model: custom.model,
        visionModel: custom.visionModel,
        imageModel: custom.imageModel,
        capabilities: custom.capabilities,
      });
    },
  };
}

/**
 * Providers eligible for a capability right now (priority order).
 *
 * INTROSPECTION VIEW: built-ins only (existing semantics). Request paths use
 * withFallback/getProviderFor, which resolve dashboard + custom credentials
 * lazily per attempt. This helper does not decrypt anything.
 */
export async function eligibleProviders(capability: CapabilityKey): Promise<AIProvider[]> {
  const registry = await getRegistry();
  const eligible: AIProvider[] = [];
  for (const { provider, enabled } of registry) {
    if (!enabled) continue;
    if (!provider.capabilities[capability]) continue;
    if (!(await provider.isConfigured())) continue;
    if (!isAvailable(provider.id)) continue;
    eligible.push(provider);
  }
  return eligible;
}

/** IDs of all providers (built-in AND custom) able to serve a capability. */
async function capableConfiguredIds(
  capability: CapabilityKey,
  routing: RoutingOptions,
): Promise<{ capable: string[]; configured: string[] }> {
  const registry = await getRegistry();
  const rows = routing.userId ? await credentialMap(routing.userId) : null;
  const customs = routing.userId ? await listCustomProviders(routing.userId) : [];

  const configured: string[] = [];
  const capable: string[] = [];
  for (const { provider, enabled } of registry) {
    if (!enabled) continue;
    const row = rows?.get(provider.id) ?? null;
    if (row ? !row.enabled : !(await provider.isConfigured())) continue;
    configured.push(provider.name);
    if (provider.capabilities[capability]) capable.push(provider.name);
  }
  for (const custom of customs) {
    if (!custom.enabled) continue;
    configured.push(custom.name);
    if (capabilitiesToFlags(custom.capabilities)[capability]) capable.push(custom.name);
  }
  return { capable, configured };
}

/**
 * Pick the provider to serve a capability (highest-priority eligible one).
 * Throws CapabilityUnavailableError when nobody can serve it.
 */
export async function getProviderFor(
  capability: CapabilityKey,
  routing: RoutingOptions = {},
): Promise<AIProvider> {
  const prepared = await prepareProviders(capability, routing);
  if (prepared.length > 0) {
    try {
      return await prepared[0].build();
    } catch (e) {
      // Fall through to the error classification below; the first provider's
      // credential could not be decrypted (e.g. missing AI_CREDENTIALS_SECRET).
      const category = e instanceof ProviderError ? e.category : "configuration";
      recordFailure(prepared[0].id, category, e instanceof Error ? e.message : String(e));
    }
  }

  // Distinguish "capability exists but all in cooldown" from "nobody supports it".
  const { capable, configured } = await capableConfiguredIds(capability, routing);
  if (capable.length > 0) {
    throw new AllProvidersUnavailableError(capability, capable);
  }
  throw new CapabilityUnavailableError(capability, configured);
}

/**
 * Execute an AI operation with automatic provider fallback.
 *
 * `op` receives the chosen provider (guaranteed to declare the capability —
 * call sites still null-check optional methods for TypeScript). On a
 * fallbackable failure the provider is marked unhealthy (cooldown) and the
 * next eligible provider is tried, up to AI_MAX_ATTEMPTS distinct providers.
 *
 * Credentials (dashboard AND custom) are decrypted per provider AT ATTEMPT
 * TIME only — never all upfront, never cached across requests.
 */
export async function withFallback<T>(
  capability: CapabilityKey,
  op: (provider: AIProvider) => Promise<T>,
  routing: RoutingOptions = {},
): Promise<T> {
  const maxAttempts = await getMaxAttempts();
  const prepared = await prepareProviders(capability, routing);

  if (prepared.length === 0) {
    // Reuse getProviderFor's precise error classification.
    await getProviderFor(capability, routing);
    throw new CapabilityUnavailableError(capability, []);
  }

  const attempts = prepared.slice(0, maxAttempts);
  let lastError: unknown = null;

  for (const candidate of attempts) {
    const start = Date.now();
    let provider: AIProvider;
    try {
      // Lazy decrypt + per-request instance construction (attempt time).
      provider = await candidate.build();
    } catch (e) {
      lastError = e;
      recordFailure(
        candidate.id,
        "configuration",
        e instanceof Error ? e.message : String(e),
      );
      continue; // Credential unusable — try the next provider.
    }
    try {
      const result = await op(provider);
      recordSuccess(provider.id, Date.now() - start);
      return result;
    } catch (e) {
      lastError = e;
      const category =
        e instanceof ProviderError
          ? e.category
          : e instanceof Error && e.name === "ProviderNotConfiguredError"
            ? "configuration"
            : "server_error";
      recordFailure(
        provider.id,
        category,
        e instanceof Error ? e.message : String(e),
      );
      if (!isFallbackable(category)) {
        // invalid_request — the request itself is wrong; rethrow immediately.
        throw e;
      }
      // else: fall through to the next eligible provider.
    }
  }

  throw lastError ?? new AllProvidersUnavailableError(capability, attempts.map((p) => p.name));
}

/** Chat completion with provider fallback — the chat engine's entry point. */
export function completeWithFallback(
  messages: ProviderChatMessage[],
  options?: ChatOptions,
  routing: RoutingOptions = {},
): Promise<ChatResult> {
  return withFallback(
    "chat",
    (provider) => provider.complete(messages, options),
    routing,
  );
}
