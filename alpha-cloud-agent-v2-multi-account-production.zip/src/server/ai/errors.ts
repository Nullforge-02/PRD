// ALPHA — AI provider error taxonomy
//
// Every provider failure is normalized into a ProviderError carrying a
// category. The router uses the category to decide whether a fallback to the
// next provider makes sense:
//
//   authentication  → mark provider unhealthy (long cooldown), try next provider
//   rate_limit      → cooldown, try next provider
//   timeout         → cooldown, try next provider
//   network         → cooldown, try next provider
//   server_error    → cooldown, try next provider
//   configuration   → try next provider (should not have been selected)
//   capability_unavailable → only another provider WITH the capability helps
//   invalid_request → rethrow immediately (malformed input / our bug —
//                     falling back would just repeat the same mistake)
//
// Error MESSAGES must never contain credentials, authorization headers or API
// keys — only safe, provider-returned status/text.

export type ErrorCategory =
  | "authentication"
  | "rate_limit"
  | "timeout"
  | "network"
  | "server_error"
  | "invalid_request"
  | "capability_unavailable"
  | "configuration";

/** Normalized provider failure. Category drives fallback + cooldown policy. */
export class ProviderError extends Error {
  readonly category: ErrorCategory;
  readonly provider: string;
  /** HTTP status from the upstream API, when the failure came from HTTP. */
  readonly status?: number;

  constructor(provider: string, category: ErrorCategory, message: string, status?: number) {
    super(message);
    this.name = "ProviderError";
    this.provider = provider;
    this.category = category;
    this.status = status;
  }
}

/** No configured provider offers the requested capability. */
export class CapabilityUnavailableError extends ProviderError {
  constructor(requested: string, configuredIds: string[]) {
    super(
      "router",
      "capability_unavailable",
      `No configured AI provider supports "${requested}".` +
        (configuredIds.length
          ? ` Configured providers: ${configuredIds.join(", ")}.`
          : " No AI provider is configured at all."),
    );
    this.name = "CapabilityUnavailableError";
  }
}

/** Providers exist for the capability but all are temporarily unavailable. */
export class AllProvidersUnavailableError extends ProviderError {
  constructor(requested: string, ids: string[]) {
    super(
      "router",
      "server_error",
      `All AI providers capable of "${requested}" are temporarily unavailable (${ids.join(", ")}). ` +
        "They are in a failure cooldown — retry shortly.",
    );
    this.name = "AllProvidersUnavailableError";
  }
}

/** Map an HTTP status code from an upstream provider to an error category. */
export function categoryForStatus(status: number): ErrorCategory {
  if (status === 401 || status === 403) return "authentication";
  if (status === 429) return "rate_limit";
  if (status === 408) return "timeout";
  if (status === 400 || status === 404 || status === 405 || status === 422) return "invalid_request";
  if (status >= 500) return "server_error";
  return "server_error";
}

/**
 * Best-effort category inference for errors thrown by SDKs / fetch that do
 * not carry structured information (used by the Z.ai SDK adapter).
 */
export function inferCategory(error: unknown): ErrorCategory {
  if (error instanceof ProviderError) return error.category;
  const message = error instanceof Error ? error.message : String(error);
  const lower = message.toLowerCase();
  if (lower.includes("not configured") || lower.includes("missing credential")) return "configuration";
  if (/\b401\b|\b403\b|unauthorized|forbidden|invalid api key|invalid_api_key/.test(lower)) return "authentication";
  if (/\b429\b|rate limit|rate_limit|quota/.test(lower)) return "rate_limit";
  if (lower.includes("timeout") || lower.includes("timed out") || lower.includes("aborted")) return "timeout";
  if (lower.includes("network") || lower.includes("fetch failed") || lower.includes("econn") || lower.includes("enotfound") || lower.includes("dns")) return "network";
  if (lower.includes("bad request") || lower.includes("invalid request") || lower.includes("invalid_request") || lower.includes("model_not_found")) return "invalid_request";
  return "server_error";
}

/** True when a failure of this category should trigger fallback to the next provider. */
export function isFallbackable(category: ErrorCategory): boolean {
  // invalid_request is intentionally NOT fallbackable — the request itself is
  // wrong and would fail identically on the next provider.
  return category !== "invalid_request";
}

/**
 * Map an error category to a SAFE human-readable message for client-facing
 * surfaces (e.g. Test Connection results). These fixed strings guarantee no
 * raw upstream response body, key material or authorization header can leak
 * into an API response.
 */
export function safeCategoryMessage(category: ErrorCategory): string {
  switch (category) {
    case "authentication":
      return "Authentication failed — check the API key";
    case "rate_limit":
      return "Rate limited by the provider — try again shortly";
    case "timeout":
      return "The provider timed out";
    case "network":
      return "Network error reaching the provider";
    case "invalid_request":
      return "The provider rejected the request — check the model id";
    case "capability_unavailable":
      return "The provider does not support this operation";
    case "configuration":
      return "Configuration error — the credential could not be used";
    case "server_error":
    default:
      return "The provider returned a server error";
  }
}

/** Cooldown (ms) applied to a provider after a failure of the given category. */
export function cooldownFor(category: ErrorCategory, consecutiveFailures: number): number {
  const base: Record<ErrorCategory, number> = {
    authentication: 15 * 60_000, // 15 min — retrying sooner is pointless
    rate_limit: 60_000,
    timeout: 30_000,
    network: 30_000,
    server_error: 30_000,
    invalid_request: 0,
    capability_unavailable: 0,
    configuration: 5 * 60_000,
  };
  // Mild backoff for repeat offenders (capped at 4×) — no retry loops.
  const factor = Math.min(Math.max(consecutiveFailures, 1), 4);
  return base[category] * factor;
}
