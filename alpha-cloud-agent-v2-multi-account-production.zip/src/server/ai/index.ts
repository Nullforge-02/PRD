// ALPHA — AI subsystem public API
//
// Call sites import from THIS module only:
//   completeWithFallback / withFallback / getProviderFor  — routing
//   listProviders / pingAllProviders / pingProvider       — status APIs
//
// Providers live in ./providers/*, the routing engine in ./router.ts,
// health tracking in ./health.ts, configuration in ./registry.ts,
// dashboard credential crypto in ./credentials.ts.
// No call site outside this directory knows which providers exist.
//
// SECURITY: nothing exported here ever returns an API key, token, secret or
// authorization header — dashboard keys are shown ONLY as a masked form
// (••••••••••••<last-4>), and environment keys are never echoed at all.

import type { AIProvider, CapabilityKey } from "./types";
import { capabilityList } from "./types";
import { getRegistry, buildProviderInstance, getProviderDescriptors } from "./registry";
import { getHealth, recordFailure, recordSuccess, isAvailable, type ProviderHealthRecord } from "./health";
import { inferCategory } from "./errors";
import { completeWithFallback, getProviderFor, withFallback, type RoutingOptions } from "./router";
import { decryptApiKey } from "./credentials";
import type { ProviderCredential } from "../repos/provider-credentials";
import { credentialMap } from "../repos/provider-credentials";
import { listCustomProviders, type CustomProvider } from "../repos/custom-providers";
import { buildGenericProvider } from "./providers/generic";
import { capabilitiesToFlags, type UserCapability } from "./capabilities";

export interface ProviderStatus {
  id: string;
  name: string;
  /** Included in routing decisions (env AI_DISABLED_PROVIDERS + dashboard). */
  enabled: boolean;
  /** Credential present (dashboard row OR environment variable). */
  configured: boolean;
  /** Where the active credential comes from (never the credential itself). */
  source: "dashboard" | "environment" | null;
  /** Masked dashboard key (••••••••••••abcd) — null for env credentials. */
  maskedKey: string | null;
  /** Effective chat model (dashboard override → env → provider default). */
  model: string;
  /** Effective vision model (dashboard override → env → default). */
  visionModel: string;
  /** Dashboard-configured base URL (null when not overridden). */
  baseUrl: string | null;
  /** UI-safe defaults for placeholders (public endpoints, no secrets). */
  defaultBaseUrl: string;
  defaultModel: string;
  defaultVisionModel: string;
  /** Dashboard-editable fields supported by this provider. */
  supportsBaseUrl: boolean;
  supportsVisionModel: boolean;
  /** Health snapshot — real observations only, "unknown" until first use. */
  healthy: boolean;
  status: ProviderHealthRecord["status"];
  latencyMs: number | null;
  capabilities: string[];
  priority: number;
  lastErrorCategory: string | null;
  /** Last Test Connection outcome (dashboard credential; real requests). */
  lastTestedAt: string | null;
  lastTestStatus: "success" | "failed" | null;
  /** Safe configuration guidance (no secrets). */
  guide: string;
}

/** Credential rows for the user (or an empty map when no user context). */
async function rowsFor(routing: RoutingOptions): Promise<Map<string, ProviderCredential>> {
  return routing.userId ? await credentialMap(routing.userId) : new Map();
}

/**
 * Resolve the instance used for a REAL attempt/ping of a provider:
 * dashboard credential first (lazy decrypt), environment fallback.
 * Returns null when the provider has no usable credential at all.
 */
async function instanceForAttempt(
  providerId: string,
  envProvider: AIProvider,
  row: ProviderCredential | null,
): Promise<AIProvider | null> {
  if (!row) {
    return (await envProvider.isConfigured()) ? envProvider : null;
  }
  if (!row.enabled) return null;
  const apiKey = await decryptApiKey(row.encryptedApiKey);
  return buildProviderInstance(providerId, {
    apiKey,
    baseUrl: row.baseUrl,
    model: row.model,
    visionModel: row.visionModel,
  });
}

/**
 * Provider registry status for the APIs — NEVER includes secrets.
 * `configured: false` providers report status "offline" (never "healthy").
 */
export async function listProviders(routing: RoutingOptions = {}): Promise<ProviderStatus[]> {
  const registry = await getRegistry();
  const rows = await rowsFor(routing);
  const descriptors = new Map(getProviderDescriptors().map((d) => [d.id, d]));

  const statuses: ProviderStatus[] = [];
  for (const { provider, priority, enabled } of registry) {
    const row = rows.get(provider.id) ?? null;
    const envConfigured = await provider.isConfigured();
    const configured = !!row || envConfigured;
    const source = row ? "dashboard" : envConfigured ? "environment" : null;
    const effectiveEnabled = enabled && (!row || row.enabled);
    const health = getHealth(provider.id);
    const status = !configured || !effectiveEnabled ? "offline" : health.status;
    const descriptor = descriptors.get(provider.id);

    statuses.push({
      id: provider.id,
      name: provider.name,
      enabled: effectiveEnabled,
      configured,
      source,
      maskedKey: row && row.keyHint ? `••••••••••••${row.keyHint}` : null,
      model: row?.model || (await provider.defaultModel()),
      visionModel: row?.visionModel || descriptor?.defaultVisionModel || "",
      baseUrl: row?.baseUrl ?? null,
      defaultBaseUrl: descriptor?.defaultBaseUrl ?? "",
      defaultModel: descriptor?.defaultModel ?? "",
      defaultVisionModel: descriptor?.defaultVisionModel ?? "",
      supportsBaseUrl: descriptor?.supportsBaseUrl ?? false,
      supportsVisionModel: descriptor?.supportsVisionModel ?? false,
      healthy: configured && effectiveEnabled && status === "healthy",
      status,
      latencyMs: configured ? health.latencyMs : null,
      capabilities: capabilityList(provider.capabilities),
      priority,
      lastErrorCategory: health.lastErrorCategory,
      lastTestedAt: row?.lastTestedAt ?? null,
      lastTestStatus: row?.lastTestStatus ?? null,
      guide: provider.configurationGuide(),
    });
  }
  return statuses;
}

/** Ping every configured provider (real requests) and return live statuses. */
export async function pingAllProviders(routing: RoutingOptions = {}): Promise<ProviderStatus[]> {
  const registry = await getRegistry();
  const rows = await rowsFor(routing);
  await Promise.all(
    registry
      .filter(({ enabled }) => enabled)
      .map(async ({ provider }) => {
        const row = rows.get(provider.id) ?? null;
        // Never ping unconfigured providers (dashboard row OR env key needed).
        const start = Date.now();
        let instance: AIProvider | null = null;
        try {
          instance = await instanceForAttempt(provider.id, provider, row);
        } catch (e) {
          recordFailure(
            provider.id,
            "configuration",
            e instanceof Error ? e.message : String(e),
          );
          return;
        }
        if (!instance) return; // not configured — nothing real to ping
        try {
          const latency = await instance.ping();
          recordSuccess(provider.id, latency || Date.now() - start);
        } catch (e) {
          recordFailure(
            provider.id,
            inferCategory(e),
            e instanceof Error ? e.message : String(e),
          );
        }
      }),
  );
  return listProviders(routing);
}

/** Live-ping a single provider by id (real request, real latency). */
export async function pingProvider(
  id: string,
  routing: RoutingOptions = {},
): Promise<ProviderStatus | null> {
  const registry = await getRegistry();
  const entry = registry.find((r) => r.provider.id === id);
  if (!entry) return null;

  const rows = await rowsFor(routing);
  const row = rows.get(id) ?? null;
  const start = Date.now();
  let instance: AIProvider | null = null;
  try {
    instance = await instanceForAttempt(id, entry.provider, row);
  } catch (e) {
    recordFailure(id, "configuration", e instanceof Error ? e.message : String(e));
    return (await listProviders(routing)).find((p) => p.id === id) ?? null;
  }
  if (!instance) {
    return (await listProviders(routing)).find((p) => p.id === id) ?? null;
  }
  try {
    const latency = await instance.ping();
    recordSuccess(id, latency || Date.now() - start);
  } catch (e) {
    recordFailure(id, inferCategory(e), e instanceof Error ? e.message : String(e));
  }
  return (await listProviders(routing)).find((p) => p.id === id) ?? null;
}

export { completeWithFallback, getProviderFor, withFallback };
export type { AIProvider, CapabilityKey, RoutingOptions };

// ============================================================
// CUSTOM providers (unlimited, user-configured, D1-backed)
// ============================================================

/** UI/API-safe status of a custom provider — NEVER includes key material. */
export interface CustomProviderStatus {
  id: string;
  name: string;
  protocol: string;
  configured: true;
  enabled: boolean;
  priority: number;
  /** Masked key (••••••••••••••abcd) — the plaintext is never returned. */
  maskedKey: string;
  baseUrl: string;
  model: string;
  visionModel: string | null;
  imageModel: string | null;
  videoModel: string | null;
  capabilities: UserCapability[];
  /** Real health from actual requests — "unknown" until first observation. */
  status: ProviderHealthRecord["status"];
  latencyMs: number | null;
  lastErrorCategory: string | null;
  lastTestedAt: string | null;
  lastTestStatus: "success" | "failed" | null;
  createdAt: string;
  updatedAt: string;
}

function customStatus(p: CustomProvider): CustomProviderStatus {
  const health = getHealth(p.id);
  const status = !p.enabled ? "offline" : health.status;
  return {
    id: p.id,
    name: p.name,
    protocol: p.protocol,
    configured: true,
    enabled: p.enabled,
    priority: p.priority,
    maskedKey: p.keyHint ? `••••••••••••${p.keyHint}` : "••••••••••••",
    baseUrl: p.baseUrl,
    model: p.model,
    visionModel: p.visionModel,
    imageModel: p.imageModel,
    videoModel: p.videoModel,
    capabilities: p.capabilities,
    status,
    latencyMs: p.enabled ? health.latencyMs : null,
    lastErrorCategory: health.lastErrorCategory,
    lastTestedAt: p.lastTestedAt,
    lastTestStatus: p.lastTestStatus,
    createdAt: p.createdAt,
    updatedAt: p.updatedAt,
  };
}

/** List the user's custom providers (safe metadata only). */
export async function listCustomProviderStatuses(
  routing: RoutingOptions = {},
): Promise<CustomProviderStatus[]> {
  if (!routing.userId) return [];
  const rows = await listCustomProviders(routing.userId);
  return rows.map(customStatus);
}

/** Live-ping a custom provider by id (real request, real latency). */
export async function pingCustomProvider(
  id: string,
  routing: RoutingOptions = {},
): Promise<CustomProviderStatus | null> {
  if (!routing.userId) return null;
  const rows = await listCustomProviders(routing.userId);
  const row = rows.find((p) => p.id === id);
  if (!row) return null;

  const start = Date.now();
  try {
    const apiKey = await decryptApiKey(row.encryptedApiKey);
    const instance = buildGenericProvider({
      id: row.id,
      name: row.name,
      apiKey,
      baseUrl: row.baseUrl,
      model: row.model,
      visionModel: row.visionModel,
      imageModel: row.imageModel,
      capabilities: row.capabilities,
    });
    const latency = await instance.ping();
    recordSuccess(row.id, latency || Date.now() - start);
  } catch (e) {
    recordFailure(row.id, inferCategory(e), e instanceof Error ? e.message : String(e));
  }
  const refreshed = (await listCustomProviders(routing.userId)).find((p) => p.id === id);
  return refreshed ? customStatus(refreshed) : null;
}

/**
 * The provider the chat composer indicator should show: the first enabled
 * TEXT-capable provider in MERGED routing order (custom providers win
 * priority ties against built-ins — same rule as the router).
 * Pure metadata — no secrets, no decryption.
 */
export async function getPrimaryChatProvider(
  routing: RoutingOptions = {},
): Promise<{
  name: string;
  model: string;
  custom: boolean;
  enabled: boolean;
  configured: boolean;
} | null> {
  type Candidate = { order: number; custom: boolean; name: string; model: string };
  const candidates: Candidate[] = [];

  if (routing.userId) {
    for (const p of await listCustomProviders(routing.userId)) {
      if (!p.enabled) continue;
      if (!capabilitiesToFlags(p.capabilities).chat) continue;
      if (!isAvailable(p.id)) continue;
      candidates.push({ order: p.priority, custom: true, name: p.name, model: p.model });
    }
  }

  const registry = await getRegistry();
  const rows = routing.userId ? await credentialMap(routing.userId) : null;
  for (const { provider, enabled, priority } of registry) {
    if (!enabled || !provider.capabilities.chat) continue;
    const row = rows?.get(provider.id) ?? null;
    if (row ? !row.enabled : !(await provider.isConfigured())) continue;
    if (!isAvailable(provider.id)) continue;
    candidates.push({
      order: priority,
      custom: false,
      name: provider.name,
      model: row?.model || (await provider.defaultModel()),
    });
  }

  candidates.sort((a, b) => a.order - b.order || Number(b.custom) - Number(a.custom));
  const first = candidates[0];
  if (!first) return null;
  return {
    name: first.name,
    model: first.model,
    custom: first.custom,
    enabled: true,
    configured: true,
  };
}
