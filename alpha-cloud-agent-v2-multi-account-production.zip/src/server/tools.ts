// ALPHA — tool registry & executor
//
// REAL tools only. Every tool executes against live data (D1/R2) or a real
// AI capability. Permission tiers gate destructive actions behind explicit
// confirmation (the API returns 409 with requiresConfirmation when a
// medium/high-permission tool is called without confirmed=true).

import { z } from "zod";
import * as notesRepo from "./repos/notes";
import * as memoriesRepo from "./repos/memories";
import * as filesRepo from "./repos/files";
import * as remindersRepo from "./repos/reminders";
import { withFallback } from "./ai";
import { putObject, buildR2Key } from "./storage";
import { createFile } from "./repos/files";
import { createJob, finishJob } from "./repos/system";
import { looksSensitive } from "./context/memory-extract";

export type ToolPermission = "low" | "medium" | "high";

export interface ToolDefinition {
  name: string;
  description: string;
  permission: ToolPermission;
  /** Compact hint of the expected args shape, shown to the chat model. */
  argHint: string;
  argsSchema: z.ZodTypeAny;
  execute: (userId: string, args: unknown) => Promise<unknown>;
}

const MAX_SEARCH_RESULTS = 20;

export const TOOLS: ToolDefinition[] = [
  {
    name: "create_note",
    description: "Create a new note with a title and optional content.",
    argHint: '{ "title": string, "content"?: string }',
    permission: "medium",
    argsSchema: z.object({
      title: z.string().min(1).max(300),
      content: z.string().max(100_000).optional(),
    }),
    async execute(userId, args) {
      const { title, content } = args as { title: string; content?: string };
      const note = await notesRepo.createNote(userId, { title, content });
      return { note };
    },
  },
  {
    name: "search_notes",
    description: "Search the user's notes by keyword. Returns matching notes.",
    argHint: '{ "query": string }',
    permission: "low",
    argsSchema: z.object({ query: z.string().min(1).max(200) }),
    async execute(userId, args) {
      const { query } = args as { query: string };
      const notes = (await notesRepo.listNotes(userId, { query })).slice(0, MAX_SEARCH_RESULTS);
      return { notes };
    },
  },
  {
    name: "read_note",
    description: "Read a single note by id.",
    argHint: '{ "id": string }',
    permission: "low",
    argsSchema: z.object({ id: z.string().min(1) }),
    async execute(userId, args) {
      const { id } = args as { id: string };
      const note = await notesRepo.findNote(id, userId);
      return note ? { note } : { error: "Note not found" };
    },
  },
  {
    name: "save_memory",
    description: "Persist a durable fact/preference about the user to long-term memory.",
    argHint: '{ "content": string, "category"?: "user"|"preferences"|"projects"|"decisions"|"people"|"workflows"|"technical"|"other" }',
    permission: "medium",
    argsSchema: z.object({
      content: z.string().min(1).max(2000),
      category: z.string().min(1).max(50).optional(),
    }),
    async execute(userId, args) {
      const { content, category } = args as { content: string; category?: string };
      // Secret-looking content (api keys, passwords, tokens…) is NEVER
      // persisted — same memory discipline as the chat-auto extractor.
      if (looksSensitive(content)) {
        return {
          error:
            "Refused: that looks like a secret (API key / password / token / credential). Secrets are never stored in long-term memory.",
        };
      }
      const memory = await memoriesRepo.createMemory(userId, {
        content,
        category: category ?? "other",
        source: "ai",
      });
      return { memory };
    },
  },
  {
    name: "search_memory",
    description: "Search the user's long-term memory by keyword.",
    argHint: '{ "query": string }',
    permission: "low",
    argsSchema: z.object({ query: z.string().min(1).max(200) }),
    async execute(userId, args) {
      const { query } = args as { query: string };
      const memories = (await memoriesRepo.listMemories(userId, { query })).slice(0, MAX_SEARCH_RESULTS);
      return { memories };
    },
  },
  {
    name: "search_files",
    description: "Search the user's stored files by filename.",
    argHint: '{ "query": string }',
    permission: "low",
    argsSchema: z.object({ query: z.string().min(1).max(200) }),
    async execute(userId, args) {
      const { query } = args as { query: string };
      const files = (await filesRepo.listFiles(userId, { query })).slice(0, MAX_SEARCH_RESULTS);
      return { files };
    },
  },
  {
    name: "web_search",
    description: "Search the web and return top results (title, snippet, URL).",
    argHint: '{ "query": string, "num"?: number }',
    permission: "low",
    argsSchema: z.object({
      query: z.string().min(1).max(400),
      num: z.number().int().min(1).max(10).optional(),
    }),
    async execute(userId, args) {
      const { query, num } = args as { query: string; num?: number };
      // Routed: only providers with the webSearch capability are eligible.
      const results = await withFallback(
        "webSearch",
        (p) => {
          if (!p.webSearch) throw new Error("Provider does not support web search");
          return p.webSearch(query, num ?? 6);
        },
        { userId },
      );
      return { results };
    },
  },
  {
    name: "generate_image",
    description:
      "Generate an image from a text prompt and store it in the user's media library.",
    argHint:
      '{ "prompt": string, "size"?: "1024x1024"|"768x1344"|"864x1152"|"1344x768"|"1152x864"|"1440x720"|"720x1440" }',
    permission: "medium",
    argsSchema: z.object({
      prompt: z.string().min(1).max(2000),
      size: z
        .enum(["1024x1024", "768x1344", "864x1152", "1344x768", "1152x864", "1440x720", "720x1440"])
        .optional(),
    }),
    async execute(userId, args) {
      const { prompt, size } = args as { prompt: string; size?: string };

      const job = await createJob({ userId, kind: "image_generation", payload: { prompt, size } });
      try {
        const chosenSize = size ?? "1024x1024";
        // Routed: only providers with the imageGeneration capability are eligible.
        const { base64, mime } = await withFallback(
          "imageGeneration",
          (p) => {
            if (!p.generateImage) throw new Error("Provider does not support image generation");
            return p.generateImage(prompt, chosenSize);
          },
          { userId },
        );
        const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
        const ext = mime === "image/jpeg" ? "jpg" : mime === "image/webp" ? "webp" : mime === "image/gif" ? "gif" : "png";
        const r2Key = buildR2Key(userId, `generated.${ext}`, "generated");
        await putObject(r2Key, bytes, mime);
        const file = await createFile({
          userId,
          filename: `generated-${Date.now()}.${ext}`,
          mimeType: mime,
          size: bytes.length,
          r2Key,
          source: "generated",
        });
        await finishJob(job.id, { result: { fileId: file.id } });
        return { file };
      } catch (e) {
        await finishJob(job.id, { error: e instanceof Error ? e.message : String(e) });
        throw e;
      }
    },
  },
  {
    name: "create_reminder",
    description: "Create a reminder for the user. dueAt is epoch milliseconds (optional).",
    argHint: '{ "title": string, "note"?: string, "dueAt"?: number, "priority"?: "low"|"normal"|"high" }',
    permission: "medium",
    argsSchema: z.object({
      title: z.string().min(1).max(300),
      note: z.string().max(2000).optional(),
      dueAt: z.number().int().positive().optional(),
      priority: z.enum(["low", "normal", "high"]).optional(),
    }),
    async execute(userId, args) {
      const { title, note, dueAt, priority } = args as {
        title: string; note?: string; dueAt?: number; priority?: "low" | "normal" | "high";
      };
      const reminder = await remindersRepo.createReminder(userId, {
        title,
        note,
        dueAt,
        priority,
      });
      return { reminder };
    },
  },
  {
    name: "list_reminders",
    description: "List the user's reminders (optionally only open ones).",
    argHint: '{ "done"?: boolean }',
    permission: "low",
    argsSchema: z.object({ done: z.boolean().optional() }),
    async execute(userId, args) {
      const { done } = args as { done?: boolean };
      const reminders = await remindersRepo.listReminders(
        userId,
        done !== undefined ? { done } : {},
      );
      return { reminders: reminders.slice(0, MAX_SEARCH_RESULTS) };
    },
  },
];

export function findTool(name: string): ToolDefinition | undefined {
  return TOOLS.find((t) => t.name === name);
}

export interface ToolExecutionRequest {
  name: string;
  args?: unknown;
  confirmed?: boolean;
}

/** Execute a tool request for a user, enforcing the permission tiers. */
export async function executeTool(userId: string, request: ToolExecutionRequest) {
  const tool = findTool(request.name);
  if (!tool) {
    return { ok: false as const, status: 404, error: `Unknown tool: ${request.name}` };
  }

  const parsed = tool.argsSchema.safeParse(request.args ?? {});
  if (!parsed.success) {
    return {
      ok: false as const,
      status: 400,
      error: `Invalid arguments for ${tool.name}: ${parsed.error.issues
        .map((i) => `${i.path.join(".") || "args"} ${i.message}`)
        .join("; ")}`,
    };
  }

  if (tool.permission !== "low" && !request.confirmed) {
    return {
      ok: false as const,
      status: 409,
      requiresConfirmation: true,
      permission: tool.permission,
      tool: tool.name,
      args: parsed.data,
      message: `Tool "${tool.name}" requires confirmation (${tool.permission} permission).`,
    };
  }

  const result = await tool.execute(userId, parsed.data);
  return { ok: true as const, result };
}

/** Compact manifest used in the chat system prompt. */
export function toolManifest(): string {
  return TOOLS.map(
    (t) => `- ${t.name} ${t.argHint}: ${t.description}`,
  ).join("\n");
}
