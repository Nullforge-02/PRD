// ALPHA — D1 data access helpers
//
// Small, native repository layer over Cloudflare D1 using the documented API:
//   db.prepare(sql).bind(...params).first() / .all() / .run()
//
// No ORM. Rows are snake_case in D1; repositories map to camelCase objects.

import { getEnv } from "./env";

export type D1 = D1Database;

export async function getDb(): Promise<D1> {
  const env = await getEnv();
  if (!env.DB) {
    throw new Error("D1 binding 'DB' is not available — check wrangler.jsonc");
  }
  return env.DB;
}

/** Run a query and return all rows (empty array if none). */
export async function all<T = Record<string, unknown>>(
  sql: string,
  ...params: unknown[]
): Promise<T[]> {
  const db = await getDb();
  const result = await db
    .prepare(sql)
    .bind(...params)
    .all<T>();
  return (result.results ?? []) as T[];
}

/** Run a query and return the first row or null. */
export async function first<T = Record<string, unknown>>(
  sql: string,
  ...params: unknown[]
): Promise<T | null> {
  const db = await getDb();
  return db
    .prepare(sql)
    .bind(...params)
    .first<T>();
}

/** Run a statement (INSERT/UPDATE/DELETE/DDL). */
export async function run(sql: string, ...params: unknown[]): Promise<void> {
  const db = await getDb();
  await db
    .prepare(sql)
    .bind(...params)
    .run();
}

/** Generate a prefixed unique id (crypto.randomUUID is Worker-native). */
export function genId(prefix: string): string {
  return `${prefix}_${crypto.randomUUID().replace(/-/g, "").slice(0, 20)}`;
}

/** Current UTC time as ISO-8601 (used for all TEXT timestamps). */
export function nowIso(): string {
  return new Date().toISOString();
}
