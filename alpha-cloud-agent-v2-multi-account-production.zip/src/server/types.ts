// ALPHA — shared domain types (server)

export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string;
  updatedAt: string;
}

export interface Session {
  id: string;
  userId: string;
  userAgent: string | null;
  ip: string | null;
  createdAt: string;
  lastSeenAt: string;
  expiresAt: string;
  revokedAt: string | null;
  lockedAt: string | null;
}

export interface Conversation {
  id: string;
  userId: string;
  title: string;
  pinned: boolean;
  archived: boolean;
  createdAt: string;
  updatedAt: string;
}

export type MessageRole = "user" | "assistant" | "tool";

export interface Message {
  id: string;
  conversationId: string;
  role: MessageRole;
  content: string;
  model: string | null;
  createdAt: string;
}

export interface Memory {
  id: string;
  userId: string;
  category: string;
  content: string;
  source: string;
  confidence: number;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Note {
  id: string;
  userId: string;
  title: string;
  content: string;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface FileRecord {
  id: string;
  userId: string;
  filename: string;
  mimeType: string;
  size: number;
  r2Key: string;
  source: "upload" | "generated";
  createdAt: string;
  updatedAt: string;
}

export interface Reminder {
  id: string;
  userId: string;
  title: string;
  note: string | null;
  dueAt: number | null;
  priority: "low" | "normal" | "high";
  done: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CalendarEvent {
  id: string;
  userId: string;
  title: string;
  location: string | null;
  startAt: number;
  endAt: number | null;
  attendees: string[];
  source: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditEvent {
  id: string;
  userId: string | null;
  action: string;
  category: string;
  details: string | null;
  ip: string | null;
  createdAt: string;
}

export interface Job {
  id: string;
  userId: string | null;
  kind: string;
  status: "queued" | "running" | "done" | "failed";
  payload: string | null;
  result: string | null;
  error: string | null;
  createdAt: string;
  startedAt: string | null;
  finishedAt: string | null;
}
