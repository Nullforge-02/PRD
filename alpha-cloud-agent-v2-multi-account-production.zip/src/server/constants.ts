// ALPHA — shared server-side constants & validation schemas

import { z } from "zod";

export const MEMORY_CATEGORIES = [
  "user",
  "preferences",
  "projects",
  "decisions",
  "people",
  "workflows",
  "technical",
  "other",
] as const;

export const memoryCategorySchema = z.enum(MEMORY_CATEGORIES);

/** Image sizes supported by the Z.ai image-generation API. */
export const IMAGE_SIZES = [
  "1024x1024",
  "768x1344",
  "864x1152",
  "1344x768",
  "1152x864",
  "1440x720",
  "720x1440",
] as const;

export const imageSizeSchema = z.enum(IMAGE_SIZES);

/** User-facing settings keys (whitelist — everything else is rejected). */
export const SETTING_KEYS = [
  "chat_model",
  "voice",
  "voice_speed",
  "memory_enabled",
  "memory_auto_learn",
  "notifications",
  "density",
  "accent",
] as const;

export const settingKeySchema = z.enum(SETTING_KEYS);
