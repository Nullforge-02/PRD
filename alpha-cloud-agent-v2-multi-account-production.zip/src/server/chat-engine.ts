// ALPHA — chat engine
//
// Real provider responses only. The flow:
//   1. buildContextPackage() assembles the layered, token-bounded context
//      (persona + memories + rolling summary + relevant older messages +
//      verbatim recent window — see src/server/context/engine.ts)
//   2. Send [system, ...recent window, new user message] to the AI provider
//   3. If the model answers with a JSON tool call, execute the real tool and
//      feed the result back (max 2 tool rounds)
//   4. Persist user/assistant/tool messages in D1
//
// Streaming: the final real text is streamed to the client in small chunks
// for a smooth UX (the provider returns complete completions; the pacing
// is cosmetic, the content is 100% the provider's response — and identical
// regardless of which routed provider produced it).

import { completeWithFallback } from "./ai";
import type { ProviderChatMessage } from "./ai/types";
import { addMessage } from "./repos/conversations";
import { buildContextPackage, type ContextStats } from "./context/engine";
import { executeTool, type ToolExecutionRequest } from "./tools";
import type { Message, MessageRole } from "./types";

const MAX_TOOL_ROUNDS = 2;

interface ToolCall {
  tool: string;
  args: unknown;
}

/** Parse a possible JSON tool-call answer. Returns null when not a tool call. */
export function parseToolCall(content: string): ToolCall | null {
  const trimmed = content.trim();
  const fenced = trimmed.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/);
  const candidate = fenced ? fenced[1] : trimmed;
  if (!candidate.startsWith("{")) return null;
  try {
    const parsed = JSON.parse(candidate);
    if (
      parsed &&
      typeof parsed === "object" &&
      typeof parsed.tool === "string" &&
      typeof parsed.args === "object" &&
      parsed.args !== null
    ) {
      return { tool: parsed.tool, args: parsed.args };
    }
  } catch {
    // Not valid JSON — treat as a normal answer.
  }
  return null;
}

export interface ChatTurnResult {
  /** The complete final answer shown to the user. */
  content: string;
  /** Tool executions that happened during this turn (name → result). */
  toolExecutions: Array<{ tool: string; ok: boolean; result?: unknown; error?: string }>;
  model: string;
  /** Display name of the provider that produced the final answer. */
  provider: string;
  /** Layered context stats (surfaced as the X-Alpha-Context header). */
  contextStats: ContextStats;
}

export async function runChatTurn(input: {
  userId: string;
  userName: string;
  model?: string;
  conversationId: string;
  /** FULL persisted history INCLUDING the just-persisted user message last. */
  allMessages: Message[];
  userMessage: string;
  /** Whether tools may be used this turn (disabled during tool previews). */
  enableTools?: boolean;
  /** Optional vision-analysis text appended to the provider's user message. */
  attachmentContext?: string;
}): Promise<ChatTurnResult> {
  // Layered context: persona + memories + summary + relevant older messages
  // in the system prompt; the verbatim recent window as provider messages.
  // Keyword scoring uses the CLEAN user text (attachmentContext would pollute
  // it — it is appended to the provider message below, not into scoring).
  const contextPackage = await buildContextPackage({
    userId: input.userId,
    userName: input.userName,
    conversationId: input.conversationId,
    userMessage: input.userMessage,
    allMessages: input.allMessages,
    enableTools: input.enableTools !== false,
  });

  // Assemble provider messages: system + recent window + new user message
  // (the new message is NOT part of the recent window — appended here once).
  const providerMessages: ProviderChatMessage[] = [
    { role: "system", content: contextPackage.systemPrompt },
    ...contextPackage.recentMessages.map((m) => ({
      role: m.role,
      content: m.content,
    })),
    { role: "user", content: input.userMessage + (input.attachmentContext ?? "") },
  ];
  const contextStats = contextPackage.stats;

  const toolExecutions: ChatTurnResult["toolExecutions"] = [];
  let model = input.model ?? "";
  let provider = "";
  let current = providerMessages;

  for (let round = 0; round <= MAX_TOOL_ROUNDS; round++) {
    // Routed chat completion — the router picks the provider (priority +
    // capability + health) and falls back automatically on provider failure.
    const completion = await completeWithFallback(current, { model: input.model }, { userId: input.userId });
    model = completion.model;
    provider = completion.provider;

    if (input.enableTools === false) {
      return { content: completion.content, toolExecutions, model, provider, contextStats };
    }

    const toolCall = parseToolCall(completion.content);
    if (!toolCall) {
      return { content: completion.content, toolExecutions, model, provider, contextStats };
    }

    // Execute the tool for real.
    const request: ToolExecutionRequest = {
      name: toolCall.tool,
      args: toolCall.args,
      confirmed: true, // confirmed by the model acting within the chat flow
    };
    let execution: Awaited<ReturnType<typeof executeTool>>;
    try {
      execution = await executeTool(input.userId, request);
    } catch (e) {
      execution = {
        ok: false,
        status: 500,
        error: e instanceof Error ? e.message : String(e),
      } as Awaited<ReturnType<typeof executeTool>>;
    }

    if (!execution.ok) {
      toolExecutions.push({ tool: toolCall.tool, ok: false, error: execution.error });
      current = [
        ...current,
        { role: "assistant", content: completion.content },
        {
          role: "user",
          content: `Tool "${toolCall.tool}" failed: ${execution.error}\nAnswer the user directly without the tool.`,
        },
      ];
      continue;
    }

    toolExecutions.push({ tool: toolCall.tool, ok: true, result: execution.result });
    current = [
      ...current,
      { role: "assistant", content: completion.content },
      {
        role: "user",
        content: `Tool "${toolCall.tool}" executed. Result:\n${JSON.stringify(execution.result).slice(0, 6000)}\nNow answer the user based on this real result.`,
      },
    ];
  }

  // Tool-round budget exhausted — ask for a plain final answer.
  const final = await completeWithFallback(
    [...current, { role: "user", content: "Please answer directly now." }],
    { model: input.model },
    { userId: input.userId },
  );
  return {
    content: final.content,
    toolExecutions,
    model: final.model,
    provider: final.provider,
    contextStats,
  };
}

/** Persist a message row (skips empty content). */
export async function persistMessage(
  conversationId: string,
  role: MessageRole,
  content: string,
  model?: string | null,
): Promise<Message> {
  return addMessage({ conversationId, role, content, model: model ?? null });
}

/** Pure greetings / very short filler never make a good conversation title. */
const GREETING_ONLY_RE =
  /^(hi|hey|hello|yo|hiya|sup|thanks|thank you|ok|okay|test|ping|good (morning|afternoon|evening))[!,. ]*$/i;

/** Strip a leading "hey alpha,"-style address from a candidate title. */
function stripLeadingAddress(message: string): string {
  return message
    .replace(/^(?:hi|hey|hello|yo|hiya|sup)[!,. ]+(?:alpha|ai|assistant|bot)?[!,. ]*/i, "")
    .replace(/^(?:alpha|ai|assistant|bot)[,:]+\s*/i, "")
    .trim();
}

/**
 * Derive a conversation title from a user message — deterministic, no AI
 * call. Greeting-only / tiny messages yield the placeholder ("New
 * conversation") so a LATER meaningful message can still title the thread.
 */
export function deriveTitle(message: string): string {
  const clean = message
    .replace(/\s+/g, " ")
    .trim();
  if (!clean || clean.length < 4 || GREETING_ONLY_RE.test(clean)) {
    return "New conversation";
  }
  const meaningful = stripLeadingAddress(clean);
  if (!meaningful || meaningful.length < 4 || GREETING_ONLY_RE.test(meaningful)) {
    return "New conversation";
  }
  return meaningful.length > 60 ? `${meaningful.slice(0, 57)}...` : meaningful;
}

/** True while the conversation still carries a placeholder/greeting title. */
export function isPlaceholderTitle(title: string): boolean {
  return title === "New conversation" || GREETING_ONLY_RE.test(title.trim()) || title.trim().length < 4;
}

/**
 * Convert the final answer into a ReadableStream of text chunks.
 * The provider returns complete completions; chunks are sliced for pacing.
 */
export function streamText(text: string, chunkSize = 24, delayMs = 18): ReadableStream<Uint8Array> {
  const encoder = new TextEncoder();
  let index = 0;
  return new ReadableStream<Uint8Array>({
    async pull(controller) {
      if (index >= text.length) {
        controller.close();
        return;
      }
      const chunk = text.slice(index, index + chunkSize);
      index += chunkSize;
      controller.enqueue(encoder.encode(chunk));
      if (delayMs > 0) {
        await new Promise((r) => setTimeout(r, delayMs));
      }
    },
  });
}
