// ALPHA — real authentication
//
// • Passwords: PBKDF2-SHA256 (100,000 iterations, 16-byte random salt),
//   stored as pbkdf2$<iterations>$<saltB64url>$<hashB64url>. Never plaintext.
//   NOTE: 100,000 is the MAXIMUM iteration count accepted by the Cloudflare
//   Workers Web Crypto implementation (deriveBits rejects anything above it),
//   so both hashing and verification must stay at or below this limit.
// • Sessions: 32 random bytes (base64url) in an HttpOnly cookie. The database
//   stores sha256(hmac(AUTH_SECRET, token)) so a leaked DB cannot forge
//   sessions. Sessions are server-side and revocable (logout, revoke, expire).
// • Lock: a per-session soft lock; unlocking requires the account password.
// • CSRF: state-changing requests must carry a same-origin Origin/Referer.
// • Rate limiting: best-effort in-memory sliding window per identifier.
//   (Per-isolate on Workers — a real but imperfect control, plus audit logs.)
//
// AUTH_SECRET is provided via `wrangler secret put AUTH_SECRET`.
// In production it is REQUIRED. In local development a per-boot ephemeral
// fallback is used (with a console warning) — never in production.

import { NextRequest } from "next/server";
import { getEnv, isProduction } from "./env";
import { genId, nowIso } from "./db";
import * as usersRepo from "./repos/users";
import type { UserWithHash } from "./repos/users";
import * as sessionsRepo from "./repos/sessions";
import { recordAudit } from "./repos/system";
import type { Session, User } from "./types";
import { getClientIp, isHttps } from "./http";

export const SESSION_COOKIE = "alpha_session";
export const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

// ============================================================
// AUTH_SECRET
// ============================================================

const g = globalThis as { __ALPHA_DEV_AUTH_SECRET__?: string };

async function getAuthSecret(): Promise<string> {
  const env = await getEnv();
  if (env.AUTH_SECRET && env.AUTH_SECRET.length >= 16) return env.AUTH_SECRET;
  if (isProduction()) {
    throw new Error(
      "AUTH_SECRET is not configured. Run: npx wrangler secret put AUTH_SECRET",
    );
  }
  // Local development only — ephemeral per boot, sessions die on restart.
  if (!g.__ALPHA_DEV_AUTH_SECRET__) {
    console.warn(
      "[alpha] AUTH_SECRET not set — using ephemeral development secret. " +
        "Set it via .dev.vars (AUTH_SECRET=...) for stable local sessions.",
    );
    g.__ALPHA_DEV_AUTH_SECRET__ = genId("devsecret");
  }
  return g.__ALPHA_DEV_AUTH_SECRET__;
}

// ============================================================
// Password hashing — PBKDF2-SHA256 via Web Crypto (Worker-safe)
// ============================================================

// Cloudflare Workers Web Crypto rejects PBKDF2 iteration counts above
// 100,000 ("iteration counts above 100000 are not supported"). Both
// hashPassword() and verifyPassword() use this exact count.
const PBKDF2_ITERATIONS = 100_000;
const PBKDF2_MAX_SUPPORTED_ITERATIONS = 5_000_000;

function b64url(bytes: Uint8Array): string {
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function pbkdf2(password: string, salt: Uint8Array, iterations: number): Promise<Uint8Array> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(password),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt: salt as unknown as BufferSource, iterations },
    key,
    256,
  );
  return new Uint8Array(bits);
}

export async function hashPassword(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const hash = await pbkdf2(password, salt, PBKDF2_ITERATIONS);
  return `pbkdf2$${PBKDF2_ITERATIONS}$${b64url(salt)}$${b64url(hash)}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  try {
    const [scheme, iterStr, saltB64, hashB64] = stored.split("$");
    if (scheme !== "pbkdf2" || !iterStr || !saltB64 || !hashB64) return false;
    const iterations = parseInt(iterStr, 10);
    // The iteration count is stored WITH the hash, so verification always uses
    // the count the hash was created with. Legacy hashes created with a higher
    // count (e.g. 210,000 from earlier Alpha builds) still parse here; on
    // Cloudflare Workers, deriveBits throws for counts above 100,000 and the
    // catch below fails CLOSED (verification returns false) — never a false
    // accept. This deployment is fresh (setup never completed at 210k), so no
    // such hashes exist in production.
    if (!Number.isFinite(iterations) || iterations < 1 || iterations > PBKDF2_MAX_SUPPORTED_ITERATIONS) return false;
    const salt = Uint8Array.from(
      atob(saltB64.replace(/-/g, "+").replace(/_/g, "/")),
      (c) => c.charCodeAt(0),
    );
    const derived = await pbkdf2(password, salt, iterations);
    const expected = Uint8Array.from(
      atob(hashB64.replace(/-/g, "+").replace(/_/g, "/")),
      (c) => c.charCodeAt(0),
    );
    if (derived.length !== expected.length) return false;
    // Constant-time compare.
    let diff = 0;
    for (let i = 0; i < derived.length; i++) diff |= derived[i] ^ expected[i];
    return diff === 0;
  } catch {
    return false;
  }
}

// ============================================================
// Session tokens
// ============================================================

function newRawToken(): string {
  return b64url(crypto.getRandomValues(new Uint8Array(32)));
}

async function hmac(secret: string, message: string): Promise<Uint8Array> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(message));
  return new Uint8Array(sig);
}

async function hashToken(rawToken: string): Promise<string> {
  const secret = await getAuthSecret();
  const mac = await hmac(secret, rawToken);
  const digest = await crypto.subtle.digest("SHA-256", mac as unknown as BufferSource);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

// ============================================================
// Cookie helpers
// ============================================================

export function readSessionCookie(req: NextRequest): string | null {
  const cookie = req.headers.get("cookie");
  if (!cookie) return null;
  const match = cookie.match(new RegExp(`(?:^|;\\s*)${SESSION_COOKIE}=([^;]+)`));
  return match ? decodeURIComponent(match[1]) : null;
}

export function buildSessionCookie(token: string, req: NextRequest): string {
  const secure = isHttps(req) ? "; Secure" : "";
  return `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${Math.floor(SESSION_TTL_MS / 1000)}${secure}`;
}

export function buildClearCookie(req: NextRequest): string {
  const secure = isHttps(req) ? "; Secure" : "";
  return `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure}`;
}

// ============================================================
// Session lifecycle
// ============================================================

export async function issueSession(
  req: NextRequest,
  userId: string,
): Promise<{ token: string; session: Session }> {
  const token = newRawToken();
  const tokenHash = await hashToken(token);
  const session = await sessionsRepo.createSession({
    userId,
    tokenHash,
    userAgent: req.headers.get("user-agent")?.slice(0, 250) ?? null,
    ip: getClientIp(req),
    ttlMs: SESSION_TTL_MS,
  });
  return { token, session };
}

export interface AuthContext {
  user: UserWithHash;
  session: Session;
}

/** Resolve the authenticated user from the request, or null. */
export async function getAuthContext(req: NextRequest): Promise<AuthContext | null> {
  const raw = readSessionCookie(req);
  if (!raw) return null;
  const tokenHash = await hashToken(raw);
  const session = await sessionsRepo.findSessionByTokenHash(tokenHash);
  if (!session) return null;
  if (session.revokedAt) return null;
  if (Date.parse(session.expiresAt) <= Date.now()) return null;
  const user = await usersRepo.findUserById(session.userId);
  if (!user) return null;
  void sessionsRepo.touchSession(session); // fire & forget (throttled)
  return { user, session };
}

// ============================================================
// CSRF — same-origin enforcement for state-changing requests
// ============================================================

export function isSameOrigin(req: NextRequest): boolean {
  const method = req.method.toUpperCase();
  if (method === "GET" || method === "HEAD" || method === "OPTIONS") return true;

  const originHeader = req.headers.get("origin");
  const referer = req.headers.get("referer");
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host");
  if (!host) return false;

  const checkUrl = (value: string): boolean => {
    try {
      const url = new URL(value);
      return url.host === host;
    } catch {
      return false;
    }
  };

  if (originHeader && originHeader !== "null") return checkUrl(originHeader);
  if (referer) return checkUrl(referer);
  // No Origin/Referer at all on a state-changing request — reject.
  return false;
}

// ============================================================
// Rate limiting (best-effort, per isolate)
// ============================================================

const rateWindows = new Map<string, number[]>();

/** Record an attempt; returns false when the identifier is rate limited. */
export function rateLimit(key: string, limit: number, windowMs: number): boolean {
  const now = Date.now();
  const attempts = (rateWindows.get(key) ?? []).filter((t) => now - t < windowMs);
  if (attempts.length >= limit) {
    rateWindows.set(key, attempts);
    return false;
  }
  attempts.push(now);
  rateWindows.set(key, attempts);
  return true;
}

// ============================================================
// High-level auth operations (used by API routes)
// ============================================================

export async function login(
  req: NextRequest,
  email: string,
  password: string,
): Promise<{ ok: true; user: User; cookie: string } | { ok: false; status: number; error: string }> {
  const ip = getClientIp(req) ?? "unknown";
  if (!rateLimit(`login:${email.toLowerCase()}:${ip}`, 8, 10 * 60 * 1000)) {
    await recordAudit({
      action: "auth.login.rate_limited",
      category: "auth",
      ip,
      details: { email },
    });
    return { ok: false, status: 429, error: "Too many attempts. Try again in a few minutes." };
  }

  const user = await usersRepo.findUserByEmail(email);
  const passwordOk = user ? await verifyPassword(password, user.passwordHash) : false;

  if (!user || !passwordOk) {
    await recordAudit({
      userId: user?.id ?? null,
      action: "auth.login.failed",
      category: "auth",
      ip,
      details: { email },
    });
    // Uniform error — do not reveal which part failed.
    return { ok: false, status: 401, error: "Invalid email or password" };
  }

  const { token } = await issueSession(req, user.id);
  await recordAudit({
    userId: user.id,
    action: "auth.login",
    category: "auth",
    ip,
    details: { email },
  });
  return { ok: true, user, cookie: buildSessionCookie(token, req) };
}

export async function setup(
  req: NextRequest,
  email: string,
  name: string,
  password: string,
): Promise<{ ok: true; user: User; cookie: string } | { ok: false; status: number; error: string }> {
  const count = await usersRepo.countUsers();
  if (count > 0) {
    return { ok: false, status: 409, error: "Setup already completed. Please sign in." };
  }
  const passwordHash = await hashPassword(password);
  const user = await usersRepo.createUser({ email, name, passwordHash });
  const { token } = await issueSession(req, user.id);
  await recordAudit({
    userId: user.id,
    action: "auth.setup",
    category: "auth",
    ip: getClientIp(req),
    details: { email },
  });
  return { ok: true, user, cookie: buildSessionCookie(token, req) };
}

export async function logout(req: NextRequest, ctx: AuthContext) {
  await sessionsRepo.revokeSession(ctx.session.id);
  await recordAudit({
    userId: ctx.user.id,
    action: "auth.logout",
    category: "auth",
    ip: getClientIp(req),
  });
}

export async function lockCurrentSession(req: NextRequest, ctx: AuthContext) {
  await sessionsRepo.lockSession(ctx.session.id);
  await recordAudit({
    userId: ctx.user.id,
    action: "security.lock",
    category: "security",
    ip: getClientIp(req),
  });
}

export async function unlockCurrentSession(
  req: NextRequest,
  ctx: AuthContext,
  password: string,
): Promise<boolean> {
  const ok = await verifyPassword(password, ctx.user.passwordHash);
  if (!ok) {
    await recordAudit({
      userId: ctx.user.id,
      action: "security.unlock.failed",
      category: "security",
      ip: getClientIp(req),
    });
    return false;
  }
  await sessionsRepo.unlockSession(ctx.session.id);
  await recordAudit({
    userId: ctx.user.id,
    action: "security.unlock",
    category: "security",
    ip: getClientIp(req),
  });
  return true;
}

export async function changePassword(
  req: NextRequest,
  ctx: AuthContext,
  currentPassword: string,
  newPassword: string,
): Promise<boolean> {
  const ok = await verifyPassword(currentPassword, ctx.user.passwordHash);
  if (!ok) return false;
  const passwordHash = await hashPassword(newPassword);
  await usersRepo.updateUserPassword(ctx.user.id, passwordHash);
  // Revoke all OTHER sessions (this one stays signed in).
  await sessionsRepo.revokeAllSessions(ctx.user.id, ctx.session.id);
  await recordAudit({
    userId: ctx.user.id,
    action: "security.password_changed",
    category: "security",
    ip: getClientIp(req),
  });
  return true;
}

export function publicUser(user: User) {
  return { id: user.id, email: user.email, name: user.name };
}

/** Expiry helper for status responses. */
export function sessionIsLocked(session: Session): boolean {
  return session.lockedAt !== null;
}

export function nowIsoSafe(): string {
  return nowIso();
}
