// ALPHA — rolling conversation summarizer (context system, Layer 2)
//
// maybeUpdateSummary() runs POST-RESPONSE (via next/server after()) and
// folds everything older than the verbatim recent window into ONE rolling
// summary row per conversation. Guarantees:
//
//   - NEVER throws (a provider failure keeps the old summary for a retry on
//     a later turn — chat is never broken by summarization).
//   - NEVER deletes or mutates raw messages.
//   - Only runs when at least SUMMARIZE_THRESHOLD messages are outside both
//     the existing summary coverage and the recent window.
//   - Logs sanitized error NAMES only — never message or summary content.

import { completeWithFallback } from "../ai";
import type { ProviderChatMessage } from "../ai/types";
import { listMessages } from "../repos/conversations";
import { getSummary, upsertSummary } from "../repos/conversation-summaries";
import { getContextBudget } from "./budget";

/** Per-message content cap inside the summarizer transcript. */
const TRANSCRIPT_ENTRY_MAX_CHARS = 800;

export async function maybeUpdateSummary(input: {
  userId: string;
  conversationId: string;
}): Promise<{ summarized: boolean; reason: string }> {
  try {
    const budget = getContextBudget();
    const messages = await listMessages(input.conversationId);
    if (messages.length === 0) return { summarized: false, reason: "no-messages" };

    const existing = await getSummary(input.conversationId, input.userId);
    const covered = existing?.lastMessageCount ?? 0;
    const uncovered = messages.slice(covered);

    // The last RECENT_MESSAGES_LIMIT messages stay verbatim in every context
    // — everything before them (beyond summary coverage) is what gets folded
    // into the rolling summary.
    const keepRawCount = Math.min(budget.RECENT_MESSAGES_LIMIT, uncovered.length);
    const toSummarize = uncovered.slice(0, uncovered.length - keepRawCount);

    if (toSummarize.length < budget.SUMMARIZE_THRESHOLD) {
      return { summarized: false, reason: "below-threshold" };
    }

    const systemPrompt =
      `You are a conversation summarizer for a personal AI assistant. ` +
      `Merge the new transcript excerpt into the previous rolling summary. ` +
      `Keep it under ~${budget.SUMMARY_TARGET_TOKENS} tokens. ` +
      `Preserve: current topic, important decisions, requirements, unresolved questions, ` +
      `user preferences, important facts established. ` +
      `Be compact and factual. Output ONLY the updated summary text — no preamble.`;

    const transcript = toSummarize
      .map((m) => {
        const content =
          m.content.length > TRANSCRIPT_ENTRY_MAX_CHARS
            ? `${m.content.slice(0, TRANSCRIPT_ENTRY_MAX_CHARS)}…`
            : m.content;
        return `[${m.role}] ${content}`;
      })
      .join("\n");

    const providerMessages: ProviderChatMessage[] = [
      { role: "system", content: systemPrompt },
      {
        role: "user",
        content:
          `Previous rolling summary:\n${existing?.summary?.trim() || "(none yet)"}\n\n` +
          `New transcript excerpt to merge:\n${transcript}`,
      },
    ];

    const result = await completeWithFallback(
      providerMessages,
      { temperature: 0.2, maxTokens: 1000 },
      { userId: input.userId },
    );

    const summaryText = result.content?.trim();
    if (!summaryText) {
      return { summarized: false, reason: "provider-failed" };
    }

    const lastIndex = covered + toSummarize.length - 1; // index within all messages
    const lastMessage = messages[lastIndex];
    if (!lastMessage) {
      return { summarized: false, reason: "below-threshold" };
    }

    await upsertSummary(input.conversationId, input.userId, {
      summary: summaryText,
      lastMessageId: lastMessage.id,
      lastMessageCount: lastIndex + 1,
      version: (existing?.version ?? 0) + 1,
    });
    return { summarized: true, reason: "updated" };
  } catch (e) {
    // Sanitized: error NAME only — never message content or summary text.
    console.error(
      "[alpha] context summarizer failed:",
      e instanceof Error ? e.name : "UnknownError",
    );
    return { summarized: false, reason: "provider-failed" };
  }
}
