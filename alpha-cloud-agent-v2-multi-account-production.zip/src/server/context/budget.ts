// ALPHA — context budget configuration + token estimation
//
// The layered context system replaces "send the last 30 messages" with four
// token-bounded layers (see src/server/context/engine.ts):
//
//   Layer 1 — RECENT_MESSAGES_LIMIT      verbatim recent window
//   Layer 2 — CONTEXT_SUMMARY_MAX_TOKENS rolling conversation summary
//   Layer 3 — RELEVANT_HISTORY_MAX_TOKENS lexically-matched older messages
//   Layer 4 — MEMORY_MAX_TOKENS          persistent memories about the user
//
// Every knob is overridable via environment variables (read lazily inside
// getContextBudget() so tests can override them; parsing NEVER throws and
// falls back to the defaults below). Reading happens per call — never at
// module top level — which keeps the module Workers-safe (same discipline as
// env.ts / registry.ts config access).

export const CONTEXT_BUDGET = {
  /** Layer 1: last N messages always included verbatim. */
  RECENT_MESSAGES_LIMIT: 16,
  /** Layer 2 budget: max estimated tokens of the summary in the system prompt. */
  CONTEXT_SUMMARY_MAX_TOKENS: 600,
  /** Layer 3 budget: max estimated tokens of relevant older messages. */
  RELEVANT_HISTORY_MAX_TOKENS: 1200,
  /** Layer 4 budget: max estimated tokens of injected memories. */
  MEMORY_MAX_TOKENS: 400,
  /** Unsummarized+outside-recent-window count that triggers summarization. */
  SUMMARIZE_THRESHOLD: 24,
  /** What we ask the summarizer model to produce. */
  SUMMARY_TARGET_TOKENS: 450,
} as const;

export type ContextBudget = {
  [K in keyof typeof CONTEXT_BUDGET]: number;
};

/**
 * Rough token estimate (~4 characters per token). Deliberately cheap and
 * dependency-free — it only needs to be consistent, not exact.
 */
export function estimateTokens(text: string): number {
  return Math.ceil(text.length / 4);
}

/**
 * Cut a string so its estimated token count fits `maxTokens`, appending an
 * explicit ellipsis marker so the model knows content was truncated.
 * Text already within budget is returned unchanged. The cut lands on a
 * UTF-16 character boundary (a lone trailing surrogate half is dropped).
 */
export function truncateToTokens(text: string, maxTokens: number): string {
  if (maxTokens <= 0) return "";
  if (estimateTokens(text) <= maxTokens) return text;
  let cut = text.slice(0, maxTokens * 4);
  // Never split a surrogate pair (emoji etc.) in half.
  const last = cut.charCodeAt(cut.length - 1);
  if (last >= 0xd800 && last <= 0xdbff) cut = cut.slice(0, -1);
  return `${cut.trimEnd()} …[truncated]`;
}

/** Read one integer env override; NEVER throws, falls back on garbage. */
function envInt(name: string, fallback: number): number {
  try {
    const raw = process.env[name];
    if (!raw) return fallback;
    const parsed = Number.parseInt(raw, 10);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
  } catch {
    return fallback;
  }
}

/**
 * Effective context budget with environment overrides applied:
 *   CONTEXT_RECENT_MESSAGES_LIMIT, CONTEXT_SUMMARY_MAX_TOKENS,
 *   CONTEXT_RELEVANT_HISTORY_MAX_TOKENS, CONTEXT_MEMORY_MAX_TOKENS,
 *   CONTEXT_SUMMARIZE_THRESHOLD, CONTEXT_SUMMARY_TARGET_TOKENS
 */
export function getContextBudget(): ContextBudget {
  return {
    RECENT_MESSAGES_LIMIT: envInt("CONTEXT_RECENT_MESSAGES_LIMIT", CONTEXT_BUDGET.RECENT_MESSAGES_LIMIT),
    CONTEXT_SUMMARY_MAX_TOKENS: envInt("CONTEXT_SUMMARY_MAX_TOKENS", CONTEXT_BUDGET.CONTEXT_SUMMARY_MAX_TOKENS),
    RELEVANT_HISTORY_MAX_TOKENS: envInt("CONTEXT_RELEVANT_HISTORY_MAX_TOKENS", CONTEXT_BUDGET.RELEVANT_HISTORY_MAX_TOKENS),
    MEMORY_MAX_TOKENS: envInt("CONTEXT_MEMORY_MAX_TOKENS", CONTEXT_BUDGET.MEMORY_MAX_TOKENS),
    SUMMARIZE_THRESHOLD: envInt("CONTEXT_SUMMARIZE_THRESHOLD", CONTEXT_BUDGET.SUMMARIZE_THRESHOLD),
    SUMMARY_TARGET_TOKENS: envInt("CONTEXT_SUMMARY_TARGET_TOKENS", CONTEXT_BUDGET.SUMMARY_TARGET_TOKENS),
  };
}
