// ALPHA — semantic memory discipline (deterministic, NO AI call)
//
// maybeExtractMemory() runs POST-RESPONSE (via next/server after()) and
// stores a memory ONLY when the user EXPLICITLY asked to remember something.
// No intent → nothing stored. Honest reasons are returned for every skip.
//
//   "remember that my project uses D1"   → stored as a fact
//   "i prefer dark mode, keep in mind"   → stored as a preference
//   "remember my api key = sk-..."       → NEVER stored (secret-looking)
//   "hello there friend"                 → never even considered (no intent)
//
// Deterministic by design — no model call, no fake understanding.

import { createMemory, listMemories } from "../repos/memories";

/** Explicit remember-intent phrasing (case-insensitive). */
const REMEMBER_INTENT_RE = /\b(?:remember|note|keep in mind|don'?t forget)\b/i;

/** Secret-looking assignments — NEVER stored, regardless of intent. */
const SENSITIVE_RE = /\b(?:api[_ -]?key|secret|password|token|credential)s?\b\s*[:=]/i;

/** Preference wording inside the extracted clause. */
const PREFERENCE_RE = /\b(?:i (?:like|prefer|hate|always|never)|my favorite)\b/i;

const MIN_CLAUSE_CHARS = 8;
/** Stored clauses are 8..MAX_CONTENT_CHARS — anything outside is skipped. */
const MAX_CONTENT_CHARS = 500;

export function detectRememberIntent(text: string): boolean {
  return REMEMBER_INTENT_RE.test(text);
}

export function looksSensitive(text: string): boolean {
  return SENSITIVE_RE.test(text);
}

/**
 * Extract the factual clause that follows the remember-intent phrase: text
 * after the phrase (up to the first sentence end), stripped of leading
 * separators/filler ("that", "to", "about", …). Returns null when nothing
 * meaningful follows (e.g. a bare "remember this"). Pure — exported for tests.
 */
export function extractRememberClause(message: string): string | null {
  const match = REMEMBER_INTENT_RE.exec(message);
  if (!match) return null;
  let rest = message.slice(match.index + match[0].length);
  rest = rest.replace(/^[\s:,;.\-–—"'“”‘’]+/, "");
  rest = rest.replace(/^(?:that|to|about|of|this|these|the following)\b[\s:,;]*/i, "");
  rest = rest.replace(/^[\s:,;.\-–—"'“”‘’]+/, "");

  // Up to the first sentence end (or the whole remainder).
  const sentence = rest.match(/^[\s\S]*?[.!?]/);
  let clause = (sentence ? sentence[0] : rest).trim();
  clause = clause.replace(/[,;:\s]+$/, "");
  if (clause.length < MIN_CLAUSE_CHARS) return null;
  return clause;
}

export type MemoryCandidate =
  | { status: "no-intent" }
  | { status: "sensitive" }
  | { status: "no-content" }
  | { status: "too-long" }
  | { status: "ok"; clause: string; category: "preference" | "fact" };

/**
 * Pure decision pipeline for one message (no D1, no model): intent →
 * sensitivity → clause extraction (8..500 chars) → category. Exported for
 * tests; maybeExtractMemory adds only the D1 dedupe + persistence.
 */
export function evaluateRememberMessage(message: string): MemoryCandidate {
  const clean = message.trim();
  if (!clean || !detectRememberIntent(clean)) return { status: "no-intent" };

  // Secret-looking content is NEVER stored — checked before anything else.
  if (looksSensitive(clean)) return { status: "sensitive" };

  const clause = extractRememberClause(clean);
  if (!clause) return { status: "no-content" };
  if (looksSensitive(clause)) return { status: "sensitive" };
  // Stored clauses are 8..500 chars — anything longer is skipped (not
  // truncated: a 500+ char "remember" is a misfired paste, not a memory).
  if (clause.length > MAX_CONTENT_CHARS) return { status: "too-long" };

  return {
    status: "ok",
    clause,
    category: PREFERENCE_RE.test(clause) ? "preference" : "fact",
  };
}

/** Normalized comparison form for dedupe. */
function normalizeForDedupe(text: string): string {
  return text
    .toLowerCase()
    .replace(/\s+/g, " ")
    .replace(/[.,!?;:]+$/g, "")
    .trim();
}

export async function maybeExtractMemory(input: {
  userId: string;
  userMessage: string;
}): Promise<{ stored: boolean; reason: string }> {
  try {
    const candidate = evaluateRememberMessage(input.userMessage);
    if (candidate.status !== "ok") {
      return { stored: false, reason: candidate.status };
    }
    const content = candidate.clause;
    const category = candidate.category;

    // Dedupe against existing memories: normalized equality, or containment
    // with a length ratio > 0.6 (near-duplicates, not supersets).
    const normalized = normalizeForDedupe(content);
    const existing = await listMemories(input.userId);
    for (const memory of existing) {
      const have = normalizeForDedupe(memory.content);
      if (!have || !normalized) continue;
      if (have === normalized) return { stored: false, reason: "duplicate" };
      if (have.includes(normalized) || normalized.includes(have)) {
        const ratio = Math.min(have.length, normalized.length) / Math.max(have.length, normalized.length);
        if (ratio > 0.6) return { stored: false, reason: "duplicate" };
      }
    }

    await createMemory(input.userId, {
      category,
      content,
      source: "chat-auto",
      confidence: 0.9,
    });
    return { stored: true, reason: "created" };
  } catch (e) {
    // Sanitized: error NAME only — never message content.
    console.error(
      "[alpha] memory extraction failed:",
      e instanceof Error ? e.name : "UnknownError",
    );
    return { stored: false, reason: "error" };
  }
}
