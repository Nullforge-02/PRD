// ALPHA — shared lexical keyword extraction
//
// The exact word-splitting used for memory retrieval (repos/memories.ts) and
// relevant-history scoring (context/engine.ts): lowercase, split on
// non-alphanumerics, keep words of 4+ characters, deduplicated, capped.
// Extracted here so both call sites share ONE definition.

export function extractKeywords(text: string, maxWords = 12): string[] {
  return Array.from(
    new Set(
      text
        .toLowerCase()
        .split(/[^a-z0-9\u00c0-\uffff]+/)
        .filter((w) => w.length >= 4),
    ),
  ).slice(0, maxWords);
}
