// ALPHA — layered context engine
//
// buildContextPackage() assembles a token-bounded context for one chat turn:
//
//   Layer 1 (verbatim)     — the last RECENT_MESSAGES_LIMIT messages before
//                            the new one, sent as real provider messages.
//   Layer 2 (summary)      — the rolling conversation summary covering
//                            messages [0 .. lastMessageCount-1], injected
//                            into the system prompt.
//   Layer 3 (relevant)     — messages between summary coverage and the
//                            recent window that lexically match the NEW
//                            message, injected into the system prompt.
//   Layer 4 (memories)     — persistent memories about the user, bounded to
//                            MEMORY_MAX_TOKENS (pinned first).
//
// The new user message itself is NOT part of the package — runChatTurn
// appends it separately, so callers pass the full persisted history
// (including the just-persisted user message as its LAST element).

import { estimateTokens, getContextBudget, truncateToTokens } from "./budget";
import { extractKeywords } from "./keywords";
import { getSummary } from "../repos/conversation-summaries";
import { retrieveRelevantMemories } from "../repos/memories";
import { toolManifest } from "../tools";
import type { Message, Memory } from "../types";

export interface ContextStats {
  recent: number;
  summary: boolean;
  relevant: number;
  memories: number;
}

export interface ContextPackage {
  systemPrompt: string;
  recentMessages: Array<{ role: "user" | "assistant"; content: string }>;
  stats: ContextStats;
}

/** Per-message content cap inside the "relevant earlier messages" section. */
const RELEVANT_ENTRY_MAX_CHARS = 600;

/**
 * Pure lexical relevance score: how many of the query keywords appear in the
 * message content. Exported for direct unit testing.
 */
export function scoreRelevance(messageContent: string, queryWords: string[]): number {
  if (queryWords.length === 0) return 0;
  const haystack = messageContent.toLowerCase();
  let score = 0;
  for (const word of queryWords) {
    if (word && haystack.includes(word)) score += 1;
  }
  return score;
}

/** Bound retrieved memories to the Layer-4 token budget (pinned first). */
function boundMemories(
  memories: Memory[],
  maxTokens: number,
): Memory[] {
  const bounded: Memory[] = [];
  let used = 0;
  for (const memory of memories) {
    const tokens = estimateTokens(memory.content);
    if (used + tokens > maxTokens) break;
    bounded.push(memory);
    used += tokens;
  }
  return bounded;
}

export async function buildContextPackage(input: {
  userId: string;
  userName: string;
  conversationId: string;
  /** The new message being sent (used for keyword scoring only — never duplicated). */
  userMessage: string;
  /**
   * FULL persisted history INCLUDING the just-persisted user message as the
   * last element (pass the listMessages() result verbatim).
   */
  allMessages: Message[];
  /** Whether tools may be used this turn (adds the tool manifest to the prompt). */
  enableTools: boolean;
}): Promise<ContextPackage> {
  const budget = getContextBudget();

  // ---- Layer 2: summary coverage ----
  const summaryRow = await getSummary(input.conversationId, input.userId);
  const covered = summaryRow?.lastMessageCount ?? 0;
  const uncovered = input.allMessages.slice(covered);
  const hasSummary = !!summaryRow && summaryRow.summary.trim().length > 0;

  // ---- Layer 1: verbatim recent window ----
  // The LAST element of allMessages is the new user message — exclude it
  // (runChatTurn appends it itself). At most RECENT_MESSAGES_LIMIT messages.
  const recentWindow = uncovered.slice(-budget.RECENT_MESSAGES_LIMIT - 1, -1);

  // ---- Layer 3: lexically relevant older messages ----
  // The gap between summary coverage and the recent window.
  const olderRemaining = uncovered.slice(
    0,
    Math.max(0, uncovered.length - 1 - recentWindow.length),
  );
  const queryWords = extractKeywords(input.userMessage);
  const relevant: Message[] = [];
  let relevantTokens = 0;
  // Select most-recent-first while the budget lasts…
  for (let i = olderRemaining.length - 1; i >= 0; i--) {
    const candidate = olderRemaining[i];
    if (scoreRelevance(candidate.content, queryWords) < 1) continue;
    const tokens = estimateTokens(candidate.content);
    if (relevantTokens + tokens > budget.RELEVANT_HISTORY_MAX_TOKENS) break;
    relevant.unshift(candidate); // …but present chronologically.
    relevantTokens += tokens;
  }

  // ---- Layer 4: persistent memories (bounded) ----
  const retrieved = await retrieveRelevantMemories(input.userId, input.userMessage);
  const memories = boundMemories(retrieved, budget.MEMORY_MAX_TOKENS);

  // ---- System prompt assembly ----
  const now = new Date();
  const lines: string[] = [
    `You are Alpha — ${input.userName}'s personal AI agent, running as a cloud application.`,
    `Current date and time: ${now.toISOString()} (UTC).`,
    "",
    "You are concise, direct and genuinely useful. You use Markdown when it helps.",
    "",
  ];

  if (memories.length > 0) {
    lines.push("### Persistent memory about the user (long-term)");
    for (const memory of memories) {
      lines.push(`- [${memory.category}]${memory.pinned ? " (pinned)" : ""} ${memory.content}`);
    }
    lines.push("");
  }

  if (hasSummary && summaryRow) {
    lines.push("### Conversation summary (earlier in this conversation)");
    lines.push(truncateToTokens(summaryRow.summary, budget.CONTEXT_SUMMARY_MAX_TOKENS));
    lines.push("");
  }

  if (relevant.length > 0) {
    lines.push("### Relevant earlier messages (older than the recent window)");
    for (const message of relevant) {
      const content =
        message.content.length > RELEVANT_ENTRY_MAX_CHARS
          ? `${message.content.slice(0, RELEVANT_ENTRY_MAX_CHARS)}…`
          : message.content;
      const role = message.role === "assistant" ? "assistant" : "user";
      lines.push(`- [${role}] ${content}`);
    }
    lines.push("");
  }

  if (hasSummary || relevant.length > 0) {
    lines.push(
      "Use the summary and earlier messages above to resolve references like 'that', 'it', 'the previous one', 'as I said'. Do not repeat already-answered content unnecessarily.",
      "",
    );
  }

  if (input.enableTools) {
    lines.push(
      "### Tools",
      "You can use tools to act on the user's behalf. Available tools:",
      toolManifest(),
      "",
      "To use a tool, reply with ONLY a JSON object (no markdown fences, no other text):",
      '{"tool": "<tool-name>", "args": { ... }}',
      "The tool will be executed and its real result returned to you; then answer the user.",
      "Only use a tool when it genuinely helps. Otherwise reply normally.",
    );
  }

  return {
    systemPrompt: lines.join("\n"),
    recentMessages: recentWindow.map((m) => ({
      role: (m.role === "assistant" ? "assistant" : "user") as "assistant" | "user",
      content: m.content,
    })),
    stats: {
      recent: recentWindow.length,
      summary: hasSummary,
      relevant: relevant.length,
      memories: memories.length,
    },
  };
}
