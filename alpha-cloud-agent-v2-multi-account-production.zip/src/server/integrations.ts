// ALPHA — integration status (real OAuth: Google/Gmail + GitHub)
//
// The single boundary where integration readiness is computed:
//   configured = OAuth client credentials exist in the environment
//                (Worker secrets GOOGLE_CLIENT_ID/SECRET — GMAIL_* legacy
//                aliases accepted — and GITHUB_CLIENT_ID/SECRET)
//   connected  = at least one REAL connection row exists in D1 (never faked)
//
// MULTI-ACCOUNT: every connected account is listed (identity, status, GitHub
// role, default flag, last-used). Tokens never flow through here — only
// connection METADATA exposed by the connected-accounts repo.

import type { ConnectedAccountInfo, IntegrationInfo } from "@/lib/api";
import type { ConnectedAccount } from "./repos/connected-accounts";
import { listAccountsByProvider } from "./repos/connected-accounts";
import { googleConfigured } from "./integrations/google";
import { githubConfigured } from "./integrations/github";

function toAccountInfo(account: ConnectedAccount): ConnectedAccountInfo {
  return {
    id: account.id,
    provider: account.provider,
    providerAccountId: account.providerAccountId,
    accountName: account.accountName,
    avatarUrl: account.avatarUrl,
    status: account.status,
    role: account.role,
    isDefault: account.isDefault,
    createdAt: account.createdAt,
    lastUsedAt: account.lastUsedAt,
  };
}

export async function getIntegrationsStatus(userId: string): Promise<IntegrationInfo[]> {
  const [googleReady, githubReady, googleAccounts, githubAccounts] = await Promise.all([
    googleConfigured(),
    githubConfigured(),
    listAccountsByProvider(userId, "google"),
    listAccountsByProvider(userId, "github"),
  ]);

  const gmailDefault =
    googleAccounts.find((a) => a.isDefault) ?? (googleAccounts.length === 1 ? googleAccounts[0] : null);
  const githubDefault =
    githubAccounts.find((a) => a.isDefault) ?? (githubAccounts.length === 1 ? githubAccounts[0] : null);

  const gmail: IntegrationInfo = {
    id: "gmail",
    name: "Gmail",
    configured: googleReady,
    connected: googleAccounts.length > 0,
    status: gmailDefault?.status ?? null,
    accountName: gmailDefault?.accountName ?? null,
    avatarUrl: gmailDefault?.avatarUrl ?? null,
    accounts: googleAccounts.map(toAccountInfo),
    defaultAccountId: gmailDefault?.id ?? null,
    setup: !googleReady
      ? "Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET as Worker secrets to enable Google OAuth."
      : googleAccounts.length === 0
        ? "OAuth is configured — click Connect to grant Alpha access."
        : googleAccounts.some((a) => a.status === "needs_reauthorization")
          ? "At least one account needs reauthorization — reconnect it to restore access."
          : googleAccounts.length > 1
            ? `${googleAccounts.length} Google accounts connected — the marked default is used for search and send; select another account with Use.`
            : "Gmail is connected — Alpha can read and send email through your Google account.",
  };

  const github: IntegrationInfo = {
    id: "github",
    name: "GitHub",
    configured: githubReady,
    connected: githubAccounts.length > 0,
    status: githubDefault?.status ?? null,
    accountName: githubDefault?.accountName ?? null,
    avatarUrl: githubDefault?.avatarUrl ?? null,
    accounts: githubAccounts.map(toAccountInfo),
    defaultAccountId: githubDefault?.id ?? null,
    setup: !githubReady
      ? "Set GITHUB_CLIENT_ID and GITHUB_CLIENT_SECRET as Worker secrets to enable GitHub OAuth."
      : githubAccounts.length === 0
        ? "OAuth is configured — click Connect to grant Alpha access."
        : githubAccounts.some((a) => a.status === "needs_reauthorization")
          ? "At least one account needs reauthorization — reconnect it to restore access."
          : githubAccounts.length > 1
            ? `${githubAccounts.length} GitHub accounts connected — assign roles (storage / scripts) to route operations.`
            : "GitHub is connected — Alpha can browse your repositories and open issues.",
  };

  return [gmail, github];
}
