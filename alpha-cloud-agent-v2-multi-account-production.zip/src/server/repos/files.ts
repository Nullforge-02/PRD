// ALPHA — file metadata repository (bytes live in R2)

import { all, first, genId, nowIso, run } from "../db";
import { escapeLike } from "./notes";
import type { FileRecord } from "../types";

interface FileRow {
  id: string;
  user_id: string;
  filename: string;
  mime_type: string;
  size: number;
  r2_key: string;
  source: string;
  created_at: string;
  updated_at: string;
}

export function toFile(row: FileRow): FileRecord {
  return {
    id: row.id,
    userId: row.user_id,
    filename: row.filename,
    mimeType: row.mime_type,
    size: row.size,
    r2Key: row.r2_key,
    source: row.source === "generated" ? "generated" : "upload",
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export async function listFiles(
  userId: string,
  opts: { source?: "upload" | "generated"; query?: string } = {},
): Promise<FileRecord[]> {
  const conditions = ["user_id = ?"];
  const params: unknown[] = [userId];
  if (opts.source) {
    conditions.push("source = ?");
    params.push(opts.source);
  }
  if (opts.query) {
    conditions.push("filename LIKE ? ESCAPE '\\'");
    params.push(`%${escapeLike(opts.query)}%`);
  }
  const rows = await all<FileRow>(
    `SELECT * FROM files WHERE ${conditions.join(" AND ")}
     ORDER BY created_at DESC`,
    ...params,
  );
  return rows.map(toFile);
}

export async function findFile(id: string, userId: string) {
  const row = await first<FileRow>(
    "SELECT * FROM files WHERE id = ? AND user_id = ?",
    id,
    userId,
  );
  return row ? toFile(row) : null;
}

export async function createFile(input: {
  userId: string;
  filename: string;
  mimeType: string;
  size: number;
  r2Key: string;
  source: "upload" | "generated";
}): Promise<FileRecord> {
  const id = genId("fil");
  const now = nowIso();
  await run(
    `INSERT INTO files (id, user_id, filename, mime_type, size, r2_key, source, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    id,
    input.userId,
    input.filename,
    input.mimeType,
    input.size,
    input.r2Key,
    input.source,
    now,
    now,
  );
  return {
    id,
    userId: input.userId,
    filename: input.filename,
    mimeType: input.mimeType,
    size: input.size,
    r2Key: input.r2Key,
    source: input.source,
    createdAt: now,
    updatedAt: now,
  };
}

export async function deleteFile(id: string, userId: string) {
  await run("DELETE FROM files WHERE id = ? AND user_id = ?", id, userId);
}

export async function storageUsage(userId: string): Promise<{ count: number; bytes: number }> {
  const row = await first<{ n: number; bytes: number }>(
    "SELECT COUNT(*) AS n, COALESCE(SUM(size), 0) AS bytes FROM files WHERE user_id = ?",
    userId,
  );
  return { count: row?.n ?? 0, bytes: row?.bytes ?? 0 };
}
