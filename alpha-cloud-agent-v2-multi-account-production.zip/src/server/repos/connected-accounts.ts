// ALPHA — connected accounts repository (D1) — MULTI-ACCOUNT
//
// Real OAuth connections (Google/Gmail, GitHub). Access + refresh tokens are
// encrypted BEFORE storage with the same AES-256-GCM construction as AI
// provider credentials but a DEDICATED HKDF info label
// (CRYPTO_PURPOSE_OAUTH_TOKENS) — key separation between credential classes.
//
// OAuth CLIENT secrets are NEVER stored here (they live in Worker secrets:
// GOOGLE_CLIENT_ID/GOOGLE_CLIENT_SECRET, GITHUB_CLIENT_ID/GITHUB_CLIENT_SECRET).
//
// MULTI-ACCOUNT model (migration 0005):
//   • A user may hold SEVERAL connected accounts per provider (multiple Google
//     accounts, multiple GitHub accounts). The DB-level uniqueness is
//     (user_id, provider, provider_account_id) — reconnecting the SAME external
//     account upserts its row (dedupe), connecting a DIFFERENT external account
//     adds a new row without touching existing ones.
//   • Each provider has ONE explicit default account (is_default=1) — the
//     account the user picked with "Use". Resolution NEVER falls back to
//     "most recently updated" (that silently switched accounts).
//   • GitHub accounts additionally carry a user-editable ROLE:
//     'storage' | 'scripts' | 'general' (NULL → treated as 'general').
//     Role-based resolution lives in integrations/account-resolver.ts.

import { all, first, genId, nowIso, run } from "../db";
import { getEnv } from "../env";
import {
  encryptCredential,
  decryptCredential,
  CRYPTO_PURPOSE_OAUTH_TOKENS,
} from "../ai/credential-crypto";

export type OAuthProvider = "google" | "github";
export type ConnectionStatus = "connected" | "needs_reauthorization";
/** GitHub account purposes. Google accounts have no role (null). */
export type GithubAccountRole = "storage" | "scripts" | "general";

export const GITHUB_ACCOUNT_ROLES: readonly GithubAccountRole[] = [
  "storage",
  "scripts",
  "general",
];

export function isGithubAccountRole(value: unknown): value is GithubAccountRole {
  return (
    typeof value === "string" &&
    (GITHUB_ACCOUNT_ROLES as readonly string[]).includes(value)
  );
}

export interface ConnectedAccount {
  id: string;
  userId: string;
  provider: OAuthProvider;
  providerAccountId: string;
  accountName: string | null;
  avatarUrl: string | null;
  /** Decrypted ONLY at call time by the integration layer — never listed. */
  encryptedAccessToken: string;
  encryptedRefreshToken: string | null;
  /** ISO timestamp when the access token expires (null = no expiry known). */
  expiresAt: string | null;
  scopes: string;
  status: ConnectionStatus;
  /** GitHub purpose: storage | scripts | general. NULL for Google accounts. */
  role: GithubAccountRole | null;
  /** The user's explicitly selected default account for this provider. */
  isDefault: boolean;
  createdAt: string;
  updatedAt: string;
  /** ISO timestamp of the last operation that actually used this account. */
  lastUsedAt: string | null;
}

interface ConnectedAccountRow {
  id: string;
  user_id: string;
  provider: string;
  provider_account_id: string;
  account_name: string | null;
  avatar_url: string | null;
  encrypted_access_token: string;
  encrypted_refresh_token: string | null;
  expires_at: string | null;
  scopes: string;
  role: string | null;
  is_default: number;
  status: string;
  created_at: string;
  updated_at: string;
  last_used_at: string | null;
}

function toAccount(row: ConnectedAccountRow): ConnectedAccount {
  return {
    id: row.id,
    userId: row.user_id,
    provider: row.provider === "google" ? "google" : "github",
    providerAccountId: row.provider_account_id,
    accountName: row.account_name,
    avatarUrl: row.avatar_url,
    encryptedAccessToken: row.encrypted_access_token,
    encryptedRefreshToken: row.encrypted_refresh_token,
    expiresAt: row.expires_at,
    scopes: row.scopes,
    status: row.status === "needs_reauthorization" ? "needs_reauthorization" : "connected",
    role:
      row.provider === "github" && isGithubAccountRole(row.role) ? row.role : null,
    isDefault: row.is_default === 1,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    lastUsedAt: row.last_used_at,
  };
}

export function isOAuthProvider(value: string): value is OAuthProvider {
  return value === "google" || value === "github";
}

// ============================================================
// Reads — explicit multi-account queries. None of them order by
// updated_at (a recently-refreshed token must NEVER change which
// account an operation uses).
// ============================================================

/** All accounts of one provider for a user, oldest connection first (stable). */
export async function listAccountsByProvider(
  userId: string,
  provider: OAuthProvider,
): Promise<ConnectedAccount[]> {
  const rows = await all<ConnectedAccountRow>(
    "SELECT * FROM connected_accounts WHERE user_id = ? AND provider = ? ORDER BY created_at ASC, id ASC",
    userId,
    provider,
  );
  return rows.map(toAccount);
}

/** All connected accounts of a user (any provider), oldest first. */
export async function listConnectedAccounts(userId: string): Promise<ConnectedAccount[]> {
  const rows = await all<ConnectedAccountRow>(
    "SELECT * FROM connected_accounts WHERE user_id = ? ORDER BY created_at ASC, id ASC",
    userId,
  );
  return rows.map(toAccount);
}

/** One account by its INTERNAL id — ownership-scoped (userId). */
export async function getAccountById(
  userId: string,
  id: string,
): Promise<ConnectedAccount | null> {
  const row = await first<ConnectedAccountRow>(
    "SELECT * FROM connected_accounts WHERE id = ? AND user_id = ?",
    id,
    userId,
  );
  return row ? toAccount(row) : null;
}

/** The user's explicitly selected default account for a provider (null when
 *  none is connected or — only possible transiently — none is flagged). */
export async function getDefaultAccount(
  userId: string,
  provider: OAuthProvider,
): Promise<ConnectedAccount | null> {
  const row = await first<ConnectedAccountRow>(
    "SELECT * FROM connected_accounts WHERE user_id = ? AND provider = ? AND is_default = 1 ORDER BY created_at ASC LIMIT 1",
    userId,
    provider,
  );
  return row ? toAccount(row) : null;
}

/**
 * Backward-compatible single-account lookup for paths that predate explicit
 * selection. Resolution order:
 *   1. the explicit default account (is_default = 1)
 *   2. when EXACTLY ONE account exists, that account (and it is promoted to
 *      default so the invariant "one default per provider" holds)
 *   3. otherwise null — callers must NOT guess (see account-resolver).
 * Never orders by updated_at.
 */
export async function findConnectedAccount(
  userId: string,
  provider: OAuthProvider,
): Promise<ConnectedAccount | null> {
  const existing = await listAccountsByProvider(userId, provider);
  if (existing.length === 0) return null;
  const flagged = existing.find((a) => a.isDefault);
  if (flagged) return flagged;
  if (existing.length === 1) {
    await setDefaultAccount(userId, existing[0].id, existing);
    return { ...existing[0], isDefault: true };
  }
  return null;
}

// ============================================================
// Token encryption (server-side only, OAuth HKDF purpose)
// ============================================================

async function requireSecret(): Promise<string> {
  const env = await getEnv();
  const secret = env.AI_CREDENTIALS_SECRET;
  if (!secret || secret.length < 16) {
    throw new Error(
      "AI_CREDENTIALS_SECRET is not configured — OAuth tokens cannot be " +
        "encrypted/decrypted. Run: npx wrangler secret put AI_CREDENTIALS_SECRET " +
        "(or set it in .dev.vars for local development).",
    );
  }
  return secret;
}

export async function encryptOAuthToken(plaintext: string): Promise<string> {
  const secret = await requireSecret();
  return encryptCredential(secret, plaintext, CRYPTO_PURPOSE_OAUTH_TOKENS);
}

export async function decryptOAuthToken(payload: string): Promise<string> {
  const secret = await requireSecret();
  try {
    return await decryptCredential(secret, payload, CRYPTO_PURPOSE_OAUTH_TOKENS);
  } catch {
    throw new Error(
      "Stored OAuth token could not be decrypted — AI_CREDENTIALS_SECRET may " +
        "have changed since the account was connected. Disconnect and reconnect.",
    );
  }
}

// ============================================================
// Upsert / update / delete
// ============================================================

export interface UpsertAccountInput {
  userId: string;
  provider: OAuthProvider;
  providerAccountId: string;
  accountName: string | null;
  avatarUrl: string | null;
  encryptedAccessToken: string;
  encryptedRefreshToken: string | null;
  expiresAt: string | null;
  scopes: string;
}

/**
 * Insert or update the connection for (user, provider, provider_account_id).
 *
 * Multi-account semantics:
 *   • Reconnecting the SAME external account updates its row in place
 *     (tokens refreshed, role and is_default PRESERVED — a re-login never
 *     steals the default flag from another account).
 *   • Connecting a DIFFERENT external account adds an independent row and
 *     never touches existing rows.
 *   • The FIRST account for a provider becomes the default automatically.
 */
export async function upsertConnectedAccount(
  input: UpsertAccountInput,
): Promise<ConnectedAccount> {
  const existing = await first<ConnectedAccountRow>(
    "SELECT * FROM connected_accounts WHERE user_id = ? AND provider = ? AND provider_account_id = ?",
    input.userId,
    input.provider,
    input.providerAccountId,
  );
  const now = nowIso();
  if (existing) {
    await run(
      `UPDATE connected_accounts
       SET account_name = ?, avatar_url = ?, encrypted_access_token = ?,
           encrypted_refresh_token = ?, expires_at = ?, scopes = ?,
           status = 'connected', updated_at = ?
       WHERE id = ?`,
      input.accountName,
      input.avatarUrl,
      input.encryptedAccessToken,
      input.encryptedRefreshToken,
      input.expiresAt,
      input.scopes,
      now,
      existing.id,
    );
    const updated = await first<ConnectedAccountRow>(
      "SELECT * FROM connected_accounts WHERE id = ?",
      existing.id,
    );
    if (updated) return toAccount(updated);
    throw new Error("Failed to update connected account");
  }
  const id = genId("oa");
  // First account of this provider becomes the default (explicit invariant).
  const priorCount = await first<{ n: number }>(
    "SELECT COUNT(*) AS n FROM connected_accounts WHERE user_id = ? AND provider = ?",
    input.userId,
    input.provider,
  );
  const isDefault = (priorCount?.n ?? 0) === 0 ? 1 : 0;
  await run(
    `INSERT INTO connected_accounts
       (id, user_id, provider, provider_account_id, account_name, avatar_url,
        encrypted_access_token, encrypted_refresh_token, expires_at, scopes,
        role, is_default, status, created_at, updated_at, last_used_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, 'connected', ?, ?, NULL)`,
    id,
    input.userId,
    input.provider,
    input.providerAccountId,
    input.accountName,
    input.avatarUrl,
    input.encryptedAccessToken,
    input.encryptedRefreshToken,
    input.expiresAt,
    input.scopes,
    isDefault,
    now,
    now,
  );
  const created = await first<ConnectedAccountRow>(
    "SELECT * FROM connected_accounts WHERE id = ?",
    id,
  );
  if (!created) throw new Error("Failed to create connected account");
  return toAccount(created);
}

/** Update stored tokens for ONE account (e.g. after a refresh-token exchange). */
export async function updateAccountTokens(
  id: string,
  userId: string,
  input: {
    encryptedAccessToken: string;
    encryptedRefreshToken?: string | null;
    expiresAt?: string | null;
  },
): Promise<void> {
  await run(
    `UPDATE connected_accounts
     SET encrypted_access_token = ?,
         encrypted_refresh_token = COALESCE(?, encrypted_refresh_token),
         expires_at = COALESCE(?, expires_at),
         status = 'connected', updated_at = ?
     WHERE id = ? AND user_id = ?`,
    input.encryptedAccessToken,
    input.encryptedRefreshToken ?? null,
    input.expiresAt ?? null,
    nowIso(),
    id,
    userId,
  );
}

/**
 * Set the user's explicit default account for its provider. Clears the flag
 * from every sibling of the same provider first — the invariant is "exactly
 * one default per (user, provider)". Pass the pre-fetched account list to
 * avoid a re-query in hot paths.
 */
export async function setDefaultAccount(
  userId: string,
  accountId: string,
  knownAccounts?: ConnectedAccount[],
): Promise<ConnectedAccount | null> {
  const accounts = knownAccounts ?? (await listConnectedAccounts(userId));
  const target = accounts.find((a) => a.id === accountId);
  if (!target) return null;
  const now = nowIso();
  // Unflag siblings, then flag the target (single round-trip each, same tx-ish
  // sequential semantics D1 offers).
  await run(
    "UPDATE connected_accounts SET is_default = 0, updated_at = ? WHERE user_id = ? AND provider = ? AND is_default = 1 AND id != ?",
    now,
    userId,
    target.provider,
    accountId,
  );
  await run(
    "UPDATE connected_accounts SET is_default = 1, updated_at = ? WHERE id = ? AND user_id = ?",
    now,
    accountId,
    userId,
  );
  return getAccountById(userId, accountId);
}

/**
 * Set the ROLE of a GitHub account (storage | scripts | general). Google
 * accounts cannot carry a role — returns null for them.
 */
export async function setAccountRole(
  userId: string,
  accountId: string,
  role: GithubAccountRole,
): Promise<ConnectedAccount | null> {
  const account = await getAccountById(userId, accountId);
  if (!account || account.provider !== "github") return null;
  await run(
    "UPDATE connected_accounts SET role = ?, updated_at = ? WHERE id = ? AND user_id = ?",
    role,
    nowIso(),
    accountId,
    userId,
  );
  return getAccountById(userId, accountId);
}

/** Record that an operation just used this account (transparency timestamp). */
export async function touchAccountUsed(userId: string, accountId: string): Promise<void> {
  await run(
    "UPDATE connected_accounts SET last_used_at = ? WHERE id = ? AND user_id = ?",
    nowIso(),
    accountId,
    userId,
  );
}

/** Mark ONE account as needing reauthorization (per-account — never
 *  blanket-marks a whole provider when several accounts are connected). */
export async function markAccountNeedsReauthorization(
  userId: string,
  accountId: string,
): Promise<void> {
  await run(
    "UPDATE connected_accounts SET status = 'needs_reauthorization', updated_at = ? WHERE id = ? AND user_id = ?",
    nowIso(),
    accountId,
    userId,
  );
}

export interface DeleteAccountResult {
  deleted: boolean;
  /** The account that was promoted to default after deleting the previous
   *  default (null when nothing needed promoting). */
  promotedDefaultId: string | null;
}

/**
 * Delete ONE account (tokens + linkage). When the deleted account was the
 * provider's default, the EARLIEST-connected remaining sibling is promoted so
 * there is always an explicit default while any account remains.
 */
export async function deleteAccount(
  userId: string,
  accountId: string,
): Promise<DeleteAccountResult> {
  const account = await getAccountById(userId, accountId);
  if (!account) return { deleted: false, promotedDefaultId: null };
  await run("DELETE FROM connected_accounts WHERE id = ? AND user_id = ?", accountId, userId);
  let promoted: string | null = null;
  if (account.isDefault) {
    const remaining = await listAccountsByProvider(userId, account.provider);
    if (remaining.length > 0) {
      const next = remaining[0]; // oldest connected sibling — stable choice
      await setDefaultAccount(userId, next.id, remaining);
      promoted = next.id;
    }
  }
  return { deleted: true, promotedDefaultId: promoted };
}

/** Revoke-ready list: all accounts of a provider (used by disconnect-all). */
export async function deleteAllAccounts(
  userId: string,
  provider: OAuthProvider,
): Promise<ConnectedAccount[]> {
  const accounts = await listAccountsByProvider(userId, provider);
  if (accounts.length > 0) {
    await run(
      "DELETE FROM connected_accounts WHERE user_id = ? AND provider = ?",
      userId,
      provider,
    );
  }
  return accounts;
}
