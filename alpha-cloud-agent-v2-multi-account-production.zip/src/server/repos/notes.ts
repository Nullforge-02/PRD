// ALPHA — notes repository

import { all, first, genId, nowIso, run } from "../db";
import type { Note } from "../types";

interface NoteRow {
  id: string;
  user_id: string;
  title: string;
  content: string;
  pinned: number;
  created_at: string;
  updated_at: string;
}

export function toNote(row: NoteRow): Note {
  return {
    id: row.id,
    userId: row.user_id,
    title: row.title,
    content: row.content,
    pinned: !!row.pinned,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export async function listNotes(
  userId: string,
  opts: { query?: string } = {},
): Promise<Note[]> {
  if (opts.query) {
    const like = `%${escapeLike(opts.query)}%`;
    const rows = await all<NoteRow>(
      `SELECT * FROM notes WHERE user_id = ? AND (title LIKE ? ESCAPE '\\' OR content LIKE ? ESCAPE '\\')
       ORDER BY pinned DESC, updated_at DESC`,
      userId,
      like,
      like,
    );
    return rows.map(toNote);
  }
  const rows = await all<NoteRow>(
    "SELECT * FROM notes WHERE user_id = ? ORDER BY pinned DESC, updated_at DESC",
    userId,
  );
  return rows.map(toNote);
}

export async function findNote(id: string, userId: string) {
  const row = await first<NoteRow>(
    "SELECT * FROM notes WHERE id = ? AND user_id = ?",
    id,
    userId,
  );
  return row ? toNote(row) : null;
}

export async function createNote(
  userId: string,
  input: { title: string; content?: string; pinned?: boolean },
): Promise<Note> {
  const id = genId("nte");
  const now = nowIso();
  await run(
    `INSERT INTO notes (id, user_id, title, content, pinned, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    id,
    userId,
    input.title,
    input.content ?? "",
    input.pinned ? 1 : 0,
    now,
    now,
  );
  return {
    id,
    userId,
    title: input.title,
    content: input.content ?? "",
    pinned: !!input.pinned,
    createdAt: now,
    updatedAt: now,
  };
}

export async function updateNote(
  id: string,
  userId: string,
  patch: { title?: string; content?: string; pinned?: boolean },
): Promise<Note | null> {
  const existing = await findNote(id, userId);
  if (!existing) return null;
  await run(
    `UPDATE notes SET title = ?, content = ?, pinned = ?, updated_at = ?
     WHERE id = ? AND user_id = ?`,
    patch.title ?? existing.title,
    patch.content ?? existing.content,
    patch.pinned !== undefined ? (patch.pinned ? 1 : 0) : existing.pinned ? 1 : 0,
    nowIso(),
    id,
    userId,
  );
  return findNote(id, userId);
}

export async function deleteNote(id: string, userId: string) {
  await run("DELETE FROM notes WHERE id = ? AND user_id = ?", id, userId);
}

/** Escape %, _ and \ for LIKE queries. */
export function escapeLike(s: string): string {
  return s.replace(/[\\%_]/g, (c) => `\\${c}`);
}
