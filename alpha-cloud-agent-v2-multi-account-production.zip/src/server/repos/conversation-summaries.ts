// ALPHA — rolling conversation summary repository (context system)
//
// One summary row per conversation (UNIQUE conversation_id). The row records
// how many leading messages the summary covers (`lastMessageCount`), so the
// context engine can layer: summary → relevant older → recent verbatim →
// new message. Raw messages are NEVER deleted — this is an index, not a
// replacement.

import { first, genId, nowIso, run } from "../db";

interface SummaryRow {
  id: string;
  conversation_id: string;
  user_id: string;
  summary: string;
  last_message_id: string;
  last_message_count: number;
  version: number;
  created_at: string;
  updated_at: string;
}

export interface ConversationSummary {
  id: string;
  conversationId: string;
  userId: string;
  summary: string;
  lastMessageId: string;
  lastMessageCount: number;
  version: number;
  createdAt: string;
  updatedAt: string;
}

export function toSummary(row: SummaryRow): ConversationSummary {
  return {
    id: row.id,
    conversationId: row.conversation_id,
    userId: row.user_id,
    summary: row.summary,
    lastMessageId: row.last_message_id,
    lastMessageCount: row.last_message_count,
    version: row.version,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export async function getSummary(
  conversationId: string,
  userId: string,
): Promise<ConversationSummary | null> {
  const row = await first<SummaryRow>(
    "SELECT * FROM conversation_summaries WHERE conversation_id = ? AND user_id = ?",
    conversationId,
    userId,
  );
  return row ? toSummary(row) : null;
}

export async function upsertSummary(
  conversationId: string,
  userId: string,
  input: {
    summary: string;
    lastMessageId: string;
    lastMessageCount: number;
    version: number;
  },
): Promise<ConversationSummary> {
  const now = nowIso();
  await run(
    `INSERT INTO conversation_summaries
       (id, conversation_id, user_id, summary, last_message_id, last_message_count, version, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(conversation_id) DO UPDATE SET
       summary = excluded.summary,
       last_message_id = excluded.last_message_id,
       last_message_count = excluded.last_message_count,
       version = excluded.version,
       updated_at = excluded.updated_at`,
    genId("csum"),
    conversationId,
    userId,
    input.summary,
    input.lastMessageId,
    input.lastMessageCount,
    input.version,
    now,
    now,
  );
  const stored = await getSummary(conversationId, userId);
  // ON CONFLICT guarantees a row exists; the read-back keeps one code path.
  return (
    stored ?? {
      id: "",
      conversationId,
      userId,
      summary: input.summary,
      lastMessageId: input.lastMessageId,
      lastMessageCount: input.lastMessageCount,
      version: input.version,
      createdAt: now,
      updatedAt: now,
    }
  );
}
