// ALPHA — settings & audit & jobs repositories

import { all, genId, nowIso, run, first } from "../db";
import type { AuditEvent, Job } from "../types";

// ---------- Settings ----------

export async function getSettings(userId: string): Promise<Record<string, string>> {
  const rows = await all<{ key: string; value: string }>(
    "SELECT key, value FROM settings WHERE user_id = ?",
    userId,
  );
  const out: Record<string, string> = {};
  for (const row of rows) out[row.key] = row.value;
  return out;
}

export async function upsertSettings(userId: string, values: Record<string, string>) {
  const now = nowIso();
  for (const [key, value] of Object.entries(values)) {
    await run(
      `INSERT INTO settings (user_id, key, value, updated_at) VALUES (?, ?, ?, ?)
       ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
      userId,
      key,
      value,
      now,
    );
  }
}

// ---------- Audit ----------

interface AuditRow {
  id: string;
  user_id: string | null;
  action: string;
  category: string;
  details: string | null;
  ip: string | null;
  created_at: string;
}

export async function recordAudit(input: {
  userId?: string | null;
  action: string;
  category: string;
  details?: Record<string, unknown> | null;
  ip?: string | null;
}): Promise<void> {
  try {
    await run(
      `INSERT INTO audit_logs (id, user_id, action, category, details, ip, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      genId("aud"),
      input.userId ?? null,
      input.action,
      input.category,
      input.details ? JSON.stringify(input.details) : null,
      input.ip ?? null,
      nowIso(),
    );
  } catch (e) {
    // Audit logging must never break the request path.
    console.error("[alpha] audit write failed:", e);
  }
}

export async function listAudit(
  userId: string | null,
  limit = 100,
): Promise<AuditEvent[]> {
  const rows = await all<AuditRow>(
    `SELECT * FROM audit_logs ${userId ? "WHERE user_id = ?" : ""}
     ORDER BY created_at DESC LIMIT ?`,
    ...(userId ? [userId] : []),
    Math.min(Math.max(limit, 1), 500),
  );
  return rows.map((row) => ({
    id: row.id,
    userId: row.user_id,
    action: row.action,
    category: row.category,
    details: row.details,
    ip: row.ip,
    createdAt: row.created_at,
  }));
}

// ---------- Jobs ----------

interface JobRow {
  id: string;
  user_id: string | null;
  kind: string;
  status: string;
  payload: string | null;
  result: string | null;
  error: string | null;
  created_at: string;
  started_at: string | null;
  finished_at: string | null;
}

export function toJob(row: JobRow): Job {
  return {
    id: row.id,
    userId: row.user_id,
    kind: row.kind,
    status: (["queued", "running", "done", "failed"].includes(row.status)
      ? row.status
      : "queued") as Job["status"],
    payload: row.payload,
    result: row.result,
    error: row.error,
    createdAt: row.created_at,
    startedAt: row.started_at,
    finishedAt: row.finished_at,
  };
}

export async function createJob(input: {
  userId: string;
  kind: string;
  payload?: Record<string, unknown>;
}): Promise<Job> {
  const id = genId("job");
  const now = nowIso();
  await run(
    `INSERT INTO jobs (id, user_id, kind, status, payload, created_at, started_at)
     VALUES (?, ?, ?, 'running', ?, ?, ?)`,
    id,
    input.userId,
    input.kind,
    input.payload ? JSON.stringify(input.payload) : null,
    now,
    now,
  );
  return {
    id,
    userId: input.userId,
    kind: input.kind,
    status: "running",
    payload: input.payload ? JSON.stringify(input.payload) : null,
    result: null,
    error: null,
    createdAt: now,
    startedAt: now,
    finishedAt: null,
  };
}

export async function finishJob(
  jobId: string,
  outcome: { result?: Record<string, unknown>; error?: string },
) {
  await run(
    `UPDATE jobs SET status = ?, result = ?, error = ?, finished_at = ? WHERE id = ?`,
    outcome.error ? "failed" : "done",
    outcome.result ? JSON.stringify(outcome.result) : null,
    outcome.error ?? null,
    nowIso(),
    jobId,
  );
}

export async function listRecentJobs(userId: string, limit = 10): Promise<Job[]> {
  const rows = await all<JobRow>(
    "SELECT * FROM jobs WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
    userId,
    Math.min(Math.max(limit, 1), 50),
  );
  return rows.map(toJob);
}

export async function countJobsByStatus(): Promise<Record<string, number>> {
  const rows = await all<{ status: string; n: number }>(
    "SELECT status, COUNT(*) AS n FROM jobs GROUP BY status",
  );
  const out: Record<string, number> = { queued: 0, running: 0, done: 0, failed: 0 };
  for (const row of rows) out[row.status] = row.n;
  return out;
}

export async function healthCheck(): Promise<boolean> {
  const row = await first<{ one: number }>("SELECT 1 AS one");
  return row?.one === 1;
}
