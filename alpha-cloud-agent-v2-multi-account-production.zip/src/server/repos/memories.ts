// ALPHA — memory repository (persistent AI memory)

import { all, first, genId, nowIso, run } from "../db";
import { escapeLike } from "./notes";
import { extractKeywords } from "../context/keywords";
import type { Memory } from "../types";

interface MemoryRow {
  id: string;
  user_id: string;
  category: string;
  content: string;
  source: string;
  confidence: number;
  pinned: number;
  created_at: string;
  updated_at: string;
}

export function toMemory(row: MemoryRow): Memory {
  return {
    id: row.id,
    userId: row.user_id,
    category: row.category,
    content: row.content,
    source: row.source,
    confidence: row.confidence,
    pinned: !!row.pinned,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export async function listMemories(
  userId: string,
  opts: { category?: string; query?: string } = {},
): Promise<Memory[]> {
  const conditions = ["user_id = ?"];
  const params: unknown[] = [userId];
  if (opts.category && opts.category !== "all") {
    conditions.push("category = ?");
    params.push(opts.category);
  }
  if (opts.query) {
    const like = `%${escapeLike(opts.query)}%`;
    conditions.push("content LIKE ? ESCAPE '\\'");
    params.push(like);
  }
  const rows = await all<MemoryRow>(
    `SELECT * FROM memories WHERE ${conditions.join(" AND ")}
     ORDER BY pinned DESC, updated_at DESC`,
    ...params,
  );
  return rows.map(toMemory);
}

export async function findMemory(id: string, userId: string) {
  const row = await first<MemoryRow>(
    "SELECT * FROM memories WHERE id = ? AND user_id = ?",
    id,
    userId,
  );
  return row ? toMemory(row) : null;
}

export async function createMemory(
  userId: string,
  input: { category: string; content: string; source?: string; confidence?: number; pinned?: boolean },
): Promise<Memory> {
  const id = genId("mem");
  const now = nowIso();
  await run(
    `INSERT INTO memories (id, user_id, category, content, source, confidence, pinned, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    id,
    userId,
    input.category,
    input.content,
    input.source ?? "manual",
    input.confidence ?? 1.0,
    input.pinned ? 1 : 0,
    now,
    now,
  );
  return {
    id,
    userId,
    category: input.category,
    content: input.content,
    source: input.source ?? "manual",
    confidence: input.confidence ?? 1.0,
    pinned: !!input.pinned,
    createdAt: now,
    updatedAt: now,
  };
}

export async function updateMemory(
  id: string,
  userId: string,
  patch: { category?: string; content?: string; confidence?: number; pinned?: boolean },
): Promise<Memory | null> {
  const existing = await findMemory(id, userId);
  if (!existing) return null;
  await run(
    `UPDATE memories SET category = ?, content = ?, confidence = ?, pinned = ?, updated_at = ?
     WHERE id = ? AND user_id = ?`,
    patch.category ?? existing.category,
    patch.content ?? existing.content,
    patch.confidence ?? existing.confidence,
    patch.pinned !== undefined ? (patch.pinned ? 1 : 0) : existing.pinned ? 1 : 0,
    nowIso(),
    id,
    userId,
  );
  return findMemory(id, userId);
}

export async function deleteMemory(id: string, userId: string) {
  await run("DELETE FROM memories WHERE id = ? AND user_id = ?", id, userId);
}

/**
 * Retrieve memories relevant to a chat message: pinned memories always,
 * plus keyword matches. Simple lexical retrieval — no fake embeddings.
 */
export async function retrieveRelevantMemories(
  userId: string,
  messageText: string,
  limit = 12,
): Promise<Memory[]> {
  // Shared lexical extraction (same splitting as the context engine).
  const words = extractKeywords(messageText);

  if (words.length === 0) {
    // No usable keywords — pinned memories only.
    return listMemories(userId).then((all) => all.filter((m) => m.pinned).slice(0, limit));
  }

  const conditions = words.map(() => "LOWER(content) LIKE ? ESCAPE '\\'");
  const params: unknown[] = words.map((w) => `%${w}%`);
  const rows = await all<MemoryRow>(
    `SELECT * FROM memories
     WHERE user_id = ? AND (pinned = 1 OR (${conditions.join(" OR ")}))
     ORDER BY pinned DESC, updated_at DESC
     LIMIT ?`,
    userId,
    ...params,
    limit,
  );
  return rows.map(toMemory);
}
