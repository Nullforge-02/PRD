// ALPHA — session repository (server-side revocable sessions)

import { all, first, genId, nowIso, run } from "../db";
import type { Session } from "../types";

interface SessionRow {
  id: string;
  user_id: string;
  token_hash: string;
  user_agent: string | null;
  ip: string | null;
  created_at: string;
  last_seen_at: string;
  expires_at: string;
  revoked_at: string | null;
  locked_at: string | null;
}

function toSession(row: SessionRow): Session {
  return {
    id: row.id,
    userId: row.user_id,
    userAgent: row.user_agent,
    ip: row.ip,
    createdAt: row.created_at,
    lastSeenAt: row.last_seen_at,
    expiresAt: row.expires_at,
    revokedAt: row.revoked_at,
    lockedAt: row.locked_at,
  };
}

export async function createSession(input: {
  userId: string;
  tokenHash: string;
  userAgent?: string | null;
  ip?: string | null;
  ttlMs: number;
}): Promise<Session> {
  const id = genId("sess");
  const now = nowIso();
  const expiresAt = new Date(Date.now() + input.ttlMs).toISOString();
  await run(
    `INSERT INTO sessions (id, user_id, token_hash, user_agent, ip, created_at, last_seen_at, expires_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    id,
    input.userId,
    input.tokenHash,
    input.userAgent ?? null,
    input.ip ?? null,
    now,
    now,
    expiresAt,
  );
  return {
    id,
    userId: input.userId,
    userAgent: input.userAgent ?? null,
    ip: input.ip ?? null,
    createdAt: now,
    lastSeenAt: now,
    expiresAt,
    revokedAt: null,
    lockedAt: null,
  };
}

export async function findSessionByTokenHash(tokenHash: string) {
  const row = await first<SessionRow>(
    "SELECT * FROM sessions WHERE token_hash = ?",
    tokenHash,
  );
  return row ? toSession(row) : null;
}

export async function listActiveSessions(userId: string): Promise<Session[]> {
  const rows = await all<SessionRow>(
    `SELECT * FROM sessions
     WHERE user_id = ? AND revoked_at IS NULL AND expires_at > ?
     ORDER BY last_seen_at DESC`,
    userId,
    nowIso(),
  );
  return rows.map(toSession);
}

export async function revokeSession(sessionId: string) {
  await run("UPDATE sessions SET revoked_at = ? WHERE id = ?", nowIso(), sessionId);
}

export async function revokeAllSessions(userId: string, exceptSessionId?: string) {
  if (exceptSessionId) {
    await run(
      "UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND id != ? AND revoked_at IS NULL",
      nowIso(),
      userId,
      exceptSessionId,
    );
  } else {
    await run(
      "UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL",
      nowIso(),
      userId,
    );
  }
}

export async function lockSession(sessionId: string) {
  await run("UPDATE sessions SET locked_at = ? WHERE id = ?", nowIso(), sessionId);
}

export async function unlockSession(sessionId: string) {
  await run("UPDATE sessions SET locked_at = NULL WHERE id = ?", sessionId);
}

/** Throttled touch — only writes when last_seen is >60s stale. */
export async function touchSession(session: Session) {
  const last = Date.parse(session.lastSeenAt);
  if (Date.now() - last < 60_000) return;
  await run(
    "UPDATE sessions SET last_seen_at = ? WHERE id = ?",
    nowIso(),
    session.id,
  );
}

export async function deleteExpiredSessions() {
  await run("DELETE FROM sessions WHERE expires_at < ?", nowIso());
}
