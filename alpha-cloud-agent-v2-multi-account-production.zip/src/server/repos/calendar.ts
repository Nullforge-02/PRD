// ALPHA — calendar events repository

import { all, first, genId, nowIso, run } from "../db";
import type { CalendarEvent } from "../types";

interface CalendarRow {
  id: string;
  user_id: string;
  title: string;
  location: string | null;
  start_at: number;
  end_at: number | null;
  attendees: string | null;
  source: string;
  created_at: string;
  updated_at: string;
}

function toEvent(row: CalendarRow): CalendarEvent {
  let attendees: string[] = [];
  if (row.attendees) {
    try {
      const parsed = JSON.parse(row.attendees);
      if (Array.isArray(parsed)) attendees = parsed.filter((a) => typeof a === "string");
    } catch {
      // ignore malformed JSON
    }
  }
  return {
    id: row.id,
    userId: row.user_id,
    title: row.title,
    location: row.location,
    startAt: row.start_at,
    endAt: row.end_at,
    attendees,
    source: row.source,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export async function listEvents(
  userId: string,
  opts: { from?: number; to?: number } = {},
): Promise<CalendarEvent[]> {
  const conditions = ["user_id = ?"];
  const params: unknown[] = [userId];
  if (opts.from !== undefined) {
    conditions.push("end_at IS NULL OR end_at >= ?");
    params.push(opts.from);
  }
  if (opts.to !== undefined) {
    conditions.push("start_at <= ?");
    params.push(opts.to);
  }
  const rows = await all<CalendarRow>(
    `SELECT * FROM calendar_events WHERE ${conditions.join(" AND ")}
     ORDER BY start_at ASC`,
    ...params,
  );
  return rows.map(toEvent);
}

export async function findEvent(id: string, userId: string) {
  const row = await first<CalendarRow>(
    "SELECT * FROM calendar_events WHERE id = ? AND user_id = ?",
    id,
    userId,
  );
  return row ? toEvent(row) : null;
}

export async function createEvent(
  userId: string,
  input: {
    title: string;
    location?: string | null;
    startAt: number;
    endAt?: number | null;
    attendees?: string[];
    source?: string;
  },
): Promise<CalendarEvent> {
  const id = genId("evt");
  const now = nowIso();
  await run(
    `INSERT INTO calendar_events (id, user_id, title, location, start_at, end_at, attendees, source, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    id,
    userId,
    input.title,
    input.location ?? null,
    input.startAt,
    input.endAt ?? null,
    input.attendees?.length ? JSON.stringify(input.attendees) : null,
    input.source ?? "manual",
    now,
    now,
  );
  return {
    id,
    userId,
    title: input.title,
    location: input.location ?? null,
    startAt: input.startAt,
    endAt: input.endAt ?? null,
    attendees: input.attendees ?? [],
    source: input.source ?? "manual",
    createdAt: now,
    updatedAt: now,
  };
}

export async function updateEvent(
  id: string,
  userId: string,
  patch: {
    title?: string;
    location?: string | null;
    startAt?: number;
    endAt?: number | null;
    attendees?: string[];
  },
): Promise<CalendarEvent | null> {
  const existing = await findEvent(id, userId);
  if (!existing) return null;
  await run(
    `UPDATE calendar_events SET title = ?, location = ?, start_at = ?, end_at = ?, attendees = ?, updated_at = ?
     WHERE id = ? AND user_id = ?`,
    patch.title ?? existing.title,
    patch.location !== undefined ? patch.location : existing.location,
    patch.startAt ?? existing.startAt,
    patch.endAt !== undefined ? patch.endAt : existing.endAt,
    patch.attendees !== undefined
      ? patch.attendees.length ? JSON.stringify(patch.attendees) : null
      : existing.attendees.length ? JSON.stringify(existing.attendees) : null,
    nowIso(),
    id,
    userId,
  );
  return findEvent(id, userId);
}

export async function deleteEvent(id: string, userId: string) {
  await run("DELETE FROM calendar_events WHERE id = ? AND user_id = ?", id, userId);
}
