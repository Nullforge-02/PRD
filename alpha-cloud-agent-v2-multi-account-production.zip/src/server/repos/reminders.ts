// ALPHA — reminders repository

import { all, first, genId, nowIso, run } from "../db";
import type { Reminder } from "../types";

interface ReminderRow {
  id: string;
  user_id: string;
  title: string;
  note: string | null;
  due_at: number | null;
  priority: string;
  done: number;
  created_at: string;
  updated_at: string;
}

export function toReminder(row: ReminderRow): Reminder {
  return {
    id: row.id,
    userId: row.user_id,
    title: row.title,
    note: row.note,
    dueAt: row.due_at,
    priority: (["low", "normal", "high"].includes(row.priority) ? row.priority : "normal") as Reminder["priority"],
    done: !!row.done,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export async function listReminders(
  userId: string,
  opts: { done?: boolean } = {},
): Promise<Reminder[]> {
  const doneFilter = opts.done !== undefined ? "AND done = ?" : "";
  const params: unknown[] = opts.done !== undefined ? [userId, opts.done ? 1 : 0] : [userId];
  const rows = await all<ReminderRow>(
    `SELECT * FROM reminders WHERE user_id = ? ${doneFilter}
     ORDER BY done ASC, CASE WHEN due_at IS NULL THEN 1 ELSE 0 END, due_at ASC`,
    ...params,
  );
  return rows.map(toReminder);
}

export async function findReminder(id: string, userId: string) {
  const row = await first<ReminderRow>(
    "SELECT * FROM reminders WHERE id = ? AND user_id = ?",
    id,
    userId,
  );
  return row ? toReminder(row) : null;
}

export async function createReminder(
  userId: string,
  input: { title: string; note?: string; dueAt?: number | null; priority?: string },
): Promise<Reminder> {
  const id = genId("rem");
  const now = nowIso();
  const priority = ["low", "normal", "high"].includes(input.priority ?? "")
    ? (input.priority as Reminder["priority"])
    : "normal";
  await run(
    `INSERT INTO reminders (id, user_id, title, note, due_at, priority, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    id,
    userId,
    input.title,
    input.note ?? null,
    input.dueAt ?? null,
    priority,
    now,
    now,
  );
  return {
    id,
    userId,
    title: input.title,
    note: input.note ?? null,
    dueAt: input.dueAt ?? null,
    priority,
    done: false,
    createdAt: now,
    updatedAt: now,
  };
}

export async function updateReminder(
  id: string,
  userId: string,
  patch: { title?: string; note?: string | null; dueAt?: number | null; priority?: string; done?: boolean },
): Promise<Reminder | null> {
  const existing = await findReminder(id, userId);
  if (!existing) return null;
  const priority =
    patch.priority && ["low", "normal", "high"].includes(patch.priority)
      ? (patch.priority as Reminder["priority"])
      : existing.priority;
  await run(
    `UPDATE reminders SET title = ?, note = ?, due_at = ?, priority = ?, done = ?, updated_at = ?
     WHERE id = ? AND user_id = ?`,
    patch.title ?? existing.title,
    patch.note !== undefined ? patch.note : existing.note,
    patch.dueAt !== undefined ? patch.dueAt : existing.dueAt,
    priority,
    patch.done !== undefined ? (patch.done ? 1 : 0) : existing.done ? 1 : 0,
    nowIso(),
    id,
    userId,
  );
  return findReminder(id, userId);
}

export async function deleteReminder(id: string, userId: string) {
  await run("DELETE FROM reminders WHERE id = ? AND user_id = ?", id, userId);
}
