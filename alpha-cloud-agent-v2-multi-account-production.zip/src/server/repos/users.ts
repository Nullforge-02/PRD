// ALPHA — user repository

import { all, first, genId, nowIso, run } from "../db";
import type { User } from "../types";

/** User row including the password hash (server-internal only). */
export type UserWithHash = User & { passwordHash: string };

interface UserRow {
  id: string;
  email: string;
  name: string;
  password_hash: string;
  created_at: string;
  updated_at: string;
}

function toUser(row: UserRow): UserWithHash {
  return {
    id: row.id,
    email: row.email,
    name: row.name,
    passwordHash: row.password_hash,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export async function findUserByEmail(email: string) {
  const row = await first<UserRow>(
    "SELECT * FROM users WHERE email = ?",
    email.toLowerCase(),
  );
  return row ? toUser(row) : null;
}

export async function findUserById(id: string) {
  const row = await first<UserRow>("SELECT * FROM users WHERE id = ?", id);
  return row ? toUser(row) : null;
}

export async function countUsers(): Promise<number> {
  const row = await first<{ n: number }>("SELECT COUNT(*) AS n FROM users");
  return row?.n ?? 0;
}

/** Create the (single) owner account during first-run setup. */
export async function createUser(input: {
  email: string;
  name: string;
  passwordHash: string;
}): Promise<User> {
  const id = genId("usr");
  const now = nowIso();
  await run(
    `INSERT INTO users (id, email, name, password_hash, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?)`,
    id,
    input.email.toLowerCase(),
    input.name,
    input.passwordHash,
    now,
    now,
  );
  return { id, email: input.email.toLowerCase(), name: input.name, createdAt: now, updatedAt: now };
}

export async function updateUserPassword(userId: string, passwordHash: string) {
  await run(
    "UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?",
    passwordHash,
    nowIso(),
    userId,
  );
}

export async function updateUserName(userId: string, name: string) {
  await run("UPDATE users SET name = ?, updated_at = ? WHERE id = ?", name, nowIso(), userId);
}
