// ALPHA — conversations & messages repository

import { all, first, genId, nowIso, run } from "../db";
import type { Conversation, Message, MessageRole } from "../types";

interface ConversationRow {
  id: string;
  user_id: string;
  title: string;
  pinned: number;
  archived: number;
  created_at: string;
  updated_at: string;
}

interface MessageRow {
  id: string;
  conversation_id: string;
  role: string;
  content: string;
  model: string | null;
  created_at: string;
}

export function toConversation(row: ConversationRow): Conversation {
  return {
    id: row.id,
    userId: row.user_id,
    title: row.title,
    pinned: !!row.pinned,
    archived: !!row.archived,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function toMessage(row: MessageRow): Message {
  return {
    id: row.id,
    conversationId: row.conversation_id,
    role: row.role as MessageRole,
    content: row.content,
    model: row.model,
    createdAt: row.created_at,
  };
}

export async function listConversations(
  userId: string,
  opts: { includeArchived?: boolean } = {},
): Promise<Conversation[]> {
  const archivedFilter = opts.includeArchived ? "" : "AND archived = 0";
  const rows = await all<ConversationRow>(
    `SELECT * FROM conversations WHERE user_id = ? ${archivedFilter}
     ORDER BY pinned DESC, updated_at DESC`,
    userId,
  );
  return rows.map(toConversation);
}

export async function findConversation(id: string, userId: string) {
  const row = await first<ConversationRow>(
    "SELECT * FROM conversations WHERE id = ? AND user_id = ?",
    id,
    userId,
  );
  return row ? toConversation(row) : null;
}

export async function createConversation(
  userId: string,
  title = "New conversation",
): Promise<Conversation> {
  const id = genId("cnv");
  const now = nowIso();
  await run(
    `INSERT INTO conversations (id, user_id, title, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?)`,
    id,
    userId,
    title,
    now,
    now,
  );
  return {
    id,
    userId,
    title,
    pinned: false,
    archived: false,
    createdAt: now,
    updatedAt: now,
  };
}

export async function updateConversation(
  id: string,
  userId: string,
  patch: { title?: string; pinned?: boolean; archived?: boolean },
): Promise<Conversation | null> {
  const existing = await findConversation(id, userId);
  if (!existing) return null;
  await run(
    `UPDATE conversations SET title = ?, pinned = ?, archived = ?, updated_at = ?
     WHERE id = ? AND user_id = ?`,
    patch.title ?? existing.title,
    patch.pinned !== undefined ? (patch.pinned ? 1 : 0) : existing.pinned ? 1 : 0,
    patch.archived !== undefined ? (patch.archived ? 1 : 0) : existing.archived ? 1 : 0,
    nowIso(),
    id,
    userId,
  );
  return findConversation(id, userId);
}

export async function deleteConversation(id: string, userId: string) {
  await run("DELETE FROM conversations WHERE id = ? AND user_id = ?", id, userId);
}

export async function addMessage(input: {
  conversationId: string;
  role: MessageRole;
  content: string;
  model?: string | null;
}): Promise<Message> {
  const id = genId("msg");
  const now = nowIso();
  await run(
    `INSERT INTO messages (id, conversation_id, role, content, model, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`,
    id,
    input.conversationId,
    input.role,
    input.content,
    input.model ?? null,
    now,
  );
  // Bump conversation updated_at so the list stays sorted by activity.
  await run(
    "UPDATE conversations SET updated_at = ? WHERE id = ?",
    now,
    input.conversationId,
  );
  return {
    id,
    conversationId: input.conversationId,
    role: input.role,
    content: input.content,
    model: input.model ?? null,
    createdAt: now,
  };
}

export async function listMessages(conversationId: string): Promise<Message[]> {
  const rows = await all<MessageRow>(
    "SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC, rowid ASC",
    conversationId,
  );
  return rows.map(toMessage);
}

export async function countMessages(conversationId: string): Promise<number> {
  const row = await first<{ n: number }>(
    "SELECT COUNT(*) AS n FROM messages WHERE conversation_id = ?",
    conversationId,
  );
  return row?.n ?? 0;
}
