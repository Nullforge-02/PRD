// ALPHA — custom AI provider repository (D1)
//
// Unlimited user-configured AI providers (Settings → AI Providers → + Add API).
// Rows store ONLY the AES-GCM ciphertext of the API key plus non-secret
// metadata. Plaintext keys exist transiently in request memory and nowhere
// else — never in D1, logs, or API responses.
//
// The metadata columns here (never the key) drive routing eligibility; the
// router decrypts lazily at attempt time (see ai/router.ts).

import { all, first, genId, nowIso, run } from "../db";
import type { UserCapability } from "../ai/capabilities";
import { parseCapabilities, serializeCapabilities } from "../ai/capabilities";

export type TestStatus = "success" | "failed";
export type ProviderProtocol = "openai-compatible";

export interface CustomProvider {
  id: string;
  userId: string;
  /** User-chosen display name (unique per user). */
  name: string;
  protocol: ProviderProtocol;
  encryptedApiKey: string;
  /** Last 4 characters of the key — masked display ONLY. */
  keyHint: string;
  baseUrl: string;
  model: string;
  visionModel: string | null;
  imageModel: string | null;
  videoModel: string | null;
  capabilities: UserCapability[];
  enabled: boolean;
  /** Lower = tried earlier by the router. */
  priority: number;
  createdAt: string;
  updatedAt: string;
  lastTestedAt: string | null;
  lastTestStatus: TestStatus | null;
}

interface CustomProviderRow {
  id: string;
  user_id: string;
  name: string;
  protocol: string;
  encrypted_api_key: string;
  key_hint: string;
  base_url: string;
  model: string;
  vision_model: string | null;
  image_model: string | null;
  video_model: string | null;
  capabilities: string;
  enabled: number;
  priority: number;
  created_at: string;
  updated_at: string;
  last_tested_at: string | null;
  last_test_status: string | null;
}

function toCustomProvider(row: CustomProviderRow): CustomProvider {
  return {
    id: row.id,
    userId: row.user_id,
    name: row.name,
    protocol: row.protocol === "openai-compatible" ? "openai-compatible" : "openai-compatible",
    encryptedApiKey: row.encrypted_api_key,
    keyHint: row.key_hint,
    baseUrl: row.base_url,
    model: row.model,
    visionModel: row.vision_model,
    imageModel: row.image_model,
    videoModel: row.video_model,
    capabilities: parseCapabilities(row.capabilities),
    enabled: !!row.enabled,
    priority: row.priority,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    lastTestedAt: row.last_tested_at,
    lastTestStatus:
      row.last_test_status === "success" || row.last_test_status === "failed"
        ? row.last_test_status
        : null,
  };
}

export async function findCustomProvider(
  id: string,
  userId: string,
): Promise<CustomProvider | null> {
  const row = await first<CustomProviderRow>(
    "SELECT * FROM ai_custom_providers WHERE id = ? AND user_id = ?",
    id,
    userId,
  );
  return row ? toCustomProvider(row) : null;
}

export async function findCustomProviderByName(
  userId: string,
  name: string,
): Promise<CustomProvider | null> {
  const row = await first<CustomProviderRow>(
    "SELECT * FROM ai_custom_providers WHERE user_id = ? AND name = ?",
    userId,
    name,
  );
  return row ? toCustomProvider(row) : null;
}

/** All custom providers of a user, in routing order (priority, createdAt). */
export async function listCustomProviders(userId: string): Promise<CustomProvider[]> {
  const rows = await all<CustomProviderRow>(
    "SELECT * FROM ai_custom_providers WHERE user_id = ? ORDER BY priority ASC, created_at ASC",
    userId,
  );
  return rows.map(toCustomProvider);
}

export interface InsertCustomProviderInput {
  userId: string;
  name: string;
  protocol: ProviderProtocol;
  encryptedApiKey: string;
  keyHint: string;
  baseUrl: string;
  model: string;
  visionModel: string | null;
  imageModel: string | null;
  videoModel: string | null;
  capabilities: UserCapability[];
  enabled: boolean;
  priority: number;
  /** Pre-seeded by the create route after its REAL connection test. */
  lastTestStatus: TestStatus;
}

export async function insertCustomProvider(
  input: InsertCustomProviderInput,
): Promise<CustomProvider> {
  const id = genId("acp");
  const now = nowIso();
  await run(
    `INSERT INTO ai_custom_providers
       (id, user_id, name, protocol, encrypted_api_key, key_hint, base_url, model,
        vision_model, image_model, video_model, capabilities, enabled, priority,
        created_at, updated_at, last_tested_at, last_test_status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    id,
    input.userId,
    input.name,
    input.protocol,
    input.encryptedApiKey,
    input.keyHint,
    input.baseUrl,
    input.model,
    input.visionModel,
    input.imageModel,
    input.videoModel,
    serializeCapabilities(input.capabilities),
    input.enabled ? 1 : 0,
    input.priority,
    now,
    now,
    now,
    input.lastTestStatus,
  );
  const created = await findCustomProvider(id, input.userId);
  if (!created) throw new Error("Failed to create custom provider");
  return created;
}

export interface UpdateCustomProviderInput {
  /** Fields explicitly provided are updated; others keep their current value. */
  name?: string;
  encryptedApiKey?: string;
  keyHint?: string;
  baseUrl?: string;
  model?: string;
  visionModel?: string | null;
  imageModel?: string | null;
  videoModel?: string | null;
  capabilities?: UserCapability[];
  enabled?: boolean;
  priority?: number;
}

export async function updateCustomProvider(
  id: string,
  userId: string,
  input: UpdateCustomProviderInput,
): Promise<CustomProvider | null> {
  const current = await findCustomProvider(id, userId);
  if (!current) return null;
  await run(
    `UPDATE ai_custom_providers
     SET name = ?, encrypted_api_key = ?, key_hint = ?, base_url = ?, model = ?,
         vision_model = ?, image_model = ?, video_model = ?, capabilities = ?,
         enabled = ?, priority = ?, updated_at = ?
     WHERE id = ?`,
    input.name ?? current.name,
    input.encryptedApiKey ?? current.encryptedApiKey,
    input.keyHint ?? current.keyHint,
    input.baseUrl ?? current.baseUrl,
    input.model ?? current.model,
    input.visionModel !== undefined ? input.visionModel : current.visionModel,
    input.imageModel !== undefined ? input.imageModel : current.imageModel,
    input.videoModel !== undefined ? input.videoModel : current.videoModel,
    input.capabilities ? serializeCapabilities(input.capabilities) : serializeCapabilities(current.capabilities),
    input.enabled !== undefined ? (input.enabled ? 1 : 0) : current.enabled ? 1 : 0,
    input.priority !== undefined ? input.priority : current.priority,
    nowIso(),
    current.id,
  );
  return findCustomProvider(id, userId);
}

/**
 * Delete a custom provider. Removes the encrypted credential, the metadata
 * and the health/test history together — no orphan credentials.
 */
export async function deleteCustomProvider(id: string, userId: string): Promise<boolean> {
  const current = await findCustomProvider(id, userId);
  if (!current) return false;
  await run("DELETE FROM ai_custom_providers WHERE id = ?", current.id);
  return true;
}

/** Record the outcome of a Test Connection run (never stores keys). */
export async function recordCustomTestResult(
  id: string,
  userId: string,
  status: TestStatus,
): Promise<void> {
  await run(
    `UPDATE ai_custom_providers
     SET last_tested_at = ?, last_test_status = ?, updated_at = updated_at
     WHERE id = ? AND user_id = ?`,
    nowIso(),
    status,
    id,
    userId,
  );
}
