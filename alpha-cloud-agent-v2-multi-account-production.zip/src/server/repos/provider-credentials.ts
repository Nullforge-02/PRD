// ALPHA — AI provider credentials repository (D1)
//
// Dashboard-managed provider credentials (Settings → AI Providers). Rows store
// ONLY the AES-GCM ciphertext (see src/server/ai/credential-crypto.ts) plus
// non-secret metadata. Plaintext keys exist transiently in request memory and
// nowhere else — never in D1, logs, or API responses.

import { all, first, genId, nowIso, run } from "../db";

export type TestStatus = "success" | "failed";

export interface ProviderCredential {
  id: string;
  userId: string;
  provider: string;
  encryptedApiKey: string;
  /** Last 4 characters of the key — used ONLY for masked display. */
  keyHint: string;
  baseUrl: string | null;
  model: string | null;
  visionModel: string | null;
  enabled: boolean;
  createdAt: string;
  updatedAt: string;
  lastTestedAt: string | null;
  lastTestStatus: TestStatus | null;
}

interface CredentialRow {
  id: string;
  user_id: string;
  provider: string;
  encrypted_api_key: string;
  key_hint: string;
  base_url: string | null;
  model: string | null;
  vision_model: string | null;
  enabled: number;
  created_at: string;
  updated_at: string;
  last_tested_at: string | null;
  last_test_status: string | null;
}

function toCredential(row: CredentialRow): ProviderCredential {
  return {
    id: row.id,
    userId: row.user_id,
    provider: row.provider,
    encryptedApiKey: row.encrypted_api_key,
    keyHint: row.key_hint,
    baseUrl: row.base_url,
    model: row.model,
    visionModel: row.vision_model,
    enabled: !!row.enabled,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    lastTestedAt: row.last_tested_at,
    lastTestStatus:
      row.last_test_status === "success" || row.last_test_status === "failed"
        ? row.last_test_status
        : null,
  };
}

export async function findCredential(
  userId: string,
  provider: string,
): Promise<ProviderCredential | null> {
  const row = await first<CredentialRow>(
    "SELECT * FROM ai_provider_credentials WHERE user_id = ? AND provider = ?",
    userId,
    provider,
  );
  return row ? toCredential(row) : null;
}

export async function listCredentials(userId: string): Promise<ProviderCredential[]> {
  const rows = await all<CredentialRow>(
    "SELECT * FROM ai_provider_credentials WHERE user_id = ? ORDER BY provider",
    userId,
  );
  return rows.map(toCredential);
}

/** Convenience map (provider id → credential) for routing decisions. */
export async function credentialMap(
  userId: string,
): Promise<Map<string, ProviderCredential>> {
  const list = await listCredentials(userId);
  return new Map(list.map((c) => [c.provider, c]));
}

export interface InsertCredentialInput {
  userId: string;
  provider: string;
  encryptedApiKey: string;
  keyHint: string;
  baseUrl: string | null;
  model: string | null;
  visionModel: string | null;
  enabled: boolean;
}

export async function insertCredential(
  input: InsertCredentialInput,
): Promise<ProviderCredential> {
  const id = genId("apc");
  const now = nowIso();
  await run(
    `INSERT INTO ai_provider_credentials
       (id, user_id, provider, encrypted_api_key, key_hint, base_url, model,
        vision_model, enabled, created_at, updated_at, last_tested_at, last_test_status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL)`,
    id,
    input.userId,
    input.provider,
    input.encryptedApiKey,
    input.keyHint,
    input.baseUrl,
    input.model,
    input.visionModel,
    input.enabled ? 1 : 0,
    now,
    now,
  );
  const created = await findCredential(input.userId, input.provider);
  if (!created) throw new Error("Failed to create provider credential");
  return created;
}

export interface UpdateCredentialInput {
  /** Fields explicitly provided are updated; others keep their current value. */
  encryptedApiKey?: string;
  keyHint?: string;
  baseUrl?: string | null;
  model?: string | null;
  visionModel?: string | null;
  enabled?: boolean;
}

export async function updateCredential(
  userId: string,
  provider: string,
  input: UpdateCredentialInput,
): Promise<ProviderCredential | null> {
  const current = await findCredential(userId, provider);
  if (!current) return null;
  await run(
    `UPDATE ai_provider_credentials
     SET encrypted_api_key = ?, key_hint = ?, base_url = ?, model = ?,
         vision_model = ?, enabled = ?, updated_at = ?
     WHERE id = ?`,
    input.encryptedApiKey ?? current.encryptedApiKey,
    input.keyHint ?? current.keyHint,
    input.baseUrl !== undefined ? input.baseUrl : current.baseUrl,
    input.model !== undefined ? input.model : current.model,
    input.visionModel !== undefined ? input.visionModel : current.visionModel,
    input.enabled !== undefined ? (input.enabled ? 1 : 0) : current.enabled ? 1 : 0,
    nowIso(),
    current.id,
  );
  return findCredential(userId, provider);
}

/** Delete the stored credential. After this the dashboard credential is gone
 *  for good (the router falls back to environment credentials, if any). */
export async function deleteCredential(
  userId: string,
  provider: string,
): Promise<boolean> {
  const current = await findCredential(userId, provider);
  if (!current) return false;
  await run("DELETE FROM ai_provider_credentials WHERE id = ?", current.id);
  return true;
}

/** Record the outcome of a Test Connection run (never stores keys). */
export async function recordTestResult(
  userId: string,
  provider: string,
  status: TestStatus,
): Promise<void> {
  await run(
    `UPDATE ai_provider_credentials
     SET last_tested_at = ?, last_test_status = ?, updated_at = updated_at
     WHERE user_id = ? AND provider = ?`,
    nowIso(),
    status,
    userId,
    provider,
  );
}
