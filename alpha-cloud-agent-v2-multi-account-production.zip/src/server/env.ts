// ALPHA — typed Cloudflare environment access
//
// Bindings (wrangler.jsonc):
//   DB      — Cloudflare D1  (structured data)
//   STORAGE — Cloudflare R2  (files & media)
//   ASSETS  — static assets (OpenNext)
//
// Secrets (wrangler secret put ...):
//   AUTH_SECRET            — session token HMAC key (REQUIRED in production)
//   AI_CREDENTIALS_SECRET  — AES-GCM key for dashboard-managed provider API
//                           keys (REQUIRED once provider keys are saved in
//                           Settings → AI Providers; see ai/credentials.ts)
//
//   ZAI_BASE_URL / ZAI_API_KEY / ZAI_TOKEN / ZAI_CHAT_ID / ZAI_USER_ID
//   ZAI_MODEL / ZAI_VISION_MODEL
//                         — Z.ai provider (see src/server/ai/providers/zai.ts)
//   OPENAI_API_KEY / OPENAI_BASE_URL / OPENAI_MODEL / OPENAI_VISION_MODEL
//   GROQ_API_KEY / GROQ_BASE_URL / GROQ_MODEL / GROQ_VISION_MODEL
//   OPENROUTER_API_KEY / OPENROUTER_BASE_URL / OPENROUTER_MODEL / OPENROUTER_VISION_MODEL
//                         — additional AI providers (see src/server/ai/providers/)
//
//   AI_PRIMARY_PROVIDER / AI_FALLBACK_PROVIDERS / AI_MAX_ATTEMPTS /
//   AI_DISABLED_PROVIDERS
//                         — AI router configuration (see src/server/ai/registry.ts)
//
//   GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET — Google OAuth (Gmail).
//     (GMAIL_CLIENT_ID / GMAIL_CLIENT_SECRET are accepted as legacy aliases.)
//   GITHUB_CLIENT_ID / GITHUB_CLIENT_SECRET — GitHub OAuth.
//   OAUTH_CALLBACK_ORIGIN  — optional override when the public origin cannot
//     be derived from the request (defaults to the request origin).

import { getCloudflareContext } from "@opennextjs/cloudflare";

/** Runtime bindings from wrangler.jsonc (worker-configuration.d.ts) + secrets. */
export type AlphaEnv = Env & {
  AUTH_SECRET?: string;
  AI_CREDENTIALS_SECRET?: string;
  ZAI_BASE_URL?: string;
  ZAI_API_KEY?: string;
  ZAI_TOKEN?: string;
  ZAI_CHAT_ID?: string;
  ZAI_USER_ID?: string;
  ZAI_MODEL?: string;
  ZAI_VISION_MODEL?: string;
  OPENAI_API_KEY?: string;
  OPENAI_BASE_URL?: string;
  OPENAI_MODEL?: string;
  OPENAI_VISION_MODEL?: string;
  GROQ_API_KEY?: string;
  GROQ_BASE_URL?: string;
  GROQ_MODEL?: string;
  GROQ_VISION_MODEL?: string;
  OPENROUTER_API_KEY?: string;
  OPENROUTER_BASE_URL?: string;
  OPENROUTER_MODEL?: string;
  OPENROUTER_VISION_MODEL?: string;
  AI_PRIMARY_PROVIDER?: string;
  AI_FALLBACK_PROVIDERS?: string;
  AI_MAX_ATTEMPTS?: string;
  AI_DISABLED_PROVIDERS?: string;
  GOOGLE_CLIENT_ID?: string;
  GOOGLE_CLIENT_SECRET?: string;
  GMAIL_CLIENT_ID?: string;
  GMAIL_CLIENT_SECRET?: string;
  GITHUB_CLIENT_ID?: string;
  GITHUB_CLIENT_SECRET?: string;
  OAUTH_CALLBACK_ORIGIN?: string;
};

export async function getEnv(): Promise<AlphaEnv> {
  const ctx = await getCloudflareContext({ async: true });
  return ctx.env as AlphaEnv;
}

export function isProduction(): boolean {
  return process.env.NODE_ENV === "production";
}
