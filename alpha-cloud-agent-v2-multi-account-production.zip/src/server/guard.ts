// ALPHA — route guard: authentication + CSRF + lock enforcement

import { NextRequest } from "next/server";
import { getAuthContext, isSameOrigin, sessionIsLocked, type AuthContext } from "./auth";
import { locked, unauthorized } from "./http";

export type GuardResult =
  | { ok: true; ctx: AuthContext }
  | { ok: false; response: Response };

/**
 * Enforce authentication for an API route.
 *
 * - State-changing methods require a same-origin Origin/Referer (CSRF).
 * - Locked sessions get 423 unless `allowLocked` (auth/unlock).
 */
export async function requireAuth(
  req: NextRequest,
  opts: { allowLocked?: boolean } = {},
): Promise<GuardResult> {
  if (!isSameOrigin(req)) {
    return { ok: false, response: new Response("Cross-origin request rejected", { status: 403 }) };
  }
  const ctx = await getAuthContext(req);
  if (!ctx) {
    return { ok: false, response: unauthorized() };
  }
  if (sessionIsLocked(ctx.session) && !opts.allowLocked) {
    return { ok: false, response: locked() };
  }
  return { ok: true, ctx };
}
