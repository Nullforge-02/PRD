// ALPHA — Next.js instrumentation hook
//
// In local development (`next dev`), this spins up the Cloudflare platform
// proxy (miniflare) so the app gets REAL local D1 + R2 bindings backed by
// `.wrangler/state` — the same code path as production on Workers.
//
// When running as the BUILT OpenNext worker (via `wrangler dev` preview or
// deployed to Cloudflare), the worker entrypoint installs the Cloudflare
// context on the global scope BEFORE Next.js boots — in that case the
// dev-proxy initialization must be skipped.

export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const contextSymbol = Symbol.for("__cloudflare-context__");
    const alreadyProvided =
      (globalThis as unknown as Record<symbol, unknown>)[contextSymbol] != null;
    if (!alreadyProvided) {
      const { initOpenNextCloudflareForDev } = await import("@opennextjs/cloudflare");
      await initOpenNextCloudflareForDev();
    }
  }
}
