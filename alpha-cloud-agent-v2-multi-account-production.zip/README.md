# ALPHA — Personal Cloud AI Agent

A production-first personal AI agent that runs as a single **Cloudflare Worker**:

```
Browser
  ↓
Next.js (Alpha UI)
  ↓
OpenNext for Cloudflare
  ↓
Cloudflare Worker
  ├── Cloudflare D1   — structured persistent data
  ├── Cloudflare R2   — files & media
  ├── AI Router → Z.ai | OpenAI | Groq | OpenRouter
  ├── Real authentication (PBKDF2 + server-side sessions)
  └── future integrations (Gmail / GitHub OAuth)
```

**Not** a local-first app: the Workers runtime is the primary target from day one. The same code path (D1/R2 bindings via `getCloudflareContext`) runs in local development through miniflare.

## What's inside

| Area | Details |
|---|---|
| **Chat** | Real AI responses via the multi-provider router (streamed), persistent conversations & messages, layered context (token-bounded rolling summary + lexically-relevant older messages + bounded recent window + persistent memories), real tool-calling (notes, memory, reminders, web search, image generation) |
| **AI Router** | 4 providers (Z.ai, OpenAI, Groq, OpenRouter) with capability routing, priority order, automatic fallback and real health tracking |
| **Files** | Upload (≤50 MB) → R2, metadata in D1, download, delete |
| **Notes** | Full CRUD, markdown editor + preview, search |
| **Memory** | Persistent AI memory (manual + AI-created), keyword retrieval into chat |
| **Media** | Real AI image generation → R2 gallery |
| **Reminders / Calendar** | Real CRUD |
| **Tools** | 10 real tools with permission tiers (low / medium-confirm / high-confirm) |
| **System** | Live health checks (D1, R2, per-provider AI latency) — nothing simulated |
| **Security** | PBKDF2-SHA256 (210k iterations) password hashing, HttpOnly SameSite cookies, server-side revocable sessions, session lock/unlock, change password, login rate-limiting, same-origin CSRF enforcement, audit log |
| **Gmail / GitHub** | Honest "Not connected" states until real OAuth credentials are configured — never simulated |

A brand-new installation starts **clean**: no users, no conversations, no notes, no memories, no files. The first visit shows a one-time setup screen to create the owner account.

## Tech stack

- Next.js 16 (App Router, TypeScript)
- OpenNext for Cloudflare (`@opennextjs/cloudflare`)
- Cloudflare D1 (native repository layer — no ORM) + R2
- Tailwind CSS 4 + shadcn/ui, Zustand, TanStack Query, framer-motion
- z-ai-web-dev-sdk (server-side only, Z.ai adapter) + native fetch for the
  OpenAI-compatible providers (no additional SDKs)

## AI providers & routing

Every AI request goes through the **AI router** (`src/server/ai/router.ts`):

```
chat engine / tools / media / voice / vision routes
  ↓ capability (chat · vision · imageGeneration · reasoning · video · fast · webSearch · tts · asr)
eligible = enabled + configured + capability + not in cooldown
  ↓ merged priority order (custom providers win ties against built-ins)
provider attempt → on failure: mark unhealthy, try next (max AI_MAX_ATTEMPTS)
```

Two provider families share one router:

- **Built-in providers** — Z.ai (default primary), OpenAI, Groq, OpenRouter,
  with their existing dashboard credentials (`ai_provider_credentials`) and
  environment fallbacks.
- **Custom providers** — **unlimited**, user-configured via Settings →
  AI Providers → **+ Add API**. Any OpenAI-compatible endpoint works:
  OpenRouter, Gemini-compatible gateways, DeepSeek, Mistral, Together,
  local/self-hosted servers — anything that speaks `/chat/completions`.
  The system never assumes a custom provider IS OpenAI; only the protocol is
  the contract.

| Built-in | Chat | Tools | Vision | Image gen | Web search | TTS | ASR |
|---|---|---|---|---|---|---|---|
| **Z.ai** (default primary) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **OpenAI** | ✓ | ✓ | ✓ | — | — | — | — |
| **Groq** | ✓ | ✓ | ✓ | — | — | — | — |
| **OpenRouter** | ✓ | ✓ | ✓ | — | — | — | — |

Providers declare their capabilities honestly — a provider without a
credential reports `configured: false` and is **never** selected or reported
healthy. If no provider can serve a capability, the API returns a clean 501;
if all capable providers are in cooldown, a 503.

### Custom providers (+ Add API)

**Settings → AI Providers → + Add API** adds as many AI APIs as you want
(no hardcoded limit, no fixed provider enum):

- Fields: provider name, API key, base URL, model (with **Fetch Models**
  discovery via `GET {baseUrl}/models` — falls back to manual entry when a
  provider doesn't implement it), optional vision / image / video models,
  the six **capabilities** (Text, Vision, Image Generation, Video, Reasoning,
  Fast), priority and enable/disable.
- **Test & Add**: nothing is saved unless the provider REALLY answers — the
  server makes a real request with the supplied key and model first; failures
  return a sanitized error (`Authentication failed — check the API key`,
  `Rate limited by the provider…`) and create nothing.
- Capabilities are **user-selected and authoritative** — routing never sends
  a vision request to a text-only provider, never sends image generation to
  a provider without the Image Generation capability, and never invents
  capabilities on its own.
- Priority: lower = tried earlier. Custom providers with the same priority
  as a built-in sort BEFORE it (an explicit user choice wins over environment
  defaults). Among customs, earlier-created wins ties.
- Keys are encrypted (AES-256-GCM, per-key random IV) in the
  `ai_custom_providers` D1 table, shown only as `••••••••••••abcd`, never
  returned to the browser. Editing without re-entering the key preserves the
  stored credential. Deleting removes credential + metadata + health data
  together — the provider is unavailable immediately, with no orphans.
- Custom providers with the Image Generation capability serve the media
  generation route through the standard `/images/generations` endpoint.

### Dashboard-managed credentials (recommended)

**Settings → AI Providers** manages provider keys from the app itself:

- Paste a key per provider (Z.ai / OpenAI / Groq / OpenRouter), optionally set
  model, vision model and base URL, enable/disable routing per provider.
- Keys are encrypted server-side with **AES-256-GCM** (unique random IV per
  key, key derived from the `AI_CREDENTIALS_SECRET` Worker secret via
  HKDF-SHA256) and stored in the `ai_provider_credentials` D1 table — never
  plaintext, never returned to the browser (only a masked
  `••••••••••••••abcd` form is shown).
- **Test connection** makes a REAL provider request and records real latency
  plus pass/fail per provider.
- Credential precedence per provider: **dashboard key → environment key**.
  A provider disabled in the dashboard is excluded from routing entirely.

The intended production secret setup is therefore just:

```
npx wrangler secret put AUTH_SECRET             # sessions
npx wrangler secret put AI_CREDENTIALS_SECRET   # provider-key + OAuth-token encryption
```

…with provider keys managed in the dashboard. Environment credentials remain
fully supported as a fallback (below) for existing deployments.

## Integrations (Gmail + GitHub, real OAuth)

Settings → Integrations (and the Gmail / GitHub views) offer **real OAuth
2.0 web-server flows** — no placeholders, no simulated connections:

- **Connect** redirects to Google / GitHub consent; the callback validates a
  random single-use `state` cookie (CSRF guard), exchanges the authorization
  code server-side, and stores the access (+ refresh) tokens **encrypted**
  with the same AES-256-GCM construction under a dedicated HKDF label
  (`connected_accounts` table). Client secrets never leave Worker secrets;
  tokens never enter URLs, logs, audit events or the browser.
- **Gmail** (scopes: `gmail.readonly`, `gmail.send`, openid/email/profile):
  search + read messages, and **send email only after an explicit
  confirmation dialog** — never silently. Expired access tokens are refreshed
  automatically from the refresh token; a failed refresh flips the connection
  to "Reauthorization needed" without crashing anything.
- **GitHub** (scopes: `read:user repo`): connected-account identity and
  read-only repository / issue / PR metadata browsing. No destructive GitHub
  operations are implemented; writes would always require explicit
  confirmation flows.
- **Multi-account:** connect SEVERAL Google accounts (personal / work /
  project / …) and SEVERAL GitHub accounts. Reconnecting the same external
  account deduplicates (updates its tokens); connecting a different one adds
  it side by side. Each provider has ONE explicit default account (*Use*),
  every operation names the account it uses (explicit selection → default —
  never "most recently updated"), and GitHub accounts carry user-editable
  **roles** (`storage` / `scripts` / `general`) used by the centralized
  account resolver. Reauthorization/disconnect is per-account.
- **Disconnect** revokes the provider token (best effort) and deletes the
  stored tokens + linkage (per account, or all accounts of a provider).
- Until `GOOGLE_CLIENT_ID`/`GOOGLE_CLIENT_SECRET` (or
  `GITHUB_CLIENT_ID`/`GITHUB_CLIENT_SECRET`) are configured as Worker
  secrets, the UI honestly shows **"Gmail OAuth is not configured"** / the
  GitHub equivalent — the Connect button explains why instead of pretending.

Production callback URLs (also in DEPLOYMENT.md):

```
https://<your-domain>/api/v1/integrations/google/callback
https://<your-domain>/api/v1/integrations/github/callback
```

### Environment credentials (fallback)

| Variable | Purpose |
|---|---|
| `AI_CREDENTIALS_SECRET` | AES-GCM secret for dashboard-stored provider keys |
| `ZAI_API_KEY` (+ `ZAI_BASE_URL`, `ZAI_TOKEN`, `ZAI_CHAT_ID`, `ZAI_USER_ID`) | Z.ai credentials |
| `ZAI_MODEL` / `ZAI_VISION_MODEL` | Z.ai models (default `glm-4.6` / `glm-4.5v`) |
| `OPENAI_API_KEY`, `OPENAI_BASE_URL`, `OPENAI_MODEL`, `OPENAI_VISION_MODEL` | OpenAI |
| `GROQ_API_KEY`, `GROQ_BASE_URL`, `GROQ_MODEL`, `GROQ_VISION_MODEL` | Groq |
| `OPENROUTER_API_KEY`, `OPENROUTER_BASE_URL`, `OPENROUTER_MODEL`, `OPENROUTER_VISION_MODEL` | OpenRouter |
| `AI_PRIMARY_PROVIDER` | routing priority #1 (default `zai`) |
| `AI_FALLBACK_PROVIDERS` | comma-separated fallback order |
| `AI_MAX_ATTEMPTS` | distinct providers per request, 1–4 (default 3) |
| `AI_DISABLED_PROVIDERS` | comma-separated ids excluded from routing |

Layered-context tuning (optional — defaults in parentheses, details in
`.env.example`; requires migration `0004`):
`CONTEXT_RECENT_MESSAGES_LIMIT` (16), `CONTEXT_SUMMARY_MAX_TOKENS` (600),
`CONTEXT_RELEVANT_HISTORY_MAX_TOKENS` (1200), `CONTEXT_MEMORY_MAX_TOKENS`
(400), `CONTEXT_SUMMARIZE_THRESHOLD` (24), `CONTEXT_SUMMARY_TARGET_TOKENS`
(450).

Failure policy (see `src/server/ai/errors.ts`): `authentication` (15 min
cooldown), `rate_limit` (60 s), `timeout`/`network`/`server_error` (30 s,
mild backoff) fall back to the next provider; `invalid_request` is returned
immediately (falling back would repeat the same mistake). Health is tracked
per Worker isolate from **real request outcomes only** — visible in System →
AI provider card and via `GET /api/v1/providers`.

## Local development

```bash
npm install                                   # or: bun install
npx wrangler d1 migrations apply alpha-db --local   # create local D1 schema
npm run dev                                   # next dev on :3000
```

`src/instrumentation.ts` starts the Cloudflare platform proxy in dev, so the app talks to **real local D1/R2 bindings** (backed by `.wrangler/state`) — identical to the production code path.

Optionally create `.dev.vars` (git-ignored) with a stable local `AUTH_SECRET`:

```
AUTH_SECRET=<openssl rand -base64 32>
```

Then open http://localhost:3000 and create the owner account.

## Verification

```bash
npm run lint        # ESLint
npm run typecheck   # tsc --noEmit
npm run build       # opennextjs-cloudflare build → .open-next/worker.js
npm run preview     # run the built worker locally (wrangler dev)
```

> Low-memory machines: if the default (Turbopack) build is OOM-killed, build with
> `npx next build --webpack` first, then `npx opennextjs-cloudflare build --skipNextBuild`.

## Deploying

See **[DEPLOYMENT.md](./DEPLOYMENT.md)** for the exact production procedure (D1 + R2 + secrets + custom domain `alpha02.org`).

## Project layout

```
migrations/            D1 SQL migrations (no seed data by design)
src/
  app/                 Next.js app router (page + /api/v1/** route handlers)
  components/          shell, auth screens, views, common UI
  server/              Cloudflare-first server core
    ai/                AI router: registry, router, health, errors, types
      providers/       zai.ts (SDK) + openai/groq/openrouter (fetch, shared core)
    repos/             native D1 repositories (users, sessions, …)
    auth.ts            real authentication & sessions
    storage.ts         R2 object storage (safe keys, MIME checks)
    tools.ts           real tool registry + executor
    chat-engine.ts     memory-aware chat + JSON tool-call protocol
  lib/                 client API helpers, store, theme
worker-configuration.d.ts   generated by `npx wrangler types`
wrangler.jsonc         Worker config (D1 binding DB, R2 binding STORAGE)
open-next.config.ts    OpenNext adapter config
```
