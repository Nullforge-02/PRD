import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Required by OpenNext for Cloudflare (produces .next/standalone).
  output: "standalone",
  // OpenNext for Cloudflare builds on top of the default Next.js build.
  // (`npx opennextjs-cloudflare build` runs `next build` itself.)
  typescript: {
    // Type errors are caught by `npm run typecheck` / CI instead.
    ignoreBuildErrors: true,
  },
  // Mark @opennextjs/cloudflare as external so the bundler doesn't try to
  // bundle it — the module only resolves inside the Workers runtime
  // (or the local dev proxy set up by initOpenNextCloudflareForDev()).
  serverExternalPackages: ["@opennextjs/cloudflare"],
};

export default nextConfig;
