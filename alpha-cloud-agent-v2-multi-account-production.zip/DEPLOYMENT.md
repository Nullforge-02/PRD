# ALPHA — Production Deployment (Cloudflare Workers)

Target: **alpha02.org** on Cloudflare Workers, via OpenNext for Cloudflare.

> Do NOT deploy to production until you have explicitly decided to. Everything
> below assumes you are ready.

---

## 0. Prerequisites

- Node.js 20+ (or Bun 1.3+) and npm
- A Cloudflare account with Workers enabled
- The Wrangler CLI (bundled with the repo): `npx wrangler`
- Z.ai provider credentials (base URL, API key, token, chat id, user id)
- A strong `AUTH_SECRET` (e.g. `openssl rand -base64 32`)

## 1. Install dependencies

```bash
npm install
```

## 2. Log in to Cloudflare

```bash
npx wrangler login
```

## 3. Create the D1 database

```bash
npx wrangler d1 create alpha-db
```

Copy the returned `database_id` and paste it into **wrangler.jsonc**, replacing
the placeholder:

```jsonc
"d1_databases": [
  {
    "binding": "DB",
    "database_name": "alpha-db",
    "database_id": "PASTE-YOUR-DATABASE-ID-HERE",   // ← replace this
    "migrations_dir": "migrations"
  }
]
```

The repo intentionally ships with a placeholder — never invent resource IDs.

## 4. Apply the production schema

```bash
# New install — apply ALL migrations in order:
npx wrangler d1 migrations apply alpha-db --remote
# (or execute each file: 0001_initial_schema.sql,
#  0002_ai_provider_credentials.sql, 0003_generic_providers_oauth.sql,
#  0004_conversation_summaries.sql, 0005_multi_account_oauth.sql)

# Existing deployment (0001 already applied manually) — apply the new ones
# in order. IMPORTANT: because 0001 was applied manually in production, the
# Wrangler migration history does not know about it. First mark 0001 as
# already applied (choose NO when asked to execute it), then apply the rest:
npx wrangler d1 migrations apply alpha-db --remote
#   → "0001_initial_schema.sql … execute?" NO  (already applied manually)
#   → "0002_ai_provider_credentials.sql … execute?" YES
#   → "0003_generic_providers_oauth.sql … execute?" YES
#   → "0004_conversation_summaries.sql … execute?" YES
#   → "0005_multi_account_oauth.sql … execute?" YES
# (or execute the files directly:)
npx wrangler d1 execute alpha-db --remote --file=migrations/0002_ai_provider_credentials.sql
npx wrangler d1 execute alpha-db --remote --file=migrations/0003_generic_providers_oauth.sql
npx wrangler d1 execute alpha-db --remote --file=migrations/0004_conversation_summaries.sql
npx wrangler d1 execute alpha-db --remote --file=migrations/0005_multi_account_oauth.sql
```

Migration `0002` creates the `ai_provider_credentials` table used by
**Settings → AI Providers** (dashboard-managed provider keys, AES-GCM
encrypted). Migration `0003` adds `ai_custom_providers` (unlimited
user-configured OpenAI-compatible providers from **Settings → AI Providers →
+ Add API**) and `connected_accounts` (real Gmail/GitHub OAuth connections,
tokens encrypted). Migration `0004` adds `conversation_summaries` (rolling
conversation summaries for the layered context system — see the optional
`CONTEXT_*` knobs in `.env.example`). Migration `0005` makes OAuth
**multi-account** — adds `role` (GitHub purpose: storage / scripts / general),
`is_default` (one explicit default account per provider) and `last_used_at`
columns to `connected_accounts`, plus a deterministic backfill that marks the
earliest-connected account per provider as the default. All are additive only —
safe to apply to an existing deployed database, no data is touched.

There is **no seed migration** — a fresh production install starts empty. The
first visit to the site shows the one-time owner-account setup screen.

## 5. Create the R2 bucket

```bash
npx wrangler r2 bucket create alpha-storage
```

The binding name in `wrangler.jsonc` is `STORAGE`; the bucket name is
`alpha-storage`. Adjust the bucket name in `wrangler.jsonc` if you use a
different one.

## 6. Configure Worker secrets

### Required

```bash
npx wrangler secret put AUTH_SECRET            # REQUIRED — session HMAC key
npx wrangler secret put AI_CREDENTIALS_SECRET  # REQUIRED for dashboard-managed AI keys + OAuth tokens
```

`AI_CREDENTIALS_SECRET` derives the AES-256-GCM keys that encrypt (a)
provider API keys saved from **Settings → AI Providers** and (b) Gmail/GitHub
OAuth tokens (dedicated HKDF label — key separation between the two classes).
Everything is stored encrypted in D1 — never plaintext, never returned to the
browser. Generate it with `openssl rand -base64 32`. With this secret in place,
provider keys are managed in the dashboard and the per-provider secrets below
are **optional**.

### OAuth integrations (Gmail + GitHub) — optional but recommended

Create the OAuth applications, then set the secrets (client secrets NEVER go
into D1, source control or the browser):

```bash
# Google Cloud console → APIs & Services → Credentials → OAuth client ID
# (Web application). Add the authorized redirect URI:
#   https://<your-domain>/api/v1/integrations/google/callback
npx wrangler secret put GOOGLE_CLIENT_ID
npx wrangler secret put GOOGLE_CLIENT_SECRET

# GitHub → Settings → Developer settings → OAuth Apps → New OAuth App.
# Authorization callback URL:
#   https://<your-domain>/api/v1/integrations/github/callback
npx wrangler secret put GITHUB_CLIENT_ID
npx wrangler secret put GITHUB_CLIENT_SECRET
```

Exact production callback URLs (replace `alpha02.org` with your domain):

- Google: `https://alpha02.org/api/v1/integrations/google/callback`
- GitHub: `https://alpha02.org/api/v1/integrations/github/callback`

Local development needs no extra configuration — the callback origin is
derived from the request (`http://localhost:3000`), and Google accepts
`http://localhost` callbacks in development OAuth clients. If the public
origin cannot be derived from requests (exotic proxy setups), set
`OAUTH_CALLBACK_ORIGIN=https://<your-domain>`.

Until these secrets exist, the Gmail/GitHub UI honestly shows
"OAuth is not configured" — the Connect button explains why.

Gmail scopes requested: `openid email profile` +
`https://www.googleapis.com/auth/gmail.readonly` +
`https://www.googleapis.com/auth/gmail.send`. Sending email always requires an
explicit confirmation in the UI (`confirmed: true` is enforced server-side) and
the confirmation dialog names the exact Gmail account that will send.
GitHub scopes: `read:user repo` (repo listing + issues/PR metadata; Alpha
performs no write operations). Alpha requests the minimum scopes its features
use — no broader permissions are asked for.

### Multi-account OAuth (Google + GitHub)

Alpha supports **several Google accounts and several GitHub accounts per
user**:

- **Connecting another account:** open Gmail (or GitHub) → *Connect another
  Google/GitHub account*. The Google authorize URL uses
  `prompt=select_account consent`, so Google ALWAYS shows the account chooser —
  pick a different account to add it. Reconnecting the SAME external account
  updates its stored tokens in place (deduplicated by the provider's account
  id — the `UNIQUE (user_id, provider, provider_account_id)` constraint); it
  never duplicates and never overwrites another account.
- **Default account:** each provider has exactly one explicit default (the
  *Use* button). Gmail search/send and GitHub browsing use the account
  selected in the view's account switcher, falling back to the explicit
  default. Alpha NEVER picks "the most recently updated" account.
- **GitHub account roles:** every GitHub account has a user-editable purpose —
  `storage` (repo/file storage operations), `scripts` (automation/scripts) or
  `general`. The centralized account resolver
  (`src/server/integrations/account-resolver.ts`) selects the right account
  for an operation: explicit id → role match → explicit default; ambiguity is
  a clear 400 error, never a silent guess.
- **Tokens** stay AES-256-GCM encrypted per account; revocation/reauth is
  per-account (a failing grant never affects the user's other accounts).

**Google test user setup (verification):** in the Google Cloud console, add
the test users (or configure the OAuth consent screen for production) that
will grant Alpha access. Each Google account that authorizes Alpha becomes a
separate connected account in **Gmail → Google Accounts**.

**GitHub OAuth configuration:** one OAuth app is enough for any number of
GitHub accounts — GitHub's authorize screen lets the user log in as any
account each time *Connect another GitHub account* is used.

### AI providers — dashboard (recommended) or environment

**Option A — dashboard-managed (recommended):** log in after deployment, open
**Settings → AI Providers**, paste each provider key and press *Save*. Keys are
encrypted (AES-GCM, unique IV per key) before storage; only a masked form
(`••••••••••••••abcd`) is ever displayed again. *Test connection* makes a REAL
provider request and records real latency. This requires
`AI_CREDENTIALS_SECRET` (above).

**Option B — environment credentials (legacy, still supported):**

**Z.ai** (default primary; the only provider with image generation, web
search, TTS and ASR) — note that a dashboard-saved Z.ai key still needs a base
URL (dashboard field or `ZAI_BASE_URL`):

```bash
npx wrangler secret put ZAI_BASE_URL
npx wrangler secret put ZAI_API_KEY
npx wrangler secret put ZAI_TOKEN
npx wrangler secret put ZAI_CHAT_ID
npx wrangler secret put ZAI_USER_ID
```

Optional additional providers (chat, tool calling, vision — the AI router
falls back to them automatically when Z.ai fails):

```bash
# OpenAI
npx wrangler secret put OPENAI_API_KEY

# Groq
npx wrangler secret put GROQ_API_KEY

# OpenRouter
npx wrangler secret put OPENROUTER_API_KEY
```

Credential precedence per provider: **dashboard credential first, environment
credential fallback.** A provider disabled in the dashboard is excluded from
routing entirely. Removing a dashboard key makes Alpha fall back to the
environment credential (if any).

Models and routing are configurable via optional secrets/vars (defaults:
`glm-4.6`, `gpt-4o-mini`, `llama-3.3-70b-versatile`, `openai/gpt-4o-mini`;
primary `zai`; max 3 provider attempts per request):

```
ZAI_MODEL, ZAI_VISION_MODEL,
OPENAI_MODEL, OPENAI_VISION_MODEL, OPENAI_BASE_URL,
GROQ_MODEL, GROQ_VISION_MODEL, GROQ_BASE_URL,
OPENROUTER_MODEL, OPENROUTER_VISION_MODEL, OPENROUTER_BASE_URL,
AI_PRIMARY_PROVIDER, AI_FALLBACK_PROVIDERS, AI_MAX_ATTEMPTS, AI_DISABLED_PROVIDERS
```

The layered context system (rolling summary + relevant older messages +
bounded recent window + bounded memories) also has optional tuning vars —
`CONTEXT_RECENT_MESSAGES_LIMIT` (16), `CONTEXT_SUMMARY_MAX_TOKENS` (600),
`CONTEXT_RELEVANT_HISTORY_MAX_TOKENS` (1200), `CONTEXT_MEMORY_MAX_TOKENS`
(400), `CONTEXT_SUMMARIZE_THRESHOLD` (24), `CONTEXT_SUMMARY_TARGET_TOKENS`
(450). Defaults are sensible; see `.env.example` for details. Requires
migration `0004` (conversation summaries).

Notes:

- `AUTH_SECRET` is **required in production**. Without it, all authentication
  endpoints return a configuration error (there is deliberately no fallback).
- **Do not lose `AI_CREDENTIALS_SECRET`** — keys saved in the dashboard cannot
  be decrypted without it (they must be removed and re-added). Rotating it
  invalidates every stored dashboard key.
- Password hashing uses PBKDF2-SHA256 at 100,000 iterations (the maximum the
  Cloudflare Workers Web Crypto accepts), with a random 16-byte salt per
  password — the count is stored with each hash for forward compatibility.
- An AI provider without credentials reports `configured: false` in the
  System view and via `GET /api/v1/providers` — it is never routed to and
  never reported healthy.
- Never put secrets in `wrangler.jsonc`, `.env`, or any committed file.
- Optional future integrations: `GMAIL_CLIENT_ID` / `GMAIL_CLIENT_SECRET`,
  `GITHUB_CLIENT_ID` / `GITHUB_CLIENT_SECRET`. Until set, the UI honestly
  shows Gmail/GitHub as "Not connected".

## 7. Build the Worker

```bash
npx opennextjs-cloudflare build
```

This runs `next build` and bundles `.open-next/worker.js`.

> Low-memory machines: if the Turbopack build is OOM-killed, run
> `npx next build --webpack` first, then
> `npx opennextjs-cloudflare build --skipNextBuild`.

## 8. Deploy

```bash
npx wrangler deploy
```

## 9. Smoke-test the workers.dev deployment

```bash
npx wrangler deployments list     # get the workers.dev URL
```

Then in a browser:

1. Open the URL → the **setup screen** appears (fresh install).
2. Create the owner account → the Alpha shell loads.
3. Send a chat message → a real AI response streams in.
4. Upload a file in Files → it appears in the list (R2 write verified).
5. System view → D1 and R2 health are green with real latencies.
6. Lock Alpha (Security) → the unlock screen requires your password.
7. Gmail view (with OAuth secrets set) → *Connect Gmail* → consent → the
   account is listed; *Connect another Google account* → pick a different
   Google account → BOTH accounts are listed, *Use* switches the default, and
   search/send name the selected account. Repeat the same idea for GitHub,
   including assigning account roles (storage / scripts / general).

Also verify with the API directly:

```bash
curl -s https://<your-worker>.workers.dev/api/v1/auth/status
# {"setupNeeded":false,"authenticated":false,"locked":false,"user":null}
# (or setupNeeded:true before creating the account)
```

## 10. Attach the custom domain alpha02.org

Either in the Cloudflare dashboard (Workers → alpha → Settings → Domains & Routes → Add → Custom domain `alpha02.org`), or via the CLI by adding to `wrangler.jsonc`:

```jsonc
"routes": [
  { "pattern": "alpha02.org", "custom_domain": true }
]
```

then `npx wrangler deploy` again. The domain's DNS must be on the same
Cloudflare account (a proxied record is created automatically).

## 11. Post-deployment checks

- Visit `https://alpha02.org` — the session cookie must be `Secure` (automatic on HTTPS).
- Repeat the smoke tests from step 9 against the custom domain.
- Check `npx wrangler tail` for runtime errors while exercising the app.

## Operational notes

- **Schema changes**: add `migrations/00NN_*.sql` files and apply with
  `npx wrangler d1 migrations apply alpha-db --remote`. Never edit an applied migration.
- **Secrets rotation**: `npx wrangler secret put AUTH_SECRET` (note: rotating
  `AUTH_SECRET` invalidates all sessions — users simply sign in again).
- **Backups**: `npx wrangler d1 export alpha-db --remote --output backup.sql`
  and use R2 lifecycle rules / bucket replication for object storage.
- **Local preview of the production build**: `npm run preview`.
- **Observability**: `wrangler.jsonc` enables Workers observability — view logs
  with `npx wrangler tail`.
