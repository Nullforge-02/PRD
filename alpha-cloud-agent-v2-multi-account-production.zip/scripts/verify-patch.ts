// ALPHA — security + provider-credential integration suite (PART 15).
//
// Runs against the LOCAL DEV server (bun run dev on :3000) plus the local
// test receiver (scripts/test-openai-receiver.ts on :3111). Every assertion
// exercises REAL production code paths — no mocks are injected into the app;
// the only test double is the local OpenAI-protocol receiver used because no
// valid OpenAI credential exists in this environment.
//
//   bun run scripts/verify-patch.ts
//
// Coverage (spec PART 15 numbering):
//   1  API key never returned from GET /api/v1/providers
//   2  D1 stores ciphertext, not plaintext
//   3  Correct decryption works server-side (unit: scripts/test-credential-crypto.ts
//      + test-connection success via local receiver + REAL Z.ai round-trip)
//   4  Wrong encryption secret cannot decrypt (unit: scripts/test-credential-crypto.ts)
//   5  Unauthorized users cannot access provider credentials
//   6  Cross-origin state-changing provider requests are rejected
//   7  API keys never appear in audit logs
//   8  API keys never appear in application logs
//   9  Test connection uses the actual stored credential (receiver records the
//      exact Authorization header Alpha sent)
//   10 Router uses a dashboard credential (workerd phase: scripts/verify-workerd.ts;
//      dev phase proves it via Test Connection + the receiver's recorded header)
//   11 Router falls back to the environment credential when no dashboard row
//   12 Removing a dashboard credential stops it being used
//   13 Existing Z.ai chat still works
//   15/25/26/27/28/29  auth/session/lock/logout/CSRF/rate-limit regression
//   16/17  D1 + R2 regression
//   18  No provider secret in client-served HTML/bundles
//   19-24 PBKDF2 (100k, random salt, never plaintext, wrong/right password)

import { readFileSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { hashPassword, verifyPassword } from "../src/server/auth";

const BASE = "http://localhost:3000";
const RECEIVER = "http://127.0.0.1:3111";
const DEV_EMAIL = "owner@alpha.dev";
const DEV_PASSWORD = "correct-horse-battery"; // LOCAL DEV ONLY (documented worklog account)
const RECEIVER_OK_KEY = "sk-dash-PROOF-wXYZ"; // fake key — OK path on the test receiver
const RECEIVER_FAIL_KEY = "sk-dash-FAIL-bad1"; // fake key — 401 path on the test receiver

let passed = 0;
const failures: string[] = [];

function assert(condition: boolean, name: string, detail?: string) {
  if (condition) {
    passed += 1;
    console.log(`  PASS  ${name}`);
  } else {
    failures.push(name);
    console.log(`  FAIL  ${name}${detail ? ` — ${detail}` : ""}`);
  }
}

interface Res {
  status: number;
  text: string;
  headers: Headers;
  json<T = Record<string, unknown>>(): T | null;
}

async function req(
  method: string,
  path: string,
  opts: { body?: unknown; cookie?: string; origin?: string } = {},
): Promise<Res> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      ...(opts.body !== undefined ? { "Content-Type": "application/json" } : {}),
      ...(opts.cookie ? { Cookie: opts.cookie } : {}),
      ...(opts.origin !== undefined ? { Origin: opts.origin } : {}),
    },
    ...(opts.body !== undefined ? { body: JSON.stringify(opts.body) } : {}),
  });
  const text = await res.text();
  return {
    status: res.status,
    text,
    headers: res.headers,
    json<T = Record<string, unknown>>(): T | null {
      try {
        return JSON.parse(text) as T;
      } catch {
        return null;
      }
    },
  };
}

/** Query the LOCAL dev D1 (miniflare state) via wrangler. */
function d1(sql: string): Array<Record<string, unknown>> {
  const out = spawnSync(
    "bun",
    [
      "x",
      "wrangler",
      "d1",
      "execute",
      "alpha-db",
      "--local",
      "--json",
      "--command",
      sql,
    ],
    { cwd: "/home/z/my-project", encoding: "utf8", timeout: 120_000 },
  );
  const stdout = out.stdout ?? "";
  // wrangler --json prints a pretty-printed array (possibly after banner text).
  const start = stdout.indexOf("[");
  const end = stdout.lastIndexOf("]");
  if (start === -1 || end === -1 || end <= start) {
    throw new Error(`wrangler d1 produced no JSON: ${stdout.slice(0, 300)}`);
  }
  const parsed = JSON.parse(stdout.slice(start, end + 1)) as Array<{ results?: Array<Record<string, unknown>> }>;
  return parsed[0]?.results ?? [];
}

function providerList(body: unknown): Array<Record<string, unknown>> {
  const data = body as { providers?: Array<Record<string, unknown>> } | null;
  return data?.providers ?? [];
}

async function main() {
  console.log("== A. PBKDF2 unit proofs (real src/server/auth.ts) ==");
  {
    const h1 = await hashPassword("unit-password-1");
    const h2 = await hashPassword("unit-password-1");
    assert(h1.startsWith("pbkdf2$100000$"), "password hash uses exactly 100000 PBKDF2 iterations");
    assert(h1.split("$")[2] !== h2.split("$")[2], "every password gets a random salt");
    assert(!(await verifyPassword("wrong", h1)), "wrong password fails verification");
    assert(await verifyPassword("unit-password-1", h1), "correct password verifies");
    assert(!h1.includes("unit-password-1"), "password is never stored plaintext");
    // Legacy 210k hash (pre-fix format) fails CLOSED on Workers but parses safely.
    const legacy = "pbkdf2$210000$c2FsdA$aGFzaA";
    assert(!(await verifyPassword("x", legacy)), "legacy >100k hash fails closed (no false accept)");
  }

  console.log("== B. Auth battery (dev server) ==");
  let cookie = "";
  {
    const status = await req("GET", "/api/v1/auth/status");
    const st = status.json<{ setupNeeded: boolean }>();
    if (st?.setupNeeded) {
      const setup = await req("POST", "/api/v1/auth/setup", {
        origin: BASE,
        body: { email: DEV_EMAIL, name: "Owner", password: DEV_PASSWORD },
      });
      assert(setup.status === 201, "owner setup succeeds (fresh DB)", setup.text.slice(0, 200));
    } else {
      assert(status.status === 200, "auth status reachable");
    }

    const wrong = await req("POST", "/api/v1/auth/login", {
      origin: BASE,
      body: { email: DEV_EMAIL, password: "definitely-wrong" },
    });
    assert(wrong.status === 401, "wrong owner password fails (401)");

    const login = await req("POST", "/api/v1/auth/login", {
      origin: BASE,
      body: { email: DEV_EMAIL, password: DEV_PASSWORD },
    });
    assert(login.status === 200, "correct owner password succeeds (200)");
    const setCookie = login.headers.get("set-cookie") ?? "";
    cookie = setCookie.split(";")[0];
    assert(cookie.startsWith("alpha_session="), "session cookie issued");

    const me = await req("GET", "/api/v1/auth/me", { cookie });
    assert(me.status === 200, "session creation + verification works (/me 200)");

    // D1: the actual owner row uses the Cloudflare-compatible count.
    const rows = d1(
      `SELECT password_hash FROM users WHERE email = '${DEV_EMAIL}'`,
    ) as Array<{ password_hash: string }>;
    assert(
      rows.length === 1 && rows[0].password_hash.startsWith("pbkdf2$100000$"),
      "D1 password hash is pbkdf2$100000$ (Cloudflare-compatible)",
    );
    assert(
      rows.length === 1 && !rows[0].password_hash.includes(DEV_PASSWORD),
      "D1 never stores the plaintext password",
    );
  }

  console.log("== C. Provider credential security ==");
  const allKeys = [RECEIVER_OK_KEY, RECEIVER_FAIL_KEY];
  {
    // 5 — unauthorized access
    const anon = await req("GET", "/api/v1/providers");
    assert(anon.status === 401, "unauthenticated GET /providers → 401");
    const anonSave = await req("POST", "/api/v1/providers/openai", {
      origin: BASE,
      body: { apiKey: RECEIVER_OK_KEY },
    });
    assert(anonSave.status === 401, "unauthenticated POST /providers/[id] → 401");

    // 6 — cross-origin state changes rejected
    const csrf = await req("POST", "/api/v1/providers/openai", {
      origin: "https://evil.example",
      body: { apiKey: RECEIVER_OK_KEY },
    });
    assert(csrf.status === 403, "cross-origin POST /providers/[id] → 403");
    const csrfDel = await req("DELETE", "/api/v1/providers/openai", {
      origin: "https://evil.example",
    });
    assert(csrfDel.status === 403, "cross-origin DELETE /providers/[id] → 403");

    // 1 — baseline list is secret-free
    const list0 = await req("GET", "/api/v1/providers", { cookie });
    assert(list0.status === 200, "GET /providers (authed) → 200");
    assert(!allKeys.some((k) => list0.text.includes(k)), "provider list contains no API keys");

    // Save a dashboard credential pointing at the local test receiver.
    const save = await req("POST", "/api/v1/providers/openai", {
      origin: BASE,
      cookie,
      body: {
        apiKey: RECEIVER_OK_KEY,
        baseUrl: `${RECEIVER}/v1`,
        model: "gpt-4o-mini",
        visionModel: "gpt-4o-mini",
      },
    });
    assert(save.status === 201, "saving a dashboard credential → 201", save.text.slice(0, 200));
    assert(!allKeys.some((k) => save.text.includes(k)), "save response never echoes the API key");
    const saved = save.json<{ provider?: { maskedKey?: string; source?: string } }>()?.provider;
    assert(saved?.maskedKey === "••••••••••••wXYZ", "masked key shown (••••••••••••wXYZ)");
    assert(saved?.source === "dashboard", "provider reports source: dashboard");

    // 2 — D1 stores ciphertext, never plaintext
    const credRows = d1(
      "SELECT provider, encrypted_api_key, key_hint FROM ai_provider_credentials",
    ) as Array<{ provider: string; encrypted_api_key: string; key_hint: string }>;
    const openaiRow = credRows.find((r) => r.provider === "openai");
    assert(!!openaiRow, "credential row exists in D1");
    assert(
      !!openaiRow && openaiRow.encrypted_api_key.startsWith("v1."),
      "D1 stores AES-GCM ciphertext (v1.<iv>.<ct>)",
    );
    assert(
      !allKeys.some((k) => credRows.some((r) => r.encrypted_api_key.includes(k))),
      "D1 ciphertext does not contain any plaintext API key",
    );

    // 9 — Test connection uses the actual STORED credential: the receiver
    // records the exact Authorization header Alpha sent.
    await fetch(`${RECEIVER}/__reset`, { method: "POST" });
    const test = await req("POST", "/api/v1/providers/openai/test", { origin: BASE, cookie });
    const testBody = test.json<{ success?: boolean; latencyMs?: number; error?: string }>();
    assert(test.status === 200 && testBody?.success === true, "test connection → real success");
    assert(typeof testBody?.latencyMs === "number" && (testBody.latencyMs ?? 0) >= 0, "test connection reports real latency");
    assert(!allKeys.some((k) => test.text.includes(k)), "test response never contains the API key");
    const seen = (await (await fetch(`${RECEIVER}/__last-auth`)).json()) as { authorization?: string };
    assert(
      seen.authorization === `Bearer ${RECEIVER_OK_KEY}`,
      "the STORED (decrypted) credential was sent to the provider",
      `receiver saw: ${seen.authorization ?? "(none)"}`,
    );

    // Update WITHOUT a key preserves the stored one.
    const update = await req("POST", "/api/v1/providers/openai", {
      origin: BASE,
      cookie,
      body: { model: "gpt-4o-mini", baseUrl: `${RECEIVER}/v1`, enabled: true },
    });
    assert(update.status === 200, "update without apiKey → 200 (key preserved)");
    const updated = update.json<{ provider?: { maskedKey?: string } }>()?.provider;
    assert(updated?.maskedKey === "••••••••••••wXYZ", "existing encrypted key preserved on update");

    // Sanitized failure path: FAIL key → real 401 from the receiver → clean message.
    const saveFail = await req("POST", "/api/v1/providers/openai", {
      origin: BASE,
      cookie,
      body: { apiKey: RECEIVER_FAIL_KEY, baseUrl: `${RECEIVER}/v1` },
    });
    assert(saveFail.status === 200, "replacing the key → 200");
    const testFail = await req("POST", "/api/v1/providers/openai/test", { origin: BASE, cookie });
    const testFailBody = testFail.json<{ success?: boolean; error?: string }>();
    assert(testFailBody?.success === false, "failing test connection → success: false");
    assert(
      typeof testFailBody?.error === "string" && testFailBody.error.length > 0 &&
        !testFailBody.error.includes("test receiver"),
      "failure error is sanitized (no raw provider body)",
      testFailBody?.error,
    );

    // 12 — removing the credential stops it being used
    const del = await req("DELETE", "/api/v1/providers/openai", { origin: BASE, cookie });
    assert(del.status === 200, "DELETE dashboard credential → 200");
    const afterDel = await req("POST", "/api/v1/providers/openai/test", { origin: BASE, cookie });
    assert(afterDel.status === 400, "test after removal → 400 (no credential configured)");
    const gone = d1("SELECT COUNT(*) AS n FROM ai_provider_credentials WHERE provider = 'openai'");
    assert(gone[0]?.n === 0, "credential row deleted from D1");
    const listDel = await req("GET", "/api/v1/providers", { cookie });
    const openaiStatus = providerList(listDel.json()).find((p) => p.id === "openai");
    assert(openaiStatus?.configured === false, "provider is not configured after removal");

    // 1 (re-check) — the full list at no point contained any key material.
    assert(!allKeys.some((k) => listDel.text.includes(k)), "provider list still contains no API keys");
  }

  console.log("== E. Regressions (chat / D1 / R2 / lock / logout / CSRF / rate-limit) ==");
  {
    // 11 + 13 — zai has NO dashboard row now; chat must work via the env/dev
    // credential (environment fallback path) with a REAL provider reply.
    const chat = await req("POST", "/api/v1/chat", {
      origin: BASE,
      cookie,
      body: { message: "Reply with exactly: PATCH OK" },
    });
    assert(chat.status === 200, "existing Z.ai chat still works (env credential fallback)");
    assert(chat.text.trim().length > 0, "chat streamed a real provider answer");

    // 16 — D1 regression
    const note = await req("POST", "/api/v1/notes", {
      origin: BASE,
      cookie,
      body: { title: "Patch verification", content: "temporary note", pinned: false },
    });
    const noteId = note.json<{ note?: { id?: string } }>()?.note?.id;
    assert(!!noteId, "notes create works");
    const notesList = await req("GET", "/api/v1/notes", { cookie });
    assert(notesList.status === 200 && notesList.text.includes("Patch verification"), "notes list works");
    if (noteId) {
      const del = await req("DELETE", `/api/v1/notes/${noteId}`, { origin: BASE, cookie });
      assert(del.status === 200, "notes delete works");
    }

    // 17 — R2 regression (upload → download → delete)
    const form = new FormData();
    form.append("file", new Blob([new TextEncoder().encode("patch-verify-upload")], { type: "text/plain" }), "patch-verify.txt");
    const up = await fetch(`${BASE}/api/v1/files`, {
      method: "POST",
      headers: { Cookie: cookie, Origin: BASE },
      body: form,
    });
    const upBody = (await up.json()) as { file?: { id?: string } };
    assert(up.status === 201 && !!upBody.file?.id, "R2 upload works");
    if (upBody.file?.id) {
      const dl = await req("GET", `/api/v1/files/${upBody.file.id}?download=1`, { cookie });
      assert(
        dl.status === 200 && dl.text === "patch-verify-upload",
        "R2 download round-trip works",
      );
      const del = await req("DELETE", `/api/v1/files/${upBody.file.id}`, { origin: BASE, cookie });
      assert(del.status === 200, "R2 delete works");
    }

    // 27 — lock / unlock
    const lock = await req("POST", "/api/v1/auth/lock", { origin: BASE, cookie });
    assert(lock.status === 200, "lock works");
    const lockedRes = await req("GET", "/api/v1/notes", { cookie });
    assert(lockedRes.status === 423, "locked session → 423 on protected routes");
    const unlockWrong = await req("POST", "/api/v1/auth/unlock", {
      origin: BASE,
      cookie,
      body: { password: "wrong-password" },
    });
    assert(unlockWrong.status === 401, "unlock with wrong password → 401");
    const unlock = await req("POST", "/api/v1/auth/unlock", {
      origin: BASE,
      cookie,
      body: { password: DEV_PASSWORD },
    });
    assert(unlock.status === 200, "unlock with correct password → 200");

    // 28 — CSRF on an existing route
    const csrfNote = await req("POST", "/api/v1/notes", {
      origin: "https://evil.example",
      cookie,
      body: { title: "evil", content: "evil" },
    });
    assert(csrfNote.status === 403, "cross-origin POST /notes → 403 (CSRF)");

    // 26 — logout revokes the session
    const logout = await req("POST", "/api/v1/auth/logout", { origin: BASE, cookie });
    assert(logout.status === 200, "logout works");
    const meAfter = await req("GET", "/api/v1/auth/me", { cookie });
    assert(meAfter.status === 401, "session revoked after logout (401)");
    const relogin = await req("POST", "/api/v1/auth/login", {
      origin: BASE,
      body: { email: DEV_EMAIL, password: DEV_PASSWORD },
    });
    assert(relogin.status === 200, "login again works");
    cookie = (relogin.headers.get("set-cookie") ?? "").split(";")[0];

    // 29 — login rate limiting (9 bad attempts on a probe identity)
    let got429 = false;
    for (let i = 0; i < 9; i++) {
      const r = await req("POST", "/api/v1/auth/login", {
        origin: BASE,
        body: { email: "ratelimit-probe@alpha.dev", password: "nope" },
      });
      if (r.status === 429) {
        got429 = true;
        break;
      }
    }
    assert(got429, "login rate limiting engages (429 after repeated failures)");
  }

  console.log("== D. REAL Z.ai dashboard credential (round-trip against the live provider) ==");
  {
    // Uses the REAL local dev Z.ai credential (from /etc/.z-ai-config) — it is
    // saved via the API (encrypted at rest), used for a REAL test connection,
    // then removed. The key is never printed. ZAI_TOKEN / ZAI_CHAT_ID /
    // ZAI_USER_ID stay environment-provided (SDK session identifiers).
    let zaiConfig: { baseUrl?: string; apiKey?: string } = {};
    try {
      zaiConfig = JSON.parse(readFileSync("/etc/.z-ai-config", "utf8"));
    } catch {
      console.log("  SKIP  no /etc/.z-ai-config in this environment");
    }
    if (zaiConfig.baseUrl && zaiConfig.apiKey) {
      const save = await req("POST", "/api/v1/providers/zai", {
        origin: BASE,
        cookie,
        body: { apiKey: zaiConfig.apiKey, baseUrl: zaiConfig.baseUrl },
      });
      assert(save.status === 201, "real Z.ai key saved as dashboard credential");
      const test = await req("POST", "/api/v1/providers/zai/test", { origin: BASE, cookie });
      const body = test.json<{ success?: boolean; latencyMs?: number; error?: string }>();
      assert(
        body?.success === true && typeof body.latencyMs === "number",
        "REAL Z.ai test connection succeeded via dashboard credential",
        `success=${body?.success} latency=${body?.latencyMs} error=${body?.error ?? "none"}`,
      );
      const list = await req("GET", "/api/v1/providers", { cookie });
      const zaiStatus = providerList(list.json()).find((p) => p.id === "zai");
      assert(zaiStatus?.source === "dashboard", "zai reports source: dashboard while saved");
      assert(
        zaiStatus?.maskedKey === `••••••••••••${zaiConfig.apiKey.slice(-4)}`,
        "masked key matches (last 4 only)",
      );
      const del = await req("DELETE", "/api/v1/providers/zai", { origin: BASE, cookie });
      assert(del.status === 200, "real Z.ai dashboard credential removed (env fallback restored)");
    }
  }

  console.log("== F. Secret-exposure audit (logs / audit / client payloads) ==");
  {
    // 7 — audit log
    const audit = await req("GET", "/api/v1/audit?limit=100", { cookie });
    assert(audit.status === 200, "audit log readable");
    assert(!allKeys.some((k) => audit.text.includes(k)), "API keys never appear in audit logs");
    const auditBody = audit.json<{ events?: Array<{ action?: string }> }>();
    const actions = new Set((auditBody?.events ?? []).map((e) => e.action));
    for (const expected of [
      "provider.credential_added",
      "provider.credential_updated",
      "provider.credential_removed",
      "provider.test_succeeded",
      "provider.test_failed",
    ]) {
      assert(actions.has(expected), `audit records ${expected}`);
    }

    // 8 — application logs
    const logs = [
      "/tmp/devserver.log",
      "/home/z/my-project/dev.log",
    ]
      .map((p) => {
        try {
          return readFileSync(p, "utf8");
        } catch {
          return "";
        }
      })
      .join("\n");
    assert(!allKeys.some((k) => logs.includes(k)), "API keys never appear in application logs");

    // 18 — client-served HTML / static chunks
    const html = await (await fetch(BASE)).text();
    assert(!allKeys.some((k) => html.includes(k)), "no provider secret in served HTML");
    let chunks = "";
    try {
      const dir = "/home/z/my-project/.next/static/chunks";
      const { readdirSync, readFileSync: rf } = await import("node:fs");
      for (const f of readdirSync(dir)) {
        if (f.endsWith(".js")) chunks += rf(`${dir}/${f}`, "utf8");
      }
    } catch {
      /* no chunks dir */
    }
    assert(!allKeys.some((k) => chunks.includes(k)), "no provider secret in client JS bundles");
  }

  console.log("");
  if (failures.length > 0) {
    console.log(`RESULT: ${failures.length} FAILED / ${passed} passed`);
    for (const f of failures) console.log(`  ✗ ${f}`);
    process.exit(1);
  }
  console.log(`RESULT: all ${passed} checks passed`);
}

void main();
