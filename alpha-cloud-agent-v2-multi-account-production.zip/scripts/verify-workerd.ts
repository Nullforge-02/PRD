// ALPHA — Cloudflare Workers runtime validation (PART 16).
//
// Boots the BUILT OpenNext worker (.open-next/worker.js) on the real workerd
// runtime via `wrangler dev` with an ISOLATED local state directory, and
// proves the Cloudflare-critical paths for real:
//
//   1. Fresh owner SETUP succeeds with PBKDF2 @ 100,000 iterations
//      (the exact operation that failed on real Cloudflare at 210,000)
//   2. Wrong password → 401; correct password → 200; session works
//   3. D1 stores pbkdf2$100000$ (not plaintext, random salt format)
//   4. Dashboard credential save → AES-256-GCM + HKDF + random IV on workerd
//   5. GET /providers shows masked key, no secrets
//   6. CHAT ROUTES THROUGH A DASHBOARD CREDENTIAL (AI_PRIMARY_PROVIDER=openai,
//      dashboard key → local test receiver records the exact Authorization)
//   7. REAL FALLBACK: dashboard openai 401 → cooldown → env Z.ai real reply
//   8. Removing the dashboard credential stops its use
//   9. No provider secret appears in responses or workerd logs
//
// Run AFTER a successful build:
//   npx next build --webpack && npx opennextjs-cloudflare build --skipNextBuild
//   bun run scripts/verify-workerd.ts
//
// The MAIN dev server on :3000 is untouched (wrangler dev reads .dev.vars at
// boot; the running next dev process is not affected by the temporary swap,
// and the original file is restored in a finally block).

import { readFileSync, writeFileSync, rmSync, mkdirSync } from "node:fs";
import { spawn, spawnSync, type ChildProcess } from "node:child_process";

const BASE = "http://localhost:3999";
const STATE = "/tmp/alpha-workerd-state";
const RECEIVER = "http://127.0.0.1:3111";
const RECEIVER_OK_KEY = "sk-dash-PROOF-wXYZ";
const RECEIVER_FAIL_KEY = "sk-dash-FAIL-bad1";
const WORKERD_EMAIL = "owner@workerd.test";
const WORKERD_PASSWORD = "workerd-pass-123";
const DEV_VARS = "/home/z/my-project/.dev.vars";
const CWD = "/home/z/my-project";

let passed = 0;
const failures: string[] = [];

function assert(condition: boolean, name: string, detail?: string) {
  if (condition) {
    passed += 1;
    console.log(`  PASS  ${name}`);
  } else {
    failures.push(name);
    console.log(`  FAIL  ${name}${detail ? ` — ${detail}` : ""}`);
  }
}

async function req(
  method: string,
  path: string,
  opts: { body?: unknown; cookie?: string } = {},
): Promise<{ status: number; text: string; headers: Headers }> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      ...(opts.body !== undefined ? { "Content-Type": "application/json" } : {}),
      ...(opts.cookie ? { Cookie: opts.cookie } : {}),
      ...(method !== "GET" ? { Origin: BASE } : {}),
    },
    ...(opts.body !== undefined ? { body: JSON.stringify(opts.body) } : {}),
  });
  return { status: res.status, text: await res.text(), headers: res.headers };
}

function d1(sql: string): Array<Record<string, unknown>> {
  const out = spawnSync(
    "bun",
    ["x", "wrangler", "d1", "execute", "alpha-db", "--local", "--persist-to", STATE, "--json", "--command", sql],
    { cwd: CWD, encoding: "utf8", timeout: 120_000 },
  );
  const stdout = out.stdout ?? "";
  const start = stdout.indexOf("[");
  const end = stdout.lastIndexOf("]");
  if (start === -1 || end === -1) throw new Error(`wrangler d1 (isolated) produced no JSON: ${stdout.slice(0, 300)}`);
  const parsed = JSON.parse(stdout.slice(start, end + 1)) as Array<{ results?: Array<Record<string, unknown>> }>;
  return parsed[0]?.results ?? [];
}

async function waitReady(timeoutMs = 120_000): Promise<boolean> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`${BASE}/api/v1/auth/status`, { headers: { Origin: BASE } });
      if (res.status === 200) return true;
    } catch {
      /* not up yet */
    }
    await new Promise((r) => setTimeout(r, 1500));
  }
  return false;
}

async function main() {
  console.log("== Cloudflare workerd runtime validation (built OpenNext worker) ==");

  // Preconditions.
  let workerExists = true;
  try {
    readFileSync(`${CWD}/.open-next/worker.js`);
  } catch {
    workerExists = false;
  }
  if (!workerExists) {
    console.log("SKIP: .open-next/worker.js not found — run the build first.");
    process.exit(1);
  }
  try {
    await fetch(`${RECEIVER}/__last-auth`);
  } catch {
    console.log("SKIP: test receiver not running — start it with:");
    console.log("  (bun run scripts/test-openai-receiver.ts > /tmp/receiver.log 2>&1 &)");
    process.exit(1);
  }

  const originalDevVars = readFileSync(DEV_VARS, "utf8");

  let wrangler: ChildProcess | null = null;
  const logChunks: string[] = [];
  try {
    // 1. Fresh isolated state + migrations.
    rmSync(STATE, { recursive: true, force: true });
    mkdirSync(STATE, { recursive: true });
    const mig = spawnSync(
      "bun",
      ["x", "wrangler", "d1", "migrations", "apply", "alpha-db", "--local", "--persist-to", STATE],
      { cwd: CWD, encoding: "utf8", timeout: 180_000 },
    );
    assert(mig.status === 0, "migrations applied to isolated workerd D1 (0001 + 0002 + 0003)");

    // 2. Temporary .dev.vars: real Z.ai env creds (for fallback) + primary
    //    openai so the dashboard credential is attempted FIRST. Values are
    //    copied silently and never printed.
    const zai = JSON.parse(readFileSync("/etc/.z-ai-config", "utf8")) as Record<string, string>;
    const secretLine = (name: string): string => {
      const m = originalDevVars.match(new RegExp(`^${name}=(.+)$`, "m"));
      return m ? `${name}=${m[1]}` : "";
    };
    const tempVars = [
      secretLine("AUTH_SECRET"),
      secretLine("AI_CREDENTIALS_SECRET"),
      `AI_PRIMARY_PROVIDER=openai`,
      `ZAI_BASE_URL=${zai.baseUrl}`,
      `ZAI_API_KEY=${zai.apiKey}`,
      `ZAI_TOKEN=${zai.token ?? ""}`,
      `ZAI_CHAT_ID=${zai.chatId ?? ""}`,
      `ZAI_USER_ID=${zai.userId ?? ""}`,
    ]
      .filter(Boolean)
      .join("\n");
    writeFileSync(DEV_VARS, tempVars + "\n");

    // 3. Boot the built worker on workerd.
    const logFile = Number(process.env.WORKERD_LOG_FD ?? 0);
    wrangler = spawn("bun", ["x", "wrangler", "dev", "--port", "3999", "--persist-to", STATE], {
      cwd: CWD,
      stdio: ["ignore", "pipe", "pipe"],
    });
    wrangler.stdout?.on("data", (d) => logChunks.push(String(d)));
    wrangler.stderr?.on("data", (d) => logChunks.push(String(d)));
    void logFile;

    const ready = await waitReady();
    if (!ready) {
      console.log("workerd did not become ready. Log tail:");
      console.log(logChunks.join("").slice(-2000));
      throw new Error("wrangler dev not ready");
    }
    assert(true, "built worker boots on workerd (auth/status 200, reads isolated D1)");

    // 4. Fresh install → setup with Cloudflare-compatible PBKDF2.
    const status = await req("GET", "/api/v1/auth/status");
    const statusBody = JSON.parse(status.text) as { setupNeeded?: boolean };
    assert(statusBody.setupNeeded === true, "isolated workerd D1 starts with setupNeeded: true");

    const setup = await req("POST", "/api/v1/auth/setup", {
      body: { email: WORKERD_EMAIL, name: "Owner", password: WORKERD_PASSWORD },
    });
    assert(setup.status === 201, "owner setup SUCCEEDS on workerd with PBKDF2 100k", setup.text.slice(0, 200));

    const wrong = await req("POST", "/api/v1/auth/login", {
      body: { email: WORKERD_EMAIL, password: "wrong-password" },
    });
    assert(wrong.status === 401, "wrong password fails on workerd (401)");

    const login = await req("POST", "/api/v1/auth/login", {
      body: { email: WORKERD_EMAIL, password: WORKERD_PASSWORD },
    });
    assert(login.status === 200, "correct password succeeds on workerd (200)");
    const cookie = (login.headers.get("set-cookie") ?? "").split(";")[0];

    const me = await req("GET", "/api/v1/auth/me", { cookie });
    assert(me.status === 200, "session works on workerd (/me 200)");

    const hashRows = d1(`SELECT password_hash FROM users WHERE email = '${WORKERD_EMAIL}'`) as Array<{ password_hash: string }>;
    assert(
      hashRows.length === 1 && hashRows[0].password_hash.startsWith("pbkdf2$100000$"),
      "workerd D1 password hash is pbkdf2$100000$ (Cloudflare-compatible)",
    );

    // 5. Provider list: zai env-configured, openai not.
    const list0 = await req("GET", "/api/v1/providers", { cookie });
    const providers0 = (JSON.parse(list0.text) as { providers?: Array<Record<string, unknown>> }).providers ?? [];
    const zai0 = providers0.find((p) => p.id === "zai");
    const openai0 = providers0.find((p) => p.id === "openai");
    assert(zai0?.source === "environment" && zai0?.configured === true, "zai configured via environment credential on workerd");
    assert(openai0?.configured === false, "openai not configured before saving a dashboard key");

    // 6. Save dashboard credential (AES-GCM + HKDF + random IV on workerd).
    const save = await req("POST", "/api/v1/providers/openai", {
      cookie,
      body: { apiKey: RECEIVER_OK_KEY, baseUrl: `${RECEIVER}/v1`, model: "gpt-4o-mini" },
    });
    assert(save.status === 201, "dashboard credential saved on workerd (AES-GCM encrypt)", save.text.slice(0, 200));
    assert(!save.text.includes(RECEIVER_OK_KEY) && !save.text.includes(RECEIVER_FAIL_KEY), "save response has no key material");
    const savedProvider = (JSON.parse(save.text) as { provider?: { maskedKey?: string; source?: string } }).provider;
    assert(savedProvider?.maskedKey === "••••••••••••wXYZ", "masked key returned on workerd");
    assert(savedProvider?.source === "dashboard", "openai reports source: dashboard on workerd");

    const credRows = d1("SELECT encrypted_api_key FROM ai_provider_credentials WHERE provider = 'openai'") as Array<{ encrypted_api_key: string }>;
    assert(
      credRows.length === 1 && credRows[0].encrypted_api_key.startsWith("v1.") && !credRows[0].encrypted_api_key.includes(RECEIVER_OK_KEY),
      "workerd D1 stores AES-GCM ciphertext (v1.<iv>.<ct>), not plaintext",
    );

    // 7. CHAT ROUTES THROUGH THE DASHBOARD CREDENTIAL (openai is primary).
    await fetch(`${RECEIVER}/__reset`, { method: "POST" });
    const chat1 = await req("POST", "/api/v1/chat", {
      cookie,
      body: { message: "Reply with exactly: WORKERD DASH OK" },
    });
    assert(chat1.status === 200, "chat succeeds routed via dashboard credential on workerd", chat1.text.slice(0, 200));
    assert(chat1.text.trim().length > 0, "chat returned a provider answer");
    const seen1 = (await (await fetch(`${RECEIVER}/__last-auth`)).json()) as { authorization?: string };
    assert(
      seen1.authorization === `Bearer ${RECEIVER_OK_KEY}`,
      "router used the DECRYPTED dashboard key (receiver saw it)",
      `receiver saw: ${seen1.authorization ?? "(none)"}`,
    );

    // 8. REAL FALLBACK: dashboard openai 401 → cooldown → env Z.ai real reply.
    const saveFail = await req("POST", "/api/v1/providers/openai", {
      cookie,
      body: { apiKey: RECEIVER_FAIL_KEY, baseUrl: `${RECEIVER}/v1` },
    });
    assert(saveFail.status === 200, "dashboard key replaced with a failing one");
    await fetch(`${RECEIVER}/__reset`, { method: "POST" });
    const chat2 = await req("POST", "/api/v1/chat", {
      cookie,
      body: { message: "Reply with exactly: WORKERD FALLBACK OK" },
    });
    assert(chat2.status === 200, "chat falls back to Z.ai after dashboard openai 401", chat2.text.slice(0, 200));
    assert(chat2.text.trim().length > 0, "fallback produced a REAL Z.ai answer");
    const seen2 = (await (await fetch(`${RECEIVER}/__last-auth`)).json()) as { authorization?: string };
    assert(
      seen2.authorization === `Bearer ${RECEIVER_FAIL_KEY}`,
      "the REPLACED dashboard key was used (and failed) before fallback",
      `receiver saw: ${seen2.authorization ?? "(none)"}`,
    );

    // 9. Provider status reflects the failure honestly + no secrets.
    const list1 = await req("GET", "/api/v1/providers", { cookie });
    const providers1 = (JSON.parse(list1.text) as { providers?: Array<Record<string, unknown>> }).providers ?? [];
    const openai1 = providers1.find((p) => p.id === "openai");
    assert(openai1?.lastErrorCategory === "authentication" || openai1?.status === "offline", "openai honestly reports the auth failure (cooldown)");
    assert(!list1.text.includes(RECEIVER_OK_KEY) && !list1.text.includes(RECEIVER_FAIL_KEY), "provider status contains no key material");

    // 10. Removing the dashboard credential stops its use.
    const del = await req("DELETE", "/api/v1/providers/openai", { cookie });
    assert(del.status === 200, "dashboard credential removed on workerd");
    const testAfter = await req("POST", "/api/v1/providers/openai/test", { cookie });
    assert(testAfter.status === 400, "test after removal → 400 (no credential, no env fallback for openai)");
    const chat3 = await req("POST", "/api/v1/chat", {
      cookie,
      body: { message: "Reply with exactly: WORKERD ENV OK" },
    });
    assert(chat3.status === 200, "chat still works via env Z.ai after credential removal", chat3.text.slice(0, 200));

    // 11. System health with live ping (real requests on workerd).
    const health = await req("GET", "/api/v1/system/health?ai=1", { cookie });
    assert(health.status === 200, "system health with live AI ping works on workerd");

    // 11a. GENERIC PROVIDER SYSTEM on workerd — Test & Add via the local
    //      receiver (REAL request through the built Worker).
    await fetch(`${RECEIVER}/__reset`, { method: "POST" });
    const addCustom = await req("POST", "/api/v1/providers/custom", {
      cookie,
      body: {
        name: "Workerd Custom",
        apiKey: RECEIVER_OK_KEY,
        baseUrl: `${RECEIVER}/v1`,
        model: "test-model-a",
        capabilities: ["TEXT", "VISION"],
        priority: 1,
      },
    });
    assert(addCustom.status === 201, "custom provider Test&Add succeeds on workerd (real request first)", addCustom.text.slice(0, 200));
    const customSaved = (JSON.parse(addCustom.text) as { provider?: { id?: string; maskedKey?: string; status?: string } }).provider;
    assert(customSaved?.maskedKey === "••••••••••••wXYZ", "custom provider masked key on workerd");
    assert(customSaved?.status === "healthy", "custom provider healthy after real test on workerd");
    const customRows = d1("SELECT encrypted_api_key FROM ai_custom_providers") as Array<{ encrypted_api_key: string }>;
    assert(
      customRows.length === 1 && customRows[0].encrypted_api_key.startsWith("v1.") && !customRows[0].encrypted_api_key.includes(RECEIVER_OK_KEY),
      "ai_custom_providers stores AES-GCM ciphertext on workerd (not plaintext)",
    );

    // Custom provider is priority 1 → BEATS the env-configured primary.
    await fetch(`${RECEIVER}/__reset`, { method: "POST" });
    const chatCustom = await req("POST", "/api/v1/chat", {
      cookie,
      body: { message: "Reply with exactly: WORKERD CUSTOM OK" },
    });
    assert(chatCustom.status === 200, "chat routes through the custom provider on workerd");
    assert(
      (chatCustom.headers.get("x-ai-provider") ?? "") === "Workerd Custom",
      "X-AI-Provider header names the custom provider",
      `header=${chatCustom.headers.get("x-ai-provider")}`,
    );
    const seenCustom = (await (await fetch(`${RECEIVER}/__last-auth`)).json()) as { authorization?: string };
    assert(
      seenCustom.authorization === `Bearer ${RECEIVER_OK_KEY}`,
      "custom provider used its DECRYPTED stored key (receiver saw it)",
      `receiver saw: ${seenCustom.authorization ?? "(none)"}`,
    );

    // Delete → immediately unavailable (no orphans).
    const delCustom = await req("DELETE", `/api/v1/providers/custom/${customSaved?.id}`, { cookie });
    assert(delCustom.status === 200, "custom provider deleted on workerd");
    const customGone = d1("SELECT COUNT(*) AS n FROM ai_custom_providers") as Array<{ n: number }>;
    assert((customGone[0]?.n ?? 1) === 0, "custom provider row fully removed (credential + metadata together)");

    // 11b. OAUTH honest states on workerd (no GOOGLE_*/GITHUB_* configured).
    const integ = await req("GET", "/api/v1/integrations", { cookie });
    const integBody = JSON.parse(integ.text) as { integrations?: Array<{ id: string; configured: boolean; connected: boolean }> };
    const gmail = integBody.integrations?.find((i) => i.id === "gmail");
    const github = integBody.integrations?.find((i) => i.id === "github");
    assert(
      integ.status === 200 && gmail?.configured === false && gmail.connected === false && github?.configured === false,
      "integrations report honest not-configured/not-connected on workerd",
    );
    const connectG = await req("GET", "/api/v1/integrations/google/connect", { cookie });
    assert(connectG.status === 503, "google connect → honest 503 on workerd (no credentials)", `status=${connectG.status}`);
    // redirect: "manual" — the 302 must NOT be followed (fetch follows by default)
    const cbBad = await fetch(`${BASE}/api/v1/integrations/google/callback?code=x&state=forged`, {
      headers: { Cookie: cookie },
      redirect: "manual",
    });
    assert(
      cbBad.status === 302 && (cbBad.headers.get("location") ?? "").includes("error"),
      "oauth callback with forged state rejected on workerd (redirect to error)",
      `status=${cbBad.status} location=${cbBad.headers.get("location")}`,
    );

    // 12. Workerd logs contain no key material.
    const logs = logChunks.join("");
    assert(!logs.includes(RECEIVER_OK_KEY) && !logs.includes(RECEIVER_FAIL_KEY), "no API key in workerd logs");
  } finally {
    // Cleanup: kill wrangler, restore .dev.vars, remove isolated state.
    if (wrangler && wrangler.pid) {
      try {
        process.kill(wrangler.pid, "SIGTERM");
      } catch {
        /* already gone */
      }
    }
    spawnSync("pkill", ["-f", "wrangler dev --port 3999"]);
    await new Promise((r) => setTimeout(r, 2500));
    writeFileSync(DEV_VARS, originalDevVars);
    console.log("cleanup: .dev.vars restored, workerd instance stopped");
    rmSync(STATE, { recursive: true, force: true });
  }

  console.log("");
  if (failures.length > 0) {
    console.log(`RESULT: ${failures.length} FAILED / ${passed} passed`);
    for (const f of failures) console.log(`  ✗ ${f}`);
    process.exit(1);
  }
  console.log(`RESULT: all ${passed} workerd checks passed`);
}

void main();
