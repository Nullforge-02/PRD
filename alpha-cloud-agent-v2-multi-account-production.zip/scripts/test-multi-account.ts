// ALPHA — TEST-ONLY multi-account OAuth verification suite.
//
//   1. (optional temp .dev.vars — see below)  bun run dev   (port 3000)
//   2. bun run scripts/test-multi-account.ts
//
// Verifies the multi-account architecture (migration 0005 + account resolver
// + account routes) with REAL endpoints only — no mocks of the app code:
//
// Part 1 — PURE unit tests of the resolver core (no server, no D1):
//   pickAccount() explicit/role/default/single-promotion/ambiguous behavior,
//   role validation, and the invariant that resolution NEVER keys off
//   updated_at (a recently refreshed token must never switch accounts).
//
// Part 2 — E2E over HTTP against the dev server + real local D1:
//   • two Google accounts + two GitHub accounts coexist (multi-account)
//   • account listing exposes metadata ONLY (no ciphertext in responses)
//   • role edit (PATCH) — GitHub only, validated enum, Google → 400
//   • default switching (POST .../default) — exactly one default per provider
//   • Gmail search/send and GitHub repos/issues resolve the EXPLICIT
//     accountId or the DEFAULT account — proven by observing WHICH account's
//     status flips to needs_reauthorization (the seeded tokens are
//     intentionally undecryptable, so every data route answers the
//     deterministic 401 reauthorization path for exactly the resolved
//     account — no external Google/Github API call is ever made)
//   • ambiguity: several accounts + no default + no selection → 400 (never a
//     silent guess)
//   • per-account disconnect keeps siblings + promotes a new default;
//     provider-level disconnect removes ALL accounts
//   • idempotent disconnect of unknown ids
//   • DB-level dedupe: a second row for the same (user, provider,
//     provider_account_id) violates the UNIQUE constraint (reconnecting the
//     same external account can never duplicate)
//   • last_used_at transparency timestamps are set on use
//   • gmail send still REQUIRES confirmed:true and still refuses when the
//     selected account cannot produce a token
//
// NOT covered (honest): the real Google/GitHub consent screens + token
// exchanges (requires real OAuth client credentials — the callback glue is
// covered by scripts/test-oauth-state.ts and the upsert path is exercised at
// the SQL level here).
//
// The suite SELF-CLEANS: every seeded row is removed at the end (and at
// startup, in case a previous run was interrupted).

import { execFileSync } from "node:child_process";
import {
  AmbiguousAccountError,
  UnknownAccountError,
  pickAccount,
} from "../src/server/integrations/account-resolver";
import {
  isGithubAccountRole,
  type ConnectedAccount,
} from "../src/server/repos/connected-accounts";

const BASE = process.argv[2] ?? "http://127.0.0.1:3000";
const ORIGIN = new URL(BASE).origin;

let passed = 0;
let failed = 0;
const failures: string[] = [];

function ok(name: string, cond: boolean, detail = ""): void {
  if (cond) {
    passed++;
    console.log(`  ✓ ${name}`);
  } else {
    failed++;
    failures.push(`${name}${detail ? ` — ${detail}` : ""}`);
    console.log(`  ✗ ${name}${detail ? ` — ${detail}` : ""}`);
  }
}

function throws(kind: unknown, fn: () => unknown): boolean {
  try {
    fn();
    return false;
  } catch (e) {
    return e instanceof (kind as abstract new (...a: never[]) => unknown);
  }
}

// ============================================================
// Part 1 — pure unit tests of the resolution core (no server)
// ============================================================

function fakeAccount(over: Partial<ConnectedAccount> & Pick<ConnectedAccount, "id">): ConnectedAccount {
  return {
    userId: "u1",
    provider: "google",
    providerAccountId: `ext-${over.id}`,
    accountName: `acct-${over.id}`,
    avatarUrl: null,
    encryptedAccessToken: "v1.x.y",
    encryptedRefreshToken: null,
    expiresAt: null,
    scopes: "",
    status: "connected",
    role: null,
    isDefault: false,
    createdAt: "2026-01-01T00:00:00Z",
    updatedAt: "2026-01-01T00:00:00Z",
    lastUsedAt: null,
    ...over,
  };
}

console.log("\nPart 1 — account resolver (pure core)");
{
  ok("empty account list → null (not connected)", pickAccount([], "google") === null);

  const a = fakeAccount({ id: "a", provider: "google", isDefault: true });
  const b = fakeAccount({ id: "b", provider: "google" });

  const explicit = pickAccount([a, b], "google", { accountId: "b" });
  ok("explicit accountId selects that account", explicit?.account.id === "b");
  ok("explicit selection reports resolution=explicit", explicit?.resolution === "explicit");
  ok("unknown accountId → UnknownAccountError", throws(UnknownAccountError, () => pickAccount([a, b], "google", { accountId: "zzz" })));

  const byDefault = pickAccount([a, b], "google", {});
  ok("no selection → explicit default account", byDefault?.account.id === "a");
  ok("default selection reports resolution=default", byDefault?.resolution === "default");

  const single = fakeAccount({ id: "solo", provider: "github" });
  const promoted = pickAccount([single], "github", {});
  ok("single account is auto-promoted", promoted?.resolution === "single-promoted" && promoted.account.id === "solo");

  ok(
    "several accounts, no default, no selection → AmbiguousAccountError",
    throws(AmbiguousAccountError, () => pickAccount([fakeAccount({ id: "x" }), fakeAccount({ id: "y" })], "google", {})),
  );

  // Role resolution (GitHub)
  const storage = fakeAccount({ id: "gh-sto", provider: "github", role: "storage" });
  const scripts = fakeAccount({ id: "gh-scr", provider: "github", role: "scripts", isDefault: true });
  const noRole = fakeAccount({ id: "gh-gen", provider: "github" });

  const byStorage = pickAccount([storage, scripts, noRole], "github", { role: "storage" });
  ok('role "storage" selects the storage account', byStorage?.account.id === "gh-sto");
  ok("role selection reports resolution=role", byStorage?.resolution === "role");
  const byScripts = pickAccount([storage, scripts, noRole], "github", { role: "scripts" });
  ok('role "scripts" selects the scripts account', byScripts?.account.id === "gh-scr");
  ok("NULL role counts as general", pickAccount([storage, noRole], "github", { role: "general" })?.account.id === "gh-gen");
  ok(
    'role with no matching account → AmbiguousAccountError',
    throws(AmbiguousAccountError, () => pickAccount([storage, scripts], "github", { role: "general" })),
  );

  // Several accounts share a role → default wins, else OLDEST; never updated_at.
  const older = fakeAccount({ id: "older", provider: "github", role: "storage", createdAt: "2026-01-01T00:00:00Z", updatedAt: "2026-01-01T00:00:00Z" });
  const newer = fakeAccount({ id: "newer", provider: "github", role: "storage", createdAt: "2026-06-01T00:00:00Z", updatedAt: "2026-12-01T00:00:00Z" });
  ok("shared role, no default → oldest connection wins", pickAccount([older, newer], "github", { role: "storage" })?.account.id === "older");

  const newerDefault = fakeAccount({ id: "newer-d", provider: "github", role: "storage", isDefault: true, createdAt: "2026-06-01T00:00:00Z", updatedAt: "2026-01-01T00:00:00Z" });
  ok("shared role, default flagged → default wins", pickAccount([older, newerDefault], "github", { role: "storage" })?.account.id === "newer-d");

  // THE invariant: a recently updated account must never steal selection.
  const quiet = fakeAccount({ id: "quiet", provider: "google", isDefault: true, updatedAt: "2026-01-01T00:00:00Z" });
  const loud = fakeAccount({ id: "loud", provider: "google", updatedAt: "2026-12-31T23:59:59Z" });
  ok(
    "recently-updated account never steals the default (no ORDER BY updated_at)",
    pickAccount([quiet, loud], "google", {})?.account.id === "quiet",
  );
  ok(
    "explicit selection beats a recently-updated account",
    pickAccount([loud, quiet], "google", { accountId: "quiet" })?.account.id === "quiet",
  );

  // Role on a GOOGLE provider is ignored (roles are GitHub-only).
  ok(
    "role is ignored for Google providers (falls back to default)",
    pickAccount([quiet, loud], "google", { role: "storage" })?.account.id === "quiet",
  );

  // Role validation helper.
  ok("isGithubAccountRole accepts storage/scripts/general", ["storage", "scripts", "general"].every(isGithubAccountRole));
  ok("isGithubAccountRole rejects unknown + null", !isGithubAccountRole("deploy") && !isGithubAccountRole(null) && !isGithubAccountRole(""));
}

// ============================================================
// Part 2 — E2E against the dev server (real HTTP + real D1)
// ============================================================

// --- cookie-jar fetch (same pattern as scripts/verify-generic-patch.ts) ---
const jar: string[] = [];
function cookieHeader(): string {
  return jar.join("; ");
}
function captureCookies(res: Response): void {
  const set = res.headers.getSetCookie?.() ?? [];
  for (const c of set) {
    const pair = c.split(";")[0];
    const name = pair.split("=")[0];
    const idx = jar.findIndex((v) => v.startsWith(`${name}=`));
    if (idx >= 0) jar.splice(idx, 1);
    jar.push(pair);
  }
}
async function req(
  method: string,
  path: string,
  body?: unknown,
  opts: { origin?: string | null; cookie?: boolean } = {},
): Promise<Response> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
      ...(opts.cookie === false ? {} : { Cookie: cookieHeader() }),
      ...(opts.origin !== undefined ? { Origin: opts.origin } : {}),
    },
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
    redirect: "manual",
  });
  captureCookies(res);
  return res;
}
async function json<T>(res: Response): Promise<T | null> {
  return (await res.json().catch(() => null)) as T | null;
}

function d1(sql: string): { success: boolean } {
  const out = execFileSync(
    "npx",
    ["wrangler", "d1", "execute", "alpha-db", "--local", "--command", sql, "--json"],
    { encoding: "utf8", timeout: 60_000 },
  );
  try {
    return JSON.parse(out) as { success: boolean };
  } catch {
    return { success: false };
  }
}

function d1Fails(sql: string): boolean {
  try {
    execFileSync(
      "npx",
      ["wrangler", "d1", "execute", "alpha-db", "--local", "--command", sql, "--json"],
      { encoding: "utf8", timeout: 60_000, stdio: "pipe" },
    );
    return false;
  } catch {
    return true; // command failed (e.g. UNIQUE constraint violation)
  }
}

interface AccountInfoApi {
  id: string;
  provider: string;
  accountName: string | null;
  status: string;
  role: string | null;
  isDefault: boolean;
  lastUsedAt: string | null;
}
interface IntegrationsApi {
  integrations: Array<{
    id: string;
    configured: boolean;
    connected: boolean;
    accounts: AccountInfoApi[];
    defaultAccountId: string | null;
    setup: string;
  }>;
}

const G1 = "oa-test-g1";
const G2 = "oa-test-g2";
const H1 = "oa-test-h1";
const H2 = "oa-test-h2";
const TOKEN = "v1.test-only-not-decryptable.deadbeef";

function seedRow(
  id: string,
  userId: string,
  provider: string,
  extId: string,
  name: string,
  isDefault: number,
): string {
  return (
    `INSERT INTO connected_accounts (id, user_id, provider, provider_account_id, account_name, ` +
    `avatar_url, encrypted_access_token, encrypted_refresh_token, expires_at, scopes, role, ` +
    `is_default, status, created_at, updated_at, last_used_at) VALUES ('${id}', '${userId}', ` +
    `'${provider}', '${extId}', '${name}', NULL, '${TOKEN}', NULL, NULL, '', NULL, ` +
    `${isDefault}, 'connected', '2026-01-01T00:00:00.000Z', '2026-01-01T00:00:00.000Z', NULL)`
  );
}

async function main(): Promise<void> {
  console.log(`\nPart 2 — E2E (base=${BASE})`);

  // ---------- preconditions ----------
  const probe = await req("GET", "/api/v1/integrations", undefined, { origin: ORIGIN });
  if (probe.status === 401) {
    // login first, then probe again
    const login = await req("POST", "/api/v1/auth/login", {
      email: "owner@alpha.dev",
      password: "correct-horse-battery",
    }, { origin: ORIGIN, cookie: false });
    if (login.status !== 200) {
      const setup = await req("POST", "/api/v1/auth/setup", {
        email: "owner@alpha.dev",
        name: "Owner",
        password: "correct-horse-battery",
      }, { origin: ORIGIN, cookie: false });
      ok("owner setup (fresh database)", setup.status === 200, `status=${setup.status}`);
    } else {
      ok("owner login", login.status === 200, `status=${login.status}`);
    }
  }
  const me = await json<{ user: { id: string } | null }>(await req("GET", "/api/v1/auth/me"));
  if (!me?.user?.id) {
    console.error("\n[abort] not authenticated — start the dev server and ensure the owner account exists.");
    process.exit(1);
  }
  const userId = me.user.id;
  ok("authenticated session", true);

  const statusProbe = await json<IntegrationsApi>(await req("GET", "/api/v1/integrations"));
  const googleConfigured = statusProbe?.integrations.find((i) => i.id === "gmail")?.configured ?? false;
  const githubConfigured = statusProbe?.integrations.find((i) => i.id === "github")?.configured ?? false;
  if (!googleConfigured || !githubConfigured) {
    console.error(
      "\n[abort] OAuth client credentials are not configured in the dev environment.\n" +
        "        Start the dev server with a temporary .dev.vars containing placeholder\n" +
        "        GOOGLE_CLIENT_ID/GOOGLE_CLIENT_SECRET and GITHUB_CLIENT_ID/GITHUB_CLIENT_SECRET\n" +
        "        (dummy values are fine — this suite never contacts Google/GitHub), then re-run.",
    );
    process.exit(1);
  }
  ok("oauth client credentials present (dummy values fine)", true);

  // ---------- clean slate + seed ----------
  d1(`DELETE FROM connected_accounts WHERE user_id='${userId}' AND id LIKE 'oa-test-%'`);
  d1(seedRow(G1, userId, "google", "test-sub-1", "personal@alpha.dev", 1));
  d1(seedRow(G2, userId, "google", "test-sub-2", "work@alpha.dev", 0));
  d1(seedRow(H1, userId, "github", "9001", "alpha-storage", 1));
  d1(seedRow(H2, userId, "github", "9002", "alpha-scripts", 0));
  ok("seeded 2 google + 2 github accounts (real D1 rows)", true);

  // ---------- listing + metadata-only guarantee ----------
  console.log("\n— listing & metadata");
  const st1 = await json<IntegrationsApi>(await req("GET", "/api/v1/integrations"));
  const gmail1 = st1?.integrations.find((i) => i.id === "gmail");
  const github1 = st1?.integrations.find((i) => i.id === "github");
  ok("both providers connected", gmail1?.connected === true && github1?.connected === true);
  ok("two google accounts listed", gmail1?.accounts.length === 2);
  ok("two github accounts listed", github1?.accounts.length === 2);
  ok("different external accounts coexist", new Set((gmail1?.accounts ?? []).map((a) => a.id)).size === 2);
  const raw = JSON.stringify(st1);
  ok("no ciphertext in the response (metadata only)", !raw.includes("encrypted") && !raw.includes(TOKEN));
  ok("default account exposed (google)", gmail1?.defaultAccountId === G1);
  ok("default account exposed (github)", github1?.defaultAccountId === H1);
  ok("account names present", (gmail1?.accounts ?? []).some((a) => a.accountName === "work@alpha.dev"));

  // ---------- role editing ----------
  console.log("\n— roles");
  const roleGoogle = await req("PATCH", `/api/v1/integrations/accounts/${G1}`, { role: "storage" }, { origin: ORIGIN });
  ok("role PATCH on a GOOGLE account → 400", roleGoogle.status === 400, `status=${roleGoogle.status}`);
  const roleBad = await req("PATCH", `/api/v1/integrations/accounts/${H1}`, { role: "deploy" }, { origin: ORIGIN });
  ok("role PATCH with invalid role → 400", roleBad.status === 400, `status=${roleBad.status}`);
  const roleUnknown = await req("PATCH", "/api/v1/integrations/accounts/oa-does-not-exist", { role: "storage" }, { origin: ORIGIN });
  ok("role PATCH on unknown account → 400", roleUnknown.status === 400, `status=${roleUnknown.status}`);

  const r1 = await json<{ account: { role: string } }>(await req("PATCH", `/api/v1/integrations/accounts/${H1}`, { role: "storage" }, { origin: ORIGIN }));
  ok("github #1 role=storage", r1?.account?.role === "storage");
  const r2 = await json<{ account: { role: string } }>(await req("PATCH", `/api/v1/integrations/accounts/${H2}`, { role: "scripts" }, { origin: ORIGIN }));
  ok("github #2 role=scripts", r2?.account?.role === "scripts");
  const st2 = await json<IntegrationsApi>(await req("GET", "/api/v1/integrations"));
  const github2 = st2?.integrations.find((i) => i.id === "github");
  ok("roles visible in listing", github2?.accounts.find((a) => a.id === H1)?.role === "storage" && github2?.accounts.find((a) => a.id === H2)?.role === "scripts");
  ok("google accounts never carry a role", (st2?.integrations.find((i) => i.id === "gmail")?.accounts ?? []).every((a) => a.role === null));

  // ---------- default switching ----------
  console.log("\n— default (Use) switching");
  const defUnknown = await req("POST", "/api/v1/integrations/accounts/oa-does-not-exist/default", undefined, { origin: ORIGIN });
  ok("default POST on unknown account → 404", defUnknown.status === 404, `status=${defUnknown.status}`);
  const defSwitch = await req("POST", `/api/v1/integrations/accounts/${G2}/default`, undefined, { origin: ORIGIN });
  ok("default POST → 200", defSwitch.status === 200, `status=${defSwitch.status}`);
  const st3 = await json<IntegrationsApi>(await req("GET", "/api/v1/integrations"));
  const gmail3 = st3?.integrations.find((i) => i.id === "gmail");
  ok("default switched to work@alpha.dev", gmail3?.defaultAccountId === G2);
  ok("exactly one default per provider", (gmail3?.accounts ?? []).filter((a) => a.isDefault).length === 1);
  ok("old default cleared", gmail3?.accounts.find((a) => a.id === G1)?.isDefault === false);

  // ---------- gmail uses the SELECTED/DEFAULT account ----------
  console.log("\n— gmail account resolution (proven via per-account status flips)");
  // Default (G2) — the seeded token is undecryptable → deterministic 401 + flip.
  const gmailDefault = await json<{ code?: string } | null>(await req("GET", "/api/v1/gmail/messages?max=5"));
  ok("gmail search with no accountId → 401 reauthorization_needed", (await req("GET", "/api/v1/gmail/messages?max=5")).status === 401 && gmailDefault?.code === "reauthorization_needed");
  let st4 = await json<IntegrationsApi>(await req("GET", "/api/v1/integrations"));
  let gmail4 = st4?.integrations.find((i) => i.id === "gmail");
  ok("DEFAULT account (work@) was used — status flipped", gmail4?.accounts.find((a) => a.id === G2)?.status === "needs_reauthorization");
  ok("other google account untouched (personal@ still connected)", gmail4?.accounts.find((a) => a.id === G1)?.status === "connected");

  // Explicit (G1).
  await req("GET", `/api/v1/gmail/messages?max=5&accountId=${G1}`);
  st4 = await json<IntegrationsApi>(await req("GET", "/api/v1/integrations"));
  gmail4 = st4?.integrations.find((i) => i.id === "gmail");
  ok("EXPLICIT account (personal@) was used — status flipped", gmail4?.accounts.find((a) => a.id === G1)?.status === "needs_reauthorization");

  // Unknown explicit account.
  const gmailUnknown = await req("GET", "/api/v1/gmail/messages?accountId=oa-does-not-exist");
  ok("unknown accountId → 404 with account list", gmailUnknown.status === 404, `status=${gmailUnknown.status}`);

  // Ambiguity: unset ALL google defaults → 400 asking to select.
  d1(`UPDATE connected_accounts SET is_default=0 WHERE user_id='${userId}' AND provider='google'`);
  const gmailAmbiguous = await req("GET", "/api/v1/gmail/messages?max=5");
  const ambBody = (await json<{ error?: string }>(gmailAmbiguous))?.error ?? "";
  ok("several accounts + no default + no selection → 400 (never a silent guess)", gmailAmbiguous.status === 400, `status=${gmailAmbiguous.status}`);
  ok("ambiguity error names the connected accounts", ambBody.includes("personal@alpha.dev") && ambBody.includes("work@alpha.dev"));

  // Restore: personal@ default, statuses reset.
  d1(`UPDATE connected_accounts SET is_default=1 WHERE user_id='${userId}' AND id='${G1}'`);
  d1(`UPDATE connected_accounts SET is_default=0 WHERE user_id='${userId}' AND id='${G2}'`);
  d1(`UPDATE connected_accounts SET status='connected' WHERE user_id='${userId}' AND id IN ('${G1}','${G2}')`);

  // ---------- gmail send: confirmation + selected account ----------
  console.log("\n— gmail send (consequential action)");
  const sendNoConfirm = await req("POST", "/api/v1/gmail/send", { to: "someone@example.com", subject: "hi", body: "hello" }, { origin: ORIGIN });
  ok("send without confirmed:true → 400 (unchanged)", sendNoConfirm.status === 400, `status=${sendNoConfirm.status}`);
  const sendSel = await req("POST", "/api/v1/gmail/send", { to: "someone@example.com", subject: "hi", body: "hello", confirmed: true, accountId: G2 }, { origin: ORIGIN });
  ok("send with selected account refuses when the account cannot produce a token", sendSel.status === 401, `status=${sendSel.status}`);
  const st5 = await json<IntegrationsApi>(await req("GET", "/api/v1/integrations"));
  ok("send used the SELECTED account (work@ flipped again)", st5?.integrations.find((i) => i.id === "gmail")?.accounts.find((a) => a.id === G2)?.status === "needs_reauthorization");

  // ---------- github uses the SELECTED/DEFAULT account ----------
  console.log("\n— github account resolution");
  await req("GET", "/api/v1/github/repos");
  let st6 = await json<IntegrationsApi>(await req("GET", "/api/v1/integrations"));
  let github6 = st6?.integrations.find((i) => i.id === "github");
  ok("DEFAULT github account (storage) used — flipped", github6?.accounts.find((a) => a.id === H1)?.status === "needs_reauthorization");
  ok("other github account untouched", github6?.accounts.find((a) => a.id === H2)?.status === "connected");
  await req("GET", `/api/v1/github/repos?accountId=${H2}`);
  st6 = await json<IntegrationsApi>(await req("GET", "/api/v1/integrations"));
  github6 = st6?.integrations.find((i) => i.id === "github");
  ok("EXPLICIT github account (scripts) used — flipped", github6?.accounts.find((a) => a.id === H2)?.status === "needs_reauthorization");
  const issuesSel = await req("GET", `/api/v1/github/repos/octocat/hello-world/issues?accountId=${H2}`);
  ok("issues route accepts accountId (reauth path for the selected account)", issuesSel.status === 401, `status=${issuesSel.status}`);
  const issuesBad = await req("GET", "/api/v1/github/repos/bad%20name/repo%20x/issues");
  ok("issues route still validates owner/repo", issuesBad.status === 400, `status=${issuesBad.status}`);

  // last_used_at transparency
  const st7 = await json<IntegrationsApi>(await req("GET", "/api/v1/integrations"));
  const allAccounts = (st7?.integrations ?? []).flatMap((i) => i.accounts);
  ok("last_used_at recorded for used accounts", allAccounts.filter((a) => a.lastUsedAt !== null).length >= 4);
  ok("last_used_at is ISO-ish timestamp", (allAccounts.find((a) => a.id === G2)?.lastUsedAt ?? "").length > 10);

  // ---------- per-account disconnect + default promotion ----------
  console.log("\n— disconnect semantics");
  const delUnknown = await req("DELETE", "/api/v1/integrations/accounts/oa-does-not-exist", undefined, { origin: ORIGIN });
  ok("disconnect unknown account → idempotent ok", delUnknown.status === 200);
  const delG2 = await json<{ ok: boolean; promotedDefaultId: string | null }>(await req("DELETE", `/api/v1/integrations/accounts/${G2}`, undefined, { origin: ORIGIN }));
  ok("disconnect ONE account (work@) succeeds", delG2?.ok === true);
  const st8 = await json<IntegrationsApi>(await req("GET", "/api/v1/integrations"));
  const gmail8 = st8?.integrations.find((i) => i.id === "gmail");
  ok("other google account remains (personal@)", gmail8?.accounts.length === 1 && gmail8.accounts[0].id === G1);
  const delG1 = await json<{ ok: boolean; promotedDefaultId: string | null }>(await req("DELETE", `/api/v1/integrations/accounts/${G1}`, undefined, { origin: ORIGIN }));
  ok("disconnecting the last default → no promotion needed", delG1?.ok === true && delG1?.promotedDefaultId === null);
  const st9 = await json<IntegrationsApi>(await req("GET", "/api/v1/integrations"));
  ok("google provider now empty", st9?.integrations.find((i) => i.id === "gmail")?.accounts.length === 0);

  // Default promotion on a MULTI-account disconnect: re-seed two googles, delete the default.
  d1(seedRow(`${G1}b`, userId, "google", "test-sub-1b", "one@alpha.dev", 1));
  d1(seedRow(`${G2}b`, userId, "google", "test-sub-2b", "two@alpha.dev", 0));
  const delDefault = await json<{ ok: boolean; promotedDefaultId: string | null }>(
    await req("DELETE", `/api/v1/integrations/accounts/${G1}b`, undefined, { origin: ORIGIN }),
  );
  ok("deleting the default promotes a sibling", delDefault?.promotedDefaultId === `${G2}b`);
  const st10 = await json<IntegrationsApi>(await req("GET", "/api/v1/integrations"));
  const gmail10 = st10?.integrations.find((i) => i.id === "gmail");
  ok("promoted sibling is the new default", gmail10?.defaultAccountId === `${G2}b` && gmail10?.accounts[0]?.isDefault === true);

  // ---------- provider-level disconnect (all accounts) ----------
  const delAll = await json<{ ok: boolean; disconnected: number }>(await req("DELETE", "/api/v1/integrations/github", undefined, { origin: ORIGIN }));
  ok("provider-level disconnect removes ALL github accounts", delAll?.ok === true && delAll?.disconnected === 2);
  const st11 = await json<IntegrationsApi>(await req("GET", "/api/v1/integrations"));
  ok("github provider empty after disconnect-all", st11?.integrations.find((i) => i.id === "github")?.accounts.length === 0);

  // ---------- DB-level dedupe (same external account cannot duplicate) ----------
  console.log("\n— dedupe (UNIQUE user+provider+provider_account_id)");
  d1(seedRow(`${G1}c`, userId, "google", "test-sub-1c", "dupe@alpha.dev", 0));
  ok(
    "second row for the SAME external account violates the UNIQUE constraint",
    d1Fails(seedRow(`${G1}d`, userId, "google", "test-sub-1c", "dupe@alpha.dev", 0)),
  );
  ok(
    "a DIFFERENT external account coexists fine",
    (() => {
      d1(seedRow(`${G2}c`, userId, "google", "test-sub-2c", "other@alpha.dev", 0));
      return true;
    })(),
  );

  // ---------- cleanup ----------
  d1(`DELETE FROM connected_accounts WHERE user_id='${userId}' AND id LIKE 'oa-test-%'`);
  const stFinal = await json<IntegrationsApi>(await req("GET", "/api/v1/integrations"));
  const remaining = (stFinal?.integrations ?? []).reduce((n, i) => n + i.accounts.length, 0);
  ok("cleanup — zero test accounts remain", remaining === 0);
}

main()
  .then(() => {
    console.log(`\n[multi-account] ${passed} passed, ${failed} failed`);
    if (failures.length > 0) {
      console.log("\nFailures:");
      for (const f of failures) console.log(`  ✗ ${f}`);
      process.exit(1);
    }
  })
  .catch((e) => {
    console.error("\n[abort] suite crashed:", e);
    process.exit(1);
  });
