// ALPHA — credential crypto unit tests (PART 15, items 3 & 4).
//
// Runs the REAL production module (src/server/ai/credential-crypto.ts — pure
// Web Crypto, no mocks) directly:
//
//   bun run scripts/test-credential-crypto.ts
//
// Proves:
//   - correct secret decrypts correctly (round-trip)
//   - a WRONG secret cannot decrypt (AES-GCM authentication failure)
//   - every encryption uses a fresh random IV (same key → different ciphertexts)
//   - tampered ciphertexts are rejected
//   - the stored form never contains the plaintext key

import { encryptCredential, decryptCredential } from "../src/server/ai/credential-crypto";

let passed = 0;
const failures: string[] = [];

function assert(condition: boolean, name: string) {
  if (condition) {
    passed += 1;
    console.log(`  PASS  ${name}`);
  } else {
    failures.push(name);
    console.log(`  FAIL  ${name}`);
  }
}

async function main() {
  const secret = "unit-test-secret-0123456789abcdef";
  const wrongSecret = "wrong-secret-9876543210fedcba";
  const key = "sk-unit-ABCD1234efgh5678";

  console.log("credential-crypto unit tests");

  // 1. Round-trip with the correct secret.
  const stored = await encryptCredential(secret, key);
  const restored = await decryptCredential(secret, stored);
  assert(restored === key, "correct secret decrypts the credential (round-trip)");

  // 2. Stored form is the versioned v1.<iv>.<ct> format.
  assert(/^v1\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(stored), "stored format is v1.<iv>.<ct>");

  // 3. The plaintext key never appears in the stored ciphertext.
  assert(!stored.includes(key), "plaintext key never appears in the stored form");

  // 4. Unique IV per encryption — encrypting twice yields different ciphertexts.
  const stored2 = await encryptCredential(secret, key);
  assert(stored !== stored2, "unique random IV per encryption (same key → different ciphertext)");
  assert((await decryptCredential(secret, stored2)) === key, "second ciphertext also decrypts");

  // 5. A WRONG secret cannot decrypt (GCM authentication failure).
  let wrongSecretThrew = false;
  try {
    await decryptCredential(wrongSecret, stored);
  } catch {
    wrongSecretThrew = true;
  }
  assert(wrongSecretThrew, "wrong encryption secret cannot decrypt the credential");

  // 6. Tampered ciphertext is rejected.
  const parts = stored.split(".");
  const tampered = `${parts[0]}.${parts[1]}.${parts[2].slice(0, -2)}AA`;
  let tamperThrew = false;
  try {
    await decryptCredential(secret, tampered);
  } catch {
    tamperThrew = true;
  }
  assert(tamperThrew, "tampered ciphertext is rejected");

  // 7. Malformed payloads are rejected (no crash, no partial data).
  let malformedThrew = 0;
  for (const bad of ["", "v1", "v1.onlyone", "notv9.abc.def", "v1...."]) {
    try {
      await decryptCredential(secret, bad);
    } catch {
      malformedThrew += 1;
    }
  }
  assert(malformedThrew === 5, "malformed payloads are rejected");

  console.log("");
  if (failures.length > 0) {
    console.log(`RESULT: ${failures.length} FAILED / ${passed} passed`);
    process.exit(1);
  }
  console.log(`RESULT: all ${passed} checks passed`);
}

void main();
