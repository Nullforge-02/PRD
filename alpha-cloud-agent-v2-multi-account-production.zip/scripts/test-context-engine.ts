// ALPHA — TEST-ONLY verification suite for the layered context / memory system.
//
//   1. bun run scripts/test-openai-receiver.ts   (terminal 1, port 3111)
//   2. bun run dev                               (terminal 2, port 3000)
//   3. bun run scripts/test-context-engine.ts    (terminal 3)
//
// Verifies against REAL endpoints only (dev server + local OpenAI-protocol
// receiver). Part 1 unit-tests the PURE helpers directly (no server, no D1):
// token estimation/truncation, env overrides, lexical scoring, remember-intent
// detection and the sensitive filter. Part 2 is a full E2E pass over HTTP:
// X-Alpha-Context header contract, semantic memory discipline (explicit
// remember intent only, never secrets), rolling summarization through the
// whole provider stack (the receiver answers summarizer-marked requests with
// a recognizable payload), raw-message preservation, lexical relevant-history
// retrieval, the recent-window budget, and Task-1 title derivation.
//
// Usage:
//   bun run scripts/test-context-engine.ts [baseUrl] [receiverUrl]

import {
  CONTEXT_BUDGET,
  estimateTokens,
  getContextBudget,
  truncateToTokens,
} from "../src/server/context/budget";
import { extractKeywords } from "../src/server/context/keywords";
import { scoreRelevance } from "../src/server/context/engine";
import {
  detectRememberIntent,
  evaluateRememberMessage,
  extractRememberClause,
  looksSensitive,
} from "../src/server/context/memory-extract";
import { deriveTitle } from "../src/server/chat-engine";

const BASE = process.argv[2] ?? "http://127.0.0.1:3000";
const RECEIVER = process.argv[3] ?? "http://127.0.0.1:3111";
const ORIGIN = new URL(BASE).origin;

let passed = 0;
let failed = 0;
const failures: string[] = [];

function ok(name: string, cond: boolean, detail = ""): void {
  if (cond) {
    passed++;
    console.log(`  ✓ ${name}`);
  } else {
    failed++;
    failures.push(`${name}${detail ? ` — ${detail}` : ""}`);
    console.log(`  ✗ ${name}${detail ? ` — ${detail}` : ""}`);
  }
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// ============================================================
// Part 1 — pure unit tests (no server, no D1)
// ============================================================

function unitTests(): void {
  console.log("\n— Part 1a: token estimator");
  ok("estimateTokens('') === 0", estimateTokens("") === 0);
  ok("estimateTokens('abcd') === 1", estimateTokens("abcd") === 1);
  ok("estimateTokens('abcde') === 2 (ceil)", estimateTokens("abcde") === 2);
  ok("estimateTokens(401 chars) === 101", estimateTokens("a".repeat(401)) === 101);

  console.log("\n— Part 1b: truncateToTokens");
  const short = "short text stays untouched";
  ok("within budget → unchanged", truncateToTokens(short, 100) === short);
  const long = "x".repeat(200);
  const truncated = truncateToTokens(long, 10);
  ok("over budget → shortened with ellipsis marker",
    truncated.length < long.length && truncated.includes("…[truncated]"),
    `len=${truncated.length}`);
  ok("over budget cut honors maxTokens*4 chars",
    truncated.startsWith("x".repeat(40)),
    `head=${truncated.slice(0, 44)}…`);
  ok("maxTokens 0 → empty string", truncateToTokens(long, 0) === "");
  const mixed = `x${"😀".repeat(30)}`;
  const cutMixed = truncateToTokens(mixed, 10);
  const cutPart = cutMixed.slice(0, cutMixed.indexOf(" …[truncated]"));
  ok("never splits a surrogate pair (lone high half dropped)",
    cutPart.length === 39 && !/[\uD800-\uDBFF]$/.test(cutPart) && cutMixed.includes("…[truncated]"),
    `cutPart units=${cutPart.length}`);

  console.log("\n— Part 1c: budget env overrides (never throw, sane fallbacks)");
  const budgetBefore = getContextBudget();
  ok("defaults from CONTEXT_BUDGET",
    budgetBefore.RECENT_MESSAGES_LIMIT === CONTEXT_BUDGET.RECENT_MESSAGES_LIMIT &&
    budgetBefore.SUMMARIZE_THRESHOLD === CONTEXT_BUDGET.SUMMARIZE_THRESHOLD);
  process.env.CONTEXT_RECENT_MESSAGES_LIMIT = "7";
  process.env.CONTEXT_SUMMARIZE_THRESHOLD = "5";
  process.env.CONTEXT_SUMMARY_TARGET_TOKENS = "300";
  const budgetOverridden = getContextBudget();
  ok("CONTEXT_RECENT_MESSAGES_LIMIT=7 → 7", budgetOverridden.RECENT_MESSAGES_LIMIT === 7);
  ok("CONTEXT_SUMMARIZE_THRESHOLD=5 → 5", budgetOverridden.SUMMARIZE_THRESHOLD === 5);
  ok("CONTEXT_SUMMARY_TARGET_TOKENS=300 → 300", budgetOverridden.SUMMARY_TARGET_TOKENS === 300);
  process.env.CONTEXT_RECENT_MESSAGES_LIMIT = "abc";
  process.env.CONTEXT_SUMMARIZE_THRESHOLD = "-3";
  delete process.env.CONTEXT_SUMMARY_TARGET_TOKENS;
  const budgetGarbage = getContextBudget();
  ok("garbage → default (16)", budgetGarbage.RECENT_MESSAGES_LIMIT === 16, `got ${budgetGarbage.RECENT_MESSAGES_LIMIT}`);
  ok("negative → default (24)", budgetGarbage.SUMMARIZE_THRESHOLD === 24, `got ${budgetGarbage.SUMMARIZE_THRESHOLD}`);
  ok("cleared target → default (450)", budgetGarbage.SUMMARY_TARGET_TOKENS === 450, `got ${budgetGarbage.SUMMARY_TARGET_TOKENS}`);
  delete process.env.CONTEXT_RECENT_MESSAGES_LIMIT;
  delete process.env.CONTEXT_SUMMARIZE_THRESHOLD;
  const budgetRestored = getContextBudget();
  ok("cleared → defaults again", budgetRestored.RECENT_MESSAGES_LIMIT === 16 && budgetRestored.SUMMARIZE_THRESHOLD === 24);

  console.log("\n— Part 1d: lexical keyword extraction + scoring");
  const queryWords = extractKeywords("What do you know about topicX?");
  ok("keywords are 4+ chars, lowercased",
    queryWords.includes("what") && queryWords.includes("know") && queryWords.includes("about") && queryWords.includes("topicx"),
    `words=${JSON.stringify(queryWords)}`);
  ok("short words excluded ('you', 'do')", !queryWords.includes("you") && !queryWords.includes("do"));
  ok("scoreRelevance counts keyword hits",
    scoreRelevance("filler message number 4 about topicX", queryWords) >= 2);
  ok("scoreRelevance 0 on unrelated content",
    scoreRelevance("totally unrelated content here", queryWords) === 0);
  ok("scoreRelevance 0 with empty query", scoreRelevance("anything at all", []) === 0);

  console.log("\n— Part 1e: remember-intent detection + sensitive filter");
  ok("'remember that …' → intent", detectRememberIntent("remember that my project uses D1"));
  ok("'don't forget …' → intent", detectRememberIntent("don't forget the milk"));
  ok("'keep in mind …' → intent", detectRememberIntent("keep in mind the deadline"));
  ok("'note the change' → intent", detectRememberIntent("please note the change"));
  ok("'hello there friend' → NO intent", !detectRememberIntent("hello there friend"));
  ok("'what do you know about topicX?' → NO intent", !detectRememberIntent("what do you know about topicX?"));
  ok("'notebook' → NO intent (word boundary)", !detectRememberIntent("update the notebook entry"));
  ok("api key assignment → sensitive", looksSensitive("remember my api key = sk-test-123"));
  ok("api_key: assignment → sensitive", looksSensitive("note api_key: abc123"));
  ok("password = → sensitive", looksSensitive("the password = hunter2"));
  ok("innocuous D1 fact → NOT sensitive", !looksSensitive("remember that my Alpha project uses Cloudflare D1"));
  ok("'token' without assignment → NOT sensitive", !looksSensitive("note the token ceremony details"));

  console.log("\n— Part 1f: clause extraction + candidate evaluation (pure pipeline)");
  const clause = extractRememberClause("remember that my Alpha project uses Cloudflare D1");
  ok("clause strips 'remember that' and keeps the fact",
    clause === "my Alpha project uses Cloudflare D1", `clause='${clause}'`);
  ok("bare 'remember this' → null clause", extractRememberClause("remember this") === null);
  const candidate = evaluateRememberMessage("remember that my Alpha project uses Cloudflare D1");
  ok("D1 fact → ok / category 'fact'",
    candidate.status === "ok" && candidate.category === "fact",
    JSON.stringify(candidate).slice(0, 80));
  const pref = evaluateRememberMessage("remember that I prefer dark mode");
  ok("'I prefer …' → ok / category 'preference'",
    pref.status === "ok" && pref.category === "preference",
    JSON.stringify(pref).slice(0, 80));
  ok("secret message → status 'sensitive'",
    evaluateRememberMessage("remember my api key = sk-test-123").status === "sensitive");
  ok("no intent → status 'no-intent'",
    evaluateRememberMessage("hello there friend").status === "no-intent");
  const longRemember = `remember that ${"detail ".repeat(200)}matters a lot here`;
  ok(`clause over 500 chars → status 'too-long' (not stored, not truncated)`,
    evaluateRememberMessage(longRemember).status === "too-long",
    `len=${longRemember.length}`);
  const mid = `remember that ${"x".repeat(60)} is a moderate fact worth keeping`;
  ok("clause between 8 and 500 chars → ok",
    evaluateRememberMessage(mid).status === "ok");
}

// ============================================================
// Part 2 — E2E over HTTP (dev server + receiver + owner account)
// ============================================================

const jar: string[] = [];
function cookieHeader(): string {
  return jar.join("; ");
}
function captureCookies(res: Response): void {
  const set = res.headers.getSetCookie?.() ?? [];
  for (const c of set) {
    const pair = c.split(";")[0];
    const name = pair.split("=")[0];
    const idx = jar.findIndex((v) => v.startsWith(`${name}=`));
    if (idx >= 0) jar.splice(idx, 1);
    jar.push(pair);
  }
}

async function req(
  method: string,
  path: string,
  body?: unknown,
): Promise<Response> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
      Cookie: cookieHeader(),
      Origin: ORIGIN,
    },
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
    redirect: "manual",
  });
  captureCookies(res);
  return res;
}

async function json<T>(res: Response): Promise<T | null> {
  return (await res.json().catch(() => null)) as T | null;
}

const CONTEXT_HEADER_RE = /^recent=\d+; summary=[01]; relevant=\d+; memories=\d+$/;
let recentBudgetAlwaysOk = true;

interface MemoryItem {
  id: string;
  source: string;
  category: string;
  content: string;
}

/** Send a chat message and return [response, parsed context header stats]. */
async function chat(
  message: string,
  conversationId?: string,
): Promise<{ res: Response; text: string; stats: { recent: number; summary: number; relevant: number; memories: number } | null; rawHeader: string | null }> {
  const res = await req("POST", "/api/v1/chat", {
    ...(conversationId ? { conversationId } : {}),
    message,
  });
  const text = res.ok ? await res.text() : "";
  const rawHeader = res.headers.get("x-alpha-context");
  let stats: { recent: number; summary: number; relevant: number; memories: number } | null = null;
  if (rawHeader && CONTEXT_HEADER_RE.test(rawHeader)) {
    const parse = (key: string) => Number(rawHeader.split(";").find((p) => p.trim().startsWith(`${key}=`))?.split("=")[1]);
    stats = { recent: parse("recent"), summary: parse("summary"), relevant: parse("relevant"), memories: parse("memories") };
    if (stats.recent > CONTEXT_BUDGET.RECENT_MESSAGES_LIMIT) recentBudgetAlwaysOk = false;
  } else if (res.ok) {
    recentBudgetAlwaysOk = false;
  }
  return { res, text, stats, rawHeader };
}

async function listMemories(): Promise<MemoryItem[]> {
  const body = await json<{ memories: MemoryItem[] }>(await req("GET", "/api/v1/memory"));
  return body?.memories ?? [];
}

async function e2eTests(): Promise<void> {
  console.log(`\n— Part 2a: environment (base=${BASE} receiver=${RECEIVER})`);
  const rx = await fetch(`${RECEIVER}/v1/models`, { headers: { Authorization: "Bearer ping" } });
  ok("test receiver reachable", rx.ok);

  const status0 = await req("GET", "/api/v1/auth/status");
  const st0 = await json<{ setupNeeded: boolean }>(status0);
  if (st0?.setupNeeded) {
    const setup = await req("POST", "/api/v1/auth/setup", {
      email: "owner@alpha.dev",
      name: "Owner",
      password: "correct-horse-battery",
    });
    ok("owner setup", setup.status === 200, `status=${setup.status}`);
  } else {
    const login = await req("POST", "/api/v1/auth/login", {
      email: "owner@alpha.dev",
      password: "correct-horse-battery",
    });
    ok("owner login", login.status === 200, `status=${login.status}`);
  }
  const me = await json<{ user: { id: string } | null }>(await req("GET", "/api/v1/auth/me"));
  ok("authenticated session", !!me?.user?.id);

  // Clean slate: remove providers from previous runs (best effort).
  const pre = await json<{ custom: Array<{ id: string; name: string }> }>(
    await req("GET", "/api/v1/providers/custom"),
  );
  for (const c of pre?.custom ?? []) {
    await req("DELETE", `/api/v1/providers/custom/${c.id}`);
  }
  const provider = await json<{ provider: { id: string } }>(
    await req("POST", "/api/v1/providers/custom", {
      name: "Context Test AI",
      apiKey: "sk-context-KEY777",
      baseUrl: `${RECEIVER}/v1`,
      model: "test-model-a",
      capabilities: ["TEXT"],
      priority: 1,
    }),
  );
  ok("custom provider added (points at receiver)", !!provider?.provider?.id);

  // Clean slate: sweep artifacts from interrupted previous runs of this same
  // suite (recognizable markers only — never touches real user data):
  //   - memories carrying the run marker or the test secret value
  //   - conversations titled by this suite's scripted first message
  const staleMemories = (await listMemories()).filter(
    (m) => m.content.includes("ctxtest-") || m.content.includes("sk-test-123"),
  );
  for (const m of staleMemories) {
    await req("DELETE", `/api/v1/memory/${m.id}`);
  }
  const staleConvos = await json<{ conversations: Array<{ id: string; title: string }> }>(
    await req("GET", "/api/v1/conversations"),
  );
  for (const c of staleConvos?.conversations ?? []) {
    if (c.title.startsWith("remember that my Alpha project uses Clou")) {
      await req("DELETE", `/api/v1/conversations/${c.id}`);
    }
  }
  ok("previous-run artifacts swept", true, `memories=${staleMemories.length}`);

  // ------------------------------------------------------------
  console.log("\n— Part 2b: header contract + semantic memory (explicit intent)");
  // ------------------------------------------------------------
  const runToken = `ctxtest-${Date.now()}`;
  const first = await chat(`remember that my Alpha project uses Cloudflare D1 (${runToken})`);
  const convId = first.res.headers.get("x-conversation-id");
  ok("chat reply 200 + real 'ok' answer", first.res.status === 200 && first.text.includes("ok"), `status=${first.res.status} text=${first.text.slice(0, 20)}`);
  ok("conversation id header present", !!convId);
  ok("X-Alpha-Context header matches exact contract format",
    !!first.rawHeader && CONTEXT_HEADER_RE.test(first.rawHeader),
    `header=${first.rawHeader}`);
  ok("routed through the custom receiver provider",
    first.res.headers.get("x-ai-provider") === "Context Test AI",
    `provider=${first.res.headers.get("x-ai-provider")}`);

  // The auto-memory runs post-response via after() — poll for it.
  let stored: MemoryItem | null = null;
  for (let i = 0; i < 16 && !stored; i++) {
    await sleep(300);
    stored = (await listMemories()).find(
      (m) => m.source === "chat-auto" && m.content.includes(runToken),
    ) ?? null;
  }
  ok("explicit 'remember' → chat-auto memory created",
    !!stored && stored.content.includes("Cloudflare D1"),
    stored ? `content=${stored.content.slice(0, 60)}` : "no memory after 5s");
  ok("auto memory category is 'fact'", stored?.category === "fact", `category=${stored?.category}`);

  // ------------------------------------------------------------
  console.log("\n— Part 2c: semantic discipline (no intent → no memory)");
  // ------------------------------------------------------------
  const countA = (await listMemories()).length;
  const noIntent = await chat("hello there friend", convId!);
  ok("plain greeting answered", noIntent.res.status === 200);
  await sleep(1200); // allow any pending after() work to land
  const countB = (await listMemories()).length;
  ok("no remember intent → memory count unchanged", countB === countA, `${countA} → ${countB}`);

  // ------------------------------------------------------------
  console.log("\n— Part 2d: sensitive filter (never store secrets)");
  // ------------------------------------------------------------
  const secret = await chat("remember my api key = sk-test-123", convId!);
  ok("secret-looking message still answered normally", secret.res.status === 200);
  await sleep(1200);
  const countC = (await listMemories()).length;
  ok("secret message → memory count unchanged", countC === countB, `${countB} → ${countC}`);
  ok("no memory contains the secret value",
    !(await listMemories()).some((m) => m.content.includes("sk-test-123")));

  // ------------------------------------------------------------
  console.log("\n— Part 2e: rolling summary (SUMMARIZE_THRESHOLD+ fillers)");
  // ------------------------------------------------------------
  const FILLERS = 30;
  const EXTRAS = 6;
  for (let n = 1; n <= FILLERS; n++) {
    const r = await chat(`filler message number ${n} about topicX for context testing`, convId!);
    if (r.res.status !== 200) {
      ok(`filler ${n} answered`, false, `status=${r.res.status}`);
      return;
    }
  }
  ok(`all ${FILLERS} filler messages answered (200)`, true);

  // The summarizer runs post-response via after() — poll for the summary.
  interface ConvDetail {
    conversation: { id: string; title: string };
    messages: Array<{ id: string; role: string }>;
    summary: { text: string; coveredMessages: number; version: number; updatedAt: string } | null;
  }
  let detail: ConvDetail | null = null;
  for (let i = 0; i < 12; i++) {
    detail = await json<ConvDetail>(await req("GET", `/api/v1/conversations/${convId}`));
    if (detail?.summary) break;
    await sleep(400);
  }
  ok("rolling summary created (post-response, ≤5s)", !!detail?.summary,
    detail?.summary ? `covered=${detail.summary.coveredMessages}` : "summary still null");
  ok("summary coveredMessages >= SUMMARIZE_THRESHOLD (24)",
    (detail?.summary?.coveredMessages ?? 0) >= CONTEXT_BUDGET.SUMMARIZE_THRESHOLD,
    `covered=${detail?.summary?.coveredMessages}`);
  ok("summary text is the REAL receiver payload (whole-stack proof)",
    !!detail?.summary?.text.startsWith("SUMMARY-BY-RECEIVER"),
    `text=${detail?.summary?.text?.slice(0, 50)}`);
  ok("summary version is a positive integer", (detail?.summary?.version ?? 0) >= 1);
  const expectedAfterFillers = (3 + FILLERS) * 2; // 3 exchanges + fillers, user+assistant each
  ok("ALL raw messages still present (never deleted)",
    detail?.messages.length === expectedAfterFillers,
    `messages=${detail?.messages.length} expected=${expectedAfterFillers}`);

  // ------------------------------------------------------------
  console.log("\n— Part 2f: relevant history (lexical Layer 3) + recent budget");
  // ------------------------------------------------------------
  // A few more distinct fillers open a deterministic gap between summary
  // coverage and the verbatim recent window.
  for (let n = FILLERS + 1; n <= FILLERS + EXTRAS; n++) {
    await chat(`filler message number ${n} about topicX for context testing`, convId!);
  }
  const question = await chat("what do you know about topicX?", convId!);
  ok("topicX question answered", question.res.status === 200);
  ok("X-Alpha-Context: relevant >= 1 (old topicX messages matched)",
    (question.stats?.relevant ?? 0) >= 1,
    `header=${question.rawHeader}`);
  ok("X-Alpha-Context: summary flag = 1 after summarization",
    question.stats?.summary === 1,
    `header=${question.rawHeader}`);
  const detail2 = await json<ConvDetail>(await req("GET", `/api/v1/conversations/${convId}`));
  const expectedAfterQuestion = (3 + FILLERS + EXTRAS) * 2 + 2;
  ok("raw messages still intact after the topicX question",
    detail2?.messages.length === expectedAfterQuestion,
    `messages=${detail2?.messages.length} expected=${expectedAfterQuestion}`);

  // ------------------------------------------------------------
  console.log("\n— Part 2g: recent-window budget (Layer 1 <= 16 everywhere)");
  // ------------------------------------------------------------
  ok("recent <= RECENT_MESSAGES_LIMIT on EVERY response this run",
    recentBudgetAlwaysOk,
    recentBudgetAlwaysOk ? "" : "some response exceeded the budget or had no header");
  const lastCheck = await chat("budget check final message", convId!);
  ok("final message context header valid + recent <= 16",
    !!lastCheck.rawHeader && CONTEXT_HEADER_RE.test(lastCheck.rawHeader) && (lastCheck.stats?.recent ?? 99) <= 16,
    `header=${lastCheck.rawHeader}`);

  // ------------------------------------------------------------
  console.log("\n— Part 2h: deterministic title derivation (Task 1 behavior)");
  // ------------------------------------------------------------
  const greeting = await chat("hi");
  const conv2 = greeting.res.headers.get("x-conversation-id");
  ok("greeting-first conversation created", greeting.res.status === 200 && !!conv2);
  const list1 = await json<{ conversations: Array<{ id: string; title: string }> }>(
    await req("GET", "/api/v1/conversations"),
  );
  const freshTitle = list1?.conversations.find((c) => c.id === conv2)?.title ?? "";
  ok("greeting-only first message keeps the placeholder title",
    freshTitle === "New conversation", `title='${freshTitle}'`);
  const meaningful = "What is the best pizza in Rome?";
  const titled = await chat(meaningful, conv2!);
  ok("meaningful follow-up answered", titled.res.status === 200);
  const list2 = await json<{ conversations: Array<{ id: string; title: string }> }>(
    await req("GET", "/api/v1/conversations"),
  );
  const finalTitle = list2?.conversations.find((c) => c.id === conv2)?.title ?? "";
  ok("conversation re-titled by the first meaningful message (not 'hi')",
    finalTitle === deriveTitle(meaningful) && finalTitle !== "New conversation",
    `title='${finalTitle}' expected='${deriveTitle(meaningful)}'`);

  // ------------------------------------------------------------
  console.log("\n— Part 2i: cleanup (leave a clean database)");
  // ------------------------------------------------------------
  const del1 = await req("DELETE", `/api/v1/conversations/${convId}`);
  const del2 = await req("DELETE", `/api/v1/conversations/${conv2}`);
  ok("test conversations deleted", del1.status === 200 && del2.status === 200, `${del1.status}/${del2.status}`);
  if (stored) {
    const delMem = await req("DELETE", `/api/v1/memory/${stored.id}`);
    ok("auto-created test memory deleted", delMem.status === 200, `status=${delMem.status}`);
  }
  const delProvider = await req("DELETE", `/api/v1/providers/custom/${provider?.provider?.id}`);
  ok("test provider deleted", delProvider.status === 200, `status=${delProvider.status}`);
  ok("deleted conversation really gone (summary cascade cleaned up)",
    (await req("GET", `/api/v1/conversations/${convId}`)).status === 404);
}

async function main(): Promise<void> {
  console.log("[test-context-engine] layered context / memory system verification");
  unitTests();
  try {
    await e2eTests();
  } catch (e) {
    ok("E2E suite ran without a fatal error", false, e instanceof Error ? e.message : String(e));
  }

  console.log("\n————————————————————————————————————");
  console.log(`RESULT: ${passed} passed, ${failed} failed`);
  if (failed > 0) {
    console.log("Failures:");
    for (const f of failures) console.log(`  ✗ ${f}`);
    process.exit(1);
  }
  console.log("ALL GREEN — verified against REAL endpoints (no mocks).");
}

main().catch((e) => {
  console.error("[test-context-engine] fatal:", e);
  process.exit(1);
});
