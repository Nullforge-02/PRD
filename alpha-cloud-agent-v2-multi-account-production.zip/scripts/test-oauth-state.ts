// ALPHA — TEST-ONLY regression suite for the OAuth state CSRF guard.
//
//   bun run scripts/test-oauth-state.ts
//
// No server needed — these are unit tests of the pure state functions
// (generateState / stateCookieHeader / verifyState) using real NextRequest
// objects. They encode the regression for the double-prefix bug:
//
//   ROOT CAUSE (fixed): the callback `state` param is ALREADY the full
//   `${provider}:${hex}` value stored in the cookie, but verifyState() used
//   to construct `${provider}:${stateParam}` = `google:google:<hex>` and
//   compare that against the cookie — which NEVER matched, so every real
//   Google/GitHub callback failed with "Security check failed (invalid state)".
//
// These tests prove:
//   • valid Google state succeeds          (the broken case before the fix)
//   • valid GitHub state succeeds          (the broken case before the fix)
//   • wrong provider fails
//   • modified state fails
//   • missing cookie fails
//   • empty / unprefixed / duplicated-prefix params fail
//   • cross-provider replay fails
//   • the cookie set by stateCookieHeader round-trips exactly

import { NextRequest } from "next/server";
import {
  OAUTH_STATE_COOKIE,
  generateState,
  stateCookieHeader,
  verifyState,
} from "../src/server/integrations/oauth-state";

let passed = 0;
let failed = 0;
const failures: string[] = [];

function ok(name: string, cond: boolean, detail = ""): void {
  if (cond) {
    passed++;
    console.log(`  ✓ ${name}`);
  } else {
    failed++;
    failures.push(`${name}${detail ? ` — ${detail}` : ""}`);
    console.log(`  ✗ ${name}${detail ? ` — ${detail}` : ""}`);
  }
}

/** A NextRequest whose cookies contain the given state cookie value. */
function requestWithStateCookie(cookieValue: string | null, url = "https://alpha02.org/api/v1/integrations/google/callback"): NextRequest {
  const headers = new Headers();
  if (cookieValue !== null) {
    // Minimal valid Cookie header (state values are [a-z0-9:]).
    headers.set("cookie", `${OAUTH_STATE_COOKIE}=${cookieValue}`);
  }
  return new NextRequest(url, { headers });
}

function hex64(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  let hex = "";
  for (const b of bytes) hex += b.toString(16).padStart(2, "0");
  return hex;
}

console.log("\nOAuth state — format invariants");
{
  const googleState = generateState("google");
  const githubState = generateState("github");
  ok("google state is `google:` + 64 hex", /^google:[0-9a-f]{64}$/.test(googleState));
  ok("github state is `github:` + 64 hex", /^github:[0-9a-f]{64}$/.test(githubState));
  ok("states are random (two draws differ)", generateState("google") !== googleState);

  const header = stateCookieHeader("google", googleState, requestWithStateCookie(null));
  ok("state cookie header stores the FULL prefixed value", header.startsWith(`${OAUTH_STATE_COOKIE}=${googleState};`));
  ok("state cookie is HttpOnly", header.includes("HttpOnly"));
  ok("state cookie is SameSite=Lax", header.includes("SameSite=Lax"));
  ok("state cookie is scoped to Path=/", header.includes("Path=/"));
  ok("state cookie is Secure on https", header.includes("Secure"));
}

console.log("\nOAuth state — valid states succeed (regression: double-prefix bug)");
{
  // BEFORE the fix, these two cases FAILED — verifyState built
  // `google:google:<hex>` and compared it to the cookie `google:<hex>`.
  const googleState = `google:${hex64()}`;
  ok(
    "valid Google state succeeds",
    verifyState(requestWithStateCookie(googleState), "google", googleState),
  );

  const githubState = `github:${hex64()}`;
  ok(
    "valid GitHub state succeeds (github callback URL)",
    verifyState(
      requestWithStateCookie(githubState, "https://alpha02.org/api/v1/integrations/github/callback"),
      "github",
      githubState,
    ),
  );
}

console.log("\nOAuth state — invalid states rejected (no CSRF weakening)");
{
  const googleState = `google:${hex64()}`;

  ok(
    "wrong provider: github state does not verify as google",
    !verifyState(requestWithStateCookie(googleState), "google", `github:${googleState.slice("github:".length)}`),
  );
  ok(
    "cross-provider replay: google cookie + github param fails",
    !verifyState(requestWithStateCookie(googleState), "github", googleState),
  );

  const flipped = googleState.slice(0, -2) + (googleState.endsWith("00") ? "11" : "00");
  ok(
    "modified state value fails",
    !verifyState(requestWithStateCookie(googleState), "google", flipped),
  );

  ok(
    "missing state cookie fails",
    !verifyState(requestWithStateCookie(null), "google", googleState),
  );

  ok(
    "empty state param fails",
    !verifyState(requestWithStateCookie(googleState), "google", ""),
  );

  ok(
    "unprefixed state param (bare hex) fails",
    !verifyState(requestWithStateCookie(googleState), "google", googleState.slice("google:".length)),
  );

  // A param that carries a DOUBLED prefix must never verify: the cookie holds
  // `google:<hex>`, so `google:google:<hex>` cannot equal it — and if a future
  // regression reintroduces the prefix construction it will be caught by the
  // "valid state succeeds" cases above, not by silently accepting this input.
  ok(
    "doubled provider prefix never verifies",
    !verifyState(requestWithStateCookie(googleState), "google", `google:${googleState}`),
  );

  ok(
    "truncated state fails",
    !verifyState(requestWithStateCookie(googleState), "google", googleState.slice(0, 40)),
  );

  ok(
    "state with wrong provider prefix but right length fails",
    !verifyState(
      requestWithStateCookie(githubStateLength(googleState)),
      "google",
      googleState.replace(/^google:/, "github:"),
    ),
  );
}

console.log("\nOAuth state — full round trip (connect → provider echo → verify)");
{
  for (const provider of ["google", "github"] as const) {
    // 1. connect route generates the state and sets the cookie…
    const state = generateState(provider);
    const header = stateCookieHeader(provider, state, requestWithStateCookie(null));
    const cookieValue = header.split(";")[0].slice(`${OAUTH_STATE_COOKIE}=`.length);
    // 2. the provider echoes the SAME full string back as ?state=…
    // 3. the callback verifies it — must succeed.
    ok(
      `${provider} connect → cookie → callback round trip succeeds`,
      verifyState(requestWithStateCookie(cookieValue), provider, state),
    );
  }
}

console.log(
  `\n${failed === 0 ? "ALL GREEN" : "FAILURES PRESENT"} — ${passed} passed, ${failed} failed\n`,
);
if (failures.length > 0) {
  for (const f of failures) console.error(`  ✗ ${f}`);
  process.exit(1);
}

// Helper used above: build a plausible same-length github-prefixed cookie.
function githubStateLength(reference: string): string {
  const hex = hex64();
  return `github:${hex}`.padEnd(reference.length, "0").slice(0, reference.length);
}
