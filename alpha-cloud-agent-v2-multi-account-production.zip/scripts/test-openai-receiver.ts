// ALPHA — TEST-ONLY local OpenAI-protocol receiver (credential plumbing).
//
//   bun run scripts/test-openai-receiver.ts        (listens on 127.0.0.1:3111)
//
// This is a VERIFICATION HARNESS, not application code: OpenAI has no valid
// credential in this environment, so provider-key plumbing (encryption →
// D1 → decryption → adapter → Authorization header) is verified against this
// local endpoint instead. It speaks the minimal OpenAI chat-completions
// protocol:
//
//   POST /v1/chat/completions
//     - Authorization containing "FAIL" → 401 {"error":{"message":...}}
//     - any other Authorization          → 200 {"choices":[{"message":{"content":"ok"}}]}
//   GET  /__last-auth   → {"authorization": "<last Authorization header>"} (for assertions)
//   POST /__reset       → clears the recorded header
//
// It records the LAST Authorization header it received so tests can assert
// exactly which key the server sent. It is never referenced by the app.
//
// Extended for the generic-provider patch:
//   GET  /v1/models         → {"data":[{"id":"test-model-a"},…]} (real list)
//   POST /v1/images/generations → 1x1 PNG b64_json (image-generation path)
//
// Extended for the context-system patch (Task 2-a):
//   POST /v1/chat/completions inspects the request body — when any message
//   content includes "conversation summarizer" (the rolling-summarizer system
//   prompt marker), it answers with a recognizable summary payload instead of
//   "ok", proving the REAL summarizer request flowed through the whole stack.
//   Normal chat messages keep getting "ok".

const PORT = 3111;

let lastAuth: string | null = null;

const server = Bun.serve({
  port: PORT,
  hostname: "127.0.0.1",
  async fetch(req) {
    const url = new URL(req.url);

    if (req.method === "GET" && url.pathname === "/__last-auth") {
      return new Response(JSON.stringify({ authorization: lastAuth }), {
        headers: { "Content-Type": "application/json" },
      });
    }
    if (req.method === "POST" && url.pathname === "/__reset") {
      lastAuth = null;
      return new Response("{}", { headers: { "Content-Type": "application/json" } });
    }

    if (req.method === "GET" && url.pathname === "/v1/models") {
      lastAuth = req.headers.get("authorization") ?? "";
      if (lastAuth.includes("FAIL")) {
        return new Response(
          JSON.stringify({ error: { message: "Invalid API key (test receiver)" } }),
          { status: 401, headers: { "Content-Type": "application/json" } },
        );
      }
      return new Response(
        JSON.stringify({
          data: [
            { id: "test-model-a" },
            { id: "test-model-b" },
            { id: "test-model-vision" },
          ],
        }),
        { status: 200, headers: { "Content-Type": "application/json" } },
      );
    }

    if (req.method === "POST" && url.pathname === "/v1/chat/completions") {
      lastAuth = req.headers.get("authorization") ?? "";
      if (lastAuth.includes("FAIL")) {
        return new Response(
          JSON.stringify({ error: { message: "Invalid API key (test receiver)" } }),
          { status: 401, headers: { "Content-Type": "application/json" } },
        );
      }
      // Context-system detection: the rolling summarizer's system prompt
      // contains the marker phrase — answer with a summary-shaped payload.
      const body = (await req.json().catch(() => null)) as
        | { messages?: Array<{ content?: unknown }> }
        | null;
      const serialized = JSON.stringify(body?.messages ?? []);
      const isSummarizer = serialized.includes("conversation summarizer");
      return new Response(
        JSON.stringify({
          choices: [
            {
              message: {
                content: isSummarizer
                  ? "SUMMARY-BY-RECEIVER: merged rolling summary"
                  : "ok",
              },
            },
          ],
        }),
        { status: 200, headers: { "Content-Type": "application/json" } },
      );
    }

    if (req.method === "POST" && url.pathname === "/v1/images/generations") {
      lastAuth = req.headers.get("authorization") ?? "";
      // 1x1 transparent PNG
      const png =
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==";
      return new Response(
        JSON.stringify({ data: [{ b64_json: png }] }),
        { status: 200, headers: { "Content-Type": "application/json" } },
      );
    }

    return new Response("not found", { status: 404 });
  },
});

console.log(`[test-openai-receiver] listening on http://127.0.0.1:${PORT} (TEST HARNESS ONLY)`);
console.log(`[test-openai-receiver] pid=${server.pid}`);

// Keep running until killed.
process.on("SIGTERM", () => process.exit(0));
