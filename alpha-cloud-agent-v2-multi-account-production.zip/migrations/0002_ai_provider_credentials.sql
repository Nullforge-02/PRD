-- ALPHA — Migration 0002: AI provider credentials (dashboard-managed)
--
-- Stores the OWNER's per-provider AI API credentials, managed from the Alpha
-- dashboard (Settings → AI Providers). Keys are NEVER stored in plaintext:
--   encrypted_api_key = "v1.<iv-b64url>.<ciphertext-b64url>"
-- encrypted with AES-256-GCM (Web Crypto, Cloudflare Workers compatible),
-- key derived from the AI_CREDENTIALS_SECRET Worker secret via HKDF-SHA256,
-- unique random 12-byte IV per credential. A fresh install has NO rows —
-- credentials are added by the owner through the dashboard (no seed data).
--
-- Safe to apply to an existing deployed D1 database: this migration only
-- CREATEs a new table; it does not touch any existing table or data.
--
-- Local:  npx wrangler d1 migrations apply alpha-db --local
-- Remote: npx wrangler d1 migrations apply alpha-db --remote

PRAGMA foreign_keys = ON;

CREATE TABLE ai_provider_credentials (
  id                 TEXT PRIMARY KEY,
  user_id            TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider           TEXT NOT NULL,                -- zai | openai | groq | openrouter
  encrypted_api_key  TEXT NOT NULL,                -- v1.<iv>.<ct> (AES-256-GCM)
  key_hint           TEXT NOT NULL DEFAULT '',     -- last 4 chars, masked display only
  base_url           TEXT,                         -- optional custom endpoint
  model              TEXT,                         -- optional chat model override
  vision_model       TEXT,                         -- optional vision model override
  enabled            INTEGER NOT NULL DEFAULT 1,   -- routing include/exclude switch
  created_at         TEXT NOT NULL,
  updated_at         TEXT NOT NULL,
  last_tested_at     TEXT,                         -- last Test Connection time
  last_test_status   TEXT,                         -- 'success' | 'failed' | NULL
  UNIQUE (user_id, provider)
);
