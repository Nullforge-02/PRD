-- ALPHA — Migration 0001: Initial Schema
-- Cloudflare D1 (SQLite). All timestamps are UTC ISO-8601 strings except
-- calendar/reminder instants, which are epoch-milliseconds integers.
--
-- Local:  npx wrangler d1 migrations apply alpha-db --local
-- Remote: npx wrangler d1 migrations apply alpha-db --remote
--
-- This migration contains ONLY schema. A brand-new installation starts with
-- NO users, NO conversations, NO notes, NO memories, NO files, NO reminders,
-- NO calendar events and NO audit entries. The first user account is created
-- through the first-run setup screen. No seed data exists by design.

PRAGMA foreign_keys = ON;

-- ============================================================
-- Users (single-user personal app, but schema is general)
-- ============================================================
CREATE TABLE users (
  id            TEXT PRIMARY KEY,
  email         TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  password_hash TEXT NOT NULL,            -- pbkdf2$<iter>$<salt>$<hash>
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);

-- ============================================================
-- Sessions (server-side, revocable)
-- ============================================================
CREATE TABLE sessions (
  id           TEXT PRIMARY KEY,
  user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash   TEXT NOT NULL UNIQUE,      -- sha256(hmac(auth_secret, token))
  user_agent   TEXT,
  ip           TEXT,
  created_at   TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  expires_at   TEXT NOT NULL,
  revoked_at   TEXT,                      -- set on logout/revoke
  locked_at    TEXT                       -- set while session is soft-locked
);
CREATE INDEX idx_sessions_user ON sessions(user_id);

-- ============================================================
-- Conversations & Messages
-- ============================================================
CREATE TABLE conversations (
  id         TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title      TEXT NOT NULL DEFAULT 'New conversation',
  pinned     INTEGER NOT NULL DEFAULT 0,
  archived   INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_conversations_user_updated ON conversations(user_id, updated_at);

CREATE TABLE messages (
  id              TEXT PRIMARY KEY,
  conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  role            TEXT NOT NULL CHECK (role IN ('user','assistant','tool')),
  content         TEXT NOT NULL,
  model           TEXT,
  created_at      TEXT NOT NULL
);
CREATE INDEX idx_messages_conversation_created ON messages(conversation_id, created_at);

-- ============================================================
-- Memory (persistent AI memory — starts empty)
-- ============================================================
CREATE TABLE memories (
  id         TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category   TEXT NOT NULL,
  content    TEXT NOT NULL,
  source     TEXT NOT NULL DEFAULT 'manual',
  confidence REAL NOT NULL DEFAULT 1.0,
  pinned     INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_memories_user_category ON memories(user_id, category);
CREATE INDEX idx_memories_user_updated ON memories(user_id, updated_at);

-- ============================================================
-- Notes
-- ============================================================
CREATE TABLE notes (
  id         TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title      TEXT NOT NULL,
  content    TEXT NOT NULL DEFAULT '',
  pinned     INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_notes_user_updated ON notes(user_id, updated_at);

-- ============================================================
-- Files (metadata in D1, bytes in R2)
-- ============================================================
CREATE TABLE files (
  id         TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  filename   TEXT NOT NULL,
  mime_type  TEXT NOT NULL,
  size       INTEGER NOT NULL,
  r2_key     TEXT NOT NULL UNIQUE,
  source     TEXT NOT NULL DEFAULT 'upload' CHECK (source IN ('upload','generated')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_files_user_created ON files(user_id, created_at);
CREATE INDEX idx_files_user_source ON files(user_id, source);

-- ============================================================
-- Reminders
-- ============================================================
CREATE TABLE reminders (
  id         TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title      TEXT NOT NULL,
  note       TEXT,
  due_at     INTEGER,
  priority   TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('low','normal','high')),
  done       INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_reminders_user_done_due ON reminders(user_id, done, due_at);

-- ============================================================
-- Calendar events
-- ============================================================
CREATE TABLE calendar_events (
  id         TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title      TEXT NOT NULL,
  location   TEXT,
  start_at   INTEGER NOT NULL,
  end_at     INTEGER,
  attendees  TEXT,                        -- JSON array of strings
  source     TEXT NOT NULL DEFAULT 'manual',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_calendar_user_start ON calendar_events(user_id, start_at);

-- ============================================================
-- Settings (per-user key/value preferences)
-- ============================================================
CREATE TABLE settings (
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key        TEXT NOT NULL,
  value      TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (user_id, key)
);

-- ============================================================
-- Audit log (real security-relevant events only)
-- ============================================================
CREATE TABLE audit_logs (
  id         TEXT PRIMARY KEY,
  user_id    TEXT REFERENCES users(id) ON DELETE SET NULL,
  action     TEXT NOT NULL,
  category   TEXT NOT NULL,
  details    TEXT,                        -- JSON string
  ip         TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_audit_user_created ON audit_logs(user_id, created_at);
CREATE INDEX idx_audit_category_created ON audit_logs(category, created_at);

-- ============================================================
-- Jobs (tracks long-running operations, e.g. image generation)
-- ============================================================
CREATE TABLE jobs (
  id         TEXT PRIMARY KEY,
  user_id    TEXT,
  kind       TEXT NOT NULL,
  status     TEXT NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','running','done','failed')),
  payload    TEXT,                        -- JSON string
  result     TEXT,                        -- JSON string
  error      TEXT,
  created_at TEXT NOT NULL,
  started_at TEXT,
  finished_at TEXT
);
CREATE INDEX idx_jobs_status_created ON jobs(status, created_at);
CREATE INDEX idx_jobs_user_created ON jobs(user_id, created_at);
