-- ALPHA — Migration 0003: generic AI providers + connected accounts (OAuth)
--
-- Part 1: ai_custom_providers
--   Unlimited USER-CONFIGURED AI providers (Settings → AI Providers → + Add API).
--   Any OpenAI-compatible endpoint works: OpenRouter, Gemini-compatible proxies,
--   DeepSeek, Mistral, Together, local/self-hosted servers, anything that speaks
--   the chat-completions protocol. The four BUILT-IN providers (zai / openai /
--   groq / openrouter, incl. their existing dashboard credentials in
--   ai_provider_credentials) are NOT touched — custom providers are merged into
--   the SAME router by capability + priority.
--
--   API keys are NEVER stored in plaintext:
--     encrypted_api_key = "v1.<iv-b64url>.<ciphertext-b64url>"
--   encrypted with AES-256-GCM (Web Crypto, Workers-safe), key derived from the
--   AI_CREDENTIALS_SECRET Worker secret via HKDF-SHA256, unique random 12-byte
--   IV per credential. key_hint = last 4 chars, masked display only.
--
--   capabilities = comma-separated user-selected set (manual selection is
--   authoritative — the system never invents capabilities):
--     TEXT, VISION, IMAGE_GENERATION, VIDEO, REASONING, FAST
--
--   priority: lower = higher precedence. Custom providers with the same
--   priority as a built-in provider sort BEFORE it (explicit user choice wins
--   over environment defaults). Default priority = 1 (primary).
--
--   metadata: JSON extension point (e.g. future per-provider model lists —
--   the schema is designed so one provider row can later own multiple models).
--
-- Part 2: connected_accounts
--   Real OAuth connections (Google/Gmail, GitHub). Tokens are encrypted with
--   the SAME AES-256-GCM construction but a DEDICATED HKDF info label
--   ("alpha:oauth-token-encryption") — key separation from AI credentials.
--   Client secrets are NEVER stored here (they live in Worker secrets only).
--
-- Safe to apply to an existing deployed D1 database: this migration only
-- CREATEs new tables; it does not touch any existing table or data.
--
-- Local:  npx wrangler d1 migrations apply alpha-db --local
-- Remote: npx wrangler d1 migrations apply alpha-db --remote
--         (if 0001 was applied manually in production, it must be marked as
--          applied first — see DEPLOYMENT.md)

PRAGMA foreign_keys = ON;

CREATE TABLE ai_custom_providers (
  id                 TEXT PRIMARY KEY,
  user_id            TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name               TEXT NOT NULL,                 -- user-chosen display name
  protocol           TEXT NOT NULL DEFAULT 'openai-compatible',
  encrypted_api_key  TEXT NOT NULL,                 -- v1.<iv>.<ct> (AES-256-GCM)
  key_hint           TEXT NOT NULL DEFAULT '',      -- last 4 chars, masked display only
  base_url           TEXT NOT NULL,                 -- endpoint root (…/v1)
  model              TEXT NOT NULL,                 -- primary chat model id
  vision_model       TEXT,                          -- optional vision model id
  image_model        TEXT,                          -- optional image-generation model id
  video_model        TEXT,                          -- optional video model id
  capabilities       TEXT NOT NULL DEFAULT 'TEXT',  -- CSV of the 6 user capabilities
  enabled            INTEGER NOT NULL DEFAULT 1,    -- routing include/exclude switch
  priority           INTEGER NOT NULL DEFAULT 1,    -- lower = tried earlier
  metadata           TEXT,                          -- JSON extension point (no secrets)
  created_at         TEXT NOT NULL,
  updated_at         TEXT NOT NULL,
  last_tested_at     TEXT,
  last_test_status   TEXT,                          -- 'success' | 'failed' | NULL
  UNIQUE (user_id, name)
);

CREATE INDEX idx_ai_custom_providers_routing
  ON ai_custom_providers(user_id, enabled, priority);

CREATE TABLE connected_accounts (
  id                       TEXT PRIMARY KEY,
  user_id                  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider                 TEXT NOT NULL,            -- 'google' | 'github'
  provider_account_id      TEXT NOT NULL,            -- Google sub / GitHub user id
  account_name             TEXT,                     -- email / login
  avatar_url               TEXT,
  encrypted_access_token   TEXT NOT NULL,            -- AES-256-GCM (oauth info label)
  encrypted_refresh_token  TEXT,                     -- Google offline access (nullable)
  expires_at               TEXT,                     -- access-token expiry (ISO) or NULL
  scopes                   TEXT NOT NULL DEFAULT '', -- granted scope string
  metadata                 TEXT,                     -- JSON, non-secret only
  status                   TEXT NOT NULL DEFAULT 'connected', -- connected | needs_reauthorization
  created_at               TEXT NOT NULL,
  updated_at               TEXT NOT NULL,
  UNIQUE (user_id, provider, provider_account_id)
);

CREATE INDEX idx_connected_accounts_lookup
  ON connected_accounts(user_id, provider);
