-- ALPHA 0004 — rolling conversation summaries (context system). Additive only.
--
-- One summary row per conversation (UNIQUE conversation_id), maintained by
-- the post-response summarizer (src/server/context/summarizer.ts). It covers
-- messages [0 .. last_message_count-1]; everything after that is either in
-- the verbatim recent window or lexically retrievable as relevant history.
-- Raw messages are NEVER deleted — the summary is an additional index, not a
-- replacement.
--
-- Local:  npx wrangler d1 migrations apply alpha-db --local
-- Remote: npx wrangler d1 migrations apply alpha-db --remote

CREATE TABLE conversation_summaries (
  id                  TEXT PRIMARY KEY,
  conversation_id     TEXT NOT NULL UNIQUE REFERENCES conversations(id) ON DELETE CASCADE,
  user_id             TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  summary             TEXT NOT NULL,
  last_message_id     TEXT NOT NULL,
  last_message_count  INTEGER NOT NULL,
  version             INTEGER NOT NULL DEFAULT 1,
  created_at          TEXT NOT NULL,
  updated_at          TEXT NOT NULL
);
CREATE INDEX idx_conversation_summaries_user ON conversation_summaries(user_id);
