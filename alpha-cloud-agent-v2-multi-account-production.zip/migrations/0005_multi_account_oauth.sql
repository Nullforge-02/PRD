-- ALPHA 0005 — multi-account OAuth: account roles + explicit default accounts.
--
-- Additive only — no table is dropped, no column is removed, existing rows
-- keep working. Enables:
--   • MULTIPLE Google accounts per Alpha user (personal / work / project / …)
--   • MULTIPLE GitHub accounts per Alpha user (storage / scripts / …)
--   • an EXPLICIT per-provider default (the account "Use" selects) — replaces
--     the old single-account assumption (ORDER BY updated_at DESC LIMIT 1)
--   • GitHub account ROLES: 'storage' | 'scripts' | 'general' (user-editable)
--   • a last_used_at timestamp for transparency ("last used" in the UI)
--
-- Columns:
--   role          TEXT     NULL for Google accounts; for GitHub one of
--                          storage|scripts|general (NULL = unassigned → treated
--                          as 'general' by the resolver)
--   is_default    INTEGER  0/1 — at most one per (user_id, provider); the
--                          UNIQUE (user_id, provider, provider_account_id)
--                          constraint from 0003 is untouched (same external
--                          account reconnect still deduplicates)
--   last_used_at  TEXT     set by the account resolver whenever an operation
--                          actually uses the account
--
-- Backfill: exactly one existing account per (user_id, provider) — the
-- EARLIEST created (stable, deterministic; NOT "most recently updated") —
-- becomes the default so existing single-account installs keep using the
-- account they already had.
--
-- Local:  npx wrangler d1 migrations apply alpha-db --local
-- Remote: npx wrangler d1 migrations apply alpha-db --remote
--         (0001–0003 were applied manually in production before the
--          migrations table existed — see DEPLOYMENT.md §4 for the safe
--          procedure; this migration is purely additive and safe on a
--          production database that already has connected_accounts rows.)

-- 1) GitHub roles (NULL for Google rows)
ALTER TABLE connected_accounts ADD COLUMN role TEXT;

-- 2) explicit per-provider default account
ALTER TABLE connected_accounts ADD COLUMN is_default INTEGER NOT NULL DEFAULT 0;

-- 3) last-used transparency timestamp
ALTER TABLE connected_accounts ADD COLUMN last_used_at TEXT;

-- 4) Backfill: earliest-created account per (user_id, provider) becomes default.
UPDATE connected_accounts
SET is_default = 1
WHERE id = (
  SELECT c2.id
  FROM connected_accounts c2
  WHERE c2.user_id = connected_accounts.user_id
    AND c2.provider = connected_accounts.provider
  ORDER BY c2.created_at ASC, c2.id ASC
  LIMIT 1
);

-- 5) Faster default lookups (one row per user+provider at most).
CREATE INDEX idx_connected_accounts_default
  ON connected_accounts(user_id, provider, is_default);
